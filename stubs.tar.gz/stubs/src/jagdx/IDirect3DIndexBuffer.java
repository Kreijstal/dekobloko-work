package jagdx;

public class IDirect3DIndexBuffer {
    public int Lock(int offset, int size, int flags, GeometryBuffer buffer) { return 0; }
    public int Unlock() { return 0; }
    public int Release() { return 0; }
}
