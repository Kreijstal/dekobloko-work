/*
 * Decompiled with CFR 0.152.
 */
final class ha
extends w {
    private w Nb;
    static ud[] Pb = new ud[3];
    private w Ob;

    ha(long l, ck ck2, ck ck3, int n, w w2, String string) {
        this(l, null, w2, string);
        this.Ob.I = ck3;
        this.Ob.w_sb = ck2;
        this.Ob.W = n;
    }

    public static void f(int n) {
        if (n != 3) {
            return;
        }
        Pb = null;
    }

    static final void e(int n) {
        da.da_e = new tf();
        if (n != 0) {
            return;
        }
        de.W.c(da.da_e, (byte)62);
    }

    final int c(int n, int n2) {
        block0: {
            if (n2 == -4168) break block0;
            ha.f(-106);
        }
        return n + (this.Ob.a(true) - -this.Nb.a(true));
    }

    final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        this.a(n, 0, n3, n6, n4);
        this.d(n5, n2 ^ n2);
    }

    private final void d(int n, int n2) {
        this.Ob.a(this.Ob.a(true), n2, 0, this.N, 0);
        int n3 = this.Ob.w_mb - -n;
        this.Nb.a(this.w_mb + -n3, 0, 0, this.N, n3);
    }

    private ha(long l, w w2, w w3, String string) {
        super(l, null);
        this.Ob = new w(0L, w2);
        this.Nb = new w(0L, w3);
        this.Nb.Y = string;
        this.a(this.Ob, -16834);
        this.a(this.Nb, -16834);
        this.d(-126);
    }

    static final int a(int n, byte by) {
        int n2 = 0;
        if (0 != (7 & n)) {
            n2 = 8 - (n & 7);
        }
        if (by != -126) {
            ha.a(-69, (byte)62);
        }
        int n3 = n - -n2;
        return n3;
    }

    ha(long l, ha ha2, String string) {
        this(l, ha2.Ob, ha2.Nb, string);
    }
}
