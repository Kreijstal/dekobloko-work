/*
 * Decompiled with CFR 0.152.
 */
final class gf {
    static boolean gf_i;
    static ck gf_a;
    static gh gf_j;
    static qm gf_e;
    static cc gf_b;
    static pi[] gf_f;
    static w gf_g;
    static nm gf_c;
    static String gf_d;
    static String gf_h;

    static final boolean a(int n, String string, String string2) {
        if (n > -94) {
            gf.a(-99);
        }
        if (qf.a(string2, 0)) {
            return false;
        }
        if (mc.a(string2, (byte)-111)) {
            return false;
        }
        if (client.a(92, string2)) {
            return false;
        }
        if (~string.length() == -1) {
            return true;
        }
        if (nn.a(false, string, string2)) {
            return false;
        }
        if (ij.a(string2, string, (byte)-117)) {
            return false;
        }
        return !he.a(string, (byte)126, string2);
    }

    static final String a(int n, boolean bl, boolean bl2, boolean bl3) {
        if (n > -124) {
            return null;
        }
        int n2 = 0;
        if (bl3) {
            n2 += 4;
        }
        if (bl2) {
            n2 += 2;
        }
        if (bl) {
            ++n2;
        }
        return ki.ki_n[n2];
    }

    static final void a(String[] stringArray, boolean bl) {
        block2: {
            if (bl) {
                return;
            }
            if (da.da_e != null) {
                da.da_e.tf_db.a(32, stringArray);
            }
            if (null == sn.sn_k) break block2;
            sn.sn_k.W.a(32, stringArray);
        }
    }

    static final void a(byte by) {
        if (!v.v_d) {
            throw new IllegalStateException();
        }
        if (by != -126) {
            String[] stringArray = null;
            gf.a(stringArray, true);
        }
        qi.M = true;
        vk.a(false, 841566312);
        hc.hc_d = 0;
    }

    public static void a(int n) {
        gf_f = null;
        gf_h = null;
        gf_d = null;
        gf_g = null;
        gf_b = null;
        gf_j = null;
        if (n != 2) {
            gf.a(46, true, false, false);
        }
        gf_a = null;
        gf_c = null;
        gf_e = null;
    }

    static {
        gf_j = new gh(0);
        gf_e = new qm(4, 1, 1, 1);
        gf_d = "<%0> has declined the invitation.";
        gf_h = "Hide lobby chat";
    }
}
