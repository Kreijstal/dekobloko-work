/*
 * Decompiled with CFR 0.152.
 */
final class am {
    static String am_d = "We closed the connection because the game was left unattended for 20 minutes. Please feel free to reconnect immediately if you are there.";
    static ke am_a;
    static String am_b;
    static boolean am_c;

    static final kc a(int n, boolean bl, int n2, int n3, int n4) {
        kc kc2;
        boolean bl2 = client.A;
        if (bl) {
            am.a(9, false, 66, -99, 40);
        }
        kc kc3 = kc2 = (kc)dg.dg_e.c((byte)49);
        while (null != kc2) {
            if (n3 == kc2.kc_n) {
                return kc2;
            }
            kc3 = (kc)dg.dg_e.d(!bl);
        }
        kc3 = new kc();
        kc3.kc_n = n3;
        kc3.kc_o = n4;
        kc3.kc_v = n2;
        dg.dg_e.a(kc3, 2777);
        wb.a(kc3, n, 60);
        return kc3;
    }

    static final int b(int n) {
        block0: {
            if (n > 69) break block0;
            am.b(-17);
        }
        return wl.wl_o + (wh.wh_d << -19637598) + (qk.qk_i << -1631507260);
    }

    public static void a(int n) {
        if (n < 77) {
            return;
        }
        am_d = null;
        am_b = null;
        am_a = null;
    }

    static {
        am_b = "The following settings need to be changed:  ";
    }
}
