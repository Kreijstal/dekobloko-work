/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

final class ki
extends bh {
    static String[] ki_n = new String[]{null, "To store your progress, you<nbsp>must", "To store your score, you<nbsp>must", "To store your score and progress, you<nbsp>must", "To store your achievements, you<nbsp>must", "To store your achievements and progress, you<nbsp>must", "To store your achievements and score, you<nbsp>must", "To store your achievements, score and progress, you<nbsp>must"};
    static tb ki_t;
    int ki_s;
    int ki_p;
    int ki_q;
    static String ki_u;
    int ki_v;
    static nm ki_w;
    int ki_r;
    int ki_o;

    static final hl a(int n, boolean bl) {
        boolean bl2 = client.A;
        if (n != 0) {
            return null;
        }
        uf uf2 = de.V;
        int n2 = uf2.d((byte)-99);
        mf.R = 0x7F & n2;
        fm.fm_f = -1 != ~(n2 & 0x80);
        tg.tg_c = uf2.d((byte)-71);
        fc.fc_h = uf2.f((byte)-108);
        if (-3 == ~mf.R) {
            vl.vl_k = uf2.e(n + 3);
            ic.ic_a = uf2.h(n + 65280);
        } else {
            vl.vl_k = 0;
            ic.ic_a = 0;
        }
        boolean bl3 = 1 == uf2.d((byte)-32);
        ad.x = uf2.c((byte)-38);
        sa.B = bl3 ? uf2.c((byte)-38) : ad.x;
        if (~mf.R == -2 || ~mf.R == -5) {
            dh.dh_d = uf2.e(3);
            qm.qm_e = uf2.c((byte)-38);
        } else {
            qm.qm_e = null;
            dh.dh_d = 0;
        }
        if (bl) {
            int n3 = uf2.e(3);
            try {
                me me2 = wj.Qb.a(127, n3);
                ib.ib_pb = me2.f((byte)-61);
                fa.fa_q = !sa.B.equals(oa.oa_f) ? me2.F : null;
            }
            catch (Exception exception) {
                qb.a(exception, 16408, "CC1");
                ib.ib_pb = null;
                fa.fa_q = null;
            }
        } else {
            ib.ib_pb = li.a(80, 0, uf2);
            fa.fa_q = null;
        }
        return new hl(bl);
    }

    static final void me_a_applet(byte by, Applet applet) {
        try {
            URL uRL = new URL(applet.getCodeBase(), "toserverlist.ws");
            if (by != 96) {
                ki.c((byte)42);
            }
            applet.getAppletContext().showDocument(gn.a(uRL, by ^ 0xFFFFFF9F, applet), "_top");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static void c(byte by) {
        ki_t = null;
        ki_w = null;
        ki_u = null;
        if (by != 22) {
            Applet applet = null;
            ki.me_a_applet((byte)121, applet);
        }
        ki_n = null;
    }

    ki(int n, int n2, int n3, int n4, int n5, int n6) {
        this.ki_v = n;
        this.ki_o = n5;
        this.ki_q = n6;
        this.ki_s = n3;
        this.ki_p = n2;
        this.ki_r = n4;
    }

    static {
        ki_u = "Any special items you earn will be given to both you and the player who gets your shapes!";
        ki_t = new tb();
    }
}
