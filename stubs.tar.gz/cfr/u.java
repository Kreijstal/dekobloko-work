/*
 * Decompiled with CFR 0.152.
 */
final class u {
    static ka u_i;
    static ck u_h;
    static int u_b;
    static String u_g;
    static String u_a;
    static int u_e;
    static String u_d;
    static String u_c;
    static int u_f;

    public static void a(int n) {
        u_g = null;
        u_a = null;
        u_h = null;
        if (n != 23358) {
            u_e = 32;
        }
        u_d = null;
        u_i = null;
        u_c = null;
    }

    static final void a(byte by, String string, long l) {
        ed.ed_c = string;
        int n = -67 % ((73 - by) / 38);
        pk.pk_r = 2;
        cf.cf_c = kf.a(string, (byte)2);
        jg.jg_i = true;
        fm.fm_d = l;
    }

    static {
        u_e = -1;
        u_g = "Multiplayer Rankings";
        u_d = "Ask to join <%0>'s game";
        u_b = 1;
        u_c = "Breakfast";
        u_f = 0;
    }
}
