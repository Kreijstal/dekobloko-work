/*
 * Decompiled with CFR 0.152.
 */
final class ln {
    static int[] ln_d;
    static int[] ln_a;
    static ck ln_c;
    static String ln_b;
    static String ln_e;

    public final String toString() {
        throw new IllegalStateException();
    }

    ln() {
    }

    public static void a(byte by) {
        ln_b = null;
        ln_c = null;
        ln_e = null;
        ln_a = null;
        int n = 52 / ((by - 7) / 42);
        ln_d = null;
    }

    static {
        ln_b = "<%0> has lost connection.";
        ln_e = "Press F10 to open Quick Chat.";
    }
}
