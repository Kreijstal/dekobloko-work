/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.awt.Component;

final class rf {
    byte[] rf_c;
    int rf_m;
    int rf_j;
    int rf_n;
    int rf_b;
    int rf_l;
    static qm rf_k = new qm(14, 0, 4, 1);
    int rf_e;
    static String rf_p = "Unpacking sound effects";
    static String rf_h;
    static int rf_o;
    static String rf_i;
    static int rf_f;
    static int rf_g;
    static int rf_a;
    static int rf_d;

    static final dh[] a(int n, uf uf2) {
        boolean bl = client.A;
        int n2 = uf2.a(8, (byte)80);
        if (~n2 < -1) {
            return null;
        }
        if (n <= 121) {
            rf_i = null;
        }
        int n3 = uf2.a(12, (byte)77);
        dh[] dhArray = new dh[n3];
        int n4 = 0;
        while (~n4 > ~n3) {
            if (!wg.a(uf2, (byte)26)) {
                int n5 = uf2.a(ma.a(n4 + -1, (byte)49), (byte)118);
                dhArray[n4] = dhArray[n5];
            } else {
                dh dh2 = new dh();
                uf2.a(24, (byte)40);
                uf2.a(24, (byte)73);
                dh2.dh_a = uf2.a(24, (byte)42);
                uf2.a(9, (byte)98);
                uf2.a(12, (byte)77);
                uf2.a(12, (byte)86);
                uf2.a(12, (byte)108);
                dhArray[n4] = dh2;
            }
            ++n4;
        }
        return dhArray;
    }

    static final void a(int n, boolean bl2, float f, String string) {
        block1: {
            if (null == pk.pk_v) {
                pk.pk_v = new qn(ah.ah_c, ed.ed_d);
                ah.ah_c.a((byte)-107, (ce)pk.pk_v);
            }
            pk.pk_v.a(bl2, f, 0x404040, string);
            hk.b();
            cg.a(true, n + 106);
            if (n == 12) break block1;
            rf_k = null;
        }
    }

    public static void a(boolean bl2) {
        rf_i = null;
        rf_p = null;
        rf_h = null;
        if (bl2) {
            uf uf2 = null;
            rf.a(88, uf2);
        }
        rf_k = null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final void a(byte by) {
        if (by != 0) {
            return;
        }
        if (null != ik.ik_f) {
            wg wg2 = ik.ik_f;
            synchronized (wg2) {
                ik.ik_f = null;
            }
        }
    }

    static final void a(int n2, Component component) {
        if (n2 != 12) {
            String string = null;
            rf.a(29, true, 0.55553657f, string);
        }
        component.removeKeyListener(f.f_r);
        component.removeFocusListener(f.f_r);
        wi.wi_b = -1;
    }

    static final int a(int n2, int n3) {
        int n4 = 0;
        if (n3 == n2) {
            n4 = qk.qk_i;
        }
        if (n3 == 1) {
            n4 = wh.wh_d;
        }
        if (-3 == ~n3) {
            n4 = wl.wl_o;
        }
        return n4;
    }

    static final void a(String[] stringArray, int n2, int n3, int n4, int n5, Applet applet) {
        boolean bl2 = client.A;
        wf.wf_n = applet.getParameter("overxgames");
        if (wf.wf_n == null) {
            wf.wf_n = "0";
        }
        jm.jm_u = applet.getParameter("overxachievements");
        if (n4 > -22) {
            rf_i = null;
        }
        if (jm.jm_u == null) {
            jm.jm_u = "0";
        }
        String string = applet.getParameter("currency");
        rb.rb_m = null != string && be.a((byte)98, string) ? cb.a((byte)-33, string) : 2;
        w.Fb = n3;
        o.o_d = n5;
        qn.qn_lb = n2;
        vi.z = new ck[stringArray.length];
        int n6 = 0;
        while (~n6 > ~stringArray.length) {
            vi.z[n6] = new ck(317, 34);
            ++n6;
        }
        dl.K = stringArray;
    }

    rf(int n2) {
        this.rf_j = n2;
    }

    static {
        rf_i = "When you match pieces, the machine transforms them into solid shapes.";
        rf_h = "Show game chat from my friends";
        rf_a = 2;
        rf_f = 0;
    }
}
