/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;

final class qf
extends ba
implements qh,
tn {
    static String qf_l = "Show chat (<%0> unread messages)";
    static ck[] qf_h;
    static String qf_j;
    static String qf_k;
    static String qf_m;
    vb qf_g;
    static int[] qf_i;

    @Override
    final tb b(int n) {
        try {
            int n2 = this.qf_g.i(-22079);
            int n3 = this.qf_g.b(false);
            int n4 = this.qf_g.f((byte)48);
            int n5 = jj.a(-110);
            if (~n4 > -1891) {
                return vm.vm_u;
            }
            if (~n4 < ~(n5 - 3)) {
                return vm.vm_u;
            }
            if (n != -5520) {
                return null;
            }
            if (!un.a(n4, n3, n2, (byte)52)) {
                return vm.vm_u;
            }
        }
        catch (NumberFormatException numberFormatException) {
            return vm.vm_u;
        }
        return dc.dc_b;
    }

    @Override
    final String e(byte by) {
        try {
            if (by <= 2) {
                ji ji2 = null;
                qf.a((ji)null, ji2, -5);
            }
            int n = this.qf_g.i(-22079);
            int n2 = this.qf_g.b(false);
            int n3 = this.qf_g.f((byte)48);
            int n4 = jj.a(-125);
            if (n3 < 1890 || ~n3 < ~(n4 - 3)) {
                return cm.a((byte)99, ad.ad_b, new String[]{"1890", Integer.toString(n4 - 3)});
            }
            if (un.a(n3, n2, n, (byte)52)) {
                return null;
            }
        }
        catch (NumberFormatException numberFormatException) {
            // empty catch block
        }
        return bf.bf_q;
    }

    @Override
    public final void a(int n, rk rk2) {
        if (n != 0xFF6666) {
            qf_m = null;
        }
        this.c((byte)-51);
    }

    static final void a(String string, int n, String string2) {
        if (cl.cl_r != null) {
            cl.cl_r.n(-120);
        }
        if (n >= -10) {
            qf_l = null;
        }
        dm.dm_c = new he(string, string2, false, true, true);
        de.W.c(dm.dm_c, (byte)91);
    }

    @Override
    public final void b(int n, rk rk2) {
        block0: {
            if (n == -2569) break block0;
            qf_i = null;
        }
    }

    static final void a(byte by, Component component) {
        component.removeMouseListener(ik.ik_f);
        component.removeMouseMotionListener(ik.ik_f);
        component.removeFocusListener(ik.ik_f);
        if (by != -35) {
            qf_j = null;
        }
        pa.pa_bb = 0;
    }

    static final void a(int n, int n2) {
        int n3 = (wj.Lb + -640) / 2;
        if (n2 <= 95) {
            qf_j = null;
        }
        int n4 = dl.M * dl.M;
        int n5 = n4 - n * n;
        ee.ee_i.a(199, 0, 90, -4 + hk.hk_i - 210, n3 - 199 * n5 / n4);
        oh.oh_d.a(438, 0, 0, hk.hk_i - 124, n3 - -202 + n5 * 438 / n4);
    }

    static final boolean a(String string, int n) {
        boolean bl2 = client.A;
        int n2 = n;
        while (~string.length() < ~n2) {
            char c2 = string.charAt(n2);
            if (!v.a(c2, -24380) && !fl.a(c2, (byte)23)) {
                return true;
            }
            ++n2;
        }
        return false;
    }

    static final void a(boolean bl2) {
        if (!vb.Z) {
            throw new IllegalStateException();
        }
        if (cl.cl_r != null) {
            cl.cl_r.n(8);
        }
        String string = qe.a((byte)103);
        dm.dm_c = new he(string, null, bl2, false, false);
        ah.ah_c.a((byte)-107, (ce)de.W);
        de.W.c(dm.dm_c, (byte)101);
        de.W.j(100);
    }

    @Override
    public final boolean a(byte by) {
        int n = -5 / ((72 - by) / 40);
        return this.qf_g.k(111);
    }

    static final void a(ji ji2, ji ji3, int n) {
        eb.eb_k = ji3;
        if (n >= -46) {
            qf.c(8);
        }
        le.E = ji2;
    }

    static final void a(String string, String[] stringArray, int n, int n2) {
        boolean bl2 = client.A;
        ka.P = kl.z;
        if (n2 != -677) {
            qf.a(false);
        }
        if (~n == -256) {
            je.je_b = bn.a(false, 13 > jk.jk_e);
            gf.a(null, false);
        } else if (~n <= -101 && 105 >= n) {
            String[] stringArray2 = stringArray;
            gf.a(stringArray2, false);
            je.je_b = wi.a(stringArray, n2 + 674);
        } else {
            je.je_b = un.a(n, string, n2 + 780);
        }
    }

    public static void c(int n) {
        qf_l = null;
        qf_j = null;
        qf_h = null;
        if (n < 110) {
            return;
        }
        qf_i = null;
        qf_k = null;
        qf_m = null;
    }

    static {
        qf_k = "Achievements This Game";
        qf_m = "<%0> must play 1 more rated game before playing with the current options.";
        qf_j = "Names cannot start or end with space or underscore";
    }
}
