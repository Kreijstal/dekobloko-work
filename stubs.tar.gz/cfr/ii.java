/*
 * Decompiled with CFR 0.152.
 */
final class ii
extends wm {
    static String ii_p = "Eliminate Score: ";
    static ji ii_t;
    static String ii_s;
    static String ii_r;
    static boolean ii_q;

    public static void e(int n) {
        ii_p = null;
        ii_r = null;
        if (n != 9369) {
            ii.e(6);
        }
        ii_t = null;
        ii_s = null;
    }

    @Override
    final String wm_a_string(String string, byte by) {
        if (by != -11) {
            String string2 = null;
            this.b(string2, (byte)-35);
        }
        if (this.b(string, (byte)-40) == vm.vm_u) {
            return ng.ng_e;
        }
        return li.li_a;
    }

    @Override
    final tb b(String string, byte by) {
        boolean bl;
        boolean bl2 = bl = null == client.a(string, -12828);
        if (!bl) {
            return vm.vm_u;
        }
        if (by != -40) {
            return null;
        }
        return dc.dc_b;
    }

    ii(rk rk2) {
        super(rk2);
    }

    static {
        ii_s = "Some players haven't unlocked the currently selected game options.<br>Please view the '<%0>' tab on the left for details.";
        ii_r = "<%0> is not on your ignore list.";
    }
}
