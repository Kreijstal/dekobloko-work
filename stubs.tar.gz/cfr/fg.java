/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.ms.awt.WComponentPeer
 *  com.ms.com.IUnknown
 *  com.ms.directX.DDSurfaceDesc
 *  com.ms.directX.DirectDraw
 *  com.ms.directX.IEnumModesCallback
 *  com.ms.win32.User32
 */
import com.ms.awt.WComponentPeer;
import com.ms.com.IUnknown;
import com.ms.directX.DDSurfaceDesc;
import com.ms.directX.DirectDraw;
import com.ms.directX.IEnumModesCallback;
import com.ms.win32.User32;
import java.awt.Component;
import java.awt.Frame;

final class fg
implements IEnumModesCallback {
    private static int[] fg_a;
    private DirectDraw fg_b = new DirectDraw();
    private static int fg_c;

    final void a(int n, boolean bl, int n2, int n3, int n4, Frame frame) {
        frame.setVisible(true);
        WComponentPeer wComponentPeer = (WComponentPeer)frame.getPeer();
        if (bl) {
            fg_c = -20;
        }
        int n5 = wComponentPeer.getHwnd();
        User32.SetWindowLong((int)n5, (int)-16, (int)Integer.MIN_VALUE);
        User32.SetWindowLong((int)n5, (int)-20, (int)8);
        this.fg_b.setCooperativeLevel((Component)frame, 17);
        this.fg_b.setDisplayMode(n2, n3, n, n4, 0);
        frame.setBounds(0, 0, n2, n3);
        frame.toFront();
        frame.requestFocus();
    }

    final void a(Frame frame, byte by) {
        this.fg_b.restoreDisplayMode();
        if (by < 121) {
            Frame frame2 = null;
            this.a(frame2, (byte)18);
        }
        this.fg_b.setCooperativeLevel((Component)frame, 8);
    }

    public final void callbackEnumModes(DDSurfaceDesc dDSurfaceDesc, IUnknown iUnknown) {
        if (null == fg_a) {
            fg_c += 4;
        } else {
            fg.fg_a[fg.fg_c++] = dDSurfaceDesc.width;
            fg.fg_a[fg.fg_c++] = dDSurfaceDesc.height;
            fg.fg_a[fg.fg_c++] = dDSurfaceDesc.rgbBitCount;
            fg.fg_a[fg.fg_c++] = dDSurfaceDesc.refreshRate;
        }
    }

    public fg() {
        this.fg_b.initialize(null);
    }

    final int[] a(int n) {
        this.fg_b.enumDisplayModes(0, null, null, (IEnumModesCallback)this);
        fg_a = new int[fg_c];
        fg_c = 0;
        this.fg_b.enumDisplayModes(n, null, null, (IEnumModesCallback)this);
        int[] nArray = fg_a;
        fg_a = null;
        fg_c = 0;
        return nArray;
    }
}
