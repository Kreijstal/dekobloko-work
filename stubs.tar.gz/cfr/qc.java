/*
 * Decompiled with CFR 0.152.
 */
final class qc {
    boolean W;
    private int qc_rb;
    private int qc_ab;
    private boolean qc_jb;
    int qc_w;
    int Ab;
    static String[] C = new String[]{"Loading text", "Lade Text", "Chargement du texte", "Carregando textos", "Tekst laden", "Cargando texto"};
    private int qc_bb;
    private boolean qc_m;
    private byte[] qc_nb;
    private int qc_k;
    private vj[] Z;
    private int[][] qc_gb;
    static boolean N;
    int qc_lb;
    private int qc_cb;
    private lk[] qc_h;
    eb qc_g;
    int T;
    static ji qc_vb;
    private int qc_kb;
    static w qc_q;
    int R;
    private int qc_t;
    private int x;
    int P;
    int[] V;
    int yb;
    private vj[] qc_eb;
    lb[] qc_v;
    oi qc_db;
    static qk qc_s;
    private int[] B;
    boolean qc_ob;
    private int L;
    private int[] qc_qb;
    int E;
    vj qc_p;
    int qc_i;
    private int qc_mb;
    boolean qc_r;
    static int Y;
    private int qc_a;
    static String qc_l;
    int D;
    private int A;
    private int M;
    int qc_hb;
    private int O;
    private int H;
    private int G;
    private int K;
    private int S;
    private int F;
    private int qc_pb;
    private boolean X;
    private int qc_f;
    private int qc_o;
    private int qc_u;
    private boolean xb;
    private int[] qc_c;
    private int qc_tb;
    private boolean qc_j;
    private int qc_sb;
    private int zb;
    private int Q;
    private int qc_fb;
    private int U;
    private int qc_ib;
    private int qc_ub;
    private ke z;
    private int y;
    private int I;
    boolean qc_wb;
    private int qc_n;
    private int qc_e;
    private boolean J;
    private int qc_d;
    private boolean qc_b;

    final boolean b(int n, boolean bl) {
        int n2;
        int n3;
        block174: {
            int n4;
            block173: {
                block172: {
                    int n5;
                    in in2;
                    int n6;
                    int n7;
                    boolean bl2 = client.A;
                    int n8 = wh.wh_c / 2;
                    rk.rk_cb -= 2 * n8;
                    fb.fb_e += n8;
                    fh.fh_h -= 2 * n8;
                    he.he_ab -= n8;
                    if (!this.qc_m) {
                        if (this.qc_wb) {
                            n8 = this.qc_bb;
                            if (-5 > ~n8) {
                                n8 = 4;
                            }
                        } else if (-1 != ~this.qc_ab) {
                            if (~this.qc_ab == -2) {
                                n8 = 1;
                            } else {
                                n8 = 2 + this.qc_ab / 4;
                                if (-5 > ~n8) {
                                    n8 = 4;
                                }
                            }
                        } else {
                            n8 = 0;
                        }
                        n7 = this.qc_g.eb_p[0].lk_c;
                        n6 = n8;
                        fh.fh_h -= n7 * 2;
                        rk.rk_cb -= n6 * 2;
                        he.he_ab -= n6;
                        fb.fb_e += n7;
                        if (this.qc_wb) {
                            n8 = 3 + this.qc_bb;
                            if (-8 > ~n8) {
                                n8 = 7;
                            }
                        } else {
                            n8 = 3 - -(this.qc_ab / 4);
                            if (5 < n8) {
                                n8 = 5;
                            }
                        }
                        n7 = this.qc_g.eb_p[0].lk_d;
                        n6 = n8;
                        fb.fb_e += n7;
                        fh.fh_h -= 2 * n7;
                        he.he_ab -= n6;
                        rk.rk_cb -= 2 * n6;
                        n8 = -4 + this.qc_g.eb_p[0].yb * 7;
                        n7 = this.E;
                        fh.fh_h -= n8 * 2;
                        fb.fb_e += n8;
                        rk.rk_cb -= n7 * 2;
                        he.he_ab -= n7;
                        n8 = !this.qc_wb ? (-3 >= ~this.qc_ab ? 1 : 0) : this.qc_bb / 2;
                        n7 = this.qc_g.eb_p[0].D;
                        n6 = n8;
                        rk.rk_cb -= n6 * 2;
                        fh.fh_h -= 2 * n7;
                        fb.fb_e += n7;
                        he.he_ab -= n6;
                        if (this.qc_wb) {
                            n8 = mn.mn_b[this.qc_bb];
                        } else {
                            n7 = this.qc_ab;
                            if (~n7 < -17) {
                                n7 = 16;
                            }
                            n8 = pn.pn_eb[n7];
                        }
                        n7 = this.qc_g.eb_p[0].lk_g;
                        n6 = n8;
                        rk.rk_cb -= n6 * 2;
                        fb.fb_e += n7;
                        fh.fh_h -= n7 * 2;
                        he.he_ab -= n6;
                    }
                    n8 = 0;
                    n7 = 0;
                    n6 = 0;
                    if (0 < this.R) {
                        --this.R;
                        if (-151 < ~this.R) {
                            ++this.qc_kb;
                            int n9 = this.R + this.qc_kb;
                            if (n9 + -this.qc_k >= this.qc_kb) {
                                n6 = 1;
                            }
                            n3 = n9 / 2;
                            if (this.qc_kb > n3 && ~(-this.qc_a + n9) <= ~this.qc_kb) {
                                n7 = 1;
                            }
                            if (this.qc_kb <= n3 - this.qc_cb) {
                                n8 = 1;
                            }
                        }
                    }
                    if (n8 != 0 && 10 > this.qc_cb) {
                        ++this.qc_cb;
                    }
                    if (n7 != 0 && this.qc_a < 10) {
                        ++this.qc_a;
                    }
                    if (n8 == 0 && ~this.qc_cb < -1) {
                        --this.qc_cb;
                    }
                    if (n6 != 0 && -11 < ~this.qc_k) {
                        ++this.qc_k;
                    }
                    if (n7 == 0 && this.qc_a > 0) {
                        --this.qc_a;
                    }
                    if (n6 == 0 && -1 > ~this.qc_k) {
                        --this.qc_k;
                    }
                    if (null != (in2 = (in)this.qc_p.c((byte)118))) {
                        if (this.qc_f != 120) {
                            if (~this.qc_f < -1 || !this.xb && -1 == ~this.R) {
                                ++this.qc_f;
                            }
                        } else if (!this.qc_g.eb_j || this.qc_p.vj_c != in2.bh_b) {
                            in2.b((byte)126);
                            this.qc_f = 0;
                            while ((in2 = (in)this.qc_p.c((byte)-82)) != null && in2.in_p && in2.bh_b != this.qc_p.vj_c) {
                                in2.b((byte)127);
                            }
                        }
                    }
                    if (!this.qc_m && this.U == 0 && !this.qc_g.eb_j && ~this.qc_hb == -1 && this.qc_wb && -5 < ~this.qc_bb) {
                        ++this.L;
                    }
                    for (n3 = 0; this.qc_g.eb_b > n3; ++n3) {
                        lk lk2;
                        lk lk3 = this.qc_g.eb_p[n3];
                        if (lk3 == null) {
                            if (0 < this.V[n3] && (~this.qc_g.eb_i < -3 || -201 < ~this.V[n3])) {
                                int n10 = n3;
                                this.V[n10] = this.V[n10] - 1;
                            }
                            if (null == (lk2 = this.qc_h[n3])) continue;
                            lk2.a(null, 127, true, null);
                            lk2.s(-21142);
                            int n11 = n3;
                            this.qc_qb[n11] = this.qc_qb[n11] + 1;
                            if (this.qc_qb[n3] != 75) continue;
                            this.qc_h[n3] = null;
                            this.Z[n3] = null;
                            this.qc_eb[n3] = null;
                            this.qc_gb[n3] = null;
                            continue;
                        }
                        if (-1 < ~lk3.U) continue;
                        if (~n3 != ~this.P) {
                            int n12 = 1 + this.qc_v[n3].lb_e / 20;
                            n4 = 0;
                            while (~n4 > ~n12) {
                                this.b(n ^ 0x1E, n3);
                                ++n4;
                            }
                        } else {
                            if (lk3.S && -1 == ~this.U && 0 == this.qc_hb) {
                                lk2 = !this.qc_m ? lk3 : null;
                                lk3.a(this.qc_db, 125, false, lk2);
                                if (bj.bj_a && dn.dn_i) {
                                    this.c(0, -81, 255);
                                }
                                if (~fk.H <= -3) {
                                    this.c(1, 31, 254);
                                }
                                if (-4 >= ~fk.H) {
                                    this.c(2, n + 98, 253);
                                }
                                if (-8 >= ~fk.H) {
                                    this.c(3, 63, 252);
                                }
                                if (mk.mk_e >= 2) {
                                    this.c(4, -84, 251);
                                }
                                if (-4 >= ~mk.mk_e) {
                                    this.c(5, -93, 250);
                                }
                                if (lk3.lk_nb >= 5) {
                                    this.c(6, n ^ 0xFFFFFFBF, 249);
                                }
                                if (lk3.lk_nb >= 10) {
                                    this.c(7, 112, 248);
                                }
                                if (pn.pn_db) {
                                    this.c(8, n ^ 0x6D, 247);
                                }
                                if (!this.qc_m) {
                                    if (!this.qc_wb || this.qc_bb >= 4) {
                                        this.L += lk3.lk_qb;
                                    }
                                    lk3.lk_qb = 0;
                                }
                                if (!this.qc_m && !lk3.S) {
                                    int n13;
                                    if (2 <= lk3.K && ~this.qc_g.eb_m <= -3) {
                                        rf rf2 = new rf(lk3.lk_fb++);
                                        n5 = 1;
                                        if (-5 >= ~lk3.K) {
                                            n5 = 2;
                                        }
                                        n13 = 1;
                                        if (lk3.K >= 7) {
                                            n13 = 2;
                                        }
                                        byte[] byArray = new byte[n5 * n13];
                                        for (n2 = 0; n2 < byArray.length; ++n2) {
                                            byArray[n2] = (byte)this.qc_g.d(6);
                                        }
                                        rf2.rf_b = n5;
                                        rf2.rf_c = byArray;
                                        rf2.rf_n = n13;
                                        lk3.a(rf2, (byte)-126);
                                    }
                                    if (-1 > ~lk3.lk_jb) {
                                        int n14 = this.b((byte)114);
                                        int n15 = n5 = n14 > 0 && this.L >= n14 ? 1 : 0;
                                        if (n5 != 0) {
                                            this.J = true;
                                            ob.ob_k = true;
                                            if (this.qc_b && !this.qc_wb && -1 + rk.O.length > this.qc_ab) {
                                                n13 = -1;
                                                if (this.X && -3 == ~this.qc_ab) {
                                                    n13 = 1;
                                                    he.he_db = true;
                                                }
                                                this.b(0, n13, this.qc_ab - -1);
                                            }
                                            lk3.a(false);
                                        }
                                    }
                                }
                            } else if (!this.qc_g.eb_j && !lk3.Bb && lk3.lk_jb > 0 && ~this.U == -1 && ~this.qc_hb == -1 && this.R == 0) {
                                int n16 = 0;
                                if (bl) {
                                    if (bj.bj_d[96]) {
                                        ++n16;
                                    }
                                    if (bj.bj_d[97]) {
                                        n16 += 2;
                                    }
                                    if (bj.bj_d[oh.oh_n]) {
                                        n16 += 4;
                                    }
                                    if (bj.bj_d[um.um_d] || bj.bj_d[98] || bj.bj_d[83]) {
                                        n16 += 8;
                                    }
                                    if (bj.bj_d[99]) {
                                        n16 += 16;
                                    }
                                }
                                lk3.d(n16, n + -1674843009);
                                if (this.qc_m) {
                                    this.qc_nb[this.qc_w++] = (byte)n16;
                                    if (this.qc_w == 20 || lk3.Bb) {
                                        we.we_b.f(60, n ^ 0xFFFFFFFE);
                                        n4 = ++we.we_b.wl_n;
                                        we.we_b.a(true, this.qc_w);
                                        we.we_b.l(n ^ 0x3D);
                                        for (n5 = 0; this.qc_w > n5; ++n5) {
                                            we.we_b.a(5, 0, this.qc_nb[n5]);
                                        }
                                        we.we_b.j(n + 18);
                                        we.we_b.b(-n4 + we.we_b.wl_n, true);
                                        this.qc_w = 0;
                                    }
                                } else if (lk3.Bb) {
                                    rf rf3;
                                    if (lk3.lk_t > 0) {
                                        rf3 = lk3.b(n + -19941);
                                        n5 = lk3.yb;
                                    } else {
                                        rf3 = lc.b(0, 0, lk3.yb);
                                        n5 = lk3.m(26580);
                                    }
                                    lk3.a(lk3.Z, (byte)127, this.P == n3);
                                    if (~lk3.lk_jb < -1) {
                                        lk3.a(n ^ 0x62, n5, rf3);
                                        this.E = -4 + n5 * 7;
                                    }
                                }
                            }
                            if (!this.qc_m && this.qc_wb) {
                                int n17 = lk3.a(0);
                                if (-50001 >= ~n17) {
                                    this.c(15, n ^ 0x54, 240);
                                }
                                if (100000 <= n17) {
                                    this.c(16, n ^ 0x3E, 239);
                                }
                                if (n17 >= 200000) {
                                    this.c(17, n + -107, 238);
                                }
                                if (~n17 <= -50001 && -3 < ~this.qc_bb) {
                                    this.c(23, -101, 232);
                                }
                            }
                        }
                        lk3.s(-21142);
                        this.a(true, lk3, 600, 200, lk3.lk_jb, n3, true);
                        if (-1 != ~lk3.lk_jb || null == this.qc_eb[n3]) continue;
                        int n18 = n3;
                        this.qc_qb[n18] = this.qc_qb[n18] + 1;
                        if (~this.qc_qb[n3] != -76) continue;
                        this.qc_eb[n3] = null;
                    }
                    n3 = 0;
                    if (this.J && !this.xb) {
                        int n19;
                        int n20;
                        if (!this.qc_wb) {
                            if (this.qc_ab < 3 && this.qc_ab == id.P && !this.qc_jb) {
                                jm.jm_r.a(new ff(0, this.qc_ab, fb.fb_e, he.he_ab, rk.rk_cb, fh.fh_h), 2777);
                                ++id.P;
                                this.qc_p.a(new in(tb.tb_a, 9, false), 2777);
                            }
                            this.qc_hb = 38;
                            this.y = this.qc_g.eb_l;
                            fh.fh_h += 50;
                            rk.rk_cb += 50;
                            he.he_ab -= 50;
                            fb.fb_e += 50;
                            ++this.qc_ab;
                            n20 = 3;
                            if (n20 < id.P) {
                                n20 = id.P;
                            }
                            this.qc_g.eb_p[0].D = 2 <= this.qc_ab ? 1 : 0;
                            this.L = 0;
                            this.qc_g.eb_l = this.qc_ab % (n20 - -1);
                            n19 = this.qc_ab / 4 + 3;
                            if (~n19 < -6) {
                                n19 = 5;
                            }
                            this.qc_g.eb_p[0].lk_d = n19;
                            if (~this.qc_ab == -1) {
                                n4 = 0;
                            } else if (-2 == ~this.qc_ab) {
                                n4 = 1;
                            } else {
                                n4 = this.qc_ab / 4 + 2;
                                if (~n4 < -5) {
                                    n4 = 4;
                                }
                            }
                            this.qc_g.eb_m = this.qc_g.eb_p[0].lk_c = n4;
                            n5 = this.qc_ab;
                            if (-17 > ~n5) {
                                n5 = 16;
                                ++this.qc_g.eb_p[0].Z;
                            }
                            this.T = n5;
                            this.qc_g.eb_p[0].a(n5, 2113050941, true);
                            this.J = false;
                        } else {
                            if (~id.P == ~this.qc_bb && !this.qc_jb) {
                                jm.jm_r.a(new ff(0, this.qc_bb, fb.fb_e, he.he_ab, rk.rk_cb, fh.fh_h), 2777);
                                ++id.P;
                                this.qc_p.a(new in(tb.tb_a, 9, false), 2777);
                            }
                            ++this.qc_bb;
                            fh.fh_h += 50;
                            rk.rk_cb += 50;
                            he.he_ab -= 50;
                            fb.fb_e += 50;
                            if (~this.qc_bb == -5) {
                                this.c(12, n ^ 0x3E, 243);
                            }
                            if (-7 == ~this.qc_bb) {
                                this.c(13, n + -84, 242);
                            }
                            if (-8 == ~this.qc_bb) {
                                this.c(14, -61, 241);
                            }
                            this.y = this.qc_g.eb_l;
                            this.qc_hb = 38;
                            this.qc_g.eb_l = this.qc_bb;
                            this.L = 0;
                            this.qc_g.eb_p[0].D = this.qc_bb / 2;
                            n20 = 3 - -this.qc_bb;
                            if (7 < n20) {
                                n20 = 7;
                            }
                            this.qc_g.eb_p[0].lk_d = n20;
                            n19 = this.qc_bb;
                            if (-5 > ~n19) {
                                n19 = 4;
                            }
                            this.qc_g.eb_m = this.qc_g.eb_p[0].lk_c = n19;
                            this.T = this.qc_bb;
                            this.qc_g.eb_p[0].a(this.qc_bb, 2113050941, false);
                            this.J = false;
                        }
                        n3 = 1;
                    }
                    int n21 = this.qc_mb;
                    int n22 = this.D;
                    while (~this.qc_lb > ~n22) {
                        if (~(--n22) != ~this.qc_lb && null == this.qc_g.eb_p[n22 % this.qc_g.eb_b]) continue;
                        n21 += 1024;
                    }
                    while (~this.qc_lb < ~n22) {
                        if (~(++n22) != ~this.qc_lb && this.qc_g.eb_p[n22 % this.qc_g.eb_b] == null) continue;
                        n21 -= 1024;
                    }
                    n4 = n21 * 31 / 32 + -n21;
                    if (~this.qc_mb != -1 || n4 <= 0) break block173;
                    this.qc_i = this.D;
                    do {
                        ++this.qc_i;
                        if (this.qc_lb == this.qc_i) break block172;
                    } while (this.qc_g.eb_p[this.qc_i % this.qc_g.eb_b] == null);
                    this.qc_mb += n4;
                    break block174;
                }
                this.qc_mb += n4;
                break block174;
            }
            this.qc_mb += n4;
        }
        while (-1 < ~this.qc_mb) {
            this.qc_i = this.D;
            do {
                --this.D;
            } while (this.D != this.qc_lb && null == this.qc_g.eb_p[this.D % this.qc_g.eb_b]);
            this.qc_mb += 1024;
        }
        while (-1025 >= ~this.qc_mb) {
            this.D = this.qc_i;
            do {
                ++this.qc_i;
            } while (this.qc_i != this.qc_lb && this.qc_g.eb_p[this.qc_i % this.qc_g.eb_b] == null);
            this.qc_mb -= 1024;
        }
        if (this.qc_g.eb_i <= n && this.Ab > 0) {
            --this.Ab;
        }
        while (this.qc_g.eb_b <= this.D && this.qc_lb >= this.qc_g.eb_b && this.qc_i >= this.qc_g.eb_b) {
            this.D -= this.qc_g.eb_b;
            this.qc_i -= this.qc_g.eb_b;
            this.qc_lb -= this.qc_g.eb_b;
        }
        if (!this.qc_m) {
            sa sa2;
            ++this.Q;
            vj vj2 = this.qc_g.eb_p[0].lk_rb;
            bh bh2 = vj2.vj_c.bh_a;
            while (bh2 != vj2.vj_c && ((sa)bh2).sa_v == 0) {
                bh2 = bh2.bh_a;
            }
            int n23 = 50 + this.Q;
            if (vj2.vj_c != bh2 && ~n23 > ~(n2 = 5 + ((sa)bh2).sa_v)) {
                n23 = n2;
            }
            while ((bh2 = bh2.bh_b) != vj2.vj_c) {
                sa sa3 = (sa)bh2;
                sa3.sa_v = n23;
                sa3.z = this.Q;
                if (16 == (0x18 & sa3.y)) {
                    sa3.sa_o = fb.fb_c[this.qc_g.eb_l][sa3.y & 7];
                } else if (~(sa3.y & 0x18) == -9) {
                    sa3.sa_o = cg.a(this.qc_g.eb_l, 7 & sa3.y, 0);
                } else if (24 == (sa3.y & 0x18)) {
                    sa3.sa_o = tg.a(true, sa3.y & 7);
                }
                n23 += 5;
            }
            while (true) {
                sa sa4;
                sa2 = sa4 = (sa)vj2.c((byte)-123);
                if (null == sa4 || this.Q < sa4.sa_v) break;
                this.qc_rb += sa4.sa_t;
                sa4.b((byte)124);
            }
            sa2 = this.qc_g.eb_p[0].W;
            if (sa2 != null) {
                sa2.D -= 10;
            }
        }
        int n24 = this.qc_lb;
        if (this.qc_g.eb_i == 2 && ~this.P <= -1) {
            n24 = this.P;
        }
        lk lk4 = this.qc_g.eb_p[n24 % this.qc_g.eb_b];
        if (!this.qc_g.eb_j && null != lk4 && ~lk4.lk_jb < -1) {
            int n25;
            int n26 = -1;
            lk lk5 = null;
            if (this.qc_m) {
                for (n25 = 1; n25 < this.qc_g.eb_b; ++n25) {
                    lk lk6 = this.qc_g.eb_p[(n24 - -n25) % this.qc_g.eb_b];
                    if (lk6 == null || 0 >= lk6.lk_jb) continue;
                    n26 = (n25 + n24) % this.qc_g.eb_b;
                    lk5 = lk6;
                    break;
                }
            }
            n25 = f.a(lk4, lk5, this.qc_ub, (byte)-119);
            if ((0 > this.P || null == lk4 || 0 == lk4.lk_jb) && ~this.qc_g.eb_i == -3) {
                int n27 = f.a(lk5, lk4, this.qc_ub, (byte)-119);
                if (~n27 < ~n25) {
                    n25 = n27;
                }
                if (-4 == ~n25) {
                    n25 = 2;
                }
            }
            if (n25 == 3 && this.qc_ub != 3) {
                String string = this.qc_g.eb_q[n26];
                this.qc_p.a(new in(cm.a((byte)108, pc.pc_a, new String[]{string}), 8, true), n + 2775);
            }
            ui[] uiArray = this.qc_m && ~this.T == -11 ? ee.ee_a : sb.sb_u[this.qc_g.eb_l];
            if (n3 == 0) {
                ob.a(this.b(true), uiArray[n25], (byte)118);
            } else {
                nn.a(this.b(true), uiArray[n25], true);
            }
            this.qc_ub = n25;
        }
        if (this.qc_m) {
            boolean bl3;
            hh.hh_b = kk.kk_i;
            boolean bl4 = bl3 = this.P >= 0 ? nk.nk_i : og.og_ib;
            if (!bl3) {
                hh.hh_b = ~bg.bg_b >= -2 ? (-2 == ~bg.bg_b ? lb.lb_c : tj.tj_ac) : cm.a((byte)96, qf.qf_l, new String[]{Integer.toString(bg.bg_b)});
            }
            int n28 = a.a_t.a(hh.hh_b);
            tm.tm_c = n28 - -32;
        }
        if (!this.qc_m || !bl || 0 <= this.P && jg.jg_i) {
            nf.nf_b = false;
        } else {
            int n29;
            nf.nf_b = false;
            int n30 = n29 = -51 < ~this.Ab ? 320 + -(tm.tm_c / 2) : 0;
            if (bh.bh_g >= n29 && ~bh.bh_g > ~(n29 - -tm.tm_c) && ~(ea.D.Ib + -28) >= ~pm.pm_f && ~ea.D.Ib < ~pm.pm_f) {
                nf.nf_b = true;
            }
            if (-1 != ~ig.Yb && n29 <= he.S && ~(tm.tm_c + n29) < ~he.S && -28 + ea.D.Ib <= nf.nf_h && ~ea.D.Ib < ~nf.nf_h) {
                if (this.P >= 0) {
                    nk.nk_i = !nk.nk_i;
                } else {
                    boolean bl5 = og.og_ib = !og.og_ib;
                }
            }
        }
        if (this.qc_g.eb_j) {
            if (!this.qc_m && ~this.qc_pb <= -61 && this.qc_ib > 1) {
                --this.qc_ib;
            }
            if (~this.qc_pb > -61) {
                in in3 = (in)this.qc_p.b(true);
                if (null == this.qc_p.c(true)) {
                    if (this.qc_m) {
                        if (0 == this.qc_pb) {
                            this.z = wd.a(n ^ 0x58, false, ~this.P > -1);
                        }
                        if (this.qc_pb >= 40) {
                            this.z.ke_c += 16;
                            ++this.z.ke_o;
                        }
                    }
                    ++this.qc_pb;
                    in3.in_r = (!this.qc_m ? 16 : 19) * this.qc_pb / 4;
                }
            }
        }
        if (null != this.z) {
            if (bl) {
                this.z.b(ea.D.Ib / 2, 122);
            }
            this.z.k((byte)114);
        }
        if (this.xb && 50 > this.qc_n) {
            ++this.qc_n;
        }
        if (this.xb && this.U < 50) {
            ++this.U;
        }
        if (!this.xb && this.qc_n > 0) {
            --this.qc_n;
        }
        if (!this.xb && 0 < this.U) {
            --this.U;
        }
        if (50 == this.qc_n) {
            ++this.S;
            if (this.S >= 140) {
                this.S = 0;
            }
            this.a((byte)-107);
            if (~(this.S % 20) == -1) {
                this.d(false);
            }
        }
        if (-1 != ~ig.Yb && this.qc_g.eb_j && !this.qc_m) {
            this.c((byte)-13);
            am.am_c = false;
            un.a((byte)96);
            kf.G = f.a(false, false, 0, false, this.qc_wb, 32357, false, false);
            dc.a(false, 95);
            return true;
        }
        if (-1 != ~ig.Yb && this.xb) {
            if (~this.qc_d > -1) {
                if (this.qc_wb && this.O < -1 + uj.uj_f.length) {
                    this.b(0, -1, 1 + this.O);
                } else {
                    this.xb = false;
                }
            } else {
                this.b(0, -1, this.O);
            }
        }
        if (this.qc_hb > 0 && ~this.U == -1) {
            --this.qc_hb;
        }
        if (this.qc_m) {
            return false;
        }
        this.qc_j = false;
        if (2 == ~this.I) {
            if (this.qc_b) {
                int n31 = this.qc_g.eb_p[0].f(-65);
                if (n31 >= 0) {
                    this.qc_j = true;
                    this.F = n31;
                } else if (!this.qc_wb && this.qc_g.eb_p[0].n(-22477)) {
                    this.F = -2;
                    this.qc_j = true;
                } else if (!this.qc_wb && -1 == ~this.qc_ab && !this.J) {
                    this.F = -1;
                    this.qc_j = true;
                }
            }
        } else {
            this.qc_j = true;
            this.F = this.I;
        }
        if (this.qc_j && 20 > this.qc_u) {
            ++this.qc_u;
        }
        if (!this.qc_j && -1 > ~this.qc_u) {
            --this.qc_u;
        }
        return false;
    }

    static final void a(int n, int n2, int n3) {
        block13: {
            int n4;
            boolean bl = client.A;
            if (0 > gd.gd_e) {
                return;
            }
            if (n3 != 19759) {
                return;
            }
            int n5 = -135 + n2;
            int n6 = -35 + n;
            int n7 = 256;
            if (75 > gd.gd_e) {
                n7 = (gd.gd_e << 1454947144) / 75;
            }
            if (200 < gd.gd_e) {
                n7 = (250 + -gd.gd_e << 100496008) / 50;
            }
            tb.a(true, wm.wm_o);
            qg.b();
            hk.b();
            vk.a(0);
            if (256 > n7) {
                hk.a(0, 0, hk.hk_j, hk.hk_i, 0, 256 + -n7);
            }
            mk.a((byte)-5);
            if (-151 < ~gd.gd_e) {
                wm.wm_o.d(n5, n6);
            } else {
                re.re_r.c(15 + n5, 10 + n6, n7);
            }
            int n8 = -125 + gd.gd_e;
            if (-1 > ~n8 && ~n8 > -51) {
                if (n8 < 20) {
                    n4 = n8 * 256 / 20;
                    qi.R.f(n5, n6, n4);
                } else if (~n8 <= -31) {
                    n4 = 256 * (-n8 + 50) / 20;
                    qi.R.f(n5, n6, n4);
                } else {
                    qi.R.f(n5, n6, 256);
                }
            }
            if (-1 <= ~(n8 = -140 + gd.gd_e)) break block13;
            n4 = 256;
            if (n8 < 20) {
                n4 = 256 * n8 / 20;
            }
            qj.qj_d.c(15 + n5, 10 + n6, n7 * n4 >> -1907879288);
        }
    }

    final void c(byte by) {
        if (this.qc_m) {
            throw new IllegalStateException();
        }
        if (!this.qc_g.eb_j) {
            this.c(false);
        }
        int n = -76 / ((by - 52) / 48);
    }

    private final void d(int n2) {
        hk.a(0, 0, 640, 480, 65793, this.qc_pb << 1907491361);
        int n3 = -(240 * this.qc_pb * this.qc_pb / 3600) + 240;
        hk.a(175, 180 - -n3, 290, 180, 0, 180);
        vk.a(200, (byte)50, a.a_n, 310, 170 - -n3, 165);
        int n4 = this.qc_ib;
        int n5 = this.qc_g.eb_p[0].x / n4;
        int n6 = this.qc_g.eb_p[0].lk_f / n4;
        int n7 = this.qc_g.eb_p[0].lk_hb / n4;
        int n8 = this.qc_g.eb_p[0].lk_ub / n4;
        int n9 = this.qc_g.eb_p[0].lk_j / n4;
        int n10 = this.qc_g.eb_p[0].lk_bb / n4;
        int n11 = this.qc_g.eb_p[0].H / n4;
        fl.a(n3 + 200, 256, 16694016, th.th_a, 185, w.w_kb);
        kn.a(w.w_kb, (byte)-39, n3 + 200, Integer.toString(n5), 0xFFFFFF, 455);
        fl.a(n3 + 220, 256, 16694016, t.t_bb, 185, w.w_kb);
        kn.a(w.w_kb, (byte)-39, n3 + 220, Integer.toString(n6), 0xFFFFFF, 455);
        fl.a(n3 + 240, 256, 16694016, ii.ii_p, 185, w.w_kb);
        if (n2 != 24) {
            return;
        }
        kn.a(w.w_kb, (byte)-39, n3 + 240, Integer.toString(n7), 0xFFFFFF, 455);
        fl.a(n3 + 260, n2 ^ 0x118, 16694016, jc.jc_b, 185, w.w_kb);
        kn.a(w.w_kb, (byte)-39, n3 + 260, Integer.toString(n8), 0xFFFFFF, 455);
        fl.a(280 - -n3, 256, 16694016, wm.wm_m, 185, w.w_kb);
        kn.a(w.w_kb, (byte)-39, n3 + 280, Integer.toString(n9), 0xFFFFFF, 455);
        fl.a(n3 + 300, n2 ^ 0x118, 16694016, on.on_a, 185, w.w_kb);
        kn.a(w.w_kb, (byte)-39, 300 + n3, Integer.toString(n10), 0xFFFFFF, 455);
        fl.a(320 + n3, 256, 16694016, qi.L, 185, w.w_kb);
        kn.a(w.w_kb, (byte)-39, n3 + 320, Integer.toString(n11), 0xFFFFFF, 455);
        hk.a(183, 327 + n3, 274, 7, 0);
        hk.a(185, n3 + 329, 270, 3, 0xFFFFFF);
        fl.a(350 + n3, 256, 16694016, n.n_a, 185, w.w_kb);
        int n12 = n11 + n9 + n6 + (n5 - (-n7 + -n8 - n10));
        kn.a(w.w_kb, (byte)-39, 350 - -n3, Integer.toString(n12), 0xFFFFFF, 455);
        ed.a(0xFFFFFF, 320, ak.ak_c, n3 + 390, (byte)75, w.w_kb);
    }

    final void a(int n2, lk lk2, int n3) {
        block20: {
            boolean bl2 = client.A;
            if (~lk2.U <= -1) {
                int n4;
                int n5;
                int n6;
                int n7;
                int n8;
                vj vj2;
                this.qc_h[n3] = lk2;
                int n9 = lk2.lk_a * -2 / 18;
                this.Z[n3] = vj2 = qn.a(-n9 + lk2.lk_a + 1, n9, -1, 1000, 36, lk2.O + 2, 36, n2 + 100);
                this.a(true, lk2, 600, 450, 0, n3, false);
                ge.a(lk2.lk_lb, lk2.lk_k / 2, (byte)127, ie.ie_e);
                if (~n3 == ~this.qc_lb) {
                    ge.a(-1, lk2.lk_k, (byte)127, jg.jg_j);
                }
                this.qc_qb[n3] = 0;
                int[] nArray = new int[lk2.lk_a * lk2.O - -1];
                this.qc_gb[n3] = nArray;
                for (n8 = 0; lk2.lk_a > n8; ++n8) {
                    n7 = 0;
                    while (~n7 > ~lk2.O) {
                        if (0 == nArray[n8 * lk2.O + n7] && 0 != (0x18 & (n6 = lk2.P[n8 * lk2.O + n7]))) {
                            int n10;
                            int n11;
                            int n12;
                            int n13;
                            n5 = n7;
                            n4 = n7;
                            int n14 = n8;
                            int n15 = n8;
                            int n16 = 0;
                            lk2.lk_w[0] = lk2.O * n8 + n7;
                            int n17 = 1;
                            int n18 = n8 * lk2.O - -n7;
                            lk2.P[n18] = lk2.P[n18] + Integer.MIN_VALUE;
                            if (~(n6 & 0x18) == -9) {
                                n13 = n6 & 0x1F;
                                while (n16 < n17) {
                                    n12 = lk2.lk_w[n16++];
                                    n11 = n12 % lk2.O;
                                    n10 = n12 / lk2.O;
                                    if (~n11 < ~n4) {
                                        n4 = n11;
                                    }
                                    if (n5 > n11) {
                                        n5 = n11;
                                    }
                                    if (n15 < n10) {
                                        n15 = n10;
                                    }
                                    if (~n11 < -1 && ~n13 == ~(lk2.P[n12 - 1] & 0x8000001F)) {
                                        lk2.lk_w[n17++] = -1 + n12;
                                        int n19 = -1 + n12;
                                        lk2.P[n19] = lk2.P[n19] + Integer.MIN_VALUE;
                                    }
                                    if (n14 > n10) {
                                        n14 = n10;
                                    }
                                    if (~n11 > ~(-1 + lk2.O) && ~(0x8000001F & lk2.P[n12 - -1]) == ~n13) {
                                        lk2.lk_w[n17++] = 1 + n12;
                                        int n20 = n12 - -1;
                                        lk2.P[n20] = lk2.P[n20] + Integer.MIN_VALUE;
                                    }
                                    if (n10 > 0 && (0x8000001F & lk2.P[-lk2.O + n12]) == n13) {
                                        lk2.lk_w[n17++] = -lk2.O + n12;
                                        int n21 = -lk2.O + n12;
                                        lk2.P[n21] = lk2.P[n21] + Integer.MIN_VALUE;
                                    }
                                    if (~(-1 + lk2.lk_a) >= ~n10 || ~n13 != ~(lk2.P[n12 - -lk2.O] & 0x8000001F)) continue;
                                    lk2.lk_w[n17++] = n12 + lk2.O;
                                    int n22 = lk2.O + n12;
                                    lk2.P[n22] = lk2.P[n22] + Integer.MIN_VALUE;
                                }
                            }
                            n13 = 1 + (n5 + (n4 - lk2.O));
                            n12 = 1 + (n14 + (n15 - lk2.lk_a));
                            n11 = 350 - -ka.a((byte)126, 101, tf.tf_cb);
                            n10 = -(n11 * (n13 * n13 - -(n12 * n12)) / (2 * lk2.lk_a * lk2.lk_a)) + n11;
                            int n23 = (0xFF00 & n12 << 938835272) + (n13 & 0xFF) + (n10 << 388133744);
                            for (int j = 0; j < n17; ++j) {
                                int n24;
                                int n25 = n24 = lk2.lk_w[j];
                                lk2.P[n25] = lk2.P[n25] - Integer.MIN_VALUE;
                                nArray[n24] = n23;
                            }
                        }
                        ++n7;
                    }
                }
                n8 = -lk2.O + lk2.C + lk2.lk_q * 2;
                n7 = -lk2.lk_a + lk2.L * 2 - -lk2.zb;
                n6 = ka.a((byte)68, 101, tf.tf_cb) + 350;
                n5 = -(n6 * (n8 * n8 - -(n7 * n7)) / (lk2.lk_a * lk2.lk_a * 2)) + n6;
                nArray[lk2.O * lk2.lk_a] = n4 = (0xFF & n8) + ((n7 & 0xFF) << -1517768664) - -(n5 << -238575664);
                uk uk2 = (uk)vj2.c((byte)-105);
                while (null != uk2) {
                    n8 = -lk2.O + uk2.uk_r * 2 + uk2.A;
                    n7 = uk2.uk_u * 2 - -uk2.uk_t + -lk2.lk_a;
                    n6 = ka.a((byte)52, 151, tf.tf_cb) + 200;
                    uk2.uk_o = -(n6 * (n7 * n7 + n8 * n8) / (lk2.lk_a * lk2.lk_a * 2)) + n6;
                    uk2 = (uk)vj2.d(true);
                }
                ql.a(vj2, -122, vj2.a((byte)124));
                if (n3 == this.P) {
                    this.qc_p.a(new in(cb.cb_i, 13, true), 2777);
                } else if (-5 >= ~this.qc_g.eb_b && this.qc_g.eb_i == 3) {
                    this.qc_p.a(new in(ji.ji_h, 8, true), 2777);
                } else {
                    String string = this.qc_g.eb_q[n3].toUpperCase();
                    this.qc_p.a(new in(cm.a((byte)122, a.a_e, new String[]{string}), 14, true), 2777);
                }
            }
            if (n2 == 18) break block20;
            this.b(false);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final void a(ui ui2, int n2) {
        boolean bl2 = client.A;
        en en2 = km.z;
        synchronized (en2) {
            ui ui3;
            nn.a(256, ui2, true);
            if (this.qc_g.eb_j) {
                ui3 = jg.jg_a;
            } else {
                ui[] uiArray = this.qc_m && this.T == 10 ? ee.ee_a : sb.sb_u[this.qc_g.eb_l];
                ui3 = uiArray[0];
            }
            th.a(ui3, n2 + 0);
            this.qc_ub = n2;
        }
    }

    final void f(int n2) {
        if (!this.qc_m) {
            throw new IllegalStateException();
        }
        we.we_b.f(62, -4);
        int n3 = -9 / ((n2 - 24) / 56);
    }

    private final void a(int n2, String string, int n3, int n4, int n5, String string2, int n6) {
        if (n6 == this.P) {
            hk.a(145 + n2, n3, 349, 18, 2587569, 100);
        }
        if (n6 == this.H) {
            hk.a(n2 + 145, n3, 349, 18, 0x80FF80, 40);
        }
        String string3 = null;
        if (n4 < 28) {
            qc_l = null;
        }
        boolean bl2 = false;
        boolean bl3 = false;
        if (-1 < ~this.P || ~(1 << n6 & this.yb) == -1) {
            if (0 <= this.P && -1 != ~(this.qc_g.eb_a & 1 << n6)) {
                bl3 = -1 == ~(1 << this.P & this.qc_g.eb_a);
                string3 = we.we_g;
            } else if (!this.qc_g.eb_j && ~(1 << n6 & this.qc_g.eb_d) != -1) {
                string3 = sk.sk_b;
                bl3 = ~this.P <= -1 && -1 == ~(1 << this.P & this.qc_g.eb_d) && null != this.qc_g.eb_p[this.P] && 0 < this.qc_g.eb_p[this.P].lk_jb;
            }
        } else {
            n5 = 0x808080;
            bl2 = true;
            string3 = rc.rc_h;
        }
        fl.a(14 + n3, 256, n5, this.qc_g.eb_q[n6], 152 + n2, se.S);
        if (null != string3) {
            int n7 = se.S.a(string3);
            int n8 = n2 + (126 + -n7);
            int n9 = n3;
            hk.c(n8 - 2, n9 - 3, n7 - -8, 17, 4, 65793);
            int[] nArray = new int[]{n8 - -n7, 11 + n9, n8 - (-n7 - 15), n9 - -15, 15 + (n8 - -n7), 15 + n9, n7 + (n8 - -15), 13 + n9, n8 - -n7 - -6, 4 + n9};
            ok.a(nArray, 65793);
            int n10 = 0xFFFFFF;
            if (bl3 && 0 != (uf.A & 0x10)) {
                n10 = 15782016;
            }
            if (bl2) {
                n10 = 0x808080;
            }
            hk.c(n8 - 1, -3 + n9 - -1, n7 - -6, 15, 4, n10);
            int[] nArray2 = new int[]{1 + n7 + n8, 10 + n9, 14 + n7 + n8, n9 - -14, n7 + (n8 + 5), n9 - -5};
            ok.a(nArray2, n10);
            se.S.a(string3, n8 - -2, 10 + n9, 65793, -1);
        }
        ed.a(n5, 353 - -n2, string, n3 + 14, (byte)75, se.S);
        ed.a(n5, n2 + 450, string2, 14 + n3, (byte)75, se.S);
    }

    private static final void a(lk lk2, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, ck ck2, pi pi2, boolean bl2) {
        int n11 = n8;
        int n12 = -n6;
        int n13 = lk2.O * 32;
        int n14 = n3 + (n9 * n6 * lk2.O * 2 + n11 * 16) / n13;
        int n15 = n3 + ((n9 + 1) * n6 * lk2.O * 2 + n11 * 16) / n13;
        int n16 = n4 + n10 * n7 / 36 + lk2.z * n7 / lk2.lk_a;
        int n17 = n4 + (n10 + 1) * n7 / 36 + lk2.z * n7 / lk2.lk_a;
        int n18 = n5 + (n9 * n8 * lk2.O * 2 + n12 * 16) / n13;
        int n19 = n5 + ((n9 + 1) * n8 * lk2.O * 2 + n12 * 16) / n13;
        if (n18 >= 500) {
            if (n19 < 500) {
                return;
            }
            int n20 = 320 + n14 * 1000 / n18;
            int n21 = 320 + n15 * 1000 / n19;
            int n22 = n2 + n16 * 1000 / n18;
            int n23 = n2 + n16 * 1000 / n19;
            int n24 = n2 + n17 * 1000 / n18;
            int n25 = n2 + n17 * 1000 / n19;
            cg.a(ck2, pi2, n20, n21, n22, n23, n24, n25, bl2, bl2, 0, -1);
            return;
        }
    }

    private final void a(int n2, byte by, boolean bl2, int n3, int n4) {
        block3: {
            if (40 > n2) {
                n3 -= (40 + -n2) / 2;
                n2 = 40;
            }
            if (bl2) {
                gd.gd_g[1].c(n3 + 19, n4, -19 + (n2 - 19), 36);
                gd.gd_g[0].c(n3, n4);
                gd.gd_g[2].c(n3 + (n2 + -19), n4);
            } else {
                ce.ce_s[1].c(19 + n3, n4, -19 + n2 - 19, 36);
                ce.ce_s[0].c(n3, n4);
                ce.ce_s[2].c(-19 + n3 - -n2, n4);
            }
            if (by == 123) break block3;
            this.qc_sb = -46;
        }
    }

    private final void c(boolean bl2) {
        block5: {
            if (bl2) {
                lk lk2 = null;
                this.a(true, lk2, -88, -111, 33, -46, false);
            }
            int n2 = this.qc_g.eb_p[0].a(0);
            if (this.qc_jb || -1 <= ~n2) break block5;
            if (this.qc_wb) {
                gh.gh_e = new kn(0, 65535, fb.fb_e, he.he_ab, rk.rk_cb, fh.fh_h, new int[]{8 * n2 - -this.qc_bb});
                if (!ph.n(-30146)) {
                    qb.a(3, (byte)85, gh.gh_e);
                }
                gn.gn_b = true;
            } else {
                gh.gh_e = new kn(1, 65534, fb.fb_e, he.he_ab, rk.rk_cb, fh.fh_h, new int[]{this.qc_ab + n2 * 256});
                if (!ph.n(-30146)) {
                    qb.a(3, (byte)85, gh.gh_e);
                }
                ge.ge_c = true;
            }
        }
    }

    final int b(boolean bl2) {
        int n2;
        int n3;
        block2: {
            boolean bl3 = client.A;
            n3 = !this.qc_m && !this.qc_wb ? 4 : 8;
            if (!this.qc_m) {
                n2 = 0;
            } else {
                int n4 = n2 = 10 != this.T ? 3 : 10;
            }
            if (bl2) break block2;
            this.b(true);
        }
        return mb.a(this.qc_r, n3, (byte)-122, this.T, n2);
    }

    public static void a(boolean bl2) {
        if (bl2) {
            Y = -69;
        }
        qc_vb = null;
        qc_s = null;
        qc_l = null;
        qc_q = null;
        C = null;
    }

    private final boolean e(int n2) {
        if (n2 != -20459) {
            this.qc_n = 0;
        }
        return this.qc_m && ~this.R == -1 && (!this.qc_g.eb_j && bj.bj_d[1] || -61 == ~this.qc_pb);
    }

    private static final void a(int n2, lk lk2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, String string, uk uk2, int[] nArray, int n10, vj vj2, int n11, int n12) {
        int n13;
        int n14;
        int n15;
        int n16;
        n7 -= n4;
        n8 -= n5;
        n9 -= n6;
        int n17 = -1;
        int n18 = lk2.O + 1;
        int n19 = lk2.r(3837);
        int n20 = lk2.lk_a + 1;
        int n21 = -1;
        int n22 = lk2.O + 1;
        int n23 = -2 * lk2.lk_a / 18;
        int n24 = lk2.lk_a + 1;
        if (n19 > n23) {
            n19 = n23;
        }
        if (uk2 != null) {
            if (n17 < uk2.uk_r) {
                n17 = uk2.uk_r;
            }
            if (n18 > uk2.uk_r + uk2.A) {
                n18 = uk2.uk_r + uk2.A;
            }
            if (n19 < uk2.uk_u) {
                n19 = uk2.uk_u;
            }
            if (n20 > uk2.uk_u + uk2.uk_t) {
                n20 = uk2.uk_u + uk2.uk_t;
            }
            if (n21 < uk2.uk_r) {
                n21 = uk2.uk_r;
            }
            if (n22 > uk2.uk_r + uk2.A) {
                n22 = uk2.uk_r + uk2.A;
            }
            if (n23 < uk2.uk_u) {
                n23 = uk2.uk_u;
            }
            if (n24 > uk2.uk_u + uk2.uk_t) {
                n24 = uk2.uk_u + uk2.uk_t;
            }
        }
        int n25 = vl.a(23841, n7 * n7 + n9 * n9, -(n4 * n7 + n6 * n9) * lk2.O);
        int n26 = vl.a(23841, n8, -n5 * lk2.lk_a);
        int n27 = n25;
        if (n25 < n17) {
            n25 = n17;
        } else if (n25 > n18) {
            n25 = n18;
        }
        if (n26 < n19) {
            n26 = n19;
        } else if (n26 > n20) {
            n26 = n20;
        }
        if (nArray == null) {
            for (n16 = n23; n16 < n24; ++n16) {
                n15 = n2;
                n14 = 0;
                if (n11 > 0 && n11 >= (n14 = 38 - n16 * 25 / lk2.lk_a)) {
                    n15 = n12;
                }
                for (n13 = n21; n13 < n22; ++n13) {
                    qc.qc_a_uk(lk2, n3, n4, n5, n6, n7, n8, n9, n13, n16, s.Qb[n15], uk2, false);
                }
                if (n11 >= n14 || n11 < n14 - 3) continue;
                for (n13 = n21; n13 < n22; ++n13) {
                    qc.qc_a_uk(lk2, n3, n4, n5, n6, n7, n8, n9, n13, n16, s.Qb[n12], uk2, true);
                    if (n11 == n14 - 1) {
                        qc.qc_a_uk(lk2, n3, n4, n5, n6, n7, n8, n9, n13, n16, s.Qb[n12], uk2, true);
                    }
                    if (n11 != n14 - 3) continue;
                    qc.qc_a_uk(lk2, n3, n4, n5, n6, n7, n8, n9, n13, n16, s.Qb[n15], uk2, true);
                }
            }
        }
        for (n16 = n17; n16 < n25; ++n16) {
            for (n15 = n19; n15 < n26; ++n15) {
                qc.a(n2, lk2, n3, n4, n5, n6, n7, n8, n9, n16, n15, n27, n23, uk2, nArray, n10, n11, n12);
            }
            for (n15 = n20 - 1; n15 >= n26; --n15) {
                qc.a(n2, lk2, n3, n4, n5, n6, n7, n8, n9, n16, n15, n27, n23, uk2, nArray, n10, n11, n12);
            }
        }
        for (n16 = n18 - 1; n16 >= n25; --n16) {
            for (n15 = n19; n15 < n26; ++n15) {
                qc.a(n2, lk2, n3, n4, n5, n6, n7, n8, n9, n16, n15, n27, n23, uk2, nArray, n10, n11, n12);
            }
            for (n15 = n20 - 1; n15 >= n26; --n15) {
                qc.a(n2, lk2, n3, n4, n5, n6, n7, n8, n9, n16, n15, n27, n23, uk2, nArray, n10, n11, n12);
            }
        }
        if (uk2 == null) {
            int n28;
            int n29;
            int n30;
            int n31;
            int n32;
            int n33;
            int n34;
            int[] nArray2 = hk.hk_l;
            n15 = hk.hk_j;
            n14 = hk.hk_i;
            for (n13 = 0; n13 < 4; ++n13) {
                for (n34 = 0; n34 < 16; ++n34) {
                    n33 = n13 * 16 + n34;
                    l.l_d[n33].a();
                    hk.b();
                    ga.a(144, 1, -9 * n13, string, 0, 36, 0xFFFFFF, w.w_kb, (byte)-126, 1, -9 * n34);
                    ++n33;
                }
            }
            hk.a(nArray2, n15, n14);
            if (vj2 != null) {
                uk uk3 = (uk)vj2.c((byte)-96);
                while (uk3 != null) {
                    n34 = 0;
                    for (n33 = 0; n33 < uk3.uk_t; ++n33) {
                        for (n32 = 0; n32 < uk3.A; ++n32) {
                            pi pi2 = uk3.uk_q[n34];
                            if (pi2 == me.J) {
                                ++n34;
                                continue;
                            }
                            int n35 = (uk3.uk_u + n33 + 4) * 16 + (uk3.uk_r + n32);
                            ck ck2 = l.l_d[n35];
                            n31 = 0;
                            for (n30 = 0; n30 < 9; ++n30) {
                                for (n29 = 0; n29 < 9; ++n29) {
                                    if (pi2 == null || pi2.pi_k[n31] != 0) {
                                        pi pi3 = n29 > 0 ? pi2 : (n32 > 0 ? uk3.uk_q[n34 - 1] : (uk3.uk_r > 0 ? me.J : null));
                                        int n36 = n28 = n29 > 0 ? n31 - 1 : n31 + 9 - 1;
                                        if (pi3 == me.J || pi3 != null && pi3.pi_k[n28] == 0) {
                                            ck2.D[n31] = 6328512;
                                        }
                                        pi3 = n29 < 8 ? pi2 : (n32 < uk3.A - 1 ? uk3.uk_q[n34 + 1] : (uk3.uk_r + uk3.A < 16 ? me.J : null));
                                        int n37 = n28 = n29 < 8 ? n31 + 1 : n31 - 9 + 1;
                                        if (pi3 == me.J || pi3 != null && pi3.pi_k[n28] == 0) {
                                            ck2.D[n31] = 4223136;
                                        }
                                        pi3 = n30 > 0 ? pi2 : (n33 > 0 ? uk3.uk_q[n34 - uk3.A] : (uk3.uk_u > -4 ? me.J : null));
                                        int n38 = n28 = n30 > 0 ? n31 - 9 : n31 + 72;
                                        if (pi3 == me.J || pi3 != null && pi3.pi_k[n28] == 0) {
                                            ck2.D[n31] = 8438015;
                                        }
                                        pi3 = n30 < 8 ? pi2 : (n33 < uk3.uk_t - 1 ? uk3.uk_q[n34 + uk3.A] : (uk3.uk_u + uk3.uk_t < 0 ? me.J : null));
                                        int n39 = n28 = n30 < 8 ? n31 + 9 : n31 + -72;
                                        if (pi3 == me.J || pi3 != null && pi3.pi_k[n28] == 0) {
                                            ck2.D[n31] = 16512;
                                        }
                                    }
                                    ++n31;
                                }
                            }
                            ++n34;
                        }
                    }
                    uk3 = (uk)vj2.d(true);
                }
            }
            if (n10 > 0) {
                if (vj2 != null) {
                    uk uk4 = (uk)vj2.c((byte)55);
                    while (uk4 != null) {
                        n34 = 0;
                        for (n33 = uk4.uk_u; n33 < uk4.uk_u + uk4.uk_t; ++n33) {
                            int n40;
                            n32 = n40 = uk4.uk_r;
                            while (n40 < uk4.uk_r + uk4.A) {
                                pi pi4;
                                int n41 = (n33 + 4) * 16 + n40;
                                if ((pi4 = uk4.uk_q[n34++]) != me.J) {
                                    int n42 = uk4.uk_r * 2 + uk4.A - 16;
                                    n31 = uk4.uk_u * 2 + uk4.uk_t + 4;
                                    n30 = uk4.uk_o * n10;
                                    n29 = n30 * n42 / 36;
                                    int n43 = n30 * n31 / 36;
                                    n28 = (n29 * n7 + n30 * n9) / 1440;
                                    int n44 = (n29 * n9 - n30 * n7) / 1440;
                                    int n45 = nArray != null ? 1620 : 6480;
                                    int n46 = -4860;
                                    int n47 = n45 + (n46 - n45) * lk2.z / lk2.lk_a;
                                    int n48 = nArray != null ? 37260 : 6480;
                                    n48 = n48 * (lk2.lk_a - lk2.z) / lk2.lk_a;
                                    n43 += n10 * n47 / 75;
                                    qc.a(lk2, n3, n4 + n28, n5 + (n43 += n10 * n10 * n48 / 5625), n6 + n44, n7, n8, n9, n40, n33, ve.ve_uc[n2][n41], pi4, true);
                                    qc.a(lk2, n3, n4 + n28, n5 + n43, n6 + n44, n7, n8, n9, n40, n33, l.l_d[n41], pi4, false);
                                }
                                ++n40;
                            }
                        }
                        uk4 = (uk)vj2.d(true);
                    }
                }
            } else {
                for (int j = -4; j < 0; ++j) {
                    for (n34 = 0; n34 < 16; ++n34) {
                        n33 = (j + 4) * 16 + n34;
                        qc.a(lk2, n3, n4, n5, n6, n7, n8, n9, n34, j, ve.ve_uc[n2][n33], null, true);
                        qc.a(lk2, n3, n4, n5, n6, n7, n8, n9, n34, j, l.l_d[n33], null, false);
                    }
                }
            }
            return;
        }
    }

    final boolean b(int n2, int n3) {
        int n4;
        bh bh2;
        boolean bl2 = client.A;
        lk lk2 = this.qc_g.eb_p[n3];
        if (lk2.S) {
            lk2.a(this.qc_db, 125, false, null);
            return true;
        }
        lb lb2 = this.qc_v[n3];
        int n5 = 19 % ((-32 - n2) / 48);
        bh bh3 = lb2.lb_g.c((byte)-86);
        if (bh3 == null) {
            return false;
        }
        if (~lb2.lb_f == -1) {
            if (!(bh3 instanceof uf)) {
                if (!(bh3 instanceof vm)) {
                    throw new IllegalStateException(bh3.getClass().getName());
                }
                bh2 = (vm)bh3;
                bh2.b((byte)103);
                if (((vm)bh2).vm_q.rf_c == null) {
                    n4 = -1;
                    int n6 = 0;
                    while (~this.qc_g.eb_b < ~n6) {
                        lk lk3 = this.qc_g.eb_p[n6];
                        if (lk3 != null && lk3.lk_fb <= ((vm)bh2).vm_q.rf_j && ~((vm)bh2).vm_q.rf_j > ~lk3.lk_gb) {
                            n4 = n6;
                            break;
                        }
                        ++n6;
                    }
                    if (n4 < 0) {
                        qb.a(null, 16408, "T2");
                        si.a(67);
                        return true;
                    }
                    while (((vm)bh2).vm_q.rf_c == null) {
                        if (this.b(24, n4)) continue;
                        qb.a(null, 16408, "T3");
                        si.a(59);
                        return true;
                    }
                }
                this.qc_db.a(((vm)bh2).vm_q, (byte)69);
                lk2.a(3, ((vm)bh2).vm_o, 3 & ((vm)bh2).vm_v, ~n3 == ~this.P, ((vm)bh2).y, ((vm)bh2).vm_n);
                lk2.a(((vm)bh2).vm_v >> -454469630, 2113050941, false);
                lk2.a(103, ((vm)bh2).vm_t, ((vm)bh2).vm_q);
                if (~this.P == ~n3) {
                    this.E = -4 + 7 * ((vm)bh2).vm_t;
                }
            } else {
                uf uf2 = (uf)lb2.lb_g.c((byte)63);
                bh2 = uf2;
                lb2.lb_f = uf2.d((byte)-29);
                uf2.j((byte)-108);
            }
        }
        if (-1 > ~lb2.lb_f) {
            bh2 = (uf)lb2.lb_g.c((byte)49);
            n4 = ((uf)bh2).a(5, (byte)110);
            --lb2.lb_e;
            --lb2.lb_f;
            if (lb2.lb_f == 0) {
                bh2.b((byte)111);
            }
            if (lk2.lk_jb <= 0 || lk2.Bb) {
                qb.a(null, 16408, "T5: " + n3 + " " + lk2.lk_jb + " " + lk2.Bb);
                si.a(107);
                return true;
            }
            lk2.d(n4, -1674843007);
        }
        return true;
    }

    final void c(int n2) {
        int n3 = -50 / ((31 - n2) / 40);
        if (!this.qc_m) {
            throw new IllegalStateException();
        }
        we.we_b.f(63, -4);
    }

    private final void a(int n2, byte by) {
        int n3;
        boolean bl2 = client.A;
        int n4 = -74 - -(ea.D.Ib / 2);
        int n5 = n2 + 250;
        int n6 = n5 + 7;
        hk.d(-5 + n5, -5 + n4, 150, 142, 14676, 87166);
        hk.d(n5, n4, 140, 127, 14676, 4427445);
        vk.a(158, (byte)50, a.a_n, 171, -16 + n4, -15 + n5);
        int n7 = n4;
        ed.a(0xFFFFFF, 70 + n5, sh.sh_e, n7 - -16, (byte)75, se.S);
        this.a(12769767, n6 - 2, 22, n7 - -20, 0, 130, 9918);
        for (n3 = 0; 7 > n3; ++n3) {
            if (~n3 > ~this.A) {
                fb.fb_c[this.qc_g.eb_l][n3].c(n3 * 18 + n6, 22 + n7, 18, 18);
                continue;
            }
            fb.fb_c[this.qc_g.eb_l][n3].c(n3 * 18 + n6, 22 + n7, 18, 18, 14676);
        }
        ed.a(0xFFFFFF, 70 + n5, md.Y, 16 + (n7 += 40), (byte)75, se.S);
        this.a(12769767, n6 + -2, 22, 20 + n7, 0, 130, 9918);
        if (-2 >= ~this.qc_t) {
            kd.kd_t.c(n6, n7 + 22, 18, 18);
        } else {
            kd.kd_t.c(n6, n7 + 22, 18, 18, 14676);
        }
        n3 = 0;
        if (2 <= this.qc_t) {
            n3 = 2;
        }
        if (3 <= this.qc_t) {
            n3 = 4;
        }
        if (4 <= this.qc_t) {
            n3 = 6;
        }
        int n8 = 0;
        while (~n8 > -7) {
            if (~n8 > ~n3) {
                tg.a(true, n8).c(18 + n6 - -(n8 * 18), 22 + n7, 18, 18);
            } else {
                tg.a(true, n8).c(18 * n8 + n6 + 18, 22 + n7, 18, 18, 14676);
            }
            ++n8;
        }
        ed.a(0xFFFFFF, 70 + n5, eh.eh_e, (n7 += 40) + 16, (byte)75, se.S);
        this.a(12769767, -2 + n6, 22, n7 + 20, 0, 130, 9918);
        n8 = this.x;
        ck ck2 = lf.lf_h[n8 + -1];
        ck2.d(n6 + 1, 22 + n7, 0);
        ck2.d(n6 + 3, 22 + n7, 0);
        ck2.d(n6 + 3 - -2, -2 + (n7 + 24), 0);
        ck2.d(3 + (n6 + -2), 24 + n7, 0);
        ck2.d(2 + (n6 + 3), 24 + n7, 0);
        if (by != 83) {
            return;
        }
        ck2.d(3 + (n6 - 2), 2 + (24 + n7), 0);
        ck2.d(3 + n6, n7 - -24 + 2, 0);
        ck2.d(3 + (n6 - -2), n7 + 26, 0);
        ck2.c(3 + n6, n7 - -24);
        fl.a(n7 + 36, 256, 0xFFFFFF, tg.tg_d[4][n8 + -1], 3 + (n6 - (-ck2.K - 6)), w.w_kb);
    }

    final void a(int n2) {
        boolean bl2 = client.A;
        this.qc_g.eb_d = 0;
        this.R = 0;
        if (n2 != 100) {
            this.E = -122;
        }
        if (this.qc_g.eb_e != this.P) {
            if (~this.qc_g.eb_e > -1) {
                this.qc_p.a(new in(ri.ri_k, 9, false), 2777);
            } else {
                String string;
                String string2 = string = this.qc_g.eb_q[this.qc_g.eb_e].toUpperCase();
                this.qc_p.a(new in(cm.a((byte)93, fh.fh_b, new String[]{string}), 11, false), 2777);
            }
        } else {
            this.qc_p.a(new in(cn.T, 10, false), 2777);
        }
    }

    private static final void qc_a_uk(lk lk2, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, ck ck2, uk uk2, boolean bl2) {
        pi pi2 = null;
        if (uk2 != null && (pi2 = uk2.uk_q[(n10 - uk2.uk_u) * uk2.A + (n9 - uk2.uk_r)]) == me.J) {
            return;
        }
        int n11 = n8;
        int n12 = -n6;
        int n13 = lk2.O * 2;
        int n14 = n9 * 4;
        int n15 = (n9 + 1) * 4;
        int n16 = n10 * 2;
        int n17 = (n10 + 1) * 2;
        if (n14 < 0) {
            n14 += 3;
        }
        if (n15 > lk2.O * 4) {
            n15 -= 3;
        }
        if (n17 > lk2.lk_a * 2) {
            --n17;
        }
        int n18 = n3 + (n14 * n6 / 2 - n11) / n13;
        int n19 = n3 + (n15 * n6 / 2 - n11) / n13;
        int n20 = n4 + n16 * n7 / (lk2.lk_a * 2);
        int n21 = n4 + n17 * n7 / (lk2.lk_a * 2);
        int n22 = n5 + (n14 * n8 / 2 - n12) / n13;
        int n23 = n5 + (n15 * n8 / 2 - n12) / n13;
        if (n22 >= 500) {
            if (n23 < 500) {
                return;
            }
            int n24 = 320 + n18 * 1000 / n22;
            int n25 = 320 + n19 * 1000 / n23;
            int n26 = n2 + n20 * 1000 / n22;
            int n27 = n2 + n20 * 1000 / n23;
            int n28 = n2 + n21 * 1000 / n22;
            int n29 = n2 + n21 * 1000 / n23;
            cg.a(ck2, pi2, n24, n25, n26, n27, n28, n29, bl2, bl2, 0, -1);
            return;
        }
    }

    private final void a(byte by) {
        block1: {
            boolean bl2 = client.A;
            this.qc_fb = 0 <= this.qc_o ? (this.qc_fb += -this.qc_o >> -1396416127) : (this.qc_fb -= this.qc_o >> -1315012991);
            this.qc_o += this.qc_fb;
            this.qc_sb = this.zb >= 0 ? (this.qc_sb += -this.zb >> -1849132639) : (this.qc_sb -= this.zb >> 680414497);
            this.qc_o = ~this.qc_o > -1 ? (this.qc_o -= this.qc_o >> 2082796292) : (this.qc_o += -this.qc_o >> -225483676);
            this.zb += this.qc_sb;
            this.zb = ~this.zb <= -1 ? (this.zb += -this.zb >> -341393628) : (this.zb -= this.zb >> -912436220);
            int n2 = 40 / ((by - -32) / 33);
            if (~this.zb >= -1) break block1;
            this.zb = 0;
            if (this.qc_sb > 0) {
                this.qc_sb = -this.qc_sb;
            }
        }
    }

    private final void b(int n2, int n3, int n4) {
        this.qc_d = n3;
        this.O = n4;
        this.xb = true;
        this.S = n2;
        this.d(false);
    }

    private final float a(int n2, int n3) {
        if (n2 >= -92) {
            return -0.037685283f;
        }
        return (float)n3 * ((7.5E-5f - (float)n3 * 2.5E-7f) * (float)n3);
    }

    final boolean e(boolean bl2) {
        boolean bl3 = client.A;
        int n2 = 3 + wh.wh_c / 16;
        fh.fh_h -= n2 * 2;
        he.he_ab -= n2;
        fb.fb_e += n2;
        rk.rk_cb -= 2 * n2;
        if (bl2) {
            this.a(81, (byte)21, false, -2, -23);
        }
        if (wh.wh_c == 13) {
            n2 = this.P >= 0 && !this.qc_g.eb_j && null != this.qc_g.eb_p[this.P] ? 1 : 0;
            boolean bl4 = ~this.P <= -1 && this.qc_g.eb_j;
            kf.G = f.a(this.qc_m, n2 != 0, this.qc_g.eb_l, !this.qc_m && !this.xb, false, 32357, bl4, true);
            nm.f(-53);
            return true;
        }
        if (this.z != null) {
            this.z.i((byte)39);
        }
        if ((83 == wh.wh_c || 84 == wh.wh_c) && this.qc_g.eb_j && !this.qc_m) {
            this.c((byte)-14);
            am.am_c = false;
            un.a((byte)-2);
            kf.G = f.a(false, false, 0, false, this.qc_wb, 32357, false, false);
            dc.a(false, 93);
            return true;
        }
        if ((83 == wh.wh_c || 84 == wh.wh_c) && this.xb) {
            if (this.qc_d < 0) {
                if (this.qc_wb && ~(uj.uj_f.length + -1) < ~this.O) {
                    this.b(0, -1, this.O - -1);
                } else {
                    this.xb = false;
                }
            } else {
                this.b(0, -1, this.O);
            }
        }
        if ((this.P < 0 || this.qc_g.eb_p[this.P] == null && this.qc_h[this.P] == null) && ~this.qc_g.eb_i < -3) {
            if (wh.wh_c == 96) {
                do {
                    --this.qc_lb;
                    if (-1 >= ~this.qc_lb) continue;
                    this.qc_lb += this.qc_g.eb_b;
                    this.qc_i += this.qc_g.eb_b;
                    this.D += this.qc_g.eb_b;
                } while (this.qc_g.eb_p[this.qc_lb % this.qc_g.eb_b] == null);
            }
            if (~wh.wh_c == -98) {
                do {
                    ++this.qc_lb;
                } while (null == this.qc_g.eb_p[this.qc_lb % this.qc_g.eb_b]);
            }
        }
        if (~te.te_p <= -3) {
            if ('0' <= el.G && el.G <= '7') {
                this.y = this.qc_g.eb_l;
                this.qc_g.eb_l = -48 + el.G;
                this.qc_hb = 38;
            }
            if (wh.wh_c >= 1 && 8 >= wh.wh_c) {
                fk.I[1] = fk.I[0];
                fk.I[0] = wh.wh_c + -1;
                if (!this.qc_m) {
                    this.qc_jb = true;
                    this.qc_g.eb_p[0].yb = fk.I[0] + (fk.I[1] << 1323324260);
                }
            }
        }
        return false;
    }

    final void b(int n2) {
        if (!this.qc_m) {
            throw new IllegalStateException();
        }
        if (n2 > -51) {
            return;
        }
        we.we_b.f(61, -4);
    }

    private final void c(int n2, int n3, int n4) {
        if (this.qc_jb) {
            return;
        }
        if (rb.a(-23, n2, o.o_g)) {
            return;
        }
        int[] nArray = o.o_g;
        int[] nArray2 = o.o_g;
        int n5 = n2;
        nArray[n5 >> 501516453] = de.b(nArray[n5 >> 501516453], 1 << lb.a(31, n5));
        int[] nArray3 = j.j_d;
        nArray2 = j.j_d;
        int n6 = 79 / ((n3 - -15) / 42);
        n5 = n2;
        nArray3[n5 >> 1862554789] = de.b(nArray3[n5 >> 1862554789], 1 << lb.a(31, n5));
        if (this.qc_g.eb_p[this.P] != null) {
            this.qc_g.eb_p[this.P].lk_cb.a(new vd(n2), 2777);
        }
        si.si_e.a(new ki(n2, n4, fb.fb_e, he.he_ab, rk.rk_cb, fh.fh_h), 2777);
    }

    private final void d(boolean bl2) {
        if (bl2) {
            this.O = -108;
        }
        this.qc_o = 0;
        this.qc_fb = 8;
        this.qc_sb = 8;
        this.zb = 0;
    }

    private final void a(byte by, int n2, int n3, int[] nArray) {
        int n4;
        boolean bl2 = client.A;
        if (~n2 == -101) {
            return;
        }
        int n5 = this.qc_g.eb_b;
        int n6 = 0;
        if (by != -17) {
            return;
        }
        for (n4 = 0; n5 > n4; ++n4) {
            if (~nArray[n4] != -201) continue;
            ++n6;
        }
        n4 = this.qc_lb;
        if (-201 == ~nArray[n4 % n5]) {
            --n6;
        }
        while (~n6 < -2) {
            if (200 != nArray[(n5 + --n4) % n5]) continue;
            n6 -= 2;
        }
        if (~n3 <= ~n4) {
            if (n4 + n5 <= n3) {
                return;
            }
            while (-1 > ~n6) {
                if (~nArray[(--n4 + n5) % n5] != -201) continue;
                n6 -= 2;
            }
            qd.Qb = false;
            int n7 = -800;
            while (n4 != n3 && ~n3 != ~(n5 + n4)) {
                if (this.qc_g.eb_p[(n5 + n4) % n5] != null) {
                    n7 = 800;
                    qd.Qb = true;
                }
                ++n4;
            }
            float f2 = this.a(n2, true);
            sm.sm_d = 10000 + (int)(f2 * (float)(sm.sm_d - 10000));
            dm.dm_d = n7 - -((int)(f2 * (float)(-n7 + dm.dm_d)));
            return;
        }
    }

    private final void a(int n2, int n3, int n4, int n5, int n6, int n7, int n8, boolean bl2) {
        block2: {
            lk lk2;
            if (!bl2) {
                lk2 = this.qc_g.eb_p[n2];
            } else {
                lk2 = this.qc_h[n2];
                int n9 = this.qc_qb[n2];
                n4 += 10000 * (n9 * n9) / 5625;
            }
            this.a(lk2, n6, n3, n8, n4, true, n5, this.qc_g.eb_l);
            if (n7 == 4) break block2;
            this.c(20);
        }
    }

    private final void a(int n2, float f2, int n3, boolean bl2, int[] nArray, int n4) {
        block12: {
            int n5;
            int n6;
            int n7;
            int n8;
            block11: {
                int n9;
                int n10;
                int n11;
                block10: {
                    boolean bl3 = client.A;
                    if (n3 == 100 && !bl2) {
                        return;
                    }
                    n11 = (dm.dm_d - -qk.qk_n) / n4;
                    n10 = (hl.hl_d + sm.sm_d) / 2;
                    if (!bl2) break block10;
                    n8 = n11;
                    n7 = n10;
                    break block11;
                }
                n6 = this.qc_g.eb_b;
                n5 = 0;
                for (n9 = 0; n9 < n6; ++n9) {
                    if (200 != nArray[n9]) continue;
                    ++n5;
                }
                n9 = this.qc_lb;
                if (nArray[n9 % n6] == 200) {
                    --n5;
                }
                while (-1 > ~n5) {
                    if (~nArray[(--n9 - -n6) % n6] != -201) continue;
                    n5 -= 2;
                }
                if (~n9 < ~n2) break block12;
                if (~(n6 + n9) >= ~n2) {
                    return;
                }
                int n12 = -2100;
                while (~n2 < ~n9) {
                    if (null != this.qc_g.eb_p[(n6 + n9) % n6]) {
                        n12 = 2100;
                    }
                    ++n9;
                }
                float f3 = this.a(n3, true);
                n7 = 10000 + (int)((float)(n10 + -10000) * f3);
                f2 *= f3;
                n8 = (int)((float)(n11 + -n12) * f3) + n12;
            }
            n6 = (int)(0.5 + 720.0 * Math.cos(f2));
            n5 = (int)(720.0 * Math.sin(f2) + 0.5);
            qk.qk_n = n6 + n8;
            sm.sm_d = n7 - n5;
            hl.hl_d = n7 + n5;
            dm.dm_d = -n6 + n8;
            return;
        }
    }

    private final void a(int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        if (n8 != 9918) {
            this.qc_ib = 122;
        }
        hk.f(n3, n5, n7, n4, n6);
        hk.f(n3 + 1, n5 - -1, -2 + n7, -2 + n4, n2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final void a(boolean bl2, int n2, int n3, boolean bl3, boolean bl4) {
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        if (n3 == 1 && bl3) {
            return;
        }
        if (this.qc_m) {
            int n12;
            float f2;
            int n13;
            int n14;
            int[] nArray;
            int n15;
            int n16;
            n11 = ea.D.Ib / 2;
            n10 = this.qc_g.eb_b;
            for (n9 = 0; n9 < n10; ++n9) {
                lk lk2 = this.qc_g.eb_p[n9];
                if (lk2 == null) continue;
                lk lk3 = lk2;
                lk2.J = 0;
                lk3.lk_k = 0;
            }
            if (bl3 && n2 == 0 || n3 == 1) {
                this.qc_e = this.qc_mb;
                this.G = this.D;
                this.qc_tb = this.qc_i;
                an.a(this.V, 0, this.qc_c, 0, n10);
                this.K = this.Ab;
            }
            if (bl3) {
                n9 = this.qc_e;
                n16 = this.G;
                n15 = this.qc_tb;
                nArray = this.qc_c;
                n14 = this.K;
                n8 = this.qc_e >= 512 ? this.qc_tb : this.G;
                n8 %= n10;
                if (n2 == n3 - 1) {
                    this.M = n8;
                }
            } else {
                n9 = this.qc_mb;
                n16 = this.D;
                n15 = this.qc_i;
                nArray = this.V;
                n14 = this.Ab;
                n8 = this.M;
            }
            n7 = n10;
            n6 = n10;
            n5 = n10;
            n4 = n10;
            float f3 = 0.0f;
            for (int k = 0; k < n10; ++k) {
                f3 += this.a(-121, nArray[k]);
            }
            float f4 = (float)n9 * 9.765625E-4f;
            float f5 = this.a(-107, nArray[n16 % n10]);
            float f6 = this.a(-125, nArray[n15 % n10]);
            f4 = 0.5f + ((f4 - 1.0f) * f5 + f4 * f6) * 0.5f;
            float f7 = 0.0f;
            float f8 = 1.0f;
            float f9 = 0.0f;
            float f10 = 0.0f;
            float f11 = 0.0f;
            float f12 = 0.0f;
            float f13 = 0.0f;
            for (n13 = 0; n13 < 10; ++n13) {
                float f14;
                f9 = (f7 + f8) * 0.5f;
                f10 = 0.0f;
                float f15 = 144.0f * (1.0f + (f9 - 1.0f) * f4);
                float f16 = 126.0f * (1.0f + (f9 - 1.0f) * f4);
                float f17 = -1.0f + f4 * 2.0f;
                for (int k = 0; k < n7; ++k) {
                    f14 = this.a(-125, nArray[(n16 - k + n10) % n10]);
                    float f18 = f14;
                    if ((double)(f17 += f18) + 1.0E-4 >= (double)f3) {
                        f12 = f17 - f3;
                        f18 -= f12;
                        n7 = k + 1;
                        n6 = k;
                    }
                    f10 += f15 * f18;
                    f15 *= 1.0f + (f9 - 1.0f) * f18;
                    if (k >= n6) break;
                    f2 = f14;
                    if ((double)(f17 += f2) + 1.0E-4 >= (double)f3) {
                        f12 = f17 - f3;
                        f2 -= f12;
                        n7 = k + 1;
                        n6 = k + 1;
                    }
                    f10 += f16 * f2;
                    f16 *= 1.0f + (f9 - 1.0f) * f2;
                }
                f11 = f10;
                float f19 = 126.0f * (f9 + (1.0f - f9) * f4);
                f14 = 144.0f * (f9 + (1.0f - f9) * f4);
                f17 = 1.0f - f4 * 2.0f;
                for (n12 = 0; n12 < n4; ++n12) {
                    f2 = this.a(-109, nArray[(n16 + 1 + n12) % n10]);
                    float f20 = f2;
                    if ((double)(f17 += f20) + 1.0E-4 >= (double)f3) {
                        f13 = f17 - f3;
                        f20 -= f13;
                        n4 = n12 + 1;
                        n5 = n12;
                    }
                    f11 += f19 * f20;
                    f19 *= 1.0f + (f9 - 1.0f) * f20;
                    if (n12 >= n5) break;
                    float f21 = f2;
                    if ((double)(f17 += f21) + 1.0E-4 >= (double)f3) {
                        f13 = f17 - f3;
                        f21 -= f13;
                        n4 = n12 + 1;
                        n5 = n12 + 1;
                    }
                    f11 += f14 * f21;
                    f14 *= 1.0f + (f9 - 1.0f) * f21;
                }
                if (f11 > 600.0f) {
                    f8 = f9;
                    continue;
                }
                f7 = f9;
            }
            n13 = (int)((640.0f - f11) * 0.5f + f10 + 0.5f);
            int n17 = (n13 - 320) * 10000 / 1000;
            boolean bl5 = n9 >= 512;
            block5: for (int k = 0; k < 2; ++k) {
                int n18;
                int n19;
                int n20;
                int n21;
                int n22;
                lk lk4;
                float f22;
                float f23;
                int n23;
                int n24;
                float f24;
                int n25;
                int n26;
                float f25;
                int n27;
                int n28;
                int n29 = n13;
                int n30 = n17;
                n12 = 10000;
                f2 = 0.0f;
                if (bl5 == (k == 0)) {
                    n28 = n7 - n7 * (n2 + 1) / n3;
                    n27 = n7 - n7 * n2 / n3;
                    f25 = 270.0f * (1.0f + (f9 - 1.0f) * f4);
                    for (n26 = 0; n26 < n7; ++n26) {
                        n25 = (n16 - n26 + n10) % n10;
                        if (nArray[n25] == 0) {
                            me.I[n26] = n30;
                            oe.J[n26] = n12;
                            nk.nk_j[n26] = n30;
                            ua.E[n26] = n12;
                            if (n26 >= n6) continue;
                            l.l_g[n26] = n30;
                            qe.qe_k[n26] = n12;
                            continue;
                        }
                        float f26 = this.a(-122, nArray[n25]);
                        float f27 = f25;
                        float f28 = 2700.0f;
                        if (n26 >= n6) {
                            f27 = f27 * 144.0f / 270.0f;
                            f28 = 1440.0f;
                        }
                        f28 *= f26;
                        n29 -= (int)((f27 *= f26) + 0.5f);
                        me.I[n26] = n30;
                        oe.J[n26] = n12;
                        float f29 = 0.0f;
                        f24 = 1.5707964f;
                        n24 = 0;
                        n23 = 0;
                        for (int i2 = 0; i2 < 10; ++i2) {
                            f2 = (f29 + f24) * 0.5f;
                            n24 = n30 - (int)((double)f28 * Math.cos(f2) + 0.5);
                            int n31 = 320 + n24 * 1000 / (n23 = n12 + (int)((double)f28 * Math.sin(f2) + 0.5));
                            if (n31 >= n29) {
                                f24 = f2;
                                continue;
                            }
                            f29 = f2;
                        }
                        f2 = f29;
                        f22 = f23 = f27 * 128.0f / 270.0f;
                        if (n26 == n6) {
                            f2 *= (1.0f - f12) * (1.0f - f12);
                            f23 *= 1.0f - f12;
                        }
                        nk.nk_j[n26] = n30 -= (int)((double)(1440.0f * f26) * Math.cos(f2) + 0.5);
                        ua.E[n26] = n12 += (int)((double)(1440.0f * f26) * Math.sin(f2) + 0.5);
                        if (n26 < n6) {
                            if (n26 == n7 - 1) {
                                f2 *= (1.0f - f12) * (1.0f - f12);
                                f22 *= 1.0f - f12;
                            }
                            l.l_g[n26] = n30 -= (int)((double)(1260.0f * f26) * Math.cos(f2) + 0.5);
                            qe.qe_k[n26] = n12 += (int)((double)(1260.0f * f26) * Math.sin(f2) + 0.5);
                        }
                        qa.qa_r[n26] = -f2;
                        f25 *= 1.0f + (f9 - 1.0f) * f26;
                        lk4 = this.qc_g.eb_p[n25];
                        if (lk4 == null) continue;
                        n22 = (int)(f23 + 0.5f);
                        dm.dm_d = nk.nk_j[n26];
                        qk.qk_n = me.I[n26];
                        sm.sm_d = ua.E[n26];
                        hl.hl_d = oe.J[n26];
                        this.a(n16 - n26, qa.qa_r[n26], n14, false, nArray, 2);
                        n21 = 128 + (dm.dm_d + qk.qk_n) * 400 / (sm.sm_d + hl.hl_d);
                        if (n21 < 0) {
                            n21 = 0;
                        } else if (n21 > 256) {
                            n21 = 256;
                        }
                        n20 = lk4.lk_k + n22;
                        if (n20 > 0) {
                            lk4.lk_lb = (lk4.lk_lb * lk4.lk_k + n21 * n22 + n20 / 2) / n20;
                        }
                        lk4.lk_k = n20;
                        if (n26 >= n6) continue;
                        n19 = (int)(f22 + 0.5f);
                        dm.dm_d = (l.l_g[n26] + nk.nk_j[n26]) / 2;
                        sm.sm_d = (qe.qe_k[n26] + ua.E[n26]) / 2;
                        this.a((byte)-17, n14, n16 - n26, nArray);
                        n18 = 128 + (dm.dm_d * 400 + sm.sm_d / 2) / sm.sm_d;
                        if (n18 < 0) {
                            n18 = 0;
                        } else if (n18 > 256) {
                            n18 = 256;
                        }
                        n20 = lk4.J + n19;
                        if (n20 > 0) {
                            lk4.lk_sb = (lk4.lk_sb * lk4.J + n18 * n19 + n20 / 2) / n20;
                        }
                        lk4.J = n20;
                    }
                    if (bl4) continue;
                    for (n26 = n7 - 1; n26 >= 0; --n26) {
                        n25 = (n16 - n26 + n10) % n10;
                        if (n3 > 1) {
                            if (bl3) {
                                if (n25 == n8) {
                                    f12 = 0.0f;
                                    continue;
                                }
                                if (n26 >= n27) {
                                    f12 = 0.0f;
                                    continue;
                                }
                                if (n26 < n28) {
                                    continue block5;
                                }
                            } else if (n25 != n8) {
                                f12 = 0.0f;
                                continue;
                            }
                        }
                        lk lk5 = this.qc_g.eb_p[n25];
                        boolean bl6 = false;
                        if (lk5 == null) {
                            lk5 = this.qc_h[n25];
                            bl6 = true;
                        }
                        if (lk5 == null || lk5.U < 0) {
                            f12 = 0.0f;
                            continue;
                        }
                        if (n26 < n6) {
                            int n32 = (int)(f12 * (float)oe.J[n26] * 0.1f);
                            f12 = 0.0f;
                            dm.dm_d = (l.l_g[n26] + nk.nk_j[n26]) / 2 - n32;
                            sm.sm_d = (qe.qe_k[n26] + ua.E[n26]) / 2;
                            this.a((byte)-17, n14, n16 - n26, nArray);
                            this.a(n25, dm.dm_d, 120, n11, sm.sm_d, 4, n14, bl6);
                        }
                        String string = this.qc_g.eb_q[n25];
                        int n33 = (int)(f12 * (float)oe.J[n26] * 0.1f);
                        f12 = 0.0f;
                        dm.dm_d = nk.nk_j[n26] - n33;
                        qk.qk_n = me.I[n26] - n33;
                        sm.sm_d = ua.E[n26];
                        hl.hl_d = oe.J[n26];
                        this.a(n16 - n26, qa.qa_r[n26], n14, bl6, nArray, 2);
                        this.a(qk.qk_n, hl.hl_d, string, (byte)-43, -1500, n11, n25, 1740, dm.dm_d, bl6, sm.sm_d);
                    }
                    continue;
                }
                n28 = n4 - n4 * (n2 + 1) / n3;
                n27 = n4 - n4 * n2 / n3;
                f25 = 270.0f * (f9 + (1.0f - f9) * f4);
                for (n26 = 0; n26 < n4; ++n26) {
                    n25 = (n16 + 1 + n26) % n10;
                    if (nArray[n25] == 0) {
                        l.l_g[n26] = n30;
                        qe.qe_k[n26] = n12;
                        nk.nk_j[n26] = n30;
                        ua.E[n26] = n12;
                        if (n26 >= n5) continue;
                        me.I[n26] = n30;
                        oe.J[n26] = n12;
                        continue;
                    }
                    float f30 = this.a(-113, nArray[n25]);
                    float f31 = f25;
                    float f32 = 2700.0f;
                    if (n26 >= n5) {
                        f31 = f31 * 126.0f / 270.0f;
                        f32 = 1260.0f;
                    }
                    f32 *= f30;
                    n29 += (int)((f31 *= f30) + 0.5f);
                    l.l_g[n26] = n30;
                    qe.qe_k[n26] = n12;
                    float f33 = 0.0f;
                    f24 = 1.5707964f;
                    n24 = 0;
                    n23 = 0;
                    for (int i3 = 0; i3 < 10; ++i3) {
                        f2 = (f33 + f24) * 0.5f;
                        n24 = n30 + (int)((double)f32 * Math.cos(f2) + 0.5);
                        int n34 = 320 + n24 * 1000 / (n23 = n12 + (int)((double)f32 * Math.sin(f2) + 0.5));
                        if (n34 < n29) {
                            f24 = f2;
                            continue;
                        }
                        f33 = f2;
                    }
                    f2 = f33;
                    f22 = f23 = f31 * 128.0f / 270.0f;
                    if (n26 == n5) {
                        f2 *= (1.0f - f13) * (1.0f - f13);
                        f22 *= 1.0f - f13;
                    }
                    nk.nk_j[n26] = n30 += (int)((double)(1260.0f * f30) * Math.cos(f2) + 0.5);
                    ua.E[n26] = n12 += (int)((double)(1260.0f * f30) * Math.sin(f2) + 0.5);
                    if (n26 < n5) {
                        if (n26 == n4 - 1) {
                            f2 *= (1.0f - f13) * (1.0f - f13);
                            f23 *= 1.0f - f13;
                        }
                        me.I[n26] = n30 += (int)((double)(1440.0f * f30) * Math.cos(f2) + 0.5);
                        oe.J[n26] = n12 += (int)((double)(1440.0f * f30) * Math.sin(f2) + 0.5);
                    }
                    qa.qa_r[n26] = f2;
                    f25 *= 1.0f + (f9 - 1.0f) * f30;
                    lk4 = this.qc_g.eb_p[n25];
                    if (lk4 == null) continue;
                    n22 = (int)(f22 + 0.5f);
                    dm.dm_d = (l.l_g[n26] + nk.nk_j[n26]) / 2;
                    sm.sm_d = (qe.qe_k[n26] + ua.E[n26]) / 2;
                    this.a((byte)-17, n14, n16 + 1 + n26, nArray);
                    n21 = 128 + (dm.dm_d * 400 + sm.sm_d / 2) / sm.sm_d;
                    if (n21 < 0) {
                        n21 = 0;
                    } else if (n21 > 256) {
                        n21 = 256;
                    }
                    n20 = lk4.J + n22;
                    if (n20 > 0) {
                        lk4.lk_sb = (lk4.lk_sb * lk4.J + n21 * n22 + n20 / 2) / n20;
                    }
                    lk4.J = n20;
                    if (n26 >= n5) continue;
                    n19 = (int)(f23 + 0.5f);
                    dm.dm_d = nk.nk_j[n26];
                    qk.qk_n = me.I[n26];
                    sm.sm_d = ua.E[n26];
                    hl.hl_d = oe.J[n26];
                    this.a(n16 + 1 + n26, qa.qa_r[n26], n14, false, nArray, 2);
                    n18 = 128 + (dm.dm_d + qk.qk_n) * 400 / (sm.sm_d + hl.hl_d);
                    if (n18 < 0) {
                        n18 = 0;
                    } else if (n18 > 256) {
                        n18 = 256;
                    }
                    n20 = lk4.lk_k + n19;
                    if (n20 > 0) {
                        lk4.lk_lb = (lk4.lk_lb * lk4.lk_k + n18 * n19 + n20 / 2) / n20;
                    }
                    lk4.lk_k = n20;
                }
                if (bl4) continue;
                for (n26 = n4 - 1; n26 >= 0; --n26) {
                    n25 = (n16 + 1 + n26) % n10;
                    if (n3 > 1) {
                        if (bl3) {
                            if (n25 == n8) {
                                f13 = 0.0f;
                                continue;
                            }
                            if (n26 >= n27) {
                                f13 = 0.0f;
                                continue;
                            }
                            if (n26 < n28) {
                                continue block5;
                            }
                        } else if (n25 != n8) {
                            f13 = 0.0f;
                            continue;
                        }
                    }
                    lk lk6 = this.qc_g.eb_p[n25];
                    boolean bl7 = false;
                    if (lk6 == null) {
                        lk6 = this.qc_h[n25];
                        bl7 = true;
                    }
                    if (lk6 == null || lk6.U < 0) {
                        f13 = 0.0f;
                        continue;
                    }
                    if (n26 < n5) {
                        String string = this.qc_g.eb_q[n25];
                        int n35 = (int)(f13 * (float)qe.qe_k[n26] * 0.1f);
                        f13 = 0.0f;
                        dm.dm_d = nk.nk_j[n26] + n35;
                        qk.qk_n = me.I[n26] + n35;
                        sm.sm_d = ua.E[n26];
                        hl.hl_d = oe.J[n26];
                        this.a(n16 + 1 + n26, qa.qa_r[n26], n14, bl7, nArray, 2);
                        this.a(qk.qk_n, hl.hl_d, string, (byte)118, -1500, n11, n25, 1740, dm.dm_d, bl7, sm.sm_d);
                    }
                    int n36 = (int)(f13 * (float)qe.qe_k[n26] * 0.1f);
                    f13 = 0.0f;
                    dm.dm_d = (l.l_g[n26] + nk.nk_j[n26]) / 2 + n36;
                    sm.sm_d = (qe.qe_k[n26] + ua.E[n26]) / 2;
                    this.a((byte)-17, n14, n16 + 1 + n26, nArray);
                    this.a(n25, dm.dm_d, 120, n11, sm.sm_d, 4, n14, bl7);
                }
            }
        } else {
            if (bl3) return;
            if (bl4) {
                return;
            }
            n11 = 240;
            n10 = 50 - this.U;
            n9 = 480 - 480 * n10 * n10 / 2500;
            lk lk7 = this.qc_g.eb_p[0];
            vj vj2 = this.qc_eb[0];
            int n37 = this.qc_qb[0];
            double d = 0.0;
            n7 = (int)(720.0 * Math.cos(d));
            n6 = (int)(720.0 * Math.sin(d));
            this.a(lk7, 10000, -1800, this.Ab, 120, true, n11, this.qc_g.eb_l);
            qc.a(this.qc_g.eb_l, lk7, n11 - n9, -n7, -1500, 10000 - n6, n7, 1740, 10000 + n6, null, null, null, n37, vj2, this.qc_hb, this.y);
        }
        if (bl3) return;
        if (bl4) {
            return;
        }
        this.I = -3;
        if (!this.qc_m) {
            sa sa2;
            int n38;
            n10 = this.qc_wb ? 167 : 127;
            hk.d(447, 61, 150, n10 + 15 + 27, 14676, 87166);
            hk.d(452, 66, 140, n10, 14676, 4427445);
            vk.a(16 + n10 + 15, (byte)50, a.a_n, 171, 50, 437);
            vk.a(45, (byte)50, a.a_n, 171, 66 + n10 + 15 - 13, 437);
            n9 = 66;
            if (this.qc_wb) {
                fl.a(n9 + 16, 256, 0xFFFFFF, re.re_s, 457, se.S);
                this.a(12769767, 457, 22, n9 + 20, 0, 49, 9918);
                kn.a(w.w_kb, (byte)-39, n9 + 36, this.qc_bb + 1 + "/" + 8, 0xFFFFFF, 501);
            } else {
                fl.a(n9 + 16, 256, 0xFFFFFF, qa.qa_u, 457, se.S);
                this.a(12769767, 457, 22, n9 + 20, 0, 49, 9918);
                kn.a(w.w_kb, (byte)-39, n9 + 36, Integer.toString(this.qc_ab + 1), 0xFFFFFF, 501);
            }
            int n39 = this.qc_jb ? 0xFF0000 : 0xFFFFFF;
            kn.a(se.S, (byte)-39, n9 + 16, cc.cc_g.trim(), n39, 587);
            this.a(12769767, 514, 22, n9 + 20, 0, 73, 9918);
            int n40 = this.qc_g.eb_p[0].H + this.qc_g.eb_p[0].x + this.qc_rb;
            kn.a(w.w_kb, (byte)-39, n9 + 36, Integer.toString(n40), n39, 582);
            ed.a(0xFFFFFF, 522, sh.sh_e, (n9 += 40) + 16, (byte)75, se.S);
            this.a(12769767, 457, 22, n9 + 20, 0, 130, 9918);
            for (n38 = 0; n38 < 7; ++n38) {
                if (n38 < this.qc_g.eb_p[0].lk_d) {
                    fb.fb_c[this.qc_g.eb_l][n38].c(459 + n38 * 18, n9 + 22, 18, 18);
                    continue;
                }
                fb.fb_c[this.qc_g.eb_l][n38].c(459 + n38 * 18, n9 + 22, 18, 18, 14676);
            }
            ed.a(0xFFFFFF, 522, md.Y, (n9 += 40) + 16, (byte)75, se.S);
            this.a(12769767, 457, 22, n9 + 20, 0, 130, 9918);
            n38 = this.qc_g.eb_p[0].lk_c;
            if (n38 >= 1) {
                kd.kd_t.c(459, n9 + 22, 18, 18);
                if (bh.bh_g >= 459 && bh.bh_g < 477 && pm.pm_f >= n9 + 22 && pm.pm_f < n9 + 22 + 18) {
                    this.I = 6;
                }
            } else {
                kd.kd_t.c(459, n9 + 22, 18, 18, 14676);
            }
            int n41 = 0;
            if (n38 >= 2) {
                n41 = 2;
            }
            if (n38 >= 3) {
                n41 = 4;
            }
            if (n38 >= 4) {
                n41 = 6;
            }
            for (n8 = 0; n8 < 6; ++n8) {
                if (n8 < n41) {
                    tg.a(true, n8).c(477 + 18 * n8, n9 + 22, 18, 18);
                    if (bh.bh_g < 477 + 18 * n8 || bh.bh_g >= 477 + 18 * n8 + 18 || pm.pm_f < n9 + 22 || pm.pm_f >= n9 + 22 + 18) continue;
                    this.I = n8;
                    continue;
                }
                tg.a(true, n8).c(477 + 18 * n8, n9 + 22, 18, 18, 14676);
            }
            n9 += 40;
            if (this.qc_wb) {
                ed.a(0xFFFFFF, 522, eh.eh_e, n9 + 16, (byte)75, se.S);
                this.a(12769767, 457, 22, n9 + 20, 0, 130, 9918);
                n8 = this.qc_g.eb_p[0].D;
                if (n8 == 0) {
                    fl.a(n9 + 36, 256, 0xFFFFFF, tg.tg_d[4][3], 462, w.w_kb);
                } else {
                    ck ck2 = lf.lf_h[n8 - 1];
                    ck2.d(460, n9 + 24 - 2, 0);
                    ck2.d(462, n9 + 24 - 2, 0);
                    ck2.d(464, n9 + 24 - 2, 0);
                    ck2.d(460, n9 + 24, 0);
                    ck2.d(464, n9 + 24, 0);
                    ck2.d(460, n9 + 24 + 2, 0);
                    ck2.d(462, n9 + 24 + 2, 0);
                    ck2.d(464, n9 + 24 + 2, 0);
                    ck2.c(462, n9 + 24);
                    fl.a(n9 + 36, 256, 0xFFFFFF, tg.tg_d[4][n8 - 1], 462 + ck2.K + 6, w.w_kb);
                }
                n9 += 40;
            }
            if ((sa2 = this.qc_g.eb_p[0].W) != null) {
                this.a(sa2, (byte)119);
            }
            vj vj3 = this.qc_g.eb_p[0].lk_rb;
            sa sa3 = (sa)vj3.b(true);
            while (sa3 != null) {
                this.a(sa3, (byte)115);
                sa sa4 = (sa)vj3.c(true);
            }
            if (this.qc_wb && this.qc_bb < 7 && this.qc_bb != -1) {
                fb.fb_c[this.qc_bb % 8][this.qc_bb % 7].c(452, 66 + n10 + 16, 18, 18);
                fb.fb_c[(this.qc_bb + 1) % 8][(this.qc_bb + 1) % 7].c(574, 66 + n10 + 16, 18, 18);
                this.a(0, 473, 16, 66 + n10 + 17, 12769767, 98, 9918);
                hk.a(476, 66 + n10 + 20, 92, 10, 0);
                hk.b(0, 0, 476 + 92 * this.L / this.b((byte)-122), 480);
                oe.a(92, 10, 0xFFFF00, -1, 0xFF0000, 476, 66 + n10 + 20);
                hk.d();
            } else if (!this.qc_wb) {
                n6 = 3;
                if (id.P > n6) {
                    n6 = id.P;
                }
                fb.fb_c[this.qc_ab % (n6 + 1)][this.qc_ab % 7].c(452, 66 + n10 + 16, 18, 18);
                fb.fb_c[(this.qc_ab + 1) % (n6 + 1)][(this.qc_ab + 1) % 7].c(574, 66 + n10 + 16, 18, 18);
                this.a(0, 473, 16, 66 + n10 + 17, 12769767, 98, 9918);
                hk.a(476, 66 + n10 + 20, 92, 10, 0);
                hk.b(0, 0, 476 + 92 * this.L / this.b((byte)125), 480);
                oe.a(92, 10, 0xFFFF00, -1, 0xFF0000, 476, 66 + n10 + 20);
                hk.d();
            }
            if (this.qc_n > 0) {
                String string;
                n6 = 480 - 480 * this.qc_n * this.qc_n / 2500;
                if (this.qc_wb) {
                    string = b.Q;
                } else if (this.qc_d >= 0) {
                    string = gn.gn_d;
                } else {
                    String string2;
                    string = string2 = cm.a((byte)103, dl.L, new String[]{Integer.toString(this.O + 1)});
                    string = cm.a((byte)119, id.O, new String[]{string2, md.U[this.O]});
                }
                String string3 = this.qc_d >= 0 ? sg.sg_h[this.qc_d] : (this.qc_wb ? uj.uj_f : rk.O)[this.O];
                int n42 = a.a_t.a(string, 164);
                int n43 = se.S.a(string3, 164);
                int n44 = w.w_kb.a(ak.ak_c, 164);
                int n45 = 0;
                if (this.qc_d >= 0 || this.qc_wb) {
                    n45 = 0;
                } else if (this.O == 0) {
                    n45 = 92;
                } else if (this.O == 1) {
                    n45 = 92;
                } else if (this.O == 2) {
                    n45 = 93;
                } else {
                    if (this.O != 3) throw new IllegalStateException();
                    n45 = 92;
                }
                int n46 = 12 + n42 * 16 + 12 + n43 * 16 + 8 + n45 + 8 + n44 * 16 + 14;
                n9 = (480 - n46) / 2 + n6;
                hk.a(224, n9 + 4, 192, n46 - 8, 0, 160);
                vk.a(n46, (byte)50, a.a_n, 200, n9, 220);
                ga.a(164, 0, n9 += 12, string, 16, 180, 0xFFFFFF, a.a_t, (byte)-128, 1, 239);
                ga.a(164, 0, n9 += n42 * 16 + 12, string3, 16, 180, 0xFFFFFF, se.S, (byte)-128, 1, 238);
                n9 += n43 * 16 + 8;
                if (this.qc_d < 0 && !this.qc_wb) {
                    if (this.O == 0) {
                        ri.a(n9, this.S, this.qc_o, -115, 320, this.zb, 0);
                    } else if (this.O == 1) {
                        int n47 = this.S < 80 ? this.S / 20 * 18 : 54;
                        int n48 = 0;
                        if (this.S < 60) {
                            n47 += vl.a(23841, 80, this.qc_o * 18 + 40);
                        } else if (this.S < 80) {
                            n47 += vl.a(23841, 80, this.zb * 18 + 40);
                        } else if (this.S < 93) {
                            n48 = vl.a(23841, 80, ve.ve_ic[this.S - 80 + 1] * 18 + 40);
                        } else {
                            hk.a(281, n9 + 54 - 2, 78, 40, 4, 65280, 100);
                        }
                        for (int k = 0; k < 3; ++k) {
                            fb.fb_c[1][0].c(302 + k * 18, n9 + 72, 18, 18);
                        }
                        fb.fb_c[1][2].c(302, n9 + 54, 18, 18);
                        fb.fb_c[1][2].c(284, n9 + 54, 18, 18);
                        fb.fb_c[1][2].c(284, n9 + 72, 18, 18);
                        kd.kd_t.c(320, n9 + n47 + n48, 18, 18 - n48);
                    } else if (this.O == 2) {
                        fm.a(2, 320, n9, this.qc_o, this.S, 123, this.zb);
                    } else {
                        if (this.O != 3) throw new IllegalStateException();
                        vk.a(this.zb, 320, 3, this.qc_o, this.S, n9, -22981);
                    }
                }
                ga.a(164, 0, n9 += n45 + 8, ak.ak_c, 16, 120, 0xFFFFFF, w.w_kb, (byte)-126, 1, 238);
            }
            if (!this.qc_m) {
                if (this.qc_wb) {
                    n6 = this.qc_j ? 1 : 0;
                    n9 = 66 + n10 + 34;
                } else {
                    n6 = this.qc_u > 0 ? 1 : 0;
                    n9 = 480 - 200 * this.qc_u * this.qc_u / 400;
                }
                if (n6 != 0) {
                    if (this.F == -1) {
                        hk.a(441, n9 + 4, 163, 140, 0, 150);
                        vk.a(148, (byte)50, a.a_n, 171, n9, 437);
                        fc.a(n9 + 10, (byte)5, false, 452);
                    } else if (this.F == -2) {
                        hk.a(441, n9 + 4, 163, 140, 0, 150);
                        vk.a(148, (byte)50, a.a_n, 171, n9, 437);
                        fl.a(n9 + 26, 256, 0xFFFFFF, mb.mb_e, 452, w.w_kb);
                        ga.a(140, 0, n9 + 32, qe.qe_j, 16, 120, 0xFFFFFF, se.S, (byte)-126, 0, 452);
                    } else {
                        hk.a(441, n9 + 4, 163, 140, 0, 150);
                        vk.a(148, (byte)50, a.a_n, 171, n9, 437);
                        ck ck3 = this.F == 6 ? kd.kd_t : tg.a(true, this.F);
                        ck3.c(452, n9 + 14, 18, 18);
                        fl.a(n9 + 28, 256, 0xFFFFFF, nk.nk_d[this.F][0], 474, w.w_kb);
                        ga.a(140, 0, n9 + 34, nk.nk_d[this.F][1], 16, 120, 0xFFFFFF, se.S, (byte)-126, 0, 452);
                    }
                } else if (this.qc_wb) {
                    n5 = se.S.a(jj.jj_d[this.qc_bb], 140);
                    n4 = 32 + n5 * 16 + 13;
                    hk.a(441, n9 + 4, 163, n4 - 8, 0, 150);
                    vk.a(n4, (byte)50, a.a_n, 171, n9, 437);
                    fl.a(n9 + 26, 256, 0xFFFFFF, cm.a((byte)102, client.E, new String[]{Integer.toString(this.qc_bb + 1)}), 452, w.w_kb);
                    ga.a(140, 0, n9 + 32, jj.jj_d[this.qc_bb], 16, 120, 0xFFFFFF, se.S, (byte)-126, 0, 452);
                }
            }
        }
        if (this.qc_g.eb_j && !this.qc_m) {
            this.d(24);
        }
        if (this.qc_m && this.qc_pb > 0) {
            this.d(this.qc_pb, 104, this.z.a(-1));
        } else if (this.e(-20459)) {
            this.d(0, 105, 0);
        }
        in in2 = (in)this.qc_p.c((byte)55);
        if (in2 != null) {
            n9 = this.qc_g.eb_j && in2.bh_b == this.qc_p.vj_c ? 1 : 0;
            in2.a(1000, 1, n11, 320, n9 != 0, this.qc_g.eb_l, this.qc_f);
        }
        if (this.qc_m) {
            int n49;
            int n50;
            n9 = nf.nf_b && bl2 || bg.bg_b > 0 && (uf.A & 0x10) == 0 ? 1 : 0;
            int n51 = tm.tm_c;
            if (this.Ab >= 50) {
                n50 = 0;
                n49 = 100 - this.Ab;
            } else {
                n50 = 320 - tm.tm_c / 2;
                n49 = this.Ab;
            }
            n49 = 28 * n49 * n49 / 2500;
            this.a(n51, (byte)123, n9 != 0, n50, ea.D.Ib - 28 + n49);
            int n52 = n9 != 0 ? 0xFFFFFF : 16694016;
            fl.a(ea.D.Ib - 6 + n49, 256, n52, hh.hh_b, n50 + 16 + 1, a.a_t);
            if (this.qc_g.eb_d != 0 && !this.qc_g.eb_j) {
                int n53 = 0;
                String string = null;
                for (n6 = 0; n6 < this.qc_g.eb_b; ++n6) {
                    if ((this.qc_g.eb_d & 1 << n6) == 0 || this.qc_g.eb_p[n6] == null || this.qc_g.eb_p[n6].lk_jb <= 0) continue;
                    if (n53 == 0) {
                        string = this.qc_g.eb_q[n6];
                    }
                    ++n53;
                }
                string = n53 == 1 ? ((this.qc_g.eb_d & 1 << this.P) != 0 ? sg.sg_g : cm.a((byte)89, cd.cd_j, new String[]{string})) : cm.a((byte)120, we.we_e, new String[]{Integer.toString(n53)});
                if (this.P >= 0 && (this.qc_g.eb_d & 1 << this.P) == 0 && this.qc_g.eb_p[this.P] != null && this.qc_g.eb_p[this.P].lk_jb > 0) {
                    string = string + cg.cg_b;
                }
                n6 = se.S.a(string);
                hk.a(636 - n6 - 4, 4, 4 + n6 + 100, 21, 3, 0, 200);
                se.S.c(string, 636, 19, 0xFFFFFF, -1);
            }
        }
        if (this.z != null) {
            this.z.a(ea.D.Ib / 2, (byte)-54);
        }
        if (this.qc_k > 0) {
            this.a(640 - this.qc_k * this.qc_k * 640 / 100, (byte)83);
        }
        if (this.qc_cb > 0) {
            ed.a(16694016, 960 - this.qc_cb * this.qc_cb * 640 / 100, ub.ub_b, -95 + ea.D.Ib / 2, (byte)75, hn.hn_g);
        }
        if (this.qc_a <= 0) return;
        ed.a(16694016, 960 - this.qc_a * this.qc_a * 640 / 100, ui.ui_o, -95 + ea.D.Ib / 2, (byte)75, hn.hn_g);
    }

    final void d(byte by) {
        if (by != -68) {
            this.qc_j = false;
        }
        this.qc_b = true;
        if (this.qc_wb) {
            this.b(0, -1, 0);
        } else {
            int n2 = this.qc_ab;
            if (rk.O.length + -1 < n2) {
                n2 = rk.O.length + -1;
            }
            int n3 = -1;
            if (this.X) {
                if (-1 == ~n2) {
                    n3 = 0;
                }
                if (~n2 == -4) {
                    n3 = 1;
                }
            }
            this.b(0, n3, n2);
        }
    }

    private static final void a(int n2, lk lk2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, uk uk2, int[] nArray, int n14, int n15, int n16) {
        int n17;
        int n18;
        int n19;
        pi pi2;
        int n20;
        int n21;
        int n22;
        int n23;
        int n24;
        int n25;
        int n26;
        int n27;
        int n28 = 0;
        if (n15 > 0 && n15 >= (n28 = 38 - n11 * 25 / lk2.lk_a)) {
            n2 = n16;
        }
        if (uk2 != null && n10 >= 0 && n10 < lk2.O && n11 < lk2.lk_a) {
            return;
        }
        int n29 = n9;
        int n30 = -n7;
        int n31 = lk2.a(n10, 126, n11);
        int n32 = (n31 & 0x18) >> 3;
        int n33 = n31 >> 5;
        int n34 = lk2.lk_ib;
        if (n31 == 0 && (n33 = lk2.b(n10, (byte)107, n11)) != 0) {
            n34 = 1;
        }
        ck ck2 = null;
        ck ck3 = null;
        ck ck4 = null;
        ck[] ckArray = null;
        ck ck5 = null;
        pi pi3 = null;
        int n35 = 0;
        boolean bl2 = false;
        boolean bl3 = false;
        int n36 = 2;
        int n37 = 1;
        int n38 = Math.abs(n9);
        int n39 = 0;
        int n40 = 0;
        if (n33 != 0 && (n34 == 1 || n34 == 2)) {
            ck2 = (n32 == 3 ? qf.qf_h : oa.oa_b)[n33 - 1 >> 1];
        } else {
            if (n33 != 0) {
                n40 = n39 = ve.ve_ic[n33];
                if (n32 == 2 || n32 == 3) {
                    for (n27 = (n11 + 1) * lk2.O + n10; n27 < lk2.O * lk2.lk_a && (n26 = lk2.P[n27] >> 5) != 0; n27 += lk2.O) {
                        n40 += ve.ve_ic[n26];
                    }
                }
            }
            if (n32 != 0 && n15 < n28 && n15 >= n28 - oa.oa_b.length * 2) {
                ck3 = oa.oa_b[n28 - 1 - n15 >> 1];
            }
            if (n15 >= n28 || n15 < n28 - oa.oa_b.length) {
                if (n32 == 1) {
                    if (((lk2.a(n10 - 1, 119, n11) ^ n31) & 0x1F) == 0) {
                        ++n35;
                    }
                    if (((lk2.a(n10 + 1, 82, n11) ^ n31) & 0x1F) == 0) {
                        n35 += 2;
                    }
                    if (((lk2.a(n10, 84, n11 - 1) ^ n31) & 0x1F) == 0) {
                        n35 += 4;
                    }
                    if (((lk2.a(n10, -97, n11 + 1) ^ n31) & 0x1F) == 0) {
                        n35 += 8;
                    }
                    ckArray = ob.ob_j[n2][n31 & 7];
                    pi3 = gf.gf_f[n35];
                } else if (n32 == 2) {
                    ck2 = fb.fb_c[n2][n31 & 7];
                } else if (n32 == 3) {
                    ck2 = tg.a(true, n31 & 7);
                }
            }
        }
        n27 = lk2.a(n11, (byte)105, n10);
        n26 = n27 + n40;
        int n41 = n27 + n40 - n39;
        if (nArray == null) {
            pi[] piArray;
            ck[] ckArray2;
            ck[] ckArray3;
            if (n10 == -1 && n11 >= n13 && n11 < lk2.lk_a + 1) {
                ckArray3 = uj.uj_d[n2];
                if (ckArray3 != null) {
                    ck4 = ckArray3[ckArray3.length - 2 - (lk2.lk_a - 1 - n11) % (ckArray3.length - 1)];
                    n36 = 6;
                    n37 = 2;
                    bl3 = true;
                    ckArray3 = bb.bb_a[n2];
                    if (ckArray3 != null) {
                        ck5 = ckArray3[ckArray3.length - 2 - (lk2.lk_a - 1 - n11) % (ckArray3.length - 1)];
                    }
                }
                if ((ckArray2 = hf.hf_e[n2]) != null) {
                    ck2 = ckArray2[ckArray2.length - 2 - (lk2.lk_a - 1 - n11) % (ckArray2.length - 1)];
                }
                if ((piArray = cc.cc_f[n2]) != null) {
                    pi3 = piArray[piArray.length - 2 - (lk2.lk_a - 1 - n11) % (piArray.length - 1)];
                }
            }
            if (n10 == lk2.O && n11 >= n13 && n11 < lk2.lk_a + 1) {
                ckArray3 = rb.rb_d[n2];
                if (ckArray3 != null) {
                    ck4 = ckArray3[ckArray3.length - 2 - (lk2.lk_a - 1 - n11) % (ckArray3.length - 1)];
                    n36 = 6;
                    n37 = 2;
                    bl3 = true;
                    ckArray3 = dg.dg_d[n2];
                    if (ckArray3 != null) {
                        ck5 = ckArray3[ckArray3.length - 2 - (lk2.lk_a - 1 - n11) % (ckArray3.length - 1)];
                    }
                }
                if ((ckArray2 = rb.rb_j[n2]) != null) {
                    ck2 = ckArray2[ckArray2.length - 2 - (lk2.lk_a - 1 - n11) % (ckArray2.length - 1)];
                }
                if ((piArray = sc.sc_j[n2]) != null) {
                    pi3 = piArray[piArray.length - 2 - (lk2.lk_a - 1 - n11) % (piArray.length - 1)];
                }
            }
            if (n11 == lk2.lk_a && n10 >= 0 && n10 < lk2.O) {
                ckArray3 = ad.ad_j[n2];
                if (ckArray3 != null) {
                    ck4 = ckArray3[n10 % ckArray3.length];
                    n36 = 6;
                    n37 = 2;
                    bl3 = true;
                }
                if ((ckArray2 = bh.bh_d[n2]) != null) {
                    ck4 = ckArray2[n10 % ckArray2.length];
                    bl2 = true;
                    n36 = 6;
                    n37 = 2;
                }
                if ((piArray = fk.G[n2]) != null) {
                    pi3 = piArray[n10 % piArray.length];
                }
            }
        }
        if (nArray != null) {
            int n42 = 0;
            if (n10 >= 0 && n10 < lk2.O && n11 >= 0 && n11 < lk2.lk_a) {
                n42 = nArray[n11 * lk2.O + n10];
            }
            if (n42 == 0) {
                n42 = nArray[lk2.O * lk2.lk_a];
            }
            byte by = (byte)n42;
            byte by2 = (byte)(n42 >> 8);
            n25 = n42 >>> 16;
            n24 = n25 * n14;
            n23 = n24 * by / (lk2.lk_a * 4);
            n22 = n24 * by2 / (lk2.lk_a * 4);
            n21 = (n23 * n7 + n24 * n9) / 1440;
            n20 = (n23 * n9 - n24 * n7) / 1440;
            n4 += n21;
            n5 += n22;
            n6 += n20;
        }
        if (uk2 != null && (pi2 = uk2.uk_q[(n11 - uk2.uk_u) * uk2.A + (n10 - uk2.uk_r)]) != null) {
            if (pi2 == me.J) {
                return;
            }
            if (pi3 == null) {
                pi3 = pi2;
            } else {
                for (int k = 0; k < 1296; ++k) {
                    d.d_e.pi_k[k] = (byte)(pi3.pi_k[k] & pi2.pi_k[k]);
                }
                pi3 = d.d_e;
            }
        }
        if (ck4 != null || ckArray != null) {
            int n43;
            int n44;
            int n45;
            int n46;
            int n47;
            n36 = n38 > n7 ? n37 + ((n36 - n37) * n7 + n38 / 2) / n38 : n37 + ((n36 - n37) * n38 + n7 / 2) / n7;
            int n48 = -n36;
            if (ck5 == null) {
                ck5 = ck4;
            }
            if (n9 > n7) {
                n48 = n36 + 1;
                if (bl3) {
                    n48 = n36;
                }
                for (int k = n36; k >= 0; --k) {
                    int n49 = lk2.O * n36 * 2;
                    n25 = n4 + ((n10 * n7 * n36 + k * n7) * 2 - n29 * n36) / n49;
                    n24 = n4 + ((n10 * n7 * n36 + k * n7) * 2 + n29 * n36) / n49;
                    n23 = n5 + (n11 * 80 + n26) * n8 / (lk2.lk_a * 80);
                    n22 = n5 + ((n11 + 1) * 80 + n41) * n8 / (lk2.lk_a * 80);
                    n21 = n6 + ((n10 * n9 * n36 + k * n9) * 2 - n30 * n36) / n49;
                    n20 = n6 + ((n10 * n9 * n36 + k * n9) * 2 + n30 * n36) / n49;
                    if (n21 < 500 || n20 < 500) continue;
                    n19 = 320 + n25 * 1000 / n21;
                    n18 = 320 + n24 * 1000 / n20;
                    n17 = n3 + n23 * 1000 / n21;
                    n47 = n3 + n23 * 1000 / n20;
                    n46 = n3 + n22 * 1000 / n21;
                    n45 = n3 + n22 * 1000 / n20;
                    if (ckArray != null) {
                        ck5 = ckArray[k == 0 ? n35 & 0xC : n35];
                    }
                    n44 = 0;
                    if (!bl3) {
                        n44 = k * ck5.K / n36;
                    }
                    n43 = -1;
                    if (bl3) {
                        n43 = (k * 2 + 1) * ck5.K / ((n36 + 1) * 2);
                    }
                    cg.a(ck5, pi3, n19, n18, n17, n47, n46, n45, bl3 || !bl2 && k == 0, false, n44, n43);
                }
            }
            if (n9 < -n7) {
                n48 = n36 + 1;
                if (bl3) {
                    n48 = n36;
                }
                for (int k = 0; k <= n36; ++k) {
                    int n50 = lk2.O * n36 * 2;
                    n25 = n4 + ((n10 * n7 * n36 + k * n7) * 2 + n29 * n36) / n50;
                    n24 = n4 + ((n10 * n7 * n36 + k * n7) * 2 - n29 * n36) / n50;
                    n23 = n5 + (n11 * 80 + n26) * n8 / (lk2.lk_a * 80);
                    n22 = n5 + ((n11 + 1) * 80 + n41) * n8 / (lk2.lk_a * 80);
                    n21 = n6 + ((n10 * n9 * n36 + k * n9) * 2 + n30 * n36) / n50;
                    n20 = n6 + ((n10 * n9 * n36 + k * n9) * 2 - n30 * n36) / n50;
                    if (n21 < 500 || n20 < 500) continue;
                    n19 = 320 + n25 * 1000 / n21;
                    n18 = 320 + n24 * 1000 / n20;
                    n17 = n3 + n23 * 1000 / n21;
                    n47 = n3 + n23 * 1000 / n20;
                    n46 = n3 + n22 * 1000 / n21;
                    n45 = n3 + n22 * 1000 / n20;
                    if (ckArray != null) {
                        ck5 = ckArray[k == n36 ? n35 & 0xC : n35];
                    }
                    n44 = 0;
                    if (!bl3) {
                        n44 = k * ck5.K / n36;
                    }
                    n43 = -1;
                    if (bl3) {
                        n43 = (k * 2 + 1) * ck5.K / ((n36 + 1) * 2);
                    }
                    cg.a(ck5, pi3, n19, n18, n17, n47, n46, n45, bl3 || !bl2 && k == n36, false, n44, n43);
                }
            }
            for (int k = n48; k <= n36; k += 2) {
                int n51 = k;
                n25 = k;
                n24 = lk2.O * n36 * 2;
                n23 = n4 + (n10 * n7 * n36 * 2 + n29 * n51) / n24;
                n22 = n4 + ((n10 + 1) * n7 * n36 * 2 + n29 * n25) / n24;
                n21 = n5 + (n11 * 80 + n26) * n8 / (lk2.lk_a * 80);
                n20 = n5 + ((n11 + 1) * 80 + n41) * n8 / (lk2.lk_a * 80);
                n19 = n6 + (n10 * n9 * n36 * 2 + n30 * n51) / n24;
                n18 = n6 + ((n10 + 1) * n9 * n36 * 2 + n30 * n25) / n24;
                if (n19 < 500 || n18 < 500) continue;
                n17 = 320 + n23 * 1000 / n19;
                n47 = 320 + n22 * 1000 / n18;
                n46 = n3 + n21 * 1000 / n19;
                n45 = n3 + n21 * 1000 / n18;
                n44 = n3 + n20 * 1000 / n19;
                n43 = n3 + n20 * 1000 / n18;
                if (ckArray != null) {
                    ck4 = ckArray[k == n36 ? n35 : n35 & 0xC];
                }
                int n52 = 0;
                if (!bl2) {
                    if (n10 < n12) {
                        n52 = (n36 - k) * ck4.K / (n36 * 2);
                    }
                    if (n10 > n12) {
                        n52 = (n36 + k) * ck4.K / (n36 * 2);
                    }
                }
                int n53 = -1;
                if (bl2) {
                    n53 = (n36 + 1 + k) * ck4.K / ((n36 + 1) * 2);
                }
                cg.a(ck4, pi3, n17, n47, n46, n45, n44, n43, !bl2 && k < n36, false, n52, n53);
            }
        }
        while (ck2 != null || ck3 != null) {
            if (ck2 == null) {
                ck2 = ck3;
                ck3 = null;
                pi3 = null;
            }
            int n54 = n10 * 4 + 2;
            int n55 = n7 / lk2.O;
            int n56 = n9 / lk2.O;
            if (n54 < 0) {
                ++n54;
                n55 /= 2;
            }
            if (n54 > lk2.O * 4) {
                --n54;
                n55 /= 2;
            }
            n25 = n4 + n54 * n7 / (lk2.O * 4);
            n24 = n5 + (n11 * 80 + n26) * n8 / (lk2.lk_a * 80);
            n23 = n5 + ((n11 + 1) * 80 + n41) * n8 / (lk2.lk_a * 80);
            n22 = n6 + n54 * n9 / (lk2.O * 4);
            if (n22 >= 500) {
                n21 = 640 + n25 * 2000 / n22;
                n20 = n3 + n24 * 1000 / n22;
                n19 = n3 + n23 * 1000 / n22;
                n18 = ((int)(Math.sqrt(n55 * n55 + n56 * n56) + 0.5) * 1000 + n22 / 2) / n22;
                if (pi3 != null) {
                    for (n17 = 0; n17 < 1296; ++n17) {
                        mf.O.D[n17] = pi3.pi_k[n17] != 0 ? ck2.D[n17] : 0;
                    }
                    ck2 = mf.O;
                }
                ck2.c(n21 - n18 >> 1, n20, n18, n19 - n20);
            }
            ck2 = null;
        }
    }

    private final int b(byte by) {
        if (!this.qc_wb && this.qc_g.eb_p[0].lk_a > this.qc_g.eb_p[0].Z) {
            return 50;
        }
        int n2 = -74 / ((63 - by) / 36);
        if (this.qc_wb && this.qc_bb < 2) {
            return 3000;
        }
        if (this.qc_wb && -5 < ~this.qc_bb) {
            return 6000;
        }
        if (this.qc_wb) {
            if (7 <= this.qc_bb) {
                return 0;
            }
            return 144;
        }
        return 0;
    }

    private final void a(int n2, boolean bl2, int n3, int n4, int n5, int n6, lk lk2) {
        int n7;
        int n8;
        boolean bl3 = client.A;
        int n9 = lk2.R;
        if (n9 > 88) {
            n9 = 88;
        }
        if (bl2) {
            return;
        }
        int n10 = n9 * (n9 * 35) / 7744 + n9 * 35 / 88;
        lm lm2 = hn.hn_g;
        int n11 = lm2.a(lk2.lk_vb);
        if (!this.qc_m) {
            n8 = (n5 + -n4) * (lk2.lk_eb + 88) / 176 + n4;
            n8 -= n11 / 2;
        } else {
            n7 = n4 - -((-n4 + n5) * ((!qd.Qb ? 16 : 160) + lk2.lk_eb) / 176);
            if (qd.Qb) {
                n7 -= n11;
            }
            int n12 = n4 + (n5 - n4) * (88 - -lk2.lk_eb) / 176;
            float f2 = this.a(n6, !bl2);
            n8 = (int)(f2 * (float)(n12 - n7) + 0.5f) + n7;
        }
        n7 = (n3 + -n2) * (lk2.lk_n + (592 + -n10)) / 702 + n2;
        if (88 <= lk2.R) {
            ck ck2 = oa.oa_b[(lk2.R - 88) / 2];
            int n13 = n11 / 27;
            if (n13 < 2) {
                ck2.c(n11 / 2 + (n8 - 13), -13 + n7, 27, 27);
            } else {
                int n14 = 0;
                while (~n14 > ~n13) {
                    ck2.c((-27 + n11) * n14 / (n13 - 1) + n8, n7 + -13, 27, 27);
                    ++n14;
                }
            }
        } else {
            lm2.a(lk2.lk_vb, n8 - 1, n7 + 6, 0, -1);
            lm2.a(lk2.lk_vb, 1 + n8, -1 + n7 + 7, 0, -1);
            lm2.a(lk2.lk_vb, -1 + n8, 7 + n7 + 1, 0, -1);
            lm2.a(lk2.lk_vb, 1 + n8, 1 + (n7 - -7), 0, -1);
            lm2.a(lk2.lk_vb, n8, n7 + 7, lk2.xb, -1);
        }
    }

    final void a(boolean bl2, lk lk2, int n2, int n3, int n4, int n5, boolean bl3) {
        block6: {
            boolean bl4 = client.A;
            while (~this.B[n5] < ~n4) {
                int n6 = n5;
                this.B[n6] = this.B[n6] - 1;
                if (bl3 || ~this.B[n5] == -1) {
                    ge.a(lk2.lk_lb, lk2.lk_k / 2, (byte)127, ha.Pb[this.B[n5]]);
                }
                if (~this.B[n5] == -3) {
                    this.qc_eb[n5] = qn.a(4, -4, 0, 3000, 9, 16, 9, 60);
                }
                if (-2 == ~this.B[n5]) {
                    bk.a((byte)-93, 500, this.qc_eb[n5]);
                }
                if (0 != this.B[n5]) continue;
                vj vj2 = this.qc_eb[n5];
                uk uk2 = (uk)vj2.c((byte)-115);
                while (null != uk2) {
                    int n7 = uk2.A + uk2.uk_r * 2 - 16;
                    int n8 = uk2.uk_t + (uk2.uk_u * 2 - -4);
                    int n9 = ka.a((byte)114, 1 + n2 - n3, tf.tf_cb) + n3;
                    uk2.uk_o = -((n8 * n8 + n7 * n7) * n9 / 2592) + n9;
                    uk2 = (uk)vj2.d(true);
                }
                ql.a(vj2, -116, vj2.a((byte)124));
                if (this.qc_m) continue;
                this.qc_g.eb_j = true;
                this.c(false);
                in in2 = new in(ua.D, 10, false);
                this.qc_p.a(in2, 2777);
                this.qc_pb = 0;
                this.qc_ib = 128;
                if (this.qc_wb && ~this.qc_bb <= -7) {
                    this.a(hb.Ub, 0);
                    continue;
                }
                this.a(rm.rm_b, 0);
            }
            if (bl2) break block6;
            this.qc_lb = -124;
        }
    }

    private final float a(int n2, boolean bl2) {
        block0: {
            if (bl2) break block0;
            this.qc_u = 11;
        }
        return (3.0E-4f - (float)n2 * 2.0E-6f) * (float)n2 * (float)n2;
    }

    private final void a(lk lk2, int n2, int n3, int n4, int n5, boolean bl2, int n6, int n7) {
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        int n14;
        int n15;
        int n16;
        boolean bl3 = client.A;
        int n17 = -1890 + n5;
        int n18 = n5 + 1620;
        int n19 = ((-n17 + n18) * 176 - -702) / 1404;
        int n20 = n3 - n19;
        int n21 = n19 + n3;
        int n22 = 320 - -vl.a(23841, n2, n20 * 1000 - -(n2 / 2));
        int n23 = vl.a(23841, n2, 1000 * n21 + n2 / 2) + 320;
        int n24 = n6 - -vl.a(23841, n2, 1000 * n17 + n2 / 2);
        int n25 = n6 + vl.a(23841, n2, 1000 * n18 - -(n2 / 2));
        boolean bl4 = lk2.S && 0 < lk2.lk_jb;
        boolean bl5 = -1 == ~lk2.lk_t && !bl4;
        boolean bl6 = lk2.e(68);
        if (!bl5) {
            aa.aa_e.c(n22, n24, -n22 + n23, n25 - n24);
        } else {
            jc.jc_f.c(n22, n24, -n22 + n23, n25 - n24);
        }
        if (bl6) {
            e.e_b.c(n22, n24, n23 + -n22, -n24 + n25);
        } else {
            cd.cd_k.c(n22, n24, -n22 + n23, n25 - n24);
        }
        u.u_h.c(n22, n24, n23 - n22, -n24 + n25);
        if (!bl2) {
            pi pi2 = null;
            qc.a(null, 116, -39, 60, -104, 82, -73, 38, 43, 29, null, pi2, true);
        }
        int n26 = lk2.yb & 0xF;
        int n27 = lk2.yb >> 1952986660;
        fb.fb_c[n7][n26].d((n23 - n22) * 52 / 176 + n22, n24 + 56 * (n25 + -n24) / 702, 36 * (n23 + -n22) / 176, 36 * (-n24 + n25) / 702, !bl5 ? 192 : 256);
        fb.fb_c[n7][n27].d(n22 + (n23 - n22) * 88 / 176, 56 * (n25 - n24) / 702 + n24, 36 * (-n22 + n23) / 176, (n25 - n24) * 36 / 702, !bl5 ? 192 : 256);
        hk.b(gk.Cb);
        int n28 = n22 - -((n23 - n22) * 10 / 176);
        int n29 = n22 + 166 * (-n22 + n23) / 176;
        int n30 = n24 + (-n24 + n25) * 115 / 702;
        int n31 = n24 + 677 * (-n24 + n25) / 702;
        hk.f(n28, n30, n29, n31);
        te.te_w = 0;
        int n32 = 0;
        while (~lk2.lk_t < ~n32) {
            rf rf2;
            n16 = uf.A;
            double d2 = 1.9634954084936207 * (double)(lk2.lk_m + n32 & 0xF) + 0.04908738521234052 * (double)(n16 & 0x7F);
            double d3 = Math.sin(d2);
            double d4 = Math.cos(d2);
            rf rf3 = rf2 = lk2.X[n32];
            if (null != rf3.rf_c) {
                n15 = rf3.rf_b;
                n14 = rf3.rf_n;
                n13 = 0;
                int n33 = 6144;
                n12 = 17408;
                if (0 < rf3.rf_l && ~rf3.rf_l > -11) {
                    n12 += -(18432 * ((-rf3.rf_l + 10) * rf3.rf_l) / 100);
                }
                if ((n12 /= n15 - -1) < n33) {
                    n33 = n12;
                }
                if (n33 > (n11 = 33792 / n14)) {
                    n33 = n11;
                }
                n10 = 0;
                while (~n10 > ~n14) {
                    for (n9 = 0; n9 < n15; ++n9) {
                        int n34;
                        if (0 == (n34 = 0xFF & rf2.rf_c[n13++])) continue;
                        if (~rf3.rf_e < -1) {
                            n34 = -rf3.rf_e;
                        }
                        int n35 = (int)Math.floor((double)n33 * ((double)(n9 + 1) * d3) + 0.5);
                        int n36 = 8192 * rf3.rf_l + n33 * (n10 + -n14);
                        int n37 = (int)Math.floor((double)n33 * ((double)(1 + n9) * d4) * 256.0);
                        hg.a(114, n35, n34, n33, n37, n36);
                    }
                    ++n10;
                }
            }
            ++n32;
        }
        wc.a(te.te_w, 0, -32186);
        int n38 = uf.A;
        double d5 = 0.04908738521234052 * (double)(0x7F & n38) + 29.45243112740431;
        double d6 = Math.sin(d5);
        double d7 = Math.cos(d5);
        n32 = (int)Math.floor(0.5 + 4096.0 * d6);
        n16 = (int)Math.floor(256.0 * (d7 * 4096.0));
        n38 = n8 = 0;
        int n39 = 0;
        while (-3 < ~n39) {
            ck ck2;
            int n40;
            int n41;
            int n42;
            while (~te.te_w < ~n8 && (-1 != ~n39 || ~n16 >= ~(n42 = gn.gn_e[3 + n8]))) {
                n42 = gn.gn_e[n8];
                int n43 = gn.gn_e[1 + n8];
                n41 = gn.gn_e[2 + n8];
                int n44 = gn.gn_e[4 + n8];
                n40 = n22 + (-n22 + n23) * (n43 + 22528 - n44 / 2) / 45056;
                n15 = (n23 + -n22) * (22528 + (n44 / 2 + n43)) / 45056 + n22;
                n14 = (n25 - n24) * (n41 + 65536) / 179712 + n24;
                n13 = n24 - -((-n24 + n25) * (65536 + (n44 - -n41)) / 179712);
                ck2 = n42 >= 0 ? (~(n42 >> 168107715) == -4 ? tg.a(true, 7 & n42) : fb.fb_c[n7][n42 & 7]) : oa.oa_b[~n42 >> 1241913985];
                ck2.c(n40, n14, -n40 + n15, n13 - n14);
                n8 += 5;
            }
            if (~n39 == -1 && lk2.lk_pb > 0) {
                n42 = ((vd)lk2.lk_cb.c((byte)101)).vd_p;
                int n45 = lk2.lk_pb;
                n41 = 18 - n45;
                if (~n41 > -1) {
                    n41 = 0;
                }
                int n46 = -8192 - -(n41 * 8192);
                n40 = (-n22 + n23) * (n32 + 14336) / 45056 + n22;
                n15 = n22 - -((n32 + 30720) * (-n22 + n23) / 45056);
                n14 = (57344 - -n46) * (n25 - n24) / 179712 + n24;
                n13 = (-n24 + n25) * (73728 + n46) / 179712 + n24;
                if (~n45 < -323) {
                    ck2 = oa.oa_b[-1 + n45 + -322 >> -260984831];
                    ck2.c(n40, n14, n15 - n40, -n14 + n13);
                } else {
                    ck2 = uf.y[n42];
                    ck2.a(n40, n14, -n40 + n15, n13 - n14);
                }
            }
            ++n39;
        }
        hk.a(gk.Cb);
        if (null != lk2.lk_vb) {
            this.a(n24, !bl2, n25, n22, n23, n4, lk2);
        }
        bb.bb_c.b(n22, n24, -n22 + n23, n25 + -n24, 192);
        bn.bn_e.c(n22, n24, n23 + -n22, n25 + -n24);
        ln.ln_c.c(n22, n24, n23 + -n22, -n24 + n25);
        uf.uf_w.c(n22, n24, n23 + -n22, n25 + -n24);
        ca.ca_qb.c(n22, n24, n23 + -n22, n25 - n24);
        if (lk2.lk_pb > 0) {
            n39 = ((vd)lk2.lk_cb.c((byte)100)).vd_p;
            int n47 = lk2.lk_pb;
            if (~n47 < -19) {
                String string = qk.qk_s[n39];
                int n48 = (n22 - -n23) / 2;
                int n49 = -84 * (n47 * n47) / 335 + 150080;
                n49 = n24 - -(n49 * (-n24 + n25) / 235170);
                if (~n47 >= -323) {
                    ga.a(88, 1, -500 + n49, string, 16, 1000, 0xFFFFFF, a.a_t, (byte)-128, 1, n48 - 44);
                } else {
                    ck ck3 = oa.oa_b[-1 + (-322 + n47) >> -1753530271];
                    n15 = a.a_t.b(string, 88);
                    n14 = a.a_t.b(string, 88, 16);
                    n13 = n15 / 18;
                    int n50 = n14 / 18;
                    n12 = 0;
                    while (~n12 > ~n50) {
                        n11 = n49;
                        if (~n50 <= -3) {
                            n11 = n49 + -(n14 / 2) + n12 * (-18 + n14) / (-1 + n50);
                        }
                        n10 = 0;
                        while (~n13 < ~n10) {
                            n9 = n48;
                            if (n13 >= 2) {
                                n9 = n10 * (n15 + -18) / (n13 + -1) + n48 - n15 / 2;
                            }
                            ck3.c(n9, n11, 18, 18);
                            ++n10;
                        }
                        ++n12;
                    }
                }
            }
        }
    }

    private final void a(sa sa2, byte by) {
        int n2 = 248 + 144 * sa2.sa_u / 2048;
        int n3 = sa2.D * 326 / 4608 + 89;
        int n4 = this.Q - sa2.z;
        int n5 = sa2.sa_v - sa2.z;
        if (by < 79) {
            this.B = null;
        }
        if (~n5 < -1) {
            n4 *= n4;
            n5 *= n5;
            n3 += (-n3 + 97) * n4 / n5;
            n2 += (555 - n2) * n4 / n5;
        }
        int n6 = !sa2.sa_q ? 12 : 18;
        lm lm2 = sa2.sa_q ? hn.hn_g : a.a_t;
        int n7 = sa2.sa_q ? 7 : 5;
        n2 -= lm2.a(sa2.sa_r) / 2;
        if (null != sa2.sa_o) {
            sa2.sa_o.c(-1 + (-(4 * n6 / 3) + (n2 += n6 * 2 / 3)), -(n6 / 2) + n3, n6, n6, sa2.sa_s);
            sa2.sa_o.c(1 + (-(4 * n6 / 3) + n2), -(n6 / 2) + n3, n6, n6, sa2.sa_s);
            sa2.sa_o.c(-(n6 * 4 / 3) + n2, n3 + (-(n6 / 2) + -1), n6, n6, sa2.sa_s);
            sa2.sa_o.c(-(4 * n6 / 3) + n2, 1 + -(n6 / 2) + n3, n6, n6, sa2.sa_s);
            sa2.sa_o.c(-(n6 * 4 / 3) + n2, -(n6 / 2) + n3, n6, n6);
        }
        lm2.a(sa2.sa_r, -1 + n2, n3 - (-n7 + 1), 0, -1);
        lm2.a(sa2.sa_r, n2 - -1, n7 + (n3 - 1), 0, -1);
        lm2.a(sa2.sa_r, -1 + n2, 1 + n3 - -n7, 0, -1);
        lm2.a(sa2.sa_r, n2 - -1, 1 + (n7 + n3), 0, -1);
        lm2.a(j.a("<b>", sa2.sa_r, "<col=FFFFFF>", 0), n2, n3 - -n7, sa2.sa_s, -1);
    }

    private final void d(int n2, int n3, int n4) {
        int n5;
        String string;
        String string2;
        int n6;
        boolean bl2 = client.A;
        hk.a(0, 0, 640, 480, 65793, n2);
        int n7 = ea.D.Ib / 2 - 100;
        hk.a(n4 + 145, n7, 350, 177, 0, 160);
        vk.a(197, (byte)50, a.a_n, 370, n7 - 10, n4 + 135);
        fl.a(n7 - -17, 256, 16694016, ub.ub_e, 152 - -n4, w.w_kb);
        hk.g(n4 + 300, 4 + n7, 170, 263172);
        hk.g(n4 + 301, n7 + 4, 170, 0x606060);
        ed.a(16694016, 353 + n4, tf.tf_ab, 17 + n7, (byte)75, w.w_kb);
        hk.g(406 + n4, 4 + n7, 170, 263172);
        hk.g(n4 + 407, n7 - -4, 170, 0x606060);
        ed.a(16694016, 450 + n4, p.p_d, n7 + 17, (byte)75, w.w_kb);
        hk.a(152 + n4, 22 + n7, 336, 263172);
        hk.a(n4 + 152, n7 - -23, 336, 0x606060);
        n7 += 25;
        if (n3 <= 90) {
            return;
        }
        for (n6 = 0; n6 < this.qc_g.eb_p.length; ++n6) {
            if (null == this.qc_g.eb_p[n6] || ~this.qc_g.eb_p[n6].lk_jb >= -1 || (this.qc_g.eb_h & 1 << n6) != 0) continue;
            string2 = eg.eg_a;
            string = "-";
            if (this.qc_g.eb_j) {
                if (~this.qc_g.eb_e == ~n6) {
                    string2 = oi.oi_e;
                    string = gd.a(false, kd.kd_p, 1, 1);
                } else {
                    string2 = oi.oi_b;
                }
            }
            this.a(n4, string2, n7, 107, 0xFFFFFF, string, n6);
            n7 += 18;
        }
        hk.a(152 - -n4, 1 + n7, 336, 263172);
        hk.a(152 - -n4, 2 + n7, 336, 0x606060);
        n7 += 4;
        n7 += (-1 + this.qc_g.eb_o) * 18;
        n6 = n5 = 0;
        while (~n5 > ~this.qc_g.eb_o) {
            String string3;
            string2 = string3 = gd.a(false, kd.kd_p, 1, -n5 + this.qc_g.eb_b);
            string = wl.wl_s;
            if (~(1 << this.qc_g.eb_f[n5] & this.qc_g.eb_h) != -1) {
                string = v.v_f;
            }
            this.a(n4, string, n7, 62, 0xB0B0B0, string3, this.qc_g.eb_f[n5]);
            n7 -= 18;
            ++n5;
        }
    }

    private final void a(int n2, int n3, String string, byte by, int n4, int n5, int n6, int n7, int n8, boolean bl2, int n9) {
        boolean bl3 = client.A;
        int n10 = -95 / ((by - 76) / 35);
        vj vj2 = this.qc_eb[n6];
        int n11 = this.qc_qb[n6];
        if (!bl2) {
            qc.a(this.qc_g.eb_l, this.qc_g.eb_p[n6], n5, n8, n4, n9, n2, n7, n3, string, null, null, n11, vj2, this.qc_hb, this.y);
        } else {
            lk lk2 = this.qc_h[n6];
            vj vj3 = this.Z[n6];
            int[] nArray = this.qc_gb[n6];
            int n12 = n2 + -n8;
            int n13 = n3 + -n9;
            uk uk2 = (uk)vj3.c((byte)-78);
            while (null != uk2) {
                int n14 = 2 * uk2.uk_r - (-uk2.A - -lk2.O);
                int n15 = -lk2.lk_a + (uk2.uk_t + 2 * uk2.uk_u);
                int n16 = n11 * uk2.uk_o;
                int n17 = n16 * n14 / (lk2.lk_a * 4);
                int n18 = n16 * n15 / (4 * lk2.lk_a);
                int n19 = (n17 * n12 - -(n16 * n13)) / 1440;
                int n20 = (-(n16 * n12) + n17 * n13) / 1440;
                qc.a(this.qc_g.eb_l, lk2, n5, n19 + n8, n18 + n4, n9 + n20, n19 + n2, n18 + n7, n3 + n20, string, uk2, null, 0, null, this.qc_hb, this.y);
                uk2 = (uk)vj3.d(true);
            }
            qc.a(this.qc_g.eb_l, lk2, n5, n8, n4, n9, n2, n7, n3, string, null, nArray, n11, vj2, this.qc_hb, this.y);
        }
    }

    qc(boolean bl2, int n2, boolean bl3, int n3, int n4, int n5, int n6, String[] stringArray, int n7, boolean bl4, boolean bl5, boolean bl6) {
        block7: {
            int n8;
            int n9;
            this.qc_jb = false;
            this.qc_p = new vj();
            this.H = -1;
            this.qc_u = 0;
            this.xb = false;
            this.Q = 0;
            this.qc_hb = 0;
            this.qc_ub = 0;
            this.qc_wb = true;
            this.U = 50;
            this.qc_pb = 0;
            this.I = -3;
            this.qc_n = 0;
            this.J = false;
            this.qc_ib = 0;
            this.qc_f = 0;
            this.qc_d = -1;
            this.qc_t = n6;
            this.qc_wb = bl5;
            this.X = bl6;
            this.P = n7;
            this.W = bl4;
            this.A = n5;
            this.qc_m = bl2;
            this.x = n4;
            this.T = n3;
            rk.rk_cb = 255;
            fb.fb_e = 100;
            he.he_ab = 144;
            fh.fh_h = 480;
            this.qc_g = new eb(n2, bl3, n3, n4, n5, n6, stringArray);
            if (~this.P <= -1) {
                this.qc_g.eb_p[this.P].lk_kb = true;
                this.qc_g.eb_p[this.P].lk_cb = new vj();
            }
            if (this.qc_m) {
                this.qc_db = new oi(32);
                this.qc_v = new lb[this.qc_g.eb_b];
                this.qc_nb = new byte[20];
                n9 = 0;
                while (~n9 > ~this.qc_g.eb_b) {
                    this.qc_v[n9] = new lb();
                    this.qc_v[n9].lb_g = new vj();
                    ++n9;
                }
                this.qc_h = new lk[this.qc_g.eb_b];
                this.qc_c = new int[this.qc_g.eb_b];
                this.V = new int[this.qc_g.eb_b];
                this.qc_gb = new int[this.qc_g.eb_b][];
                this.Z = new vj[this.qc_g.eb_b];
            }
            this.qc_eb = new vj[this.qc_g.eb_b];
            this.B = new int[this.qc_g.eb_b];
            n9 = n8 = 0;
            while (this.qc_g.eb_b > n8) {
                this.B[n8] = this.qc_g.eb_p[n8].lk_jb;
                ++n8;
            }
            this.qc_qb = new int[this.qc_g.eb_b];
            this.a(false, 0, 1, false, true);
            if (this.qc_m) break block7;
            this.qc_g.eb_p[0].lk_rb = new vj();
            this.qc_g.eb_p[0].lk_u = new ee(l.c(4));
            rf rf2 = lc.b(0, 0, this.qc_g.eb_p[0].m(26580));
            int n10 = this.qc_g.eb_p[0].m(26580);
            this.E = n10 * 7 + -4;
            this.qc_g.eb_p[0].a(84, n10, rf2);
            if (this.qc_wb) {
                this.qc_b = id.P < 4;
            } else {
                boolean bl7 = this.qc_b = id.P < 3;
            }
            if (this.qc_b) {
                this.b(0, !this.X ? -1 : 0, 0);
            }
        }
    }

    static {
        Y = 360;
        qc_l = "Who can join";
    }
}
