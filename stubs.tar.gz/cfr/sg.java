/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Frame;

final class sg {
    static String[] sg_j = new String[]{"Connecting to update server", "Verbinde mit Aktualisierungsserver", "Connexion au serveur de mise \u00e0 jour", "Conectando ao servidor de atualiza\u00e7\u00e3o", "Met updateserver verbinden", "Connecting to update server (untranslated)"};
    static String sg_g;
    String sg_f;
    static int[] sg_d;
    String sg_i;
    static w sg_e;
    static String[] sg_h;
    boolean sg_c;
    static String[] sg_a;
    static ck sg_b;

    static final String a(String string, String string2, int n, byte by) {
        if (by <= 122) {
            return null;
        }
        if (!dc.a(string, (byte)-70)) {
            return ge.ge_d;
        }
        if (~jj.jj_b != -3) {
            return be.be_s;
        }
        wb wb2 = g.a(-3805, string2);
        if (wb2 == null) {
            return cm.a((byte)97, ii.ii_r, new String[]{string2});
        }
        wb2.b((byte)109);
        wb2.e((byte)74);
        --ed.ed_g;
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n2 = uf2.wl_n;
        uf2.a(true, 3);
        uf2.a(0, string);
        uf2.b(uf2.wl_n - n2, true);
        return null;
    }

    public static void a(int n) {
        sg_e = null;
        sg_b = null;
        if (n != 3) {
            String string = null;
            sg.a(null, string, 114, (byte)124);
        }
        sg_j = null;
        sg_a = null;
        sg_h = null;
        sg_g = null;
        sg_d = null;
    }

    static final ql a(int n, fd fd2, int n2, int n3, int n4, int n5) {
        Frame frame;
        if (n4 < 54) {
            fd fd3 = null;
            sg.a(-76, fd3, 0, 22, 26, 93);
        }
        if ((frame = jh.a(n5, fd2, n, n2, false, n3)) == null) {
            return null;
        }
        ql ql2 = new ql();
        ql2.ql_g = frame;
        ql2.ql_g.add(ql2);
        ql2.setBounds(0, 0, n, n5);
        ql2.addFocusListener(ql2);
        ql2.requestFocus();
        return ql2;
    }

    static final void a(String[][] stringArray, boolean bl, byte[] byArray, ji ji2, int[] nArray, byte by, String[][] stringArray2, String[] stringArray3, int n, byte[] byArray2, pi[] piArray, int[] nArray2, int n2, ji ji3, String[] stringArray4, ji ji4, ck[][] ckArray, ck[][] ckArray2, int n3) {
        if (by > -2) {
            sg.a(null, 4, -122L);
        }
        hb.a(byArray2, 1, piArray, ji2, stringArray3, 3, n2, ji3, stringArray2, ckArray2, bl, nArray, ckArray, byArray, stringArray, ji4, n3, stringArray4, nArray2, null);
    }

    sg() {
    }

    static final boolean a(String string, int n, long l) {
        wb wb2 = ed.a(string, (byte)16);
        if (n <= 111) {
            sg_e = null;
        }
        if (null != wb2 && wb2.Vb != null) {
            return true;
        }
        return cd.cd_m != null && bj.a(l, (byte)50) != null;
    }

    static {
        sg_h = new String[]{"Before playing a multiplayer game, please learn the ropes by completing the first 3 stages of Stamina Mode. It will only take a few minutes.", "Congratulations! The multiplayer game is now unlocked.<br><br>If you wish, you can continue playing Stamina Mode, or you can end this game any time and enter the multiplayer lobby. Press 'ESC' for the Options Menu."};
        sg_a = new String[3];
        sg_g = "You are offering to draw.";
    }
}
