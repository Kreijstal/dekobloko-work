/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;
import java.awt.Component;
import java.awt.Graphics;

final class dk
extends Canvas {
    private Component dk_e;
    static int dk_a;
    static int dk_g;
    static int dk_i;
    static int dk_c;
    static ck dk_h;
    static String[] dk_j;
    static String dk_f;
    static String dk_b;
    static String dk_d;

    @Override
    public final void update(Graphics graphics) {
        this.dk_e.update(graphics);
    }

    dk(Component component) {
        this.dk_e = component;
    }

    static final void a(int n2) {
        boolean bl = client.A;
        uf uf2 = de.V;
        int n3 = uf2.d((byte)-36);
        if (n3 == 0) {
            int[] nArray;
            int[] nArray2 = nArray = b.h(56);
            Object object = nArray;
            uf uf3 = uf2;
            int n4 = uf3.d((byte)-116);
            int n5 = 0;
            while (~n4 < ~n5) {
                nArray2[n5] = uf3.i(7553);
                ++n5;
            }
            object = (f)rc.rc_e.c((byte)92);
            if (object == null) {
                si.a(95);
                return;
            }
            ((f)object).f_u = true;
            ((f)object).f_t = nArray;
            ((bh)object).b((byte)112);
        } else if (~n3 != -2) {
            if (n3 != 2) {
                qb.a(null, 16408, "A1: " + qk.d((byte)89));
                si.a(90);
            } else {
                f f2;
                f f3 = f2 = (f)rc.rc_e.c((byte)-64);
                if (f2 == null) {
                    si.a(115);
                    return;
                }
                f2.f_t = b.h(109);
                f2.f_u = true;
                f2.b((byte)119);
            }
        } else {
            ki ki2 = (ki)cg.cg_c.c((byte)-66);
            if (null == ki2) {
                si.a(127);
                return;
            }
            ki2.b((byte)106);
        }
        int n6 = 17 % ((-81 - n2) / 35);
    }

    public static void b(int n2) {
        if (n2 != 16057) {
            return;
        }
        dk_h = null;
        dk_j = null;
        dk_b = null;
        dk_d = null;
        dk_f = null;
    }

    @Override
    public final void paint(Graphics graphics) {
        this.dk_e.paint(graphics);
    }

    static {
        dk_f = "Some special items will sit in your bucket until you activate them. To activate one, pop a shape next to it.";
        dk_b = "Invite only";
        dk_j = new String[]{"Move back to the previous menu level.", "Return to the top level of the menu.", "Auto-respond to the last thing in your chat window.", "Open the Quick Chat menu.", "Repeat the last thing you said.", "Close the Quick Chat menu."};
        le.a((byte)125, 50);
        dk_d = "Hide game chat";
    }
}
