/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;

abstract class eh {
    int eh_g;
    int[] eh_f;
    int eh_i;
    Image eh_c;
    static jc eh_b = new jc();
    static boolean[][] eh_h;
    static String eh_e;
    static String eh_d;
    static ni eh_j;
    static int eh_a;

    final void a(byte by) {
        if (by > -82) {
            this.a((byte)23);
        }
        hk.a(this.eh_f, this.eh_g, this.eh_i);
    }

    abstract void a(int var1, byte var2, int var3, Component var4);

    static final void a(byte by, byte[] byArray) {
        int n;
        wl wl2;
        boolean bl = client.A;
        if (by != -72) {
            eh_a = 89;
        }
        wl wl3 = wl2 = new wl(byArray);
        wl3.wl_n = -2 + byArray.length;
        ec.ec_g = wl3.e(3);
        da.da_d = new boolean[ec.ec_g];
        sg.sg_d = new int[ec.ec_g];
        fh.fh_a = new int[ec.ec_g];
        tm.tm_a = new int[ec.ec_g];
        hc.hc_c = new int[ec.ec_g];
        pd.pd_e = new byte[ec.ec_g][];
        tc.Nb = new byte[ec.ec_g][];
        wl3.wl_n = -(ec.ec_g * 8) + (byArray.length - 7);
        ed.ed_f = wl3.e(3);
        i.i_d = wl3.e(3);
        int n2 = 1 + (wl3.d((byte)-104) & 0xFF);
        for (n = 0; n < ec.ec_g; ++n) {
            sg.sg_d[n] = wl2.e(qm.b(by, -69));
        }
        for (n = 0; ec.ec_g > n; ++n) {
            fh.fh_a[n] = wl2.e(qm.b(by, -69));
        }
        for (n = 0; n < ec.ec_g; ++n) {
            tm.tm_a[n] = wl2.e(3);
        }
        for (n = 0; ec.ec_g > n; ++n) {
            hc.hc_c[n] = wl2.e(3);
        }
        wl3.wl_n = -(3 * (n2 + -1)) + (byArray.length - (7 + ec.ec_g * 8));
        mb.mb_d = new int[n2];
        n = 1;
        while (~n2 < ~n) {
            mb.mb_d[n] = wl2.h(by + 65352);
            if (0 == mb.mb_d[n]) {
                mb.mb_d[n] = 1;
            }
            ++n;
        }
        wl3.wl_n = 0;
        for (n = 0; ec.ec_g > n; ++n) {
            int n3;
            int n4;
            int n5 = tm.tm_a[n];
            int n6 = hc.hc_c[n];
            int n7 = n5 * n6;
            byte[] byArray2 = new byte[n7];
            tc.Nb[n] = byArray2;
            byte[] byArray3 = new byte[n7];
            pd.pd_e[n] = byArray3;
            boolean bl2 = false;
            int n8 = wl3.d((byte)-35);
            if ((n8 & 1) == 0) {
                n4 = 0;
                while (~n7 < ~n4) {
                    byArray2[n4] = wl2.g((byte)-127);
                    ++n4;
                }
                if (~(n8 & 2) != -1) {
                    for (n4 = 0; n4 < n7; ++n4) {
                        byArray3[n4] = wl2.g((byte)-119);
                        n3 = byArray3[n4];
                        bl2 |= ~n3 != 0;
                    }
                }
            } else {
                for (n4 = 0; n5 > n4; ++n4) {
                    for (n3 = 0; n3 < n6; ++n3) {
                        byArray2[n3 * n5 + n4] = wl2.g((byte)-124);
                    }
                }
                if ((2 & n8) != 0) {
                    for (n4 = 0; n5 > n4; ++n4) {
                        for (n3 = 0; n6 > n3; ++n3) {
                            byte by2 = wl2.g((byte)-115);
                            byArray3[n4 + n3 * n5] = by2;
                            byte by3 = by2;
                            bl2 |= -1 != by3;
                        }
                    }
                }
            }
            da.da_d[n] = bl2;
        }
    }

    abstract void a(byte var1, Graphics var2, int var3, int var4);

    eh() {
    }

    public static void a(int n) {
        block0: {
            eh_e = null;
            eh_d = null;
            eh_h = null;
            eh_b = null;
            eh_j = null;
            if (n == 24744) break block0;
            eh.a(125);
        }
    }

    static {
        eh_e = "Shape feedback:";
    }
}
