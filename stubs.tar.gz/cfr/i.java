/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

final class i {
    static String i_g;
    static vj i_b;
    static String i_f;
    static String i_a;
    static int i_c;
    static int i_d;
    static w i_e;

    i() {
    }

    static final int a(int n) {
        if (n != 1) {
            return -83;
        }
        return ql.ql_c;
    }

    public static void b(int n) {
        i_g = null;
        i_e = null;
        i_b = null;
        i_f = null;
        if (n != 28180) {
            return;
        }
        i_a = null;
    }

    static final void a(wl wl2, int n) {
        byte[] byArray;
        boolean bl = client.A;
        byte[] byArray2 = byArray = new byte[24];
        if (dj.dj_cb == null) {
            wl2.a(false, 24, byArray, n);
        } else {
            try {
                dj.dj_cb.a(0L, (byte)-109);
                dj.dj_cb.a(byArray, (byte)-76);
                int n2 = 0;
                while (-25 < ~n2 && -1 == ~byArray[n2]) {
                    ++n2;
                }
                if (n2 >= 24) {
                    throw new IOException();
                }
            }
            catch (Exception exception) {
                int n3 = 0;
                while (~n3 > -25) {
                    byArray[n3] = (byte)-1;
                    ++n3;
                }
            }
            wl2.a(false, 24, byArray, n);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final byte[] a(byte[] byArray, int n) {
        wl wl2 = new wl(byArray);
        int n2 = wl2.d((byte)-119);
        int n3 = -11 / ((-4 - n) / 59);
        int n4 = wl2.i(7553);
        if (n4 < 0 || ad.ad_u != 0 && ~n4 < ~ad.ad_u) {
            throw new RuntimeException();
        }
        if (~n2 != -1) {
            int n5 = wl2.i(7553);
            if (n5 < 0 || -1 != ~ad.ad_u && ad.ad_u < n5) {
                throw new RuntimeException();
            }
            byte[] byArray2 = new byte[n5];
            if (1 == n2) {
                td.a(byArray2, n5, byArray, n4, 9);
            } else {
                lf lf2 = jf.jf_g;
                synchronized (lf2) {
                    jf.jf_g.a((byte)111, wl2, byArray2);
                }
            }
            return byArray2;
        }
        byte[] byArray3 = new byte[n4];
        wl2.a(byArray3, 0, (byte)126, n4);
        return byArray3;
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    static {
        i_a = "As you are under 13, we won't save your email address on our systems. Your email address will still be used to log in, but you won't recieve any emails from Jagex. For more information, please check the relevant parts of our <%0><hotspot=0>Terms and Conditions</hotspot><%1> and <%0><hotspot=1>Privacy Policy</hotspot><%1>.";
        i_f = "Create a free Account";
        i_g = "Accept";
    }
}
