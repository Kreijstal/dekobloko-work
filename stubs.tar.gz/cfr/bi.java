/*
 * Decompiled with CFR 0.152.
 */
final class bi {
    private kj[] bi_b = new kj[10];
    private int bi_c;
    private int bi_a;

    private final byte[] a() {
        int n;
        int n2 = 0;
        for (n = 0; n < 10; ++n) {
            if (this.bi_b[n] == null || this.bi_b[n].kj_r + this.bi_b[n].kj_h <= n2) continue;
            n2 = this.bi_b[n].kj_r + this.bi_b[n].kj_h;
        }
        if (n2 == 0) {
            return new byte[0];
        }
        n = 22050 * n2 / 1000;
        byte[] byArray = new byte[n];
        for (int i = 0; i < 10; ++i) {
            if (this.bi_b[i] == null) continue;
            int n3 = this.bi_b[i].kj_r * 22050 / 1000;
            int n4 = this.bi_b[i].kj_h * 22050 / 1000;
            int[] nArray = this.bi_b[i].a(n3, this.bi_b[i].kj_r);
            for (int j = 0; j < n3; ++j) {
                int n5 = byArray[j + n4] + (nArray[j] >> 8);
                if ((n5 + 128 & 0xFFFFFF00) != 0) {
                    n5 = n5 >> 31 ^ 0x7F;
                }
                byArray[j + n4] = (byte)n5;
            }
        }
        return byArray;
    }

    final ud b() {
        byte[] byArray = this.a();
        return new ud(22050, byArray, 22050 * this.bi_c / 1000, 22050 * this.bi_a / 1000);
    }

    private bi(wl wl2) {
        for (int i = 0; i < 10; ++i) {
            int n = wl2.d((byte)-82);
            if (n == 0) continue;
            --wl2.wl_n;
            this.bi_b[i] = new kj();
            this.bi_b[i].a(wl2);
        }
        this.bi_c = wl2.e(3);
        this.bi_a = wl2.e(3);
    }

    static final bi a(ji ji2, int n, int n2) {
        byte[] byArray = ji2.a(n2, 76, n);
        if (byArray == null) {
            return null;
        }
        return new bi(new wl(byArray));
    }
}
