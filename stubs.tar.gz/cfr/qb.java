/*
 * Decompiled with CFR 0.152.
 */
import java.io.DataInputStream;
import java.io.IOException;
import java.net.URL;

final class qb
extends dd {
    static im qb_r;
    static String qb_t;
    private qk qb_v;
    static ln qb_s;
    static ck qb_q;
    static int qb_u;
    static w qb_p;

    @Override
    final void d(byte by) {
        block1: {
            if (by < 107) {
                this.d((byte)12);
            }
            if (null == this.qb_v) break block1;
            this.qb_v.a(0);
        }
    }

    @Override
    final void a(Object object, byte by, boolean bl) {
        pj pj2;
        boolean bl2 = client.A;
        if (null != this.qb_v) {
            try {
                this.qb_v.a(0);
            }
            catch (Exception exception) {
                // empty catch block
            }
            this.qb_v = null;
        }
        this.qb_v = (qk)object;
        this.e((byte)-15);
        this.a((byte)-124, bl);
        int n = -84 % ((by - -75) / 50);
        this.dd_h = null;
        this.dd_c.wl_n = 0;
        while (null != (pj2 = (pj)this.dd_g.a((byte)-111))) {
            this.dd_d.a(pj2, -7267);
        }
        while (null != (pj2 = (pj)this.dd_l.a((byte)-71))) {
            this.dd_n.a(pj2, -7267);
        }
        if (0 != this.dd_f) {
            try {
                this.dd_i.wl_n = 0;
                this.dd_i.a(true, 4);
                this.dd_i.a(true, (int)this.dd_f);
                this.dd_i.a(0, false);
                this.qb_v.a(0, this.dd_i.wl_r.length, 1, this.dd_i.wl_r);
            }
            catch (IOException iOException) {
                try {
                    this.qb_v.a(0);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                ++this.dd_j;
                this.dd_o = -2;
                this.qb_v = null;
            }
        }
        this.dd_b = 0;
        this.dd_e = ik.a(4);
    }

    private final void a(byte by, boolean bl) {
        if (null == this.qb_v) {
            return;
        }
        try {
            this.dd_i.wl_n = 0;
            this.dd_i.a(true, bl ? 2 : 3);
            if (by >= -108) {
                return;
            }
            this.dd_i.a(-93, 0L);
            this.qb_v.a(0, this.dd_i.wl_r.length, 1, this.dd_i.wl_r);
        }
        catch (IOException iOException) {
            try {
                this.qb_v.a(0);
            }
            catch (Exception exception) {
                // empty catch block
            }
            ++this.dd_j;
            this.dd_o = -2;
            this.qb_v = null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static final int a(boolean bl2, int n, jg jg2, int n2, int n3, jg jg3, String string) {
        int n4;
        int n5;
        boolean bl3 = client.A;
        String string2 = jg2.a((byte)56);
        int n6 = -65 / ((-58 - n2) / 43);
        String string3 = jg3.a((byte)56);
        if (null == qc.qc_s && !mb.a(false, -75)) {
            return -1;
        }
        if (ph.xb == ba.ba_f) {
            wb.Ub = null;
            we.we_b.wl_n = 0;
            if (string != null) {
                n5 = 0;
                if (bl2) {
                    n5 |= 1;
                }
                vi.A.wl_n = 0;
                vi.A.a(gg.A.nextInt(), false);
                vi.A.a(gg.A.nextInt(), false);
                vi.A.b(8, string2);
                vi.A.b(8, string3);
                vi.A.b(8, bc.a(string, 65));
                vi.A.d(-1, n3);
                vi.A.a(true, n);
                vi.A.a(true, n5);
                we.we_b.a(true, 18);
                we.we_b.wl_n += 2;
                n4 = we.we_b.wl_n;
                String string4 = a.a(se.h(25144), (byte)121);
                if (string4 == null) {
                    string4 = "";
                }
                we.we_b.a(0, string4);
                re.a(uk.uk_p, ea.ea_k, we.we_b, vi.A, 0);
                we.we_b.b(true, -n4 + we.we_b.wl_n);
            } else {
                vi.A.wl_n = 0;
                vi.A.a(gg.A.nextInt(), false);
                vi.A.a(gg.A.nextInt(), false);
                vi.A.b(8, jg2.a(true) ? string2 : "");
                vi.A.b(8, !jg3.a(true) ? "" : string3);
                we.we_b.a(true, 16);
                ++we.we_b.wl_n;
                n5 = we.we_b.wl_n;
                re.a(uk.uk_p, ea.ea_k, we.we_b, vi.A, 0);
                we.we_b.b(-n5 + we.we_b.wl_n, true);
            }
            wj.c(4792, -1);
            ph.xb = kb.kb_c;
        }
        if (kb.kb_c == ph.xb && pe.b(25973, 1)) {
            n5 = de.V.d((byte)-70);
            de.V.wl_n = 0;
            if (n5 < 100 || ~n5 < -106) {
                if (n5 == 248) {
                    jg.a(se.h(25144), 0);
                    rk.Y = tj.tj_ic;
                    si.a(89);
                    jd.Qb = false;
                    return n5;
                }
                if (99 != n5) {
                    sm.sm_e = -1;
                    bh.bh_k = n5;
                    ph.xb = rb.rb_f;
                } else {
                    pe.b(25973, vi.d(1));
                    wb.Ub = new Boolean(f.a(de.V, 19));
                    de.V.wl_n = 0;
                }
            } else {
                ph.xb = ll.ll_a;
                ph.Eb = new String[-100 + n5];
            }
        }
        if (ph.xb == ll.ll_a && pe.b(25973, n5 = 2)) {
            n4 = de.V.e(3);
            de.V.wl_n = 0;
            if (pe.b(25973, n4)) {
                int n7 = ph.Eb.length;
                int n8 = 0;
                while (true) {
                    if (~n7 >= ~n8) {
                        si.a(60);
                        jd.Qb = false;
                        return n7 + 100;
                    }
                    ph.Eb[n8] = de.V.b(true);
                    ++n8;
                }
            }
        }
        if (rb.rb_f == ph.xb && fh.a((byte)117)) {
            if (255 != bh.bh_k) {
                rk.Y = de.V.c((byte)-38);
            } else {
                String string5 = de.V.c(-16829);
                if (null != string5) {
                    a.a(string5, false, se.h(25144));
                }
            }
            si.a(105);
            jd.Qb = false;
            return bh.bh_k;
        }
        if (null != qc.qc_s) {
            return -1;
        }
        if (!jd.Qb) {
            n5 = hc.hc_a;
            hc.hc_a = ef.P;
            jd.Qb = true;
            ef.P = n5;
            return -1;
        }
        rk.Y = 30000L >= sl.a(-1) ? re.re_u : kh.kh_f;
        jd.Qb = false;
        return 249;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    final boolean a(byte by) {
        int n;
        boolean bl2 = client.A;
        if (null != this.qb_v) {
            long l = ik.a(by ^ 0xFFFFFFCC);
            n = (int)(-this.dd_e + l);
            if (200 < n) {
                n = 200;
            }
            this.dd_e = l;
            this.dd_b += n;
            if (-30001 > ~this.dd_b) {
                try {
                    this.qb_v.a(0);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                this.qb_v = null;
            }
        }
        if (null == this.qb_v) {
            return this.c((byte)-114) == 0 && this.c(by ^ 0xFFFFFFC8) == 0;
        }
        try {
            this.qb_v.b((byte)-124);
            pj pj2 = (pj)this.dd_d.b(-2198);
            while (pj2 != null) {
                this.dd_i.wl_n = 0;
                this.dd_i.a(true, 1);
                this.dd_i.a(-71, pj2.be_r);
                this.qb_v.a(0, this.dd_i.wl_r.length, 1, this.dd_i.wl_r);
                this.dd_g.a(pj2, -7267);
                pj2 = (pj)this.dd_d.b((byte)20);
            }
            if (by != -56) {
                return false;
            }
            pj2 = (pj)this.dd_n.b(-2198);
            while (null != pj2) {
                this.dd_i.wl_n = 0;
                this.dd_i.a(true, 0);
                this.dd_i.a(-98, pj2.be_r);
                this.qb_v.a(0, this.dd_i.wl_r.length, 1, this.dd_i.wl_r);
                this.dd_l.a(pj2, -7267);
                pj2 = (pj)this.dd_n.b((byte)20);
            }
            int n2 = 0;
            while (~n2 > -101) {
                int n3;
                int n4;
                int n5;
                int n6 = this.qb_v.b(0);
                if (-1 < ~n6) {
                    throw new IOException();
                }
                if (-1 == ~n6) {
                    return true;
                }
                this.dd_b = 0;
                n = 0;
                if (null == this.dd_h) {
                    n = 10;
                } else if (0 == this.dd_h.K) {
                    n = 1;
                }
                if (~n < -1) {
                    n5 = -this.dd_c.wl_n + n;
                    if (~n5 < ~n6) {
                        n5 = n6;
                    }
                    this.qb_v.a(n5, this.dd_c.wl_n, (byte)17, this.dd_c.wl_r);
                    if (~this.dd_f != -1) {
                        n4 = 0;
                        while (~n5 < ~n4) {
                            this.dd_c.wl_r[this.dd_c.wl_n - -n4] = (byte)qm.b(this.dd_c.wl_r[this.dd_c.wl_n + n4], this.dd_f);
                            ++n4;
                        }
                    }
                    this.dd_c.wl_n += n5;
                    if (~this.dd_c.wl_n <= ~n) {
                        if (this.dd_h == null) {
                            this.dd_c.wl_n = 0;
                            n4 = this.dd_c.d((byte)-48);
                            n3 = this.dd_c.i(7553);
                            int n7 = this.dd_c.d((byte)-99);
                            int n8 = this.dd_c.i(7553);
                            int n9 = 0x7F & n7;
                            boolean bl3 = 0 != (0x80 & n7);
                            long l = (long)n3 + ((long)n4 << -1415245088);
                            pj pj3 = null;
                            if (bl3) {
                                pj3 = (pj)this.dd_l.b(by + -2142);
                                while (pj3 != null && pj3.be_r != l) {
                                    pj3 = (pj)this.dd_l.b((byte)20);
                                }
                            } else {
                                pj3 = (pj)this.dd_g.b(-2198);
                                while (pj3 != null && (pj3.be_r ^ 0xFFFFFFFFFFFFFFFFL) != (l ^ 0xFFFFFFFFFFFFFFFFL)) {
                                    pj3 = (pj)this.dd_g.b((byte)20);
                                }
                            }
                            if (pj3 == null) {
                                throw new IOException();
                            }
                            int n10 = n9 != 0 ? 9 : 5;
                            this.dd_h = pj3;
                            this.dd_h.J = new wl(n8 - -n10 - -this.dd_h.M);
                            this.dd_h.J.a(true, n9);
                            this.dd_h.J.a(n8, false);
                            this.dd_h.K = 10;
                            this.dd_c.wl_n = 0;
                        } else {
                            if (0 != this.dd_h.K) throw new IOException();
                            if (-1 == this.dd_c.wl_r[0]) {
                                this.dd_h.K = 1;
                                this.dd_c.wl_n = 0;
                            } else {
                                this.dd_h = null;
                            }
                        }
                    }
                } else {
                    n4 = -this.dd_h.K + 512;
                    n5 = -this.dd_h.M + this.dd_h.J.wl_r.length;
                    if (n4 > n5 + -this.dd_h.J.wl_n) {
                        n4 = n5 + -this.dd_h.J.wl_n;
                    }
                    if (n4 > n6) {
                        n4 = n6;
                    }
                    this.qb_v.a(n4, this.dd_h.J.wl_n, (byte)17, this.dd_h.J.wl_r);
                    if (0 != this.dd_f) {
                        n3 = 0;
                        while (~n3 > ~n4) {
                            this.dd_h.J.wl_r[n3 + this.dd_h.J.wl_n] = (byte)qm.b(this.dd_h.J.wl_r[n3 + this.dd_h.J.wl_n], this.dd_f);
                            ++n3;
                        }
                    }
                    this.dd_h.K += n4;
                    this.dd_h.J.wl_n += n4;
                    if (~this.dd_h.J.wl_n == ~n5) {
                        this.dd_h.e((byte)116);
                        this.dd_h.z = false;
                        this.dd_h = null;
                    } else if (512 == this.dd_h.K) {
                        this.dd_h.K = 0;
                    }
                }
                ++n2;
            }
            return true;
        }
        catch (IOException iOException) {
            try {
                this.qb_v.a(0);
            }
            catch (Exception exception) {
                // empty catch block
            }
            ++this.dd_j;
            this.dd_o = -2;
            this.qb_v = null;
            return this.c((byte)-115) == 0 && -1 == ~this.c(0);
        }
    }

    @Override
    final void a(int n) {
        try {
            this.qb_v.a(0);
            if (n != 8192) {
                this.a((byte)-2);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.dd_o = -1;
        ++this.dd_j;
        this.qb_v = null;
        this.dd_f = (byte)(Math.random() * 255.0 + 1.0);
    }

    public static void d(int n) {
        qb_s = null;
        qb_q = null;
        qb_p = null;
        int n2 = -57 % ((60 - n) / 50);
        qb_t = null;
        qb_r = null;
    }

    static final int a(int n, String string, boolean bl2) {
        if (n != 0) {
            return 14;
        }
        if (!bl2) {
            return wf.wf_q.a(string);
        }
        return aj.aj_d.a(string);
    }

    static final void a(int n, byte by, kn kn2) {
        pb.pb_c.a(kn2, 2777);
        if (by != 85) {
            qb_t = null;
        }
        fm.a((byte)-113, n, kn2);
    }

    static final void a(Throwable throwable, int n, String string) {
        boolean bl2 = client.A;
        try {
            String string2 = "";
            if (throwable != null) {
                string2 = j.a(throwable, (byte)37);
            }
            if (string != null) {
                if (throwable != null) {
                    string2 = string2 + " | ";
                }
                string2 = string2 + string;
            }
            im.a(18239, string2);
            string2 = bh.a(0, string2, "%3a", ":");
            string2 = bh.a(n + -16408, string2, "%40", "@");
            string2 = bh.a(n ^ n, string2, "%26", "&");
            string2 = bh.a(0, string2, "%23", "#");
            if (null == th.th_b) {
                return;
            }
            mh mh2 = o.o_f.a(new URL(th.th_b.getCodeBase(), "clienterror.ws?c=" + wb.Rb + "&u=" + (eh.eh_d == null ? "" + ua.B : eh.eh_d) + "&v1=" + fd.fd_k + "&v2=" + fd.fd_c + "&e=" + string2), (byte)42);
            while (mh2.mh_c == 0) {
                ua.a(1L, -128);
            }
            if (1 == mh2.mh_c) {
                DataInputStream dataInputStream = (DataInputStream)mh2.mh_b;
                dataInputStream.read();
                dataInputStream.close();
            }
        }
        catch (Exception exception) {}
    }

    private final void e(byte by) {
        if (by != -15) {
            return;
        }
        if (this.qb_v == null) {
            return;
        }
        try {
            this.dd_i.wl_n = 0;
            this.dd_i.a(true, 6);
            this.dd_i.b((byte)46, 3);
            this.dd_i.d(-1, 0);
            this.qb_v.a(0, this.dd_i.wl_r.length, 1, this.dd_i.wl_r);
        }
        catch (IOException iOException) {
            try {
                this.qb_v.a(by + 15);
            }
            catch (Exception exception) {
                // empty catch block
            }
            this.qb_v = null;
            ++this.dd_j;
            this.dd_o = -2;
        }
    }

    static {
        qb_u = 22;
        qb_s = new ln();
    }
}
