/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class kb {
    static String kb_f = "Data server full or too many connections from your address. Please try again in a few minutes.";
    static um kb_c = new um();
    static int kb_g;
    static String kb_d;
    static String kb_b;
    static String kb_e;
    static bk kb_i;
    static int[] kb_a;
    static Applet kb_h;

    static final byte[] a(int n, String string) {
        block0: {
            if (n < -14) break block0;
            kb.a(95);
        }
        return pc.pc_b.a(0, string, "");
    }

    public static void a(int n) {
        if (n > -85) {
            kb_g = -67;
        }
        kb_f = null;
        kb_d = null;
        kb_b = null;
        kb_a = null;
        kb_c = null;
        kb_h = null;
        kb_i = null;
        kb_e = null;
    }

    static {
        kb_b = "Your request to join has been declined.";
        kb_a = new int[8192];
        kb_e = "You can get other special items by popping two or more shapes in one go.";
        kb_d = "Close";
    }
}
