/*
 * Decompiled with CFR 0.152.
 */
abstract class rh
extends bh {
    mi rh_n;
    int rh_o;

    abstract void a();

    abstract void b();

    rh() {
    }

    abstract int a(mi var1);
}
