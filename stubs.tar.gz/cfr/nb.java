/*
 * Decompiled with CFR 0.152.
 */
interface nb {
    public String b(byte var1);

    public tb a(int var1);

    public void c(byte var1);

    public boolean a(byte var1);
}
