/*
 * Decompiled with CFR 0.152.
 */
final class hc {
    static double hc_b = Math.atan2(1.0, 0.0);
    static String hc_e = "Searching for opponents";
    static String hc_f = "To report a player, right-click on their name and select the option to report abuse.";
    static int hc_d;
    static int hc_a;
    static int[] hc_c;

    static final void a(int n) {
        boolean bl = client.A;
        hk.f(243, 197, 369, 143, 0xFFFFFF);
        hk.a(244, 198, 367, 141, 0);
        if (null == d.d_h) {
            if (null != bn.bn_g) {
                bn.bn_g.a(wf.wf_m, 245, 199, 365, 139, 0xFFFFFF, -1, 1, 1, 0);
                return;
            }
        } else {
            int n2;
            ck ck2 = d.d_h[wh.wh_a];
            if (null == ck2) {
                if (null != bn.bn_g) {
                    bn.bn_g.a(wf.wf_m, 245, 199, 365, 139, 0xFFFFFF, -1, 1, 1, 0);
                }
            } else {
                ck2.c(245, 199);
            }
            int n3 = -96 / ((n - -79) / 41);
            if (~ac.F > ~dk.dk_i && (ck2 = d.d_h[bh.bh_m]) != null) {
                int n4 = (ck2.K - -60) * ac.F / dk.dk_i;
                n2 = -30 + n4;
                if (!lb.lb_b) {
                    bn.a((byte)-115, (ck2.K + -n2) * 256 / 30, -256 * n2 / 30, 199, ck2, 245);
                } else {
                    bn.a((byte)-112, n2 * -256 / 30, (ck2.K - n2) * 256 / 30, 199, ck2, 245);
                }
            }
            if (bn.bn_g != null) {
                int n5;
                String string = null;
                n2 = n5 = 0;
                while (~n5 > ~d.d_h.length) {
                    ck ck3 = d.d_h[n5];
                    if (null != ck3 && (365 != ck3.K || ck3.C != 139)) {
                        string = string == null ? Integer.toString(n5) : string + ", " + n5;
                    }
                    ++n5;
                }
                if (string != null) {
                    bn.bn_g.a("Screenshot(s) " + string + " is/are the wrong size! Should be " + 365 + "<times>" + 139, 245, 199, 365, 139, 0xFF6633, 0, 1, 1, 0);
                }
            }
            return;
        }
    }

    public static void a(byte by) {
        hc_e = null;
        hc_c = null;
        int n = -68 / ((16 - by) / 39);
        hc_f = null;
    }

    static final pi a(int n, int[] nArray, pi pi2) {
        pi pi3 = new pi(0, n, 0);
        pi3.lc_b = pi2.lc_b;
        pi3.lc_i = pi2.lc_i;
        pi3.lc_a = pi2.lc_a;
        pi3.lc_g = pi2.lc_g;
        pi3.lc_c = pi2.lc_c;
        pi3.pi_l = nArray;
        pi3.lc_d = pi2.lc_d;
        pi3.pi_k = pi2.pi_k;
        return pi3;
    }
}
