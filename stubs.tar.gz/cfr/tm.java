/*
 * Decompiled with CFR 0.152.
 */
final class tm {
    static String tm_g;
    static jd tm_b;
    static int[] tm_a;
    static int tm_d;
    static String tm_e;
    static String[] tm_f;
    static String tm_h;
    static int tm_c;

    static final int a(byte by) {
        long l;
        int n;
        boolean bl2 = client.A;
        boolean bl3 = false;
        boolean bl4 = false;
        while (ab.c((byte)52)) {
            k.k_f.a(-111);
            if (k.k_f.b((byte)114)) {
                bl3 = true;
            }
            if (wh.wh_c != 13) continue;
            bl4 = true;
        }
        k.k_f.a(ub.a(bh.bh_g, (byte)-81, pm.pm_f), -20563, ub.a(he.S, (byte)-81, nf.nf_h));
        if (k.k_f.b((byte)114)) {
            bl3 = true;
        }
        int n2 = 0;
        if (!bl3 || ~k.k_f.sk_h > -1) {
            if (bl4 && -3 != ~bc.B) {
                bf.a(false);
            }
        } else {
            n2 = qf.qf_i[k.k_f.sk_h];
            if (2 == n2 || -6 == ~n2) {
                bf.a(false);
            }
        }
        if (by > -88) {
            tm.a((byte)116);
        }
        if (n2 == 0 && 2 == bc.B && 0 >= (n = (int)((10999L - (l = ik.a(4) - di.F)) / 1000L))) {
            n2 = 2;
            bl.a(-79, 5, true);
        }
        return n2;
    }

    public static void a(int n) {
        tm_e = null;
        tm_b = null;
        tm_a = null;
        tm_f = null;
        tm_h = null;
        if (n <= 87) {
            tm_h = null;
        }
        tm_g = null;
    }

    static final void b(byte by) {
        md.U[4] = dn.dn_j;
        md.U[7] = pa.W;
        md.U[1] = t.t_ib;
        md.U[2] = u.u_c;
        md.U[3] = kl.kl_w;
        md.U[6] = l.l_e;
        if (by > -30) {
            return;
        }
        md.U[5] = ea.y;
        md.U[0] = vf.vf_c;
        ac.z[ac.z.length - 2] = ta.ta_g;
        ac.z[-1 + ac.z.length] = ph.zb;
    }

    static {
        tm_e = "You have not yet unlocked this option for use.";
        tm_d = 0;
        tm_g = "Waiting for music";
        tm_f = new String[]{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        tm_h = "Create your own free Jagex account";
    }
}
