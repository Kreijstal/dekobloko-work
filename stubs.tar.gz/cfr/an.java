/*
 * Decompiled with CFR 0.152.
 */
final class an {
    static final void a(int[] nArray, int n, int n2) {
        n2 = n + n2 - 7;
        while (n < n2) {
            nArray[n++] = 0;
            nArray[n++] = 0;
            nArray[n++] = 0;
            nArray[n++] = 0;
            nArray[n++] = 0;
            nArray[n++] = 0;
            nArray[n++] = 0;
            nArray[n++] = 0;
        }
        n2 += 7;
        while (n < n2) {
            nArray[n++] = 0;
        }
    }

    static final void a(int[] nArray, int n, int[] nArray2, int n2, int n3) {
        if (nArray == nArray2) {
            if (n == n2) {
                return;
            }
            if (n2 > n && n2 < n + n3) {
                n += --n3;
                n2 += n3;
                n3 = n - n3;
                n3 += 7;
                while (n >= n3) {
                    nArray2[n2--] = nArray[n--];
                    nArray2[n2--] = nArray[n--];
                    nArray2[n2--] = nArray[n--];
                    nArray2[n2--] = nArray[n--];
                    nArray2[n2--] = nArray[n--];
                    nArray2[n2--] = nArray[n--];
                    nArray2[n2--] = nArray[n--];
                    nArray2[n2--] = nArray[n--];
                }
                n3 -= 7;
                while (n >= n3) {
                    nArray2[n2--] = nArray[n--];
                }
                return;
            }
        }
        n3 += n;
        n3 -= 7;
        while (n < n3) {
            nArray2[n2++] = nArray[n++];
            nArray2[n2++] = nArray[n++];
            nArray2[n2++] = nArray[n++];
            nArray2[n2++] = nArray[n++];
            nArray2[n2++] = nArray[n++];
            nArray2[n2++] = nArray[n++];
            nArray2[n2++] = nArray[n++];
            nArray2[n2++] = nArray[n++];
        }
        n3 += 7;
        while (n < n3) {
            nArray2[n2++] = nArray[n++];
        }
    }

    static final void a(int[] nArray, int n, int n2, int n3) {
        n2 = n + n2 - 7;
        while (n < n2) {
            nArray[n++] = n3;
            nArray[n++] = n3;
            nArray[n++] = n3;
            nArray[n++] = n3;
            nArray[n++] = n3;
            nArray[n++] = n3;
            nArray[n++] = n3;
            nArray[n++] = n3;
        }
        n2 += 7;
        while (n < n2) {
            nArray[n++] = n3;
        }
    }

    static final void a(Object[] objectArray, int n, Object[] objectArray2, int n2, int n3) {
        if (objectArray == objectArray2) {
            if (n == n2) {
                return;
            }
            if (n2 > n && n2 < n + n3) {
                n += --n3;
                n2 += n3;
                n3 = n - n3;
                n3 += 7;
                while (n >= n3) {
                    objectArray2[n2--] = objectArray[n--];
                    objectArray2[n2--] = objectArray[n--];
                    objectArray2[n2--] = objectArray[n--];
                    objectArray2[n2--] = objectArray[n--];
                    objectArray2[n2--] = objectArray[n--];
                    objectArray2[n2--] = objectArray[n--];
                    objectArray2[n2--] = objectArray[n--];
                    objectArray2[n2--] = objectArray[n--];
                }
                n3 -= 7;
                while (n >= n3) {
                    objectArray2[n2--] = objectArray[n--];
                }
                return;
            }
        }
        n3 += n;
        n3 -= 7;
        while (n < n3) {
            objectArray2[n2++] = objectArray[n++];
            objectArray2[n2++] = objectArray[n++];
            objectArray2[n2++] = objectArray[n++];
            objectArray2[n2++] = objectArray[n++];
            objectArray2[n2++] = objectArray[n++];
            objectArray2[n2++] = objectArray[n++];
            objectArray2[n2++] = objectArray[n++];
            objectArray2[n2++] = objectArray[n++];
        }
        n3 += 7;
        while (n < n3) {
            objectArray2[n2++] = objectArray[n++];
        }
    }

    static final void a(byte[] byArray, int n, byte[] byArray2, int n2, int n3) {
        if (byArray == byArray2) {
            if (n == n2) {
                return;
            }
            if (n2 > n && n2 < n + n3) {
                n += --n3;
                n2 += n3;
                n3 = n - n3;
                n3 += 7;
                while (n >= n3) {
                    byArray2[n2--] = byArray[n--];
                    byArray2[n2--] = byArray[n--];
                    byArray2[n2--] = byArray[n--];
                    byArray2[n2--] = byArray[n--];
                    byArray2[n2--] = byArray[n--];
                    byArray2[n2--] = byArray[n--];
                    byArray2[n2--] = byArray[n--];
                    byArray2[n2--] = byArray[n--];
                }
                n3 -= 7;
                while (n >= n3) {
                    byArray2[n2--] = byArray[n--];
                }
                return;
            }
        }
        n3 += n;
        n3 -= 7;
        while (n < n3) {
            byArray2[n2++] = byArray[n++];
            byArray2[n2++] = byArray[n++];
            byArray2[n2++] = byArray[n++];
            byArray2[n2++] = byArray[n++];
            byArray2[n2++] = byArray[n++];
            byArray2[n2++] = byArray[n++];
            byArray2[n2++] = byArray[n++];
            byArray2[n2++] = byArray[n++];
        }
        n3 += 7;
        while (n < n3) {
            byArray2[n2++] = byArray[n++];
        }
    }

    static final void a(byte[] byArray, int n, int n2, byte by) {
        n2 = n + n2 - 7;
        while (n < n2) {
            byArray[n++] = by;
            byArray[n++] = by;
            byArray[n++] = by;
            byArray[n++] = by;
            byArray[n++] = by;
            byArray[n++] = by;
            byArray[n++] = by;
            byArray[n++] = by;
        }
        n2 += 7;
        while (n < n2) {
            byArray[n++] = by;
        }
    }
}
