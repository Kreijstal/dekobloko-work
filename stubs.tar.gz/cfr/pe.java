/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

final class pe {
    static ck pe_d;
    static String pe_a;
    static String pe_c;
    static String pe_b;
    static w pe_e;

    public static void a(int n) {
        pe_e = null;
        pe_b = null;
        pe_c = null;
        pe_a = null;
        if (n != -1) {
            pe.a(100, -24);
        }
        pe_d = null;
    }

    static final void b(int n) {
        boolean bl = client.A;
        uf uf2 = de.V;
        int n2 = uf2.d((byte)-119);
        if (n != 14750) {
            pe_e = null;
        }
        if (-1 != ~n2) {
            if (n2 != 1) {
                qb.a(null, 16408, "A1: " + qk.d((byte)47));
                si.a(78);
            } else {
                fa fa2;
                int n3 = uf2.i(7553);
                fa fa3 = fa2 = (fa)sa.C.c((byte)46);
                while (fa2 != null && ~n3 != ~fa2.fa_s) {
                    fa3 = (fa)sa.C.d(true);
                }
                if (fa3 == null) {
                    si.a(60);
                    return;
                }
                fa3.b((byte)119);
            }
        } else {
            hd hd2 = (hd)c.c_r.c((byte)80);
            if (null == hd2) {
                si.a(67);
                return;
            }
            int n4 = uf2.d((byte)-90);
            if (0 != n4) {
                byte[] byArray = new byte[n4];
                uf2.a(byArray, 0, (byte)125, n4);
            } else {
                Object var5_10 = null;
            }
            uf2.wl_n += 4;
            if (!uf2.g(0)) {
                si.a(n ^ 0x39D2);
                return;
            }
            hd2.b((byte)109);
        }
    }

    static final boolean b(int n, int n2) {
        if (n != 25973) {
            pe_b = null;
        }
        if (~de.V.wl_n <= ~n2) {
            return true;
        }
        if (qc.qc_s == null) {
            return false;
        }
        try {
            int n3 = qc.qc_s.b(0);
            if (~n3 < -1) {
                if (-de.V.wl_n + n2 < n3) {
                    n3 = -de.V.wl_n + n2;
                }
                qc.qc_s.a(n3, de.V.wl_n, (byte)17, de.V.wl_r);
                p.p_a = ik.a(4);
                de.V.wl_n += n3;
                if (n2 > de.V.wl_n) {
                    return false;
                }
                de.V.wl_n = 0;
                return true;
            }
            if (-1 < ~n3 || (sl.a(n + -25974) ^ 0xFFFFFFFFFFFFFFFFL) < -30001L) {
                si.a(69);
                return false;
            }
        }
        catch (IOException iOException) {
            si.a(96);
        }
        return false;
    }

    static final int a(byte[] byArray, int n, int n2, int n3) {
        boolean bl = client.A;
        int n4 = -1;
        if (n2 > -103) {
            pe.a(73, -42);
        }
        for (int i = n3; i < n; ++i) {
            n4 = a.a_j[(byArray[i] ^ n4) & 0xFF] ^ n4 >>> 922790152;
        }
        return n4 ^= 0xFFFFFFFF;
    }

    static final boolean a(int n, int n2) {
        if (n != 922790152) {
            return false;
        }
        return n2 == (-n2 & n2);
    }

    static {
        pe_c = "Passwords must be between 5 and 20 characters long";
        pe_a = "Please remove <%0> from your ignore list first.";
    }
}
