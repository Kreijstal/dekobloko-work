/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

final class gn {
    static String gn_d = "Stamina Mode";
    static int gn_a;
    static boolean gn_b;
    static int[] gn_e;
    static String[][] gn_c;
    static volatile long gn_f;

    public static void a(int n) {
        gn_e = null;
        if (n != 0) {
            return;
        }
        gn_c = null;
        gn_d = null;
    }

    static final URL a(URL uRL, int n, Applet applet) {
        String string = null;
        if (n != -1) {
            return null;
        }
        if (null != rb.rb_l && !rb.rb_l.equals(applet.getParameter("settings"))) {
            string = rb.rb_l;
        }
        String string2 = null;
        if (u.u_a != null && !u.u_a.equals(applet.getParameter("session"))) {
            string2 = u.u_a;
        }
        return pl.a(string2, string, false, uRL, -1);
    }

    static final void b(int n) {
        if (n != -29550) {
            return;
        }
        ef.f((byte)53);
        uf.k(-4840);
    }

    static {
        gn_f = 0L;
    }
}
