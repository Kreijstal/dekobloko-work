/*
 * Decompiled with CFR 0.152.
 */
final class ib
extends t
implements vn {
    private ek ib_lb;
    static w ib_mb;
    static String ib_pb;
    static ud ib_ob;
    static int ib_kb;
    static w ib_nb;

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        block1: {
            if (this.ib_lb == ek2) {
                this.m((byte)-102);
            }
            if (by == 67) break block1;
            ib_nb = null;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, byte by, int n6, int n7, int[] nArray) {
        block43: {
            int n8;
            int n9;
            int n10;
            int n11;
            int n12;
            int n13;
            int n14;
            block49: {
                boolean bl2;
                int n15;
                block44: {
                    block47: {
                        int n16;
                        block48: {
                            block45: {
                                block46: {
                                    boolean bl3 = client.A;
                                    if (n4 < 0) break block43;
                                    if (~qg.qg_e >= ~n7) {
                                        return;
                                    }
                                    if (0 > n && 0 > n6 && n3 < 0) {
                                        return;
                                    }
                                    if (~n <= ~qg.qg_a && ~n6 <= ~qg.qg_a && qg.qg_a <= n3) {
                                        return;
                                    }
                                    if (by != 117) {
                                        return;
                                    }
                                    n15 = n4 + -n7;
                                    if (n2 == n7) break block44;
                                    n13 = n14 = n << 1227044752;
                                    n12 = n2 - n7;
                                    n11 = (n6 + -n << 66747280) / n12;
                                    n10 = (n3 + -n << -1797323984) / n15;
                                    if (~n11 <= ~n10) {
                                        n9 = n11;
                                        n11 = n10;
                                        n10 = n9;
                                        bl2 = true;
                                    } else {
                                        bl2 = false;
                                    }
                                    if (~n7 <= -1) break block45;
                                    if (-1 >= ~n2) break block46;
                                    n7 = n2 - n7;
                                    n14 += n10 * n7;
                                    n13 += n11 * n7;
                                    n7 = n2;
                                    break block47;
                                }
                                n7 = -n7;
                                n13 += n7 * n11;
                                n14 += n7 * n10;
                                n7 = 0;
                                break block48;
                            }
                            n9 = qg.qg_d[n7];
                            while (~n2 < ~n7) {
                                n8 = n13 >> -1892120976;
                                if (~qg.qg_a < ~n8) {
                                    n16 = (n14 >> 460376112) + -(n13 >> -775770064);
                                    if (n16 == 0) {
                                        if (0 <= n8 && qg.qg_a > n8) {
                                            cf.a(n8 + n9, (byte)57, nArray, n5, n16);
                                        }
                                    } else {
                                        if (~qg.qg_a >= ~(n16 + n8)) {
                                            n16 = -1 + (-n8 + qg.qg_a);
                                        }
                                        if (-1 >= ~n8) {
                                            cf.a(n9 + n8, (byte)57, nArray, n5, n16);
                                        } else {
                                            cf.a(n9, (byte)57, nArray, n5, n16 - -n8);
                                        }
                                    }
                                }
                                if (qg.qg_e <= ++n7) {
                                    return;
                                }
                                n14 += n10;
                                n9 += hk.hk_j;
                                n13 += n11;
                            }
                            break block47;
                        }
                        n9 = qg.qg_d[n7];
                        while (~n2 < ~n7) {
                            n8 = n13 >> -1892120976;
                            if (~qg.qg_a < ~n8) {
                                n16 = (n14 >> 460376112) + -(n13 >> -775770064);
                                if (n16 == 0) {
                                    if (0 <= n8 && qg.qg_a > n8) {
                                        cf.a(n8 + n9, (byte)57, nArray, n5, n16);
                                    }
                                } else {
                                    if (~qg.qg_a >= ~(n16 + n8)) {
                                        n16 = -1 + (-n8 + qg.qg_a);
                                    }
                                    if (-1 >= ~n8) {
                                        cf.a(n9 + n8, (byte)57, nArray, n5, n16);
                                    } else {
                                        cf.a(n9, (byte)57, nArray, n5, n16 - -n8);
                                    }
                                }
                            }
                            if (qg.qg_e <= ++n7) {
                                return;
                            }
                            n14 += n10;
                            n9 += hk.hk_j;
                            n13 += n11;
                        }
                    }
                    n9 = n4 - n2;
                    if (-1 != ~n9) {
                        n8 = n3 << 1532248144;
                        if (!bl2) {
                            n13 = n6 << 146991248;
                        } else {
                            n14 = n6 << 438867216;
                        }
                        n10 = (-n14 + n8) / n9;
                        n11 = (-n13 + n8) / n9;
                    } else {
                        n10 = 0;
                        n11 = 0;
                    }
                    break block49;
                }
                if (~n4 == ~n7) {
                    n11 = 0;
                    n14 = n6 << 2007832880;
                    n10 = 0;
                    n13 = n << -711561136;
                } else {
                    n12 = n4 + -n2;
                    if (n6 > n) {
                        n13 = n << -412399376;
                        n14 = n6 << 553969200;
                        n11 = (-n + n3 << 2082018960) / n15;
                        n10 = (n3 + -n6 << -1002129424) / n12;
                    } else {
                        n10 = (n3 - n << -1836659600) / n15;
                        n11 = (n3 - n6 << 1634149136) / n12;
                        n13 = n6 << 1837752368;
                        n14 = n << -2004970288;
                    }
                }
                bl2 = false;
                if (n7 < 0) {
                    n7 = Math.min(-n7, n2 + -n7);
                    n14 += n7 * n10;
                    n13 += n7 * n11;
                    n7 = 0;
                }
            }
            if (n7 < 0) {
                n7 = -n7;
                n14 += n10 * n7;
                n13 += n7 * n11;
                n7 = 0;
            }
            n12 = qg.qg_d[n7];
            while (n4 > n7) {
                n9 = n13 >> 1610130064;
                if (qg.qg_a > n9) {
                    n8 = -(n13 >> -1500555088) + (n14 >> 1540722832);
                    if (-1 == ~n8) {
                        if (0 <= n9 && qg.qg_a > n9) {
                            cf.a(n9 - -n12, (byte)57, nArray, n5, n8);
                        }
                    } else {
                        if (~qg.qg_a >= ~(n8 + n9)) {
                            n8 = qg.qg_a + -n9 - 1;
                        }
                        if (n9 >= 0) {
                            cf.a(n9 - -n12, (byte)57, nArray, n5, n8);
                        } else {
                            cf.a(n12, (byte)57, nArray, n5, n9 + n8);
                        }
                    }
                }
                if (~qg.qg_e >= ~(++n7)) {
                    return;
                }
                n14 += n10;
                n13 += n11;
                n12 += hk.hk_j;
            }
            return;
        }
    }

    private final ek a(kg kg2, String string, byte by) {
        ek ek2 = new ek(string, kg2);
        ek2.ce_p = new fk();
        int n = this.y + -6;
        this.y += 38;
        if (by != -90) {
            ib_nb = null;
        }
        ek2.b(30, -16 + (this.ce_t + -14), 15, n, by + -16465);
        this.b(ek2, (byte)-55);
        this.f(109);
        return ek2;
    }

    private final void m(byte by) {
        if (!this.S) {
            return;
        }
        if (by >= -30) {
            return;
        }
        this.S = false;
    }

    static final ke a(byte by, boolean bl2) {
        ec ec2;
        ke ke2;
        ke ke3 = ke2 = new ke(5);
        int n = 372;
        if (he.he_db) {
            n -= 12;
        }
        if (ph.n(-30146)) {
            ec2 = new ec(20, qn.qn_rb, a.a_t);
            ec2.ec_m = n;
            ec2.ec_l = -(ec2.ec_n / 2) + 320;
            ke3.a(ec2, 118);
        } else {
            ec ec3;
            ke2.a(new ec(22, sf.E[0], a.a_t), 123);
            ke2.a(new ec(22, sf.E[1], a.a_t), 118);
            ke2.a(new ec(22, sf.E[2], a.a_t), 111);
            ec2 = ec3 = ke2.ke_f[0];
            ke2.ke_f[2].ec_n = 185;
            ec ec4 = ke2.ke_f[1];
            ec4.ec_n = 185;
            ec3.ec_n = 185;
            ke2.ke_f[0].ec_l = 120 + -(ke2.ke_f[0].ec_n / 2);
            ke2.ke_f[1].ec_l = 320 - ke2.ke_f[1].ec_n / 2;
            ke2.ke_f[2].ec_l = 520 + -(ke2.ke_f[2].ec_n / 2);
            ke2.ke_f[1].ec_m = ke2.ke_f[2].ec_m = n;
            ke2.ke_f[0].ec_m = ke2.ke_f[2].ec_m;
        }
        n += 43;
        if (he.he_db) {
            ec2 = new ec(3, oa.oa_c, a.a_t);
            ec2.ec_m = n;
            ec2.ec_l = -(ec2.ec_n / 2) + 320;
            n += 28;
            ke3.a(ec2, 122);
        }
        ec2 = new ec(13, pc.pc_f, a.a_t);
        ec2.ec_l = 320 - ec2.ec_n / 2;
        ec2.ec_m = n;
        ke3.a(ec2, 126);
        ke3.ke_q = 272;
        ke3.y = 500;
        ke3.ke_w = 70;
        ke3.z = 76;
        ke3.a(fc.fc_e, bl2, -129);
        int n2 = -87 % ((19 - by) / 60);
        return ke3;
    }

    static final void a(byte by, ck[] ckArray) {
        int n = -81 / ((-23 - by) / 37);
        d.d_h = ckArray;
        if (d.d_h != null && -4 < ~ckArray.length) {
            throw new IllegalArgumentException("");
        }
    }

    static final int l(int n) {
        sc.sc_l.a(-126);
        if (n <= 65) {
            ib_ob = null;
        }
        if (!ta.ta_k.a((byte)-56)) {
            return oj.b(0);
        }
        return 0;
    }

    ib(ka ka2, ln ln2) {
        super(ka2, 200, 150);
        String string = null;
        if (ln2 == qb.qb_s) {
            string = si.si_c;
        } else if (kl.kl_p != ln2) {
            if (gd.gd_c == ln2) {
                this.y += 30;
                string = gd.gd_i;
            }
        } else {
            string = dc.dc_g;
            this.y += 10;
            if (wj.r(98)) {
                this.y += 20;
                string = wm.wm_g;
            }
        }
        ce ce2 = new ce(string, null);
        ce2.ce_t = this.ce_t;
        ce2.ce_u = 0;
        ce2.y = 80;
        ce2.D = 50;
        ce2.ce_p = new a(bj.bj_f, 10, 10, 0, 10, 0xFFFFFF, -1, 1, 0, 16, 0, 0, true);
        this.b(ce2, (byte)-55);
        this.ib_lb = this.a(this, og.og_gb, (byte)-90);
    }

    public static void m(int n) {
        ib_nb = null;
        ib_pb = null;
        if (n > -10) {
            return;
        }
        ib_mb = null;
        ib_ob = null;
    }

    static {
        ib_kb = 20;
    }
}
