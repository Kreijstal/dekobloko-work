/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;
import java.awt.Graphics;

final class mf
extends oe
implements vn {
    static String S;
    static String V;
    static int Q;
    private ek U;
    private pn T = new pn(new di(0x989898), gf.gf_i, 0, 0, 140, 25);
    static sb N;
    static ck O;
    static int R;
    static String P;

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        if (n < 38) {
            V = null;
        }
        super.a(ce2, 98, n2, n3);
        this.U.I = this.T.a(-128).a(20350) == dc.dc_b;
    }

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        if (by != 67) {
            R = -124;
        }
        if (this.T.a(-101).a(by ^ 0x4F3D) != dc.dc_b) {
            return;
        }
        kh.a(-31, this.T.i(-22079), this.T.f((byte)48), this.T.b(false));
    }

    static final void a(int n, int n2, int n3, Canvas canvas) {
        try {
            Graphics graphics = canvas.getGraphics();
            le.le_m.a((byte)54, graphics, n2, n3);
            graphics.dispose();
            if (n != 1) {
                V = null;
            }
        }
        catch (Exception exception) {
            canvas.repaint();
        }
    }

    static final void h(int n2) {
        vk.vk_f = hk.hk_i;
        wj.Lb = hk.hk_j;
        pa.g((byte)115);
        dc.dc_e.a(g.R.N + -42, g.R.w_mb, 0, 107, 0);
        fn.fn_g.a(aj.aj_a.w_mb, 0, 0, kf.O, 0);
        int n3 = kf.O + 2;
        gg.y.a(aj.aj_a.w_mb, n2 ^ 5, !pd.pd_a ? 0 : n3, -(!pd.pd_a ? 0 : n3) + aj.aj_a.N, 0);
        bf.c((byte)-103);
        uh.uh_c.a(g.R.w_mb, 0, -40 + g.R.N, 40, 0);
        p.p_b.a(wm.wm_h.w_mb, 0, 0, 30, 0);
        li.li_h.a(wm.wm_h.w_mb, n2 ^ 5, 30, -70 + (wm.wm_h.N - 2), 0);
        f.f_o.a(68, n2 ^ 5, 5, 30, 5);
        d.d_a.a(78, 0, 5, 30, 75);
        tg.tg_f.a(48, 0, 5, 30, 155);
        md.X.a(48, 0, n2, 30, 205);
        int n4 = !pd.pd_a ? 200 : 250;
        jc.jc_h.a(363 + -n4, n2 + -5, 5, 30, 5 - -n4);
        bk.Rb.a(-370 + (wm.wm_h.w_mb - 5), 0, 5, 30, 370);
        gf.gf_c.a(6, 37, vh.vh_e, 5, -10 + (li.li_h.N - 32), li.li_h.w_mb - 5 - 5, 2);
        int n5 = (wm.wm_h.w_mb + 2) / 2;
        o.o_a.a(n5 + -2, 0, wm.wm_h.N + -40, 40, 0);
        if (!pd.pd_a) {
            n5 = 0;
        }
        se.U.a(wm.wm_h.w_mb - n5, 0, wm.wm_h.N + -40, 40, n5);
    }

    static final void a(int n2, String[] stringArray, byte[] byArray, ji ji2, int n3, String[][] stringArray2, ck[][] ckArray, int n4, String[][] stringArray3, String[] stringArray4, String[] stringArray5, ck[][] ckArray2, int n5, byte[] byArray2, int[] nArray) {
        int n6;
        boolean bl2 = client.A;
        pa.pa_db = stringArray5;
        jj.jj_a = stringArray;
        gn.gn_c = stringArray2;
        hb.Qb = stringArray3;
        pf.pf_k = stringArray4;
        hd.hd_u = n2;
        rn.rn_e = ckArray;
        da.da_a = byArray2;
        mg.Vb = n4;
        be.be_u = ckArray2;
        ne.ne_c = byArray;
        b.P = nArray;
        fj.fj_a = bj.a(112, ji2, "lobby", "gameprivacy");
        si.si_d = bj.a(112, ji2, "lobby", "ratedgame");
        client.x = bj.a(112, ji2, "lobby", "opentome");
        bb.bb_b = bj.a(112, ji2, "lobby", "allowspectators");
        ed.ed_b = new String[5];
        ed.ed_b[2] = om.om_g;
        ed.ed_b[3] = hd.hd_p;
        ed.ed_b[4] = ik.ik_a;
        ed.ed_b[1] = ul.ul_h;
        ed.ed_b[0] = dk.dk_b;
        gg.y = new w(0L, null);
        gh.gh_b = new w(0L, fh.fh_g, cb.cb_h);
        kn.kn_r = new w(0L, dd.dd_k, ak.ak_a);
        ec.ec_k = new nm(0L, new w(0L, null), gf.gf_g, tm.tm_b);
        gg.y.a(gh.gh_b, -16834);
        if (pd.pd_a) {
            gg.y.a(kn.kn_r, n3 + -7940);
        }
        gg.y.a(ec.ec_k, -16834);
        ec.ec_k.Rb.a(-122, ua.H);
        w w2 = ec.ec_k.Rb;
        ec.ec_k.Rb.W = 1;
        w2.X = 1;
        fn.fn_g = new w(0L, ua.H);
        fn.fn_g.X = 1;
        uh.uh_c = new w(0L, hd.hd_q, pc.pc_f.toUpperCase());
        p.p_b = new w(0L, ml.ml_a, in.in_u.toUpperCase());
        li.li_h = new w(0L, bf.bf_t);
        f.f_o = new w(0L, fh.fh_g, li.li_c);
        d.d_a = new w(0L, bl.Y, ml.ml_c);
        tg.tg_f = new w(0L, bl.Y, ba.ba_e);
        md.X = new w(0L, bl.Y, be.be_o);
        jc.jc_h = new w(0L, bl.Y, gk.Db);
        bk.Rb = new w(0L, dd.dd_k, bk.Qb);
        gf.gf_c = new nm(0L, new w(0L, null), gf.gf_g, tm.tm_b);
        o.o_a = new w(0L, d.d_g, qe.qe_c.toUpperCase());
        o.o_a.Hb = pd.pd_a;
        se.U = new w(0L, d.d_g, (!pd.pd_a ? pl.pl_c : p.p_c).toUpperCase());
        wm.wm_h = new w(0L, null);
        wm.wm_h.a(p.p_b, -16834);
        wm.wm_h.a(li.li_h, -16834);
        li.li_h.a(f.f_o, -16834);
        li.li_h.a(d.d_a, -16834);
        li.li_h.a(tg.tg_f, -16834);
        if (pd.pd_a) {
            li.li_h.a(md.X, -16834);
        }
        li.li_h.a(jc.jc_h, -16834);
        li.li_h.a(bk.Rb, -16834);
        li.li_h.a(gf.gf_c, n3 + -7940);
        if (pd.pd_a) {
            wm.wm_h.a(o.o_a, -16834);
        }
        wm.wm_h.a(se.U, -16834);
        f.f_n = new w(0L, ua.H);
        f.f_n.W = 0;
        f.f_n.X = 1;
        ce.A = new w(0L, kn.kn_p, gm.J.toUpperCase());
        tc.Ob = new w(0L, ui.x);
        tc.Ob.a(f.f_n, -16834);
        tc.Ob.a(ce.A, -16834);
        cl.cl_n = new w(0L, gf.gf_g);
        cl.cl_n.a(-128, ua.H);
        cl.cl_n.W = 1;
        w w3 = cl.cl_n;
        w3.X = 1;
        in.in_o = new w(0L, null);
        if (n3 != -8894) {
            return;
        }
        he.he_jb = new w(0L, ua.H);
        he.he_jb.X = 1;
        kl.kl_r = new w(0L, fh.fh_g, cb.cb_h);
        ea.A = new w(0L, dd.dd_k, ak.ak_a);
        tb.tb_b = new nm(0L, new w(0L, null), gf.gf_g, tm.tm_b);
        in.in_o.a(he.he_jb, -16834);
        in.in_o.a(kl.kl_r, -16834);
        if (pd.pd_a) {
            in.in_o.a(ea.A, n3 ^ 0x637C);
        }
        in.in_o.a(tb.tb_b, n3 ^ 0x637C);
        ma.G = new w(0L, hd.hd_q, om.om_b.toUpperCase());
        fl.fl_b = new w(0L, ml.ml_a);
        qm.qm_a = new w(0L, bf.bf_t);
        li.li_d = new w(0L, i.i_e, bk.Nb.toUpperCase());
        um.um_c = new w[4 + n5];
        qa.qa_v = new qd[n5 - -4][];
        um.um_c[0] = new w(0L, sg.sg_e, qc.qc_l);
        qa.qa_v[0] = new qd[6];
        int n7 = 0;
        while (~n7 > -6) {
            qa.qa_v[0][n7 - -1] = new qd(0L, l.l_a, null, df.df_ab, fj.fj_a[n7], ed.ed_b[n7]);
            ++n7;
        }
        if (2 <= b.P.length) {
            um.um_c[1] = new w(0L, sg.sg_e, hb.Pb);
            qa.qa_v[1] = new qd[1 + b.P.length];
            qa.qa_v[1][0] = new qd(0L, l.l_a, null, df.df_ab, null, hd.hd_t);
            for (n7 = 0; b.P.length > n7; ++n7) {
                qa.qa_v[1][n7 + 1] = new qd(0L, l.l_a, null, df.df_ab, null, Integer.toString(b.P[n7]));
            }
        }
        um.um_c[2] = new w(0L, sg.sg_e, bc.G);
        qa.qa_v[2] = new qd[]{new qd(0L, l.l_a, null, df.df_ab, null, hd.hd_t), new qd(0L, l.l_a, null, df.df_ab, bb.bb_b[0], jh.jh_f), new qd(0L, l.l_a, null, df.df_ab, bb.bb_b[1], h.h_f)};
        if (mg.Vb > 1) {
            um.um_c[3] = new w(0L, sg.sg_e, mk.mk_a);
            qa.qa_v[3] = new qd[mg.Vb + 1];
            qa.qa_v[3][0] = new qd(0L, l.l_a, null, df.df_ab, null, hd.hd_t);
            for (n7 = 0; mg.Vb > n7; ++n7) {
                qa.qa_v[3][n7 - -1] = new qd(0L, l.l_a, null, df.df_ab, null, pf.pf_k[n7]);
            }
        }
        for (n7 = 0; n5 > n7; ++n7) {
            um.um_c[4 + n7] = new w(0L, sg.sg_e, pa.pa_db[n7]);
            qa.qa_v[4 - -n7] = new qd[lb.a(da.da_a[n7], 255) - -1];
            qa.qa_v[n7 + 4][0] = new qd(0L, l.l_a, null, df.df_ab, null, hd.hd_t);
            n6 = 0;
            while (~(da.da_a[n7] & 0xFF) < ~n6) {
                ck ck2 = rn.rn_e != null ? (null == rn.rn_e[n7] ? null : rn.rn_e[n7][n6]) : null;
                String string = null == gn.gn_c ? null : (null != gn.gn_c[n7] ? gn.gn_c[n7][n6] : null);
                qa.qa_v[n7 + 4][n6 - -1] = new qd(0L, l.l_a, null, df.df_ab, ck2, string);
                ++n6;
            }
        }
        n7 = 0;
        while (~n7 > ~(n5 - -4)) {
            if (null != um.um_c[n7]) {
                um.um_c[n7].Db = 11;
            }
            if (null != qa.qa_v[n7]) {
                for (n6 = 0; n6 < qa.qa_v[n7].length; ++n6) {
                    if (qa.qa_v[n7][n6] == null || qa.qa_v[n7][n6].Tb == null) continue;
                    qa.qa_v[n7][n6].Tb.Db = 11;
                }
            }
            ++n7;
        }
        fh.fh_d = new w(0L, d.d_g);
        nn.nn_a = new w(0L, d.d_g);
        tg.tg_i = new w(0L, fc.fc_c);
        tg.tg_i.a(-112, ua.H);
        tg.tg_i.W = 1;
        w w4 = tg.tg_i;
        w4.X = 1;
        oh.oh_d = new w(0L, null);
        oh.oh_d.a(fl.fl_b, -16834);
        oh.oh_d.a(qm.qm_a, -16834);
        qm.qm_a.a(li.li_d, -16834);
        n6 = 0;
        while (~n6 > ~(4 + n5)) {
            if (!(~n6 == -2 && -3 < ~b.P.length || n6 == 3 && -2 <= ~mg.Vb)) {
                qm.qm_a.a(um.um_c[n6], -16834);
                for (int j = 0; j < qa.qa_v[n6].length; ++j) {
                    if (qa.qa_v[n6][j] == null) continue;
                    qm.qm_a.a(qa.qa_v[n6][j], -16834);
                }
            }
            ++n6;
        }
        oh.oh_d.a(fh.fh_d, -16834);
        oh.oh_d.a(nn.nn_a, n3 + -7940);
        oh.oh_d.a(tg.tg_i, -16834);
        ie.ie_a = new w(0L, tg.tg_h, ea.ea_u.toUpperCase());
        qc.qc_q = new w(0L, kn.kn_p, kb.kb_d.toUpperCase());
    }

    @Override
    final void g(int n2) {
        int n3 = 250;
        this.T.b(25, 140, -n3 + this.ce_t >> 876882657, this.y - 5 >> -262495615, -16555);
        this.U.b(30, 100, 10 + (140 + (-n3 + this.ce_t >> -1122840863)), 2 + (20 + (this.y - n2) >> -5749503), n2 ^ 0xFFFFBF4B);
    }

    static final void a(byte by, int n2) {
        if (by < 80) {
            S = null;
        }
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        uf2.a(true, 2);
        uf2.a(true, 4);
        uf2.a(true, am.b(112));
    }

    public static void i(int n2) {
        block0: {
            O = null;
            S = null;
            V = null;
            N = null;
            P = null;
            if (n2 == -17690) break block0;
            O = null;
        }
    }

    @Override
    final void a(int n2, int n3, int n4, int n5) {
        block0: {
            super.a(n2, -106, n4, n5);
            bj.bj_f.a(vf.vf_e, 4 + n2 + this.ce_u, 4 + bj.bj_f.R + n5 - -this.D, 0xFFFFFF, -1);
            if (n3 < -103) break block0;
            ek ek2 = null;
            this.a((byte)-51, -52, ek2, -94, 59);
        }
    }

    mf(int n2, int n3, int n4, int n5) {
        super(n2, n3, n4, n5, null);
        this.T.a((byte)79, new qf());
        this.U = new ek(fa.fa_o, this);
        this.K = new ce[]{this.T, this.U};
        this.U.ce_p = new fk();
        this.f(119);
    }

    static {
        V = "Add name";
        S = "Please select options in the following rows:  ";
        O = new ck(36, 36);
        P = "Achievements";
    }
}
