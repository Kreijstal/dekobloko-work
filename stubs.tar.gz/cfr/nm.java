/*
 * Decompiled with CFR 0.152.
 */
final class nm
extends w {
    w Rb;
    static String Pb = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&'*+-/=?^_{}~";
    jd Sb;
    static boolean Qb;
    static int[] Nb;
    w Ob;

    static final void f(int n) {
        int n2 = -114 % ((n - 79) / 35);
        fj.a(48, (byte)-89, hm.hm_d);
    }

    public static void g(int n) {
        Nb = null;
        if (n != 48) {
            Nb = null;
        }
        Pb = null;
    }

    static final int a(float f, float f2, boolean bl, float f3) {
        int n;
        float f4;
        float f5;
        float f6;
        block7: {
            float f7;
            float f8;
            block6: {
                float f9;
                block5: {
                    block4: {
                        block3: {
                            block2: {
                                block1: {
                                    boolean bl2 = client.A;
                                    f6 = 0.0f;
                                    f5 = 0.0f;
                                    f4 = 0.0f;
                                    float f10 = f * 6.0f % 6.0f;
                                    int n2 = (int)f10;
                                    float f11 = f10 - (float)n2;
                                    f8 = (-f3 + 1.0f) * f2;
                                    f7 = (-(f11 * f3) + 1.0f) * f2;
                                    f9 = f2 * (-((1.0f - f11) * f3) + 1.0f);
                                    n = n2;
                                    if (~n == -1) break block1;
                                    if (~n == -2) break block2;
                                    if (-3 == ~n) break block3;
                                    if (~n == -4) break block4;
                                    if (4 == n) break block5;
                                    if (-6 == ~n) break block6;
                                    break block7;
                                }
                                f4 = f8;
                                f6 = f2;
                                f5 = f9;
                                break block7;
                            }
                            f5 = f2;
                            f6 = f7;
                            f4 = f8;
                            break block7;
                        }
                        f5 = f2;
                        f6 = f8;
                        f4 = f9;
                        break block7;
                    }
                    f5 = f7;
                    f4 = f2;
                    f6 = f8;
                    break block7;
                }
                f6 = f9;
                f4 = f2;
                f5 = f8;
                break block7;
            }
            f6 = f2;
            f4 = f7;
            f5 = f8;
        }
        if (bl) {
            return 25;
        }
        n = 256;
        int n3 = Math.min(Math.round((float)n * f6), n - 1);
        int n4 = Math.min(Math.round(f5 * (float)n), -1 + n);
        int n5 = Math.min(Math.round((float)n * f4), -1 + n);
        int n6 = 0xFF & n5 | (n4 << 457078600 & 0xFF00 | 0xFF0000 & n3 << -1294601872);
        return n6;
    }

    private final boolean a(boolean bl, int n, byte by, int n2, int n3, int n4, boolean bl2) {
        if (by != 43) {
            this.a(97, true, false, -111);
        }
        boolean bl3 = bl || this.w_jb && !bl2;
        this.Ob.a((byte)-94, n4, this.Rb.N, bl3);
        this.a(n, n3, by ^ 0x2B, false, n2);
        return bl3;
    }

    private final void b(int n, int n2, int n3) {
        this.Rb.w_mb = -n + (this.w_mb - n3);
        this.Rb.N = this.N;
        this.Ob.w_vb = n2;
        this.Ob.w_mb = -n + (this.w_mb + -n3);
        this.Sb.a(this.w_mb + -n3, (byte)-32, this.N, this.Ob.N, n3, -this.Ob.Ib, this.Rb.N, 0);
    }

    static final ck g(byte by) {
        int n;
        boolean bl = client.A;
        int n2 = tm.tm_a[0] * hc.hc_c[0];
        byte[] byArray = tc.Nb[0];
        int[] nArray = new int[n2];
        for (n = 0; n < n2; ++n) {
            nArray[n] = mb.mb_d[lb.a(255, byArray[n])];
        }
        n = -8 % ((by - -40) / 42);
        ck ck2 = new ck(ed.ed_f, i.i_d, sg.sg_d[0], fh.fh_a[0], tm.tm_a[0], hc.hc_c[0], nArray);
        oa.a(127);
        return ck2;
    }

    static final boolean a(int n2, int n3, int n4) {
        boolean bl2 = client.A;
        if (n3 != 1) {
            Qb = true;
        }
        boolean bl3 = true;
        if (!sc.sc_m && null == tf.tf_gb) {
            bl3 = false;
        }
        if (pk.pk_r == 0 && null != g.N) {
            bl3 = false;
        }
        if (2 == pk.pk_r && !hl.a((byte)-53)) {
            bl3 = false;
        }
        if (~wh.wh_c == -85) {
            if (bl3) {
                if (~dj.dj_ab.length() < -1) {
                    String string = dj.dj_ab.toString();
                    if (!ue.a(n3 ^ 0x801, string)) {
                        int n5 = pk.pk_r;
                        if (n5 == 0 && null != cd.cd_m) {
                            n5 = 1;
                        }
                        if (-3 == ~rf.a(0, n5)) {
                            eg.a(n5, n4, 1, (byte)71);
                        }
                        ce.a(n2, (byte)-85, pk.pk_r, ed.ed_c, -1, string);
                    } else {
                        ca.a(null, null, wd.wd_a, (byte)90, 2, 0);
                        ca.a(null, null, um.um_e, (byte)69, 2, 0);
                    }
                }
                qk.a((byte)94);
                return true;
            }
            if (0 != pk.pk_r) {
                qk.a((byte)94);
            }
            return true;
        }
        if (wh.wh_c == 85) {
            if (bl3 && 0 < dj.dj_ab.length()) {
                vf.a(dj.dj_ab, -23510, dj.dj_ab.length() - 1, ' ');
            }
            return true;
        }
        char c = el.G;
        if (kh.a(c, 8212)) {
            if (bl3 && 80 > dj.dj_ab.length()) {
                String string;
                dj.dj_ab.append(c);
                int n6 = 485;
                String string2 = oa.oa_f;
                string2 = string = b.a(n3 + 82, string2);
                if (pk.pk_r != 2) {
                    String string3 = "";
                    if (~pk.pk_r == -1) {
                        if (cd.cd_m == null && ii.ii_q) {
                            string3 = "[" + uc.uc_b + "] ";
                        }
                        if (null != cd.cd_m) {
                            string3 = !wh.wh_b || null == f.f_q ? "[" + cm.a((byte)125, hf.hf_a, new String[]{cd.cd_m.Vb}) + "] " : "[" + f.f_q + "] ";
                        }
                    }
                    string3 = string3 + string2 + ": ";
                    n6 -= ff.ff_o.a(string3);
                } else {
                    int n7;
                    String string4 = cm.a((byte)94, oj.oj_b, new String[]{ua.a(ed.ed_c, true)});
                    String string5 = cm.a((byte)108, im.im_j, new String[]{string});
                    int n8 = ff.ff_o.a(string4);
                    n6 = n8 > (n7 = ff.ff_o.a(string5)) ? (n6 -= n8) : (n6 -= n7);
                }
                if (~ff.ff_o.a(dj.dj_ab.toString()) < ~n6) {
                    vf.a(dj.dj_ab, -23510, dj.dj_ab.length() + -1, ' ');
                }
            }
            return true;
        }
        return false;
    }

    final boolean a(int n2, int n3, int n4, boolean bl2, int n5, boolean bl3) {
        if (n4 != -15230) {
            return false;
        }
        return this.a(bl2, this.Rb.N, (byte)43, n2, n3, n5, bl3);
    }

    nm(long l, w w2, w w3, jd jd2) {
        super(l, null);
        this.Rb = new w(0L, w3);
        this.Sb = new jd(0L, jd2);
        this.a(this.Rb, -16834);
        this.a(this.Sb, -16834);
        this.Ob = w2;
        this.Rb.a(w2, -16834);
    }

    static final void h(byte by) {
        block0: {
            if (by == 112) break block0;
            Qb = false;
        }
    }

    final void a(int n2, boolean bl2, boolean bl3, int n3) {
        block0: {
            this.a(this.Rb.N, n2, 0, bl3, n3);
            if (bl2) break block0;
            nm.h((byte)66);
        }
    }

    static final void e(int n2) {
        if (!ai.f((byte)-126)) {
            return;
        }
        bl.a(-11, 4, false);
        int n3 = -75 / ((-27 - n2) / 47);
    }

    final void a(int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        this.w_mb = n7;
        if (n2 != 6) {
            return;
        }
        this.w_vb = n5;
        this.Ib = n3;
        this.N = n6;
        this.b(n8, 0, n4);
    }

    private final void a(int n2, int n3, int n4, boolean bl2, int n5) {
        if (this.Sb.i((byte)7)) {
            this.Ob.Mb += n5;
        }
        if (this.Sb.h((byte)78)) {
            this.Ob.Mb -= n5;
        }
        if (this.Sb.g((byte)-127)) {
            this.Ob.Mb += n2;
        }
        if (this.Sb.f(n4)) {
            this.Ob.Mb -= n2;
        }
        if (this.w_jb) {
            this.Ob.Mb -= n3;
        }
        if (!bl2) {
            if (~(-(this.Ob.Mb + this.Ob.Ib)) < ~(this.Ob.F + this.Ob.N + -this.Rb.N)) {
                this.Ob.Mb = -(-this.Rb.N + (this.Ob.N - -this.Ob.F)) - this.Ob.Ib;
            }
            if (-1 < ~(-(this.Ob.Ib - -this.Ob.Mb))) {
                this.Ob.Mb = -this.Ob.Ib;
            }
        } else {
            if (0 > -(this.Ob.Ib - -this.Ob.Mb)) {
                this.Ob.Mb = -this.Ob.Ib;
            }
            if (~(this.Ob.F + (this.Ob.N + -this.Rb.N)) > ~(-(this.Ob.Mb + this.Ob.Ib))) {
                this.Ob.Mb = -this.Ob.Ib + -(-this.Rb.N + (this.Ob.F + this.Ob.N));
            }
        }
        if (this.Sb.j((byte)-2)) {
            this.Ob.Ib = -this.Sb.a(bl2, (byte)88, this.Rb.N, this.Ob.N);
            this.Ob.Mb = 0;
        }
        this.Sb.a(this.Rb.N, this.Ob.N, 106, -this.Ob.Ib);
    }

    static {
        Nb = new int[128];
    }
}
