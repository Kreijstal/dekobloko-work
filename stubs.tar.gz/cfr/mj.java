/*
 * Decompiled with CFR 0.152.
 */
interface mj
extends kg {
    public void a(int var1, se var2, int var3, int var4);
}
