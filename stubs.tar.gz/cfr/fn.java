/*
 * Decompiled with CFR 0.152.
 */
import java.nio.ByteBuffer;

final class fn
extends mk {
    static String fn_f = "Invite more players, or alternatively try changing the '<%0>' setting.";
    static w fn_g;
    private ByteBuffer fn_h;

    @Override
    final byte[] a(int n) {
        if (n != 256) {
            return null;
        }
        byte[] byArray = new byte[this.fn_h.capacity()];
        this.fn_h.position(0);
        this.fn_h.get(byArray);
        return byArray;
    }

    static final void a(ji ji2, ji ji3, ji ji4, int n) {
        Object object;
        int n2;
        boolean bl2 = client.A;
        c.c_m = bj.a(112, ji2, "commonui", "frame_top");
        g.O = bj.a(112, ji2, "commonui", "frame_bottom");
        jm.jm_q = id.a(ji2, "jagex_logo_grey", "commonui", 8192);
        rm.rm_a = bj.a(112, ji2, "commonui", "button");
        tl.tl_u = ac.a(0, "commonui", "validation", ji2);
        bj.bj_f = vi.a(ji4, ji2, "commonui", (byte)110, "arezzo12");
        hh.hh_e = vi.a(ji4, ji2, "commonui", (byte)93, "arezzo14");
        ec.ec_p = vi.a(ji4, ji2, "commonui", (byte)-121, "arezzo14bold");
        ck ck2 = new ck(ji3.a(0, "", "button.gif"), jh.jh_b);
        hn.a("dropdown", ji2, "commonui", (byte)73);
        pi[] piArray = t.a("screen_options", ji2, false, "commonui");
        df.Y = new pi[4];
        jj.jj_e = new pi[4];
        aa.aa_c = new pi[4];
        pi[][] piArrayArray = new pi[][]{df.Y, jj.jj_e, aa.aa_c};
        int[][] nArrayArray = new int[4][];
        nArrayArray[0] = piArray[0].pi_l;
        for (n2 = 1; n2 < nArrayArray.length; ++n2) {
            nArrayArray[n2] = (int[])nArrayArray[0].clone();
        }
        n2 = piArray[0].pi_k[0];
        nArrayArray[2][n2] = 0xFFFFFF;
        nArrayArray[1][n2] = 2394342;
        nArrayArray[3][n2] = 4767999;
        int n3 = 0;
        while (~n3 > -4) {
            pi[] piArray2 = piArrayArray[n3];
            object = piArray2;
            for (int i = 0; piArray2.length > i; ++i) {
                piArray2[i] = hc.a(0, nArrayArray[i], piArray[n3]);
            }
            ++n3;
        }
        n3 = ck2.H;
        uh.a(-9074);
        ck2.a();
        hk.c(0, 0, hk.hk_j, hk.hk_i);
        ck ck3 = new ck(n3, n3);
        object = ck3;
        ((ck)object).a();
        ck2.e(0, n);
        ck ck4 = new ck(n3, n3);
        ck4.a();
        ck2.e(n3 - ck2.I, 0);
        ck ck5 = new ck(ck2.I - 2 * n3, n3);
        ck5.a();
        ck2.e(-n3, 0);
        mk.a((byte)-5);
        rm.rm_a = new ck[]{ck3, ck5, ck4};
    }

    fn() {
    }

    public static void b(int n) {
        if (n != 0) {
            ji ji2 = null;
            fn.a(null, null, ji2, 51);
        }
        fn_g = null;
        fn_f = null;
    }

    @Override
    final void a(byte[] byArray, boolean bl2) {
        this.fn_h = ByteBuffer.allocateDirect(byArray.length);
        this.fn_h.position(0);
        if (!bl2) {
            return;
        }
        this.fn_h.put(byArray);
    }
}
