/*
 * Decompiled with CFR 0.152.
 */
final class bg {
    static int bg_d;
    static String bg_a;
    static mm bg_g;
    static int bg_b;
    static String bg_e;
    static String bg_c;
    static String bg_f;

    static final c a(boolean bl) {
        block1: {
            if (hd.hd_r == null) {
                hd.hd_r = new c();
                hd.hd_r.a(0xCCCCCC, hh.hh_e);
                hd.hd_r.c_n = 14;
                hd.hd_r.c_p = bj.bj_f;
                hd.hd_r.c_q = 0;
                hd.hd_r.c_d = 5;
                hd.hd_r.c_o = 0x757575;
                hd.hd_r.c_f = 0x2A2A2A;
                hd.hd_r.c_c = 6;
                hd.hd_r.c_h = 4;
            }
            if (bl) break block1;
            bg_c = null;
        }
        return hd.hd_r;
    }

    public static void a(byte by) {
        bg_c = null;
        bg_f = null;
        bg_g = null;
        bg_a = null;
        bg_e = null;
        int n = -115 / ((by - -42) / 57);
    }

    static final void a(int n) {
        int n2;
        int n3;
        boolean bl = client.A;
        qg.b();
        ch.ch_b = new int[260];
        if (n > -113) {
            bg.a(-59);
        }
        me.y = 11;
        for (n3 = 0; 256 > n3; ++n3) {
            double d = 15.0;
            ch.ch_b[n3] = (int)(255.0 * Math.pow((float)n3 / 256.0f, d));
        }
        n3 = n2 = 256;
        while (~ch.ch_b.length < ~n2) {
            ch.ch_b[n2] = 255;
            ++n2;
        }
    }

    static final void a(byte[] byArray, int[] nArray, String[] stringArray, byte[] byArray2, int n, String[][] stringArray2, ji ji2, int n2, int n3, ji ji3, ck[][] ckArray, ck[][] ckArray2, boolean bl, ji ji4, String[][] stringArray3) {
        block0: {
            s.a(n3 ^ 0x6276, n, ckArray2, byArray2, ckArray, n2, bl, stringArray3, nArray, byArray, ji2, null, ji3, null, stringArray, stringArray2, ji4);
            if (n3 == 25150) break block0;
            bg.a((byte)118);
        }
    }

    static {
        bg_a = "<%0> has entered another game.";
        bg_f = "This password contains your email address, and would be easy to guess";
        bg_c = "Loading extra data";
        bg_e = "You do not have a suitable number of players for the current options.";
    }
}
