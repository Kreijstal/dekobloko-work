/*
 * Decompiled with CFR 0.152.
 */
final class wi {
    static String wi_a = "to keep fullscreen or";
    static int wi_b = 0;

    static final void a(byte by, ji ji2) {
        block0: {
            va.b(ji2.a(by ^ 0xFFFFFFCD, "", "headers.packvorbis"));
            va va2 = va.a(ji2, "jagex logo2.packvorbis", "");
            va2.a();
            if (by == -51) break block0;
            wi_b = -123;
        }
    }

    static final cd a(String[] stringArray, int n) {
        if (n != -3) {
            wi_b = 29;
        }
        cd cd2 = new cd(false);
        cd2.cd_d = stringArray;
        return cd2;
    }

    static final boolean a(int n, String string) {
        if (!jg.jg_i) {
            return false;
        }
        if (~pk.pk_r != -3 || cf.cf_c == null || !cf.cf_c.equals(kf.a(string, (byte)2))) {
            return false;
        }
        int n2 = 82 / ((-50 - n) / 34);
        return true;
    }

    public static void a(int n) {
        block0: {
            wi_a = null;
            if (n == 0) break block0;
            String[] stringArray = null;
            wi.a(stringArray, 103);
        }
    }

    static final void a(boolean bl2, int n, String string) {
        block0: {
            dc.dc_d = bl2;
            mg.Nb = true;
            cl.cl_r = new gk(ah.ah_c, ec.ec_p, string, vb.Z, dc.dc_d);
            ah.ah_c.a((byte)-115, (ce)cl.cl_r);
            if (n <= -20) break block0;
            wi_b = -117;
        }
    }
}
