/*
 * Decompiled with CFR 0.152.
 */
abstract class ti
extends bh {
    int ti_n;

    ti() {
    }
}
