/*
 * Decompiled with CFR 0.152.
 */
final class sa
extends bh {
    int sa_v;
    static String sa_n = "OVER <%0>";
    int sa_s;
    ck sa_o;
    int D;
    static int sa_p = -1;
    static String A = "members-only content";
    String sa_r;
    int z;
    static ud sa_w;
    int sa_u;
    int y;
    static boolean x;
    boolean sa_q;
    static vj C;
    static String B;
    int sa_t;

    public static void c(byte by) {
        block0: {
            sa_n = null;
            C = null;
            A = null;
            sa_w = null;
            B = null;
            if (by < -65) break block0;
            sa.c((byte)-48);
        }
    }

    static final void a(String string, int n) {
        block6: {
            boolean bl = client.A;
            ++jc.jc_g;
            if (~sa_p == 0 && 0 == ~u.u_e) {
                u.u_e = pm.pm_f;
                sa_p = bh.bh_g;
            }
            if (null == string ? null == k.k_e : !string.equals(k.k_e)) {
                boolean bl2 = !wd.wd_d && jc.jc_g >= o.o_b && o.o_b - -he.he_gb > jc.jc_g;
                jc.jc_g = string != null && (wd.wd_d || bl2) ? o.o_b : 0;
                if (null == string) {
                    if (bl2) {
                        wd.wd_d = true;
                    }
                } else {
                    wd.wd_d = false;
                }
                dh.dh_e = u.u_e;
                pa.Z = sa_p;
            }
            k.k_e = string;
            if (!wd.wd_d && ~o.o_b < ~jc.jc_g && pm.pm_b) {
                dh.dh_e = u.u_e;
                pa.Z = sa_p;
                jc.jc_g = 0;
            }
            sa_p = n;
            u.u_e = -1;
            if (!wd.wd_d || ~ve.ve_hc != ~jc.jc_g) break block6;
            jc.jc_g = 0;
            wd.wd_d = false;
        }
    }

    sa(boolean bl, int n, int n2, int n3, int[] nArray, int n4, int n5, String[] stringArray) {
        this.sa_t = n3;
        this.sa_u = n;
        this.y = n5;
        this.sa_q = bl;
        this.D = n2;
        this.sa_r = hf.a(stringArray.length, 0, stringArray, (byte)74);
        if (nArray != null) {
            if (n4 >= nArray.length) {
                n4 = nArray.length + -1;
            }
            this.sa_s = nArray[n4];
        } else {
            this.sa_s = n4;
        }
    }

    static {
        C = new vj();
    }
}
