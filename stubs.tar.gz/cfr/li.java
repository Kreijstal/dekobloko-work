/*
 * Decompiled with CFR 0.152.
 */
final class li {
    static String li_g;
    static String li_a;
    static w li_h;
    static String li_f;
    static ri li_b;
    static ck li_i;
    static w li_d;
    static long li_e;
    static String li_c;

    static final String a(int n, int n2, wl wl2) {
        try {
            int n3 = wl2.a(false);
            if (n3 > n) {
                n3 = n;
            }
            byte[] byArray = new byte[n3];
            wl2.wl_n += me.z.a(wl2.wl_n, (byte)91, n2, byArray, wl2.wl_r, n3);
            String string = un.a(byArray, 0, 0, n3);
            return string;
        }
        catch (Exception exception) {
            return "Cabbage";
        }
    }

    public static void a(int n) {
        li_b = null;
        li_i = null;
        li_f = null;
        li_h = null;
        li_d = null;
        li_g = null;
        li_c = null;
        int n2 = 26 % ((n - -65) / 33);
        li_a = null;
    }

    static {
        li_a = "Email is valid";
        li_f = "Report <%0> for abuse";
        li_c = "Status";
        li_b = null;
        li_g = "You are invited to <%0>'s game.";
    }
}
