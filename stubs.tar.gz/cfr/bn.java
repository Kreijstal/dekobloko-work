/*
 * Decompiled with CFR 0.152.
 */
final class bn {
    static String bn_a;
    static boolean[] bn_f;
    static mm bn_g;
    static String bn_c;
    static String bn_b;
    static String bn_d;
    static ck bn_e;

    public static void a(byte by) {
        if (by != 92) {
            bn_c = null;
        }
        bn_g = null;
        bn_b = null;
        bn_e = null;
        bn_a = null;
        bn_d = null;
        bn_f = null;
        bn_c = null;
    }

    static final void a(byte by, int n, int n2, int n3, ck ck2, int n4) {
        int n5;
        boolean bl = client.A;
        int n6 = (n + -n2 << 1042191592) / ck2.K;
        n4 += ck2.F;
        int n7 = (n2 << -286083416) - -(n6 * ck2.F);
        if (by > -96) {
            bn_d = null;
        }
        int n8 = hk.hk_j * (n3 += ck2.z) + n4;
        int n9 = 0;
        int n10 = ck2.H;
        int n11 = ck2.I;
        int n12 = hk.hk_j + -n11;
        int n13 = 0;
        if (~n3 > ~hk.hk_h) {
            n5 = hk.hk_h + -n3;
            n8 += n5 * hk.hk_j;
            n9 += n11 * n5;
            n10 -= n5;
            n3 = hk.hk_h;
        }
        if (hk.hk_b < n10 + n3) {
            n10 -= -hk.hk_b + n3 + n10;
        }
        if (~hk.hk_c < ~n4) {
            n5 = hk.hk_c + -n4;
            n12 += n5;
            n11 -= n5;
            n9 += n5;
            n13 += n5;
            n7 += n5 * n6;
            n4 = hk.hk_c;
            n8 += n5;
        }
        if (~(n11 + n4) < ~hk.hk_g) {
            n5 = n11 + (n4 - hk.hk_g);
            n13 += n5;
            n12 += n5;
            n11 -= n5;
        }
        if (~n11 < -1) {
            if (0 >= n10) {
                return;
            }
            for (n3 = -n10; 0 > n3; ++n3) {
                n5 = n7;
                for (n4 = -n11; 0 > n4; ++n4) {
                    int n14 = n5 >> 1563408872;
                    n5 += n6;
                    int n15 = -n14 + 256;
                    if (n14 < 0) {
                        ++n9;
                        ++n8;
                        continue;
                    }
                    int n16 = ck2.D[n9++];
                    if (~n16 != -1) {
                        if (~n14 < -256) {
                            hk.hk_l[n8] = n16;
                        } else {
                            int n17 = hk.hk_l[n8];
                            int n18 = n15 * (0xFF00FF & n17) + n14 * (n16 & 0xFF00FF) >> 484059016 & 0xFF00FF;
                            hk.hk_l[n8] = lb.a(65280, lb.a(65280, n16) * n14 + n15 * lb.a(65280, n17) >> -1554550744) + n18;
                        }
                    }
                    ++n8;
                }
                n9 += n13;
                n8 += n12;
            }
            return;
        }
    }

    static final cd a(boolean bl, boolean bl2) {
        if (bl) {
            ck ck2 = null;
            bn.a((byte)42, -57, 101, -103, ck2, 71);
        }
        cd cd2 = new cd(true);
        cd2.cd_e = bl2;
        return cd2;
    }

    static final void a(long l, int n, byte by) {
        if (by != -84) {
            bn_f = null;
        }
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n2 = uf2.wl_n;
        uf2.a(true, 6);
        uf2.a(l, (byte)0);
        uf2.b(uf2.wl_n + -n2, true);
    }

    static {
        bn_c = "PANIC!";
        bn_a = "Kick";
        bn_d = "Loading graphics";
        bn_b = "Enter name of player to delete from list";
    }
}
