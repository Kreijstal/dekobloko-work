/*
 * Decompiled with CFR 0.152.
 */
interface vn
extends kg {
    public void a(byte var1, int var2, ek var3, int var4, int var5);
}
