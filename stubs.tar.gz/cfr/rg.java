/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class rg {
    static String rg_b = "Offline";
    static String rg_e = "Player names can be up to 12 letters, numbers and underscores";
    static String rg_d;
    static String rg_f;
    static qm rg_g;
    static boolean rg_c;
    static sk rg_a;

    static final boolean a(Applet applet, byte by) {
        boolean bl = client.A;
        if (vf.vf_a) {
            return true;
        }
        try {
            String string = "tuhstatbut";
            String string2 = (String)nc.a(true, "getcookies", applet);
            String[] stringArray = ji.a(';', (byte)66, string2);
            if (by >= -55) {
                rg.a(-124);
            }
            int n = 0;
            while (~n > ~stringArray.length) {
                int n2 = stringArray[n].indexOf(61);
                if (n2 >= 0 && stringArray[n].substring(0, n2).trim().equals(string)) {
                    return true;
                }
                ++n;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null != applet.getParameter("tuhstatbut");
    }

    public static void a(int n) {
        rg_d = null;
        rg_b = null;
        rg_e = null;
        rg_g = null;
        rg_a = null;
        int n2 = 36 / ((-41 - n) / 35);
        rg_f = null;
    }

    static {
        rg_f = "Can you unlock the Master Challenge by reaching Stage<nbsp>4 of Stamina Mode?";
        rg_d = "Please try again in a few minutes.";
        rg_g = new qm(10, 2, 2, 0);
        rg_c = true;
    }
}
