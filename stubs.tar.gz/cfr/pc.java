/*
 * Decompiled with CFR 0.152.
 */
final class pc {
    static String pc_c = "A detailed explanation of each rule can be found through the link on our website.<br>(in the Help Section)";
    static String pc_d = "Private";
    static ji pc_b;
    static String pc_a;
    static String pc_e;
    static String pc_f;

    static final String a(int n) {
        if (sh.sh_d == pa.V) {
            return ve.Gc;
        }
        if (n != 2) {
            return null;
        }
        return tc.Qb;
    }

    public static void a(byte by) {
        pc_d = null;
        pc_a = null;
        if (by >= -9) {
            return;
        }
        pc_e = null;
        pc_b = null;
        pc_c = null;
        pc_f = null;
    }

    static final boolean a(int n, int n2, long l, String string, int[] nArray) {
        if (n2 != 2) {
            pc_a = null;
        }
        return nArray != null && (n != 2 || sg.a(string, 120, l));
    }

    static {
        pc_a = "FINISH<br><%0>";
        pc_e = "Change display name";
        pc_f = "Return to Main Menu";
    }
}
