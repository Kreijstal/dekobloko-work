/*
 * Decompiled with CFR 0.152.
 */
final class nd {
    static int[] nd_a;
    static int nd_b;
    private static final String z;

    public static void a(int n) {
        if (n != 3) {
            nd_b = -26;
        }
        nd_a = null;
    }

    static {
        z = "nd.A(";
        nd_a = new int[]{2, 3, 4, 6, 8};
    }
}
