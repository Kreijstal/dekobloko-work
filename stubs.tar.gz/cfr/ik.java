/*
 * Decompiled with CFR 0.152.
 */
final class ik {
    static gb ik_e;
    static int[][] ik_h;
    static ei[] ik_c;
    static String[] ik_d;
    static ck[][] ik_b;
    static String ik_g;
    static wg ik_f;
    static String ik_a;

    static final void a(int n2, ck ck2, String string) {
        block0: {
            lb.lb_h = ck2;
            n.n_b = string;
            if (n2 == 200) break block0;
            ik_f = null;
        }
    }

    static final void c(int n2) {
        if (n2 < 34) {
            ik_h = null;
        }
        dj.a(wd.wd_c, 22);
    }

    public static void b(int n2) {
        ik_c = null;
        ik_g = null;
        ik_f = null;
        if (n2 < 74) {
            return;
        }
        ik_d = null;
        ik_a = null;
        ik_b = null;
        ik_e = null;
        ik_h = null;
    }

    static final synchronized long a(int n2) {
        if (n2 != 4) {
            return -114L;
        }
        long l = System.currentTimeMillis();
        if (jf.jf_d > l) {
            pm.pm_e += -l + jf.jf_d;
        }
        jf.jf_d = l;
        return pm.pm_e + l;
    }

    static final int a(byte by, int n2) {
        int n3 = -14 % ((by - 36) / 56);
        return 200 * (-1 + n2) * n2;
    }

    static final boolean a(String string, byte by) {
        if (by != -118) {
            ik_b = null;
        }
        return g.a(-3805, string) != null;
    }

    static final ta a(int n2, String string) {
        if (jj.jj_f.a(91) && !string.equals(jj.jj_f.b((byte)86))) {
            jj.jj_f = ui.a(0, string);
        }
        if (n2 <= 96) {
            return null;
        }
        return jj.jj_f;
    }

    static {
        ik_d = new String[]{null, "Or click", "Or click", "Or click", "Or click", "Or click", "Or click", "Or click"};
        ik_g = "Offer unrated rematch";
        ik_b = new ck[6][4];
        ik_c = new ei[8];
        ik_f = new wg();
        ik_a = "Open";
    }
}
