/*
 * Decompiled with CFR 0.152.
 */
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;

final class oh
implements Runnable {
    static int oh_n = 64;
    static w oh_d;
    private URL oh_j;
    private mh oh_h;
    private DataInputStream oh_g;
    private int oh_k;
    private wl oh_a;
    static char[] oh_f;
    private fd oh_m;
    static boolean oh_b;
    private mh oh_l;
    static ck oh_e;
    static w oh_i;
    static int[] oh_c;
    private mh oh_o;

    final wl a(boolean bl) {
        if (3 == this.oh_k) {
            return this.oh_a;
        }
        if (!bl) {
            return null;
        }
        this.oh_k = -68;
        return null;
    }

    final synchronized boolean a(int n) {
        if (2 <= this.oh_k) {
            return true;
        }
        if (this.oh_k == 0) {
            if (null == this.oh_o) {
                this.oh_o = this.oh_m.a(this.oh_j, (byte)66);
            }
            if (~this.oh_o.mh_c == -1) {
                return false;
            }
            if (~this.oh_o.mh_c != -2) {
                this.oh_o = null;
                ++this.oh_k;
                return false;
            }
        }
        if (~this.oh_k == -2) {
            if (this.oh_h == null) {
                this.oh_h = this.oh_m.a(100, this.oh_j.getHost(), 443);
            }
            if (~this.oh_h.mh_c == -1) {
                return false;
            }
            if (1 != this.oh_h.mh_c) {
                ++this.oh_k;
                this.oh_h = null;
                return false;
            }
        }
        if (null == this.oh_g) {
            try {
                if (0 == this.oh_k) {
                    this.oh_g = (DataInputStream)this.oh_o.mh_b;
                }
                if (~this.oh_k == -2) {
                    Socket socket = (Socket)this.oh_h.mh_b;
                    socket.setSoTimeout(10000);
                    OutputStream outputStream = socket.getOutputStream();
                    outputStream.write(17);
                    outputStream.write(km.a(6216, (CharSequence)("JAGGRAB " + this.oh_j.getFile() + "\n\n")));
                    this.oh_g = new DataInputStream(socket.getInputStream());
                }
                this.oh_a.wl_n = 0;
            }
            catch (IOException iOException) {
                this.finalize();
                ++this.oh_k;
            }
        }
        if (n >= -89) {
            this.a(true);
        }
        if (null == this.oh_l) {
            this.oh_l = this.oh_m.a((byte)121, 5, this);
        }
        if (0 == this.oh_l.mh_c) {
            return false;
        }
        if (-2 != ~this.oh_l.mh_c) {
            this.finalize();
            ++this.oh_k;
            return false;
        }
        return false;
    }

    static final byte[] a(String string, int n) {
        block0: {
            if (n == -15192) break block0;
            String string2 = null;
            oh.a(null, -55, null, null, string2);
        }
        return lc.lc_h.a(0, string, "");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public final void run() {
        boolean bl = client.A;
        try {
            int n;
            while (this.oh_a.wl_n < this.oh_a.wl_r.length && (n = this.oh_g.read(this.oh_a.wl_r, this.oh_a.wl_n, -this.oh_a.wl_n + this.oh_a.wl_r.length)) >= 0) {
                this.oh_a.wl_n += n;
            }
            if (this.oh_a.wl_r.length == this.oh_a.wl_n) {
                throw new Exception("HG1: " + this.oh_a.wl_r.length + " " + this.oh_j);
            }
            oh oh2 = this;
            synchronized (oh2) {
                this.finalize();
                this.oh_k = 3;
            }
        }
        catch (Exception exception) {
            oh oh3 = this;
            synchronized (oh3) {
                this.finalize();
                ++this.oh_k;
            }
        }
    }

    public static void b(boolean bl) {
        oh_e = null;
        oh_c = null;
        oh_d = null;
        if (bl) {
            return;
        }
        oh_f = null;
        oh_i = null;
    }

    static final void a(byte by) {
        block0: {
            if (by == 13) break block0;
            String string = null;
            oh.a(string, -97);
        }
    }

    protected final void finalize() {
        if (null != this.oh_o) {
            if (this.oh_o.mh_b != null) {
                try {
                    ((DataInputStream)this.oh_o.mh_b).close();
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            this.oh_o = null;
        }
        if (this.oh_h != null) {
            if (this.oh_h.mh_b != null) {
                try {
                    ((Socket)this.oh_h.mh_b).close();
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            this.oh_h = null;
        }
        if (this.oh_g != null) {
            try {
                this.oh_g.close();
            }
            catch (Exception exception) {
                // empty catch block
            }
            this.oh_g = null;
        }
        this.oh_l = null;
    }

    static final ui a(ji ji2, int n, String string, pl pl2, String string2) {
        if (n != 91) {
            return null;
        }
        int n2 = ji2.b(n + -92, string);
        int n3 = ji2.a(n2, n + 12939, string2);
        return jg.a(true, pl2, n3, n2, ji2);
    }

    oh(fd fd2, URL uRL, int n) {
        this.oh_j = uRL;
        this.oh_m = fd2;
        this.oh_a = new wl(n);
    }

    static {
        oh_b = false;
        oh_f = new char[]{(char)91, (char)93, (char)35};
    }
}
