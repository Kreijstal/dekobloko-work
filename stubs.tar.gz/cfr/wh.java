/*
 * Decompiled with CFR 0.152.
 */
final class wh {
    static int wh_a;
    static String wh_e;
    static ck wh_f;
    static boolean wh_b;
    static int wh_c;
    static int wh_d;
    private static final String z;

    public static void a(boolean bl) {
        block0: {
            wh_f = null;
            wh_e = null;
            if (bl) break block0;
            wh.a(true);
        }
    }

    static {
        z = "wh.A(";
        wh_e = "Player";
        wh_b = false;
    }
}
