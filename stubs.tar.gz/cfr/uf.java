/*
 * Decompiled with CFR 0.152.
 */
import java.util.Date;

final class uf
extends wl {
    private int uf_v;
    private ee uf_u;
    private int x;
    static int A;
    static vj z;
    static ck uf_w;
    static String uf_t;
    static ck[] y;
    static String[] B;

    uf(byte[] byArray) {
        super(byArray);
    }

    final int i(byte by) {
        int n = -7 / ((by - -78) / 33);
        return this.wl_r[this.wl_n++] - this.uf_u.a(false) & 0xFF;
    }

    final void l(int n) {
        block0: {
            this.wl_r[this.wl_n] = 0;
            this.uf_v = 8;
            if (n > 44) break block0;
            uf.a((byte)40, -33L);
        }
    }

    final void j(int n) {
        block1: {
            if (-9 < ~this.uf_v) {
                ++this.wl_n;
                this.uf_v = 8;
            }
            if (n == 20) break block1;
            this.i((byte)-104);
        }
    }

    uf(int n) {
        super(n);
    }

    final void a(int n, int n2, int n3) {
        boolean bl = client.A;
        n3 &= ee.ee_b[n];
        if (n2 != 0) {
            uf_w = null;
        }
        while (~n < ~this.uf_v) {
            int n4 = this.wl_n++;
            this.wl_r[n4] = (byte)(this.wl_r[n4] + (n3 >>> (n -= this.uf_v)));
            this.wl_r[this.wl_n] = 0;
            this.uf_v = 8;
        }
        if (~this.uf_v != ~n) {
            this.uf_v -= n;
            int n5 = this.wl_n;
            this.wl_r[n5] = (byte)(this.wl_r[n5] + (n3 << this.uf_v));
        } else {
            int n6 = this.wl_n++;
            this.wl_r[n6] = (byte)(this.wl_r[n6] + n3);
            this.wl_r[this.wl_n] = 0;
            this.uf_v = 8;
        }
    }

    static final void g(int n, int n2) {
        boolean bl = client.A;
        if (n2 != -2093) {
            uf_w = null;
        }
        fl.a(130, 256, 16694016, mb.mb_e, n + 80, w.w_kb);
        int n3 = 140;
        int n4 = 0;
        for (int i = 0; i < 6; ++i) {
            int n5 = 245 * (i % 2) + (80 + n);
            fl.a(n3 - -14, 256, 0xFFFFFF, nk.nk_d[i][0], n5, w.w_kb);
            tg.a(true, i).c(n5 - -n, 20 + n3, 18, 18);
            int n6 = ga.a(211, 0, n3 + 20, nk.nk_d[i][1], 16, 64, 0xFFFFFF, se.S, (byte)-128, 0, n5 + 24);
            if (~n4 > ~n6) {
                n4 = n6;
            }
            if (-2 != ~(i % 2)) continue;
            n3 += 16 * n4 + 20 - -8;
            n4 = 0;
            if (~i <= -5) continue;
            hk.a(n + 80, -5 + n3, 480, 394758);
            hk.a(n + 80, -4 + n3, 480, 0x606060);
        }
    }

    final void j(byte by) {
        block0: {
            this.x = 8 * this.wl_n;
            if (by == -108) break block0;
            this.j(119);
        }
    }

    static final void k(int n) {
        block8: {
            boolean bl = client.A;
            if (lg.W > 0) {
                --lg.W;
            } else if (~bf.bf_r < -1) {
                --bf.bf_r;
            } else if (-1 > ~tg.tg_e) {
                --tg.tg_e;
            }
            if (~lg.W < -1) {
                pa.g((byte)-89);
            }
            if (bf.bf_r > 0) {
                qf.a(bf.bf_r, 114);
            }
            if (~tg.tg_e < -1) {
                qf.a(tg.tg_e, 112);
            }
            if (n == -4840) break block8;
            uf.h((byte)73);
        }
    }

    final void a(int n, byte[] byArray, int n2, int n3) {
        boolean bl = client.A;
        int n4 = 55 / ((5 - n) / 45);
        for (int i = 0; i < n2; ++i) {
            byArray[n3 + i] = (byte)(this.wl_r[this.wl_n++] + -this.uf_u.a(false));
        }
    }

    final void k(byte by) {
        block0: {
            this.wl_n = (7 + this.x) / 8;
            if (by < -97) break block0;
            uf_w = null;
        }
    }

    public static void h(byte by) {
        z = null;
        y = null;
        if (by <= 111) {
            A = -90;
        }
        uf_t = null;
        uf_w = null;
        B = null;
    }

    final void f(int n, int n2) {
        block0: {
            this.wl_r[this.wl_n++] = (byte)(n + this.uf_u.a(false));
            if (n2 == -4) break block0;
            y = null;
        }
    }

    final int a(int n, byte by) {
        boolean bl = client.A;
        if (by <= 39) {
            return 9;
        }
        int n2 = this.x >> 227270371;
        int n3 = -(7 & this.x) + 8;
        int n4 = 0;
        this.x += n;
        while (~n3 > ~n) {
            n4 += (ee.ee_b[n3] & this.wl_r[n2++]) << n + -n3;
            n -= n3;
            n3 = 8;
        }
        n4 = ~n != ~n3 ? (n4 += this.wl_r[n2] >> -n + n3 & ee.ee_b[n]) : (n4 += ee.ee_b[n3] & this.wl_r[n2]);
        return n4;
    }

    static final String a(byte by, long l) {
        ed.ed_a.setTime(new Date(l));
        int n = ed.ed_a.get(7);
        int n2 = ed.ed_a.get(5);
        int n3 = ed.ed_a.get(2);
        int n4 = ed.ed_a.get(1);
        int n5 = ed.ed_a.get(11);
        if (by != 60) {
            uf.a((byte)-1, 45L);
        }
        int n6 = ed.ed_a.get(12);
        int n7 = ed.ed_a.get(13);
        return tm.tm_f[-1 + n] + ", " + n2 / 10 + n2 % 10 + "-" + db.db_e[n3] + "-" + n4 + " " + n5 / 10 + n5 % 10 + ":" + n6 / 10 + n6 % 10 + ":" + n7 / 10 + n7 % 10 + " GMT";
    }

    final void a(int[] nArray, byte by) {
        block0: {
            this.uf_u = new ee(nArray);
            if (by > 61) break block0;
            this.i((byte)-25);
        }
    }

    static {
        uf_t = "Concluded";
        B = new String[]{"[BACKSPACE]", "[HOME]", "[F9]", "[F10]", "[F11]", "[ESC]"};
    }
}
