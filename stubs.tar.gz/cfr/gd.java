/*
 * Decompiled with CFR 0.152.
 */
final class gd {
    static String gd_a = "You need a rating of <%1> to play with the current options.";
    static boolean gd_b;
    static String gd_h;
    static ln gd_c;
    static ck[] gd_g;
    static int gd_e;
    static String gd_i;
    static String gd_d;
    static boolean gd_f;

    static final boolean a(int n, int n2, int n3, byte by) {
        int n4 = -42 / ((-5 - by) / 35);
        return vm.a(-89, n3, n2, n);
    }

    static final String a(boolean bl, int n, int n2, int n3) {
        if (n3 <= 0) {
            throw new IllegalArgumentException("Can only get ordinal for positive numbers");
        }
        if (bl) {
            gd.a(false, 12, -120, -73);
        }
        if (-1 == ~n) {
            int n4 = n3 % 100;
            if (-12 >= ~n4 && -14 <= ~n4) {
                return n3 + "th";
            }
            int n5 = n3 % 10;
            if (~n5 == -2) {
                return n3 + "st";
            }
            if (n5 == 2) {
                return n3 + "nd";
            }
            if (~n5 == -4) {
                return n3 + "rd";
            }
            return n3 + "th";
        }
        if (~n == -2) {
            return n3 + ".";
        }
        if (2 == n) {
            if (-2 == ~n3) {
                if (2 != n2) {
                    return n3 + "er";
                }
                return n3 + "\u00e8re";
            }
            return n3 + "\u00e8me";
        }
        if (-4 == ~n) {
            if (~n2 != -3) {
                return n3 + "\u00ba";
            }
            return n3 + "\u00aa";
        }
        if (~n == -5) {
            return n3 + "e";
        }
        throw new IllegalArgumentException("Unsupported language " + n);
    }

    public static void a(byte by) {
        gd_c = null;
        if (by != -118) {
            gd.a(90, -20, -14, (byte)115);
        }
        gd_i = null;
        gd_g = null;
        gd_d = null;
        gd_h = null;
        gd_a = null;
    }

    static {
        gd_h = "Spectate";
        gd_c = new ln();
        gd_i = "Fullscreen mode was cancelled after a delay of 10 seconds. If you were unable to accept fullscreen mode during this time, there may be a problem with your configuration. You could try restarting your browser and trying again.";
        gd_d = "This game option is not available in rated games.";
    }
}
