/*
 * Decompiled with CFR 0.152.
 */
interface jl {
    public nb a(int var1);
}
