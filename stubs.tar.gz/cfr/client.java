/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;

public final class client
extends bd {
    static byte[] D = new byte[65536];
    static ud F;
    static String E;
    static String y;
    static ck[] x;
    static ck[] C;
    static String B;
    public static boolean A;

    private final void o(int n) {
        if (null != wk.wk_q) {
            sh.a(false, wk.wk_q);
            wk.wk_q = null;
            vj.a(true);
        }
        tm.b((byte)-81);
        cl.y = vg.a(3, 21);
        vb.S = vg.a(4, 44);
        ii.ii_t = vg.a(6, 39);
        eg.eg_e = vg.a(11, 102);
        ph.Db = vg.a(7, 50);
        jj.jj_c = vg.a(8, 113);
        ah.ah_d = vg.a(9, n ^ 0x6123);
        wg.wg_h = vg.a(10, n ^ 0x616A);
        sh.sh_g = new cb(65);
        sh.sh_g.a("basic", ah.ah_i, bn.bn_d, (byte)95, ng.ng_l);
        sh.sh_g.a("arial13", ah.ah_i, un.un_a, (byte)112, ne.ne_d);
        sh.sh_g.a("arial13", qc.qc_vb, un.un_a, (byte)106, ne.ne_d);
        sh.sh_g.a("arialbold14", ah.ah_i, un.un_a, (byte)-97, ne.ne_d);
        sh.sh_g.a("arialbold14", qc.qc_vb, un.un_a, (byte)94, ne.ne_d);
        sh.sh_g.a("lobby", ah.ah_i, bn.bn_d, (byte)-21, ng.ng_l);
        sh.sh_g.a("lobby", qc.qc_vb, un.un_a, (byte)87, ne.ne_d);
        sh.sh_g.a(sc.sc_k, (byte)122, jj.jj_c, he.he_fb);
        sh.sh_g.a(sc.sc_k, (byte)-109, ah.ah_d, he.he_fb);
        if (n != 24903) {
            String string = null;
            client.a(string, -14);
        }
        sh.sh_g.a(tm.tm_g, (byte)51, wg.wg_h, kd.kd_q);
        sh.sh_g.a("", ii.ii_t, bn.bn_d, (byte)102, ng.ng_l);
        sh.sh_g.a("", ph.Db, un.un_a, (byte)-107, ne.ne_d);
        sh.sh_g.a(qa.qa_w, (byte)-121, eg.eg_e, ga.ga_b);
        sh.sh_g.a(bk.Ob, (byte)114, cl.y, bg.bg_c);
        sh.sh_g.a(bk.Ob, (byte)-45, vb.S, bg.bg_c);
    }

    static final jc a(String string, int n) {
        if (string == null || 0 == string.length()) {
            return eh.eh_b;
        }
        int n2 = string.indexOf(64);
        if (-1 == n2) {
            return hm.hm_a;
        }
        String string2 = string.substring(0, n2);
        String string3 = string.substring(1 + n2);
        if (n != -12828) {
            return null;
        }
        jc jc2 = ng.a(n + 12827, string2);
        if (null != jc2) {
            return jc2;
        }
        return da.a(string3, -2734);
    }

    private final void i(byte by) {
        block125: {
            boolean bl2;
            int n;
            boolean bl3 = A;
            boolean bl4 = false;
            if (kf.I != null && ~kf.I.qc_g.eb_i <= -4) {
                bl4 = true;
            }
            if (null != ce.C && -4 >= ~ce.C.qc_g.eb_i) {
                bl4 = true;
            }
            if (bl4) {
                if (of.of_e > 0) {
                    --of.of_e;
                }
                if (of.of_e == 0) {
                    if (~kd.kd_u > -16 && ~jf.jf_c > -16 && 8 > ak.ak_d) {
                        ++ak.ak_d;
                    }
                    if (15 < kd.kd_u && ~jf.jf_c < -16 && -2 > ~ak.ak_d) {
                        --ak.ak_d;
                    }
                    of.of_e = 50;
                    kd.kd_u = jf.jf_c;
                }
            } else {
                ak.ak_d = 1;
            }
            fl.a((byte)-108);
            pm.pm_g = ne.b((byte)-40);
            if (sa.x && null != wj.Ob) {
                wj.Ob.a(a.a_g * 50 / 128);
                sa.x = false;
            }
            if (cl.cl_v != null && cl.cl_v.ql_e) {
                sn.a(false);
                nm.e(54);
            }
            this.b(null != cl.cl_v, -11);
            if (of.of_c) {
                this.o(24903);
                of.of_c = false;
            }
            ++uf.A;
            if (ta.a((byte)-104)) {
                this.g(10);
                if (ta.a((byte)-93)) {
                    return;
                }
            }
            if (!sh.sh_j) {
                ql.a(jk.jk_c, (byte)-115);
                if (this.n(0)) {
                    sh.sh_j = true;
                }
            } else if (se.i(-1)) {
                int n2;
                if (!ai.f((byte)-127)) {
                    if (!pk.d(65)) {
                        if (cn.f((byte)123)) {
                            if (gb.Vb != gb.Ob) {
                                this.b(30661, false);
                            } else {
                                n2 = we.a(false);
                                if (~n2 == -2) {
                                    og.a(im.im_f, fe.fe_b, true);
                                }
                                this.b(30661, true);
                            }
                        } else {
                            this.b(30661, false);
                        }
                    } else {
                        n2 = this.a(null != cl.cl_v, (byte)102);
                        if (1 == n2 || 2 == n2) {
                            if (cl.cl_v != null) {
                                sn.a(false);
                            }
                            if (~n2 == -3) {
                                pk.me_a_applet((byte)-17, se.h(25144));
                            }
                        }
                        this.b(30661, true);
                    }
                } else if (~gb.Vb != ~gb.Ob) {
                    this.b(30661, false);
                } else {
                    n2 = tm.a((byte)-117);
                    if (-3 == ~n2) {
                        sn.a(false);
                    } else if (~n2 != -4) {
                        if (~n2 == -5) {
                            og.a(true, 3, true);
                        }
                    } else {
                        jk.a(2, true);
                    }
                    this.b(30661, true);
                }
            } else {
                dc.a(-60);
            }
            if (!ph.n(-30146)) {
                bh bh2;
                while (true) {
                    ki ki2;
                    bh2 = ki2 = (ki)si.si_e.a(4);
                    if (ki2 == null) break;
                    ce.a(4, ki2, -697);
                }
                while (true) {
                    ff ff2 = (ff)jm.jm_r.a(4);
                    bh2 = ff2;
                    if (ff2 == null) break;
                    wk.a(3, 5, ff2);
                }
            }
            block2: while (vi.a(mk.mk_c, 0)) {
                int n3;
                int n4;
                if (~bh.bh_k == -10) {
                    mn.mn_c = false;
                    String string = de.V.c((byte)-38);
                    wj.a(1, -86, false, 0, true, string);
                    continue;
                }
                if (77 == bh.bh_k) {
                    mn.mn_c = false;
                    pn.a(true, false, true);
                    continue;
                }
                if (-15 == ~bh.bh_k) {
                    we.a((byte)66);
                    cd.a(true);
                    nk.a(id.g(8192), rd.b(-95), 0, 5, oe.b(-10498, 2000), qi.e((byte)117), vl.A, 150, oe.b(-10498, 8), 1024);
                    dg.a(21014, tc.g((byte)98), l.a(-126));
                    gk.Ib = true;
                    uh.uh_b = true;
                    mn.mn_c = false;
                    int[] nArray = j.j_d;
                    int[] nArray2 = j.j_d;
                    n = 0;
                    while (~n > -9) {
                        nArray[n] = 0;
                        ++n;
                    }
                    continue;
                }
                if (~bh.bh_k == -16) {
                    if (uh.uh_b) {
                        bb.b(true);
                        kh.a(true);
                        kf.G = f.a(false, false, 0, false, false, 32357, false, false);
                        dc.a(false, 126);
                        un.a((byte)-124);
                        fm.fm_b = false;
                        fa.fa_n = false;
                        gd.gd_f = true;
                        uh.uh_b = false;
                        jg.a(-48);
                    }
                    mn.mn_c = false;
                    wk.wk_i = false;
                    continue;
                }
                if (~bh.bh_k == -11 && uh.uh_b) {
                    ke.a((byte)113);
                    continue;
                }
                if (-76 == ~bh.bh_k) {
                    int[] nArray;
                    int[] nArray3 = nArray = b.h(-123);
                    Object object = de.V;
                    int n5 = ((wl)object).d((byte)-45);
                    int n6 = 0;
                    while (~n6 > ~n5) {
                        nArray3[n6] = ((wl)object).i(7553);
                        ++n6;
                    }
                    if (nm.Qb) {
                        int[] nArray4 = nArray;
                        int[] nArray5 = o.o_g;
                        object = o.o_g;
                        n5 = 0;
                        while (-9 < ~n5) {
                            nArray4[n5] = lb.a(nArray4[n5], ~nArray5[n5]);
                            ++n5;
                        }
                        if (null != kf.I && kf.I.qc_g.eb_p[kf.I.P] != null) {
                            n = 0;
                            while (~n > -32) {
                                if (rb.a(-18, n, nArray)) {
                                    kf.I.qc_g.eb_p[kf.I.P].lk_cb.a(new vd(n), 2777);
                                }
                                ++n;
                            }
                        }
                        int[] nArray6 = j.j_d;
                        int[] nArray7 = nArray;
                        object = nArray;
                        n5 = 0;
                        while (~n5 > -9) {
                            nArray6[n5] = de.b(nArray6[n5], nArray7[n5]);
                            ++n5;
                        }
                    }
                    int[] nArray8 = o.o_g;
                    int[] nArray9 = nArray;
                    object = nArray;
                    n5 = 0;
                    while (-9 < ~n5) {
                        nArray8[n5] = de.b(nArray8[n5], nArray9[n5]);
                        ++n5;
                    }
                    continue;
                }
                if (58 == bh.bh_k || bh.bh_k == 59) {
                    int n7;
                    int n8;
                    int n9 = de.V.e(3);
                    n = n9 & 0xF;
                    int n10 = 3 & n9 >> 1315490500;
                    int n11 = n9 >> -1189014074 & 7;
                    int n12 = (n9 & 0xEE4) >> -1446042807;
                    n4 = ~(n9 & 0x1000) != -1 ? 1 : 0;
                    n3 = (0x2000 & n9) != 0 ? 1 : 0;
                    boolean bl5 = (n9 & 0x4000) != 0;
                    boolean bl6 = -1 != ~(n9 & 0x8000);
                    int n13 = de.V.e(3);
                    int n14 = de.V.d((byte)-92);
                    int n15 = de.V.d((byte)-116);
                    int n16 = de.V.g((byte)-100);
                    if (~n16 > -1) {
                        n16 = -2;
                    }
                    String[] stringArray = new String[n15];
                    for (n8 = 0; n8 < n15; ++n8) {
                        stringArray[n8] = de.V.b(true);
                    }
                    n8 = de.V.d((byte)-27);
                    gh.gh_e = null;
                    qc qc2 = new qc(true, n14, n4 != 0, n, n10, n11, n12, stringArray, n16, n3 != 0, false, false);
                    qc2.R = n13;
                    qc2.qc_r = bl5;
                    if (!bl5) {
                        if (bl6) {
                            qc2.qc_p.a(new in(cf.cf_e, 10, true), 2777);
                        }
                    } else {
                        qc2.qc_p.a(new in(bn.bn_c, 8, true), 2777);
                    }
                    int n17 = 0;
                    for (n7 = 0; n7 < qc2.qc_g.eb_b; ++n7) {
                        if (-1 == ~(n8 & 1 << n7)) continue;
                        qc2.V[n7] = 200;
                        ++n17;
                    }
                    if (-3 > ~n17) {
                        qc2.Ab = 100;
                    }
                    n7 = qc2.P;
                    if (-1 < ~n7) {
                        n7 = 0;
                        while (200 != qc2.V[n7]) {
                            ++n7;
                        }
                    }
                    if (2 == n17) {
                        n7 = (n7 + 1) % qc2.qc_g.eb_b;
                        while (qc2.V[n7] != 200) {
                            n7 = (n7 - -1) % qc2.qc_g.eb_b;
                        }
                    }
                    qc2.D = qc2.qc_i = n7;
                    qc2.qc_lb = qc2.qc_i;
                    if (-59 != ~bh.bh_k) {
                        ce.C = qc2;
                        fa.fa_n = true;
                    } else {
                        kf.I = qc2;
                        fm.fm_b = true;
                        eb.a(58);
                    }
                    wk.wk_i = false;
                    am.am_c = true;
                    ui[] uiArray = n != 10 ? sb.sb_u[n14] : ee.ee_a;
                    nn.a(qc2.b(true), uiArray[0], true);
                    continue;
                }
                if (bh.bh_k == 60) {
                    if (fm.fm_b || fa.fa_n) {
                        fm.fm_b = false;
                        am.am_c = false;
                        fa.fa_n = false;
                        cd.a(true);
                        un.a((byte)-125);
                        jg.a(-111);
                    }
                    wk.wk_i = false;
                    continue;
                }
                qc qc3 = null;
                if (fm.fm_b) {
                    qc3 = kf.I;
                } else if (fa.fa_n) {
                    qc3 = ce.C;
                }
                if (null != qc3) {
                    if (61 == bh.bh_k) {
                        n = de.V.d((byte)-92);
                        lk lk2 = qc3.qc_g.eb_p[n];
                        lk2.a(~n == ~qc3.P, de.V, (byte)118);
                        qc3.a(true, lk2, 600, 200, lk2.lk_jb, n, false);
                        if (qc3.P != n) continue;
                        we.we_b.f(59, -4);
                        we.we_b.a(true, lk2.U);
                        qc3.E = 7 * lk2.yb - 4;
                        continue;
                    }
                    if (bh.bh_k == 62) {
                        n = de.V.d((byte)-124);
                        int n18 = de.V.d((byte)-116);
                        if (~qc3.qc_g.eb_b >= ~n || qc3.qc_g.eb_p[n] == null) {
                            qb.a(null, 16408, "T4: " + n);
                            si.a(85);
                            continue;
                        }
                        lk lk3 = qc3.qc_g.eb_p[n];
                        while (~lk3.lk_fb > ~lk3.lk_gb) {
                            if (qc3.b(-117, n)) continue;
                            qb.a(null, 16408, "T6");
                            si.a(79);
                            continue block2;
                        }
                        qc3.a(18, lk3, n);
                        qc3.qc_g.eb_p[n] = null;
                        qc3.qc_g.eb_d &= ~(1 << n);
                        --qc3.qc_g.eb_i;
                        if (qc3.P == n) {
                            cd.a(true);
                            ob.ob_k = true;
                            qc3.a(rm.rm_b, 0);
                        }
                        qc3.qc_r = false;
                        ca.ca_kb = 1;
                        jb.jb_a = false;
                        rb.rb_e = 0;
                        ak.ak_d = 1;
                        qc3.T = n18;
                        continue;
                    }
                    if (-64 == ~bh.bh_k) {
                        n = de.V.d((byte)-53);
                        int n19 = de.V.d((byte)-118);
                        int n20 = sm.sm_e + -de.V.wl_n;
                        if (0 > n20) {
                            qb.a(null, 16408, "T8: " + n + " " + n19 + " " + n20);
                            si.a(65);
                            continue;
                        }
                        uf uf2 = new uf(n20 + 1);
                        uf2.a(true, n19);
                        uf2.a(false, n20, de.V.wl_r, de.V.wl_n);
                        uf2.wl_n = 0;
                        qc3.qc_v[n].lb_g.a(uf2, 2777);
                        qc3.qc_v[n].lb_e += n19;
                        continue;
                    }
                    if (-65 == ~bh.bh_k) {
                        n = de.V.d((byte)-127);
                        lk lk4 = qc3.qc_g.eb_p[n];
                        vm vm2 = new vm();
                        vm2.y = de.V.g((byte)-88);
                        vm2.vm_n = de.V.g((byte)-118);
                        vm2.vm_v = de.V.d((byte)-93);
                        vm2.vm_o = de.V.d((byte)-83);
                        vm2.vm_q = qc3.qc_db.a(true, true, de.V);
                        vm2.vm_t = de.V.d((byte)-64);
                        qc3.qc_v[n].lb_g.a(vm2, 2777);
                        int n21 = de.V.a(117);
                        n4 = de.V.a(127) + n21;
                        if (~n4 < ~n21) {
                            for (n3 = n21; n4 > n3; ++n3) {
                                rf rf2 = new rf(n3);
                                if (~n == ~qc3.P) {
                                    rf2.rf_m = -n21 + n3;
                                }
                                qc3.qc_db.a(rf2, 0);
                            }
                            while (~lk4.lk_fb > ~lk4.lk_gb) {
                                if (qc3.b(-126, n)) continue;
                                qb.a(null, 16408, "T7");
                                si.a(97);
                            }
                            lk4.lk_gb = n4;
                            lk4.lk_fb = n21;
                        }
                        if (qc3.P != n) continue;
                        while (vm2.a((byte)58)) {
                            qc3.b(-118, n);
                        }
                        we.we_b.f(59, -4);
                        we.we_b.a(true, qc3.qc_g.eb_p[n].U);
                        qc3.qc_w = 0;
                        continue;
                    }
                    if (-66 == ~bh.bh_k) {
                        n = de.V.d((byte)-60);
                        lk lk5 = qc3.qc_g.eb_p[n];
                        while (qc3.b(-116, n)) {
                        }
                        if (~qc3.P == ~n) {
                            int n22 = 0;
                            while (~lk5.lk_jb < ~n22) {
                                fh.fh_h += 30000;
                                rk.rk_cb += 30000;
                                ++n22;
                            }
                        }
                        lk5.lk_jb = 0;
                        lk5.k(-9897);
                        qc3.qc_w = 0;
                        if (~n != ~qc3.P) continue;
                        qc3.qc_p.a(new in(cb.cb_i, 13, true), 2777);
                        qc3.qc_ob = true;
                        continue;
                    }
                    if (~bh.bh_k == -67) {
                        n = de.V.d((byte)-22);
                        int n23 = de.V.d((byte)-76);
                        lk lk6 = qc3.qc_g.eb_p[n];
                        for (int k = 0; k < n23; ++k) {
                            lk6.b(-19939);
                        }
                        continue;
                    }
                    if (67 == bh.bh_k) {
                        n = de.V.d((byte)-50);
                        rf rf3 = qc3.qc_db.a(true, true, de.V);
                        qc3.qc_g.eb_p[n].a(rf3, (byte)-121);
                        continue;
                    }
                    if (~bh.bh_k == -69) {
                        qc3.T = de.V.d((byte)-35);
                        qc3.qc_p.a(new in(eb.eb_c, 12, false), 2777);
                        continue;
                    }
                    if (bh.bh_k == 69) {
                        qc3.T = de.V.d((byte)-78);
                        qc3.qc_r = true;
                        qc3.qc_p.a(new in(bn.bn_c, 8, false), 2777);
                        continue;
                    }
                    if (~bh.bh_k == -77) {
                        qc3.qc_g.eb_f[qc3.qc_g.eb_o] = de.V.g((byte)-89);
                        ++qc3.qc_g.eb_o;
                        continue;
                    }
                    if (70 == bh.bh_k) {
                        n = de.V.g((byte)-104);
                        int n24 = 0;
                        while (~n24 > ~qc3.qc_g.eb_b) {
                            if (null != qc3.qc_g.eb_p[n24]) {
                                while (!qc3.qc_v[n24].lb_g.b(-24)) {
                                    qc3.b(39, n24);
                                }
                            }
                            ++n24;
                        }
                        qc3.qc_g.a(n, (byte)-70);
                        qc3.a(100);
                        if (qc3.P >= 0) {
                            cd.a(true);
                        }
                        if (-1 < ~n || qc3.qc_ob) {
                            qc3.a(rm.rm_b, 0);
                        } else {
                            qc3.a(hb.Ub, 0);
                        }
                        ob.ob_k = true;
                        continue;
                    }
                    if (71 == bh.bh_k) {
                        qc3.qc_g.eb_d = de.V.d((byte)-45);
                        continue;
                    }
                    if (bh.bh_k == 72) {
                        qc3.qc_g.eb_h = de.V.d((byte)-19);
                        continue;
                    }
                    if (bh.bh_k == 73) {
                        qc3.qc_g.eb_a = de.V.d((byte)-77);
                        continue;
                    }
                    if (~bh.bh_k == -75) {
                        qc3.yb = de.V.d((byte)-31);
                        qc3.qc_g.eb_d &= ~qc3.yb;
                        qc3.qc_g.eb_a &= ~qc3.yb;
                        continue;
                    }
                }
                this.f((byte)126);
            }
            wj.c(4792, 0);
            if (by < 49) {
                String string = null;
                client.a(string, 33);
            }
            boolean bl7 = bl2 = null == hh.hh_a || ~ef.N < -1;
            if (fm.fm_b) {
                boolean bl8 = bl2 = nk.nk_i;
            }
            if (fa.fa_n) {
                boolean bl9 = bl2 = og.og_ib;
            }
            if (bl2) {
                bg.bg_b = 0;
            }
            if (ea.c((byte)-60)) {
                n = this.g((byte)125);
                if (~n == -1 || n == 1) {
                    if (1 != n) {
                        if (uh.uh_b) {
                            un.a((byte)-123);
                            gd.gd_f = true;
                            if (fm.fm_b) {
                                wj.a(1, -99, false, 0, true, af.af_a);
                            }
                            kf.G = f.a(false, false, 0, false, false, 32357, false, false);
                            dc.a(false, 96);
                            uh.uh_b = false;
                            fm.fm_b = false;
                            fa.fa_n = false;
                            jg.a(-100);
                            am.am_c = false;
                        }
                        wk.wk_i = false;
                        mn.mn_c = false;
                    } else {
                        wk.wk_i = true;
                        mn.mn_c = true;
                    }
                }
                boolean bl10 = false;
                if (~n == -3) {
                    bl10 = true;
                }
                if (uh.uh_b || mn.mn_c || wk.wk_i) {
                    bl10 = true;
                }
                if (!ea.c((byte)-88)) {
                    bl10 = false;
                }
                if (bl10) {
                    gh.a(false);
                }
            }
            of.a(0);
            if (!sh.sh_j || am.am_c || jg.jg_a == rc.rc_d) break block125;
            nn.a(256, jg.jg_a, true);
        }
    }

    public static void j(byte by) {
        y = null;
        D = null;
        E = null;
        F = null;
        C = null;
        if (by != -56) {
            C = null;
        }
        x = null;
        B = null;
    }

    @Override
    final void e(int n) {
        if (km.z != null) {
            km.z.e();
        }
        if (n != 0) {
            return;
        }
        if (null != cj.cj_b) {
            cj.cj_b.e();
        }
        if (null != cl.cl_v) {
            sn.a(false);
        }
        s.h((byte)88);
    }

    private final void b(int n2, boolean bl2) {
        block77: {
            int n3;
            block75: {
                block78: {
                    block76: {
                        boolean bl3 = A;
                        if (n2 != 30661) {
                            return;
                        }
                        if (gb.Vb == gb.Ob) break block75;
                        if (ve.ve_nc != gb.Ob) break block76;
                        if (++rf.rf_f != 16) break block77;
                        if (!im.im_f) {
                            ed.a(n2 + -30553);
                        } else {
                            gf.a((byte)-126);
                        }
                        gb.Ob = g.L;
                        break block77;
                    }
                    if (~gb.Ob == ~g.L) break block78;
                    if (-1 != ~(--rf.rf_f)) break block77;
                    gb.Ob = gb.Vb;
                    break block77;
                }
                if (!ph.n(-30146)) {
                    if (null != gh.gh_e) {
                        qb.a(3, (byte)85, gh.gh_e);
                    }
                    ek.g(n2 + -31870);
                    if (1 != fe.fe_b) {
                        if (2 != fe.fe_b) {
                            if (fe.fe_b != 3) {
                                if (fe.fe_b == 4) {
                                    dc.a(false, n2 + -30547);
                                } else if (-6 != ~fe.fe_b) {
                                    if (-7 == ~fe.fe_b) {
                                        cl.B = qj.a(-44, false);
                                    } else if (fe.fe_b != 8) {
                                        if (7 != fe.fe_b) {
                                            throw new IllegalStateException(Integer.toString(fe.fe_b));
                                        }
                                        ca.ca_wb = oj.a(false, 415);
                                    } else {
                                        am.am_a = ib.a((byte)82, false);
                                    }
                                } else {
                                    h.h_d = uh.a(o.o_g, false, 0, -111);
                                }
                            } else {
                                jk.a(2, true);
                            }
                        } else {
                            jm.a(0, true);
                        }
                    } else {
                        vk.a(true, (byte)-53);
                    }
                }
                gb.Ob = lk.I;
                break block77;
            }
            boolean bl4 = false;
            boolean bl5 = false;
            if (!bl2) {
                if (null != kf.G) {
                    if (ba.ba_c) {
                        pd.pd_d.g((byte)-96);
                    } else if (!lk.F) {
                        if (!mg.Zb) {
                            if (!fm.fm_e) {
                                if (!ve.Hc) {
                                    if (nk.nk_k) {
                                        f.f_s.g(2824);
                                    } else if (!gi.gi_b) {
                                        kf.G.k(128);
                                    } else {
                                        h.a(null, (byte)95);
                                        wf.a(false);
                                        n3 = lg.a(0, true);
                                        if (1 == n3 || ~n3 == -3) {
                                            gi.gi_b = false;
                                            kf.G.c(n2 ^ 0xFFFF883A, n3 == 2);
                                        }
                                        if (3 == n3) {
                                            sm.a((byte)-65, se.h(25144));
                                        }
                                    }
                                } else {
                                    ca.ca_wb.d(-8622);
                                }
                            } else {
                                am.am_a.l((byte)101);
                            }
                        } else {
                            cl.B.f((byte)-63);
                        }
                    } else {
                        h.h_d.j(-114);
                    }
                } else if (am.am_c) {
                    if (uh.uh_b) {
                        bl4 = true;
                        bl5 = kf.G == null && !ea.d((byte)92);
                    } else if (!kf.I.b(2, true)) {
                        while (ab.c((byte)50) && !kf.I.e(false)) {
                        }
                    }
                } else if (uh.uh_b) {
                    bl4 = true;
                }
            }
            if (uh.uh_b && !mn.mn_c && !wk.wk_i) {
                if (fm.fm_b && jg.jg_i) {
                    bl4 = false;
                }
                ka.a(bl4, -3051);
                if (fa.fa_n) {
                    ce.C.b(2, bl5);
                }
                if (fm.fm_b) {
                    ph.a(180, 320, false, bl5);
                    if (jg.jg_i) {
                        bl5 = false;
                    }
                    kf.I.b(2, bl5);
                }
                while (ab.c((byte)-123)) {
                    int n4 = n3 = null == hh.hh_a || -1 > ~ef.N ? 1 : 0;
                    if (fm.fm_b) {
                        int n5 = n3 = nk.nk_i ? 1 : 0;
                    }
                    if (fa.fa_n) {
                        int n6 = n3 = og.og_ib ? 1 : 0;
                    }
                    if (!bl2) {
                        if (fm.fm_b) {
                            if (gd.a(13, 12, 15, (byte)-83)) {
                                continue;
                            }
                        } else if (n3 != 0) {
                            ig.a(12, 15, 13, (byte)69);
                        }
                    }
                    if (fa.fa_n && bl5) {
                        ce.C.e(false);
                    }
                    if (!fm.fm_b || !bl5) continue;
                    kf.I.e(false);
                }
            }
            if (!uh.uh_b) {
                gn.b(-29550);
                if (ab.e(n2 + -58860) == 0) {
                    we.a((byte)68);
                }
            }
            int n7 = n3 = hh.hh_a == null || -1 > ~ef.N ? 1 : 0;
            if (fm.fm_b) {
                int n8 = n3 = nk.nk_i ? 1 : 0;
            }
            if (fa.fa_n) {
                int n9 = n3 = og.og_ib ? 1 : 0;
            }
            if (n3 == 0) {
                if (-1 > ~ef.N) {
                    --ef.N;
                }
            } else if (~ef.N > ~dl.M) {
                ++ef.N;
            }
            int n10 = dl.M * dl.M;
            int n11 = -(ef.N * ef.N) + n10;
            int n12 = ea.ea_p + 120 * n11 / n10;
            ij.a(n12, -32);
            if (ue.ue_b == hh.hh_a && ab.e(n2 + -58860) == 0) {
                if (am.am_c) {
                    db.db_d = false;
                    if (kf.I != null && -39 < ~kf.I.qc_hb) {
                        ue.ue_b = dn.dn_p[kf.I.qc_g.eb_l];
                    }
                    if (fa.fa_n) {
                        ue.ue_b = dn.dn_p[ce.C.qc_g.eb_l];
                    }
                    wg.wg_f = !uh.uh_b;
                } else if (uh.uh_b) {
                    db.db_d = false;
                    wg.wg_f = false;
                    ue.ue_b = null;
                } else {
                    db.db_d = true;
                    ue.ue_b = tc.Tb;
                    wg.wg_f = true;
                }
            }
            if (ue.ue_b == hh.hh_a || 30 > ++vf.vf_b) break block77;
            vf.vf_b = 0;
            hh.hh_a = ue.ue_b;
            qd.Nb = wg.wg_f;
        }
    }

    @Override
    final void a(int n2) {
        client.j((byte)-56);
        vd.c((byte)101);
        vj.b((byte)79);
        bj.a(112);
        km.c(710);
        n.b(128);
        ml.a((byte)-33);
        wh.a(true);
        jb.a((byte)-9);
        hn.b(6);
        oh.b(false);
        wg.a(true);
        hm.b(64);
        hk.a();
        ji.a(127);
        th.a(122);
        bb.a(-117);
        wl.d(8);
        ik.b(78);
        jh.a(false);
        fe.a((byte)-108);
        ge.a(true);
        dm.a(121);
        hc.a((byte)82);
        o.a(false);
        l.b(126);
        u.a(23358);
        hl.a(-21128);
        pc.a((byte)-46);
        sh.a((byte)-105);
        lj.a(89);
        jf.a(-114);
        ie.a((byte)-120);
        eh.a(24744);
        cb.b(12623);
        ql.b(-100);
        ri.a((byte)-91);
        dd.b((byte)115);
        im.a(0);
        ne.a((byte)0);
        nh.a((byte)-73);
        qk.c(-11657);
        pl.b(113);
        en.f();
        ui.b(31158);
        ia.f();
        ke.l(126);
        qc.a(false);
        ah.a(8);
        gn.a(0);
        ul.b((byte)-75);
        lk.g(36);
        bh.b(25189);
        wa.a(18);
        ch.a(78);
        d.a(36);
        rc.a(-120);
        tm.a(103);
        j.a(true);
        w.f((byte)77);
        ve.h((byte)116);
        nk.a(-121);
        tj.e(-18263);
        gg.c(0);
        be.a(-106);
        vh.a(true);
        p.a(110);
        ed.b(-96);
        rg.a(-114);
        ka.h((byte)102);
        wj.s(0);
        qn.n((byte)89);
        ph.m((byte)24);
        gk.p(15);
        tf.b(true);
        lg.f((byte)1);
        he.i(0);
        cn.j(3);
        jg.b((byte)101);
        c.a(23302);
        mc.a(0);
        ng.a(-61);
        je.b(23369);
        oa.b(-1);
        ad.a((byte)-67);
        lf.a(-13495);
        of.a((byte)91);
        am.a(119);
        lc.a(-27983);
        mm.a();
        ub.b((byte)-32);
        nd.a(3);
        pd.a((byte)-120);
        h.b((byte)-128);
        uc.a(true);
        rn.a(-117);
        ll.a(108);
        qd.f(77);
        nm.g(48);
        ha.f(3);
        jd.e(32);
        gb.e(-2);
        s.i((byte)-94);
        pf.a((byte)-103);
        mg.f(256);
        ak.a((byte)-112);
        ec.a((byte)102);
        sk.e(-28610);
        vk.a((byte)-93);
        ic.a(-18551);
        vf.a(27067);
        om.a(false);
        kb.a(-109);
        jk.a((byte)-91);
        hh.a(-9724);
        cc.a((byte)-94);
        e.a(-22811);
        pe.a(-1);
        fh.b(0);
        eb.b(92);
        oi.a(2);
        sa.c((byte)-82);
        uk.c(127);
        sl.a((byte)110);
        uf.h((byte)120);
        nn.a(14925);
        gf.a(2);
        v.a(-66);
        gh.a(98);
        fm.a(true);
        ee.a((byte)-78);
        hg.a((byte)126);
        rf.a(false);
        in.a(123);
        vm.a(121);
        eg.a(10140);
        pm.a(62);
        mf.i(-17690);
        gd.a((byte)-118);
        ok.d();
        aj.b(0);
        bk.e(15338);
        qb.d(112);
        ab.d(1);
        pj.h((byte)106);
        kh.b(-1643605936);
        el.b(true);
        le.b(true);
        hf.b(12741);
        ci.a(-27513);
        sf.f((byte)-126);
        pg.a((byte)126);
        ib.m(-30);
        a.a(-1);
        qg.a();
        va.c();
        oj.a(3805);
        dh.a((byte)-68);
        vg.a((byte)91);
        rm.a(2);
        fc.a(38);
        aa.a(true);
        li.a(101);
        dk.b(16057);
        un.b((byte)86);
        oc.a(true);
        mk.a(false);
        if (n2 < 75) {
            return;
        }
        td.a();
        vl.a(true);
        kl.a(true);
        uj.a((byte)111);
        mn.a(-117);
        kk.a((byte)-117);
        bc.b((byte)-102);
        al.a((byte)-100);
        qj.b((byte)126);
        cf.a((byte)126);
        ce.c(54);
        ma.e((byte)-79);
        t.l((byte)94);
        bl.i(2);
        kf.h(116);
        rd.b((byte)-119);
        k.a(-5161);
        ih.b();
        ue.a((byte)-128);
        fl.a(29047);
        ga.a((byte)-52);
        cj.a(-48);
        ig.g((byte)34);
        em.a((byte)82);
        sm.a(30553);
        ac.g((byte)-17);
        me.c(0);
        la.a((byte)92);
        fb.a((byte)117);
        jj.a(false);
        we.b((byte)-37);
        db.a((byte)91);
        dn.d(72);
        wf.f(-119);
        gi.a(79);
        dc.a(true);
        qe.a(-20007);
        kj.a();
        fj.a(25988);
        cg.a(124);
        bn.a((byte)92);
        wd.a(1);
        de.g(-121);
        og.i((byte)109);
        rk.j(81);
        ca.l(104);
        df.a(1);
        qi.f((byte)117);
        g.a(-99);
        pa.h((byte)47);
        dl.b(false);
        wm.c(18966);
        bg.a((byte)22);
        md.f((byte)106);
        ai.a(-59);
        b.a(-109);
        tc.h((byte)105);
        hb.e(-102);
        da.a((byte)-121);
        rb.a(573767765);
        qf.c(119);
        pn.l(33);
        oe.b(true);
        vb.j(-20);
        ea.b((byte)-37);
        fn.b(0);
        mb.a(false);
        se.g(11344);
        id.c(true);
        si.e(0);
        uh.b((byte)73);
        vi.f((byte)46);
        qm.a(2);
        ua.e(8);
        sc.b(false);
        hj.a();
        wi.a(0);
        cm.a(1714134600);
        dg.a(8);
        kc.a(93);
        kn.a(-1);
        sg.a(3);
        ug.a(-21771);
        fk.c(8);
        on.a((byte)6);
        di.c(87);
        gm.d(38);
        tg.a(false);
        ef.g(0);
        wb.e(-78);
        cl.c((byte)-39);
        pb.a((byte)78);
        lb.a(-19893);
        f.c(30061);
        ki.c((byte)22);
        sb.a(13820388);
        ff.a(-45);
        ta.a(false);
        um.a(0);
        bf.a(-73);
        af.a((byte)-47);
        cd.a((byte)121);
        dj.b(true);
        wc.a(2);
        ij.a(-85);
        wk.c(7751);
        qa.e(-30349);
        ob.a((byte)121);
        ln.a((byte)-89);
        hd.a(22771);
        fa.c((byte)-74);
        sn.a((byte)86);
        nf.a(-120);
        jm.e(62);
        te.e(0);
        ii.e(9369);
        tl.g((byte)-68);
        kd.e(127);
        re.g((byte)-112);
        i.b(28180);
        pk.c(-59);
        tb.a(20908);
        ba.d((byte)127);
        jc.a(true);
        this.bd_m = null;
    }

    @Override
    final void d(int n2) {
        int n3;
        boolean bl2;
        boolean bl3 = A;
        Canvas canvas = ne.d(-86);
        if (ta.a((byte)-56)) {
            jf.a(canvas, cd.a(n2 ^ 0x2140), -6351);
            return;
        }
        if (!sh.sh_j) {
            cn.a(true, canvas);
            return;
        }
        if (!se.i(-1)) {
            qi.a(100.0f, -81, bg.bg_c);
            cn.a(true, canvas);
            return;
        }
        qn.a(kd.kd_t, qm.qm_c, (byte)-109);
        boolean bl4 = bl2 = kf.G == null && !ea.d((byte)111) && (!fm.fm_b || !jg.jg_i);
        if (0 == rb.rb_e) {
            ca.ca_kb = ak.ak_d;
        }
        if (-2 <= ~ca.ca_kb) {
            jb.jb_a = false;
        } else {
            sg.sg_b.a();
        }
        do {
            if (~rb.rb_e == -1) {
                ai.e((byte)84);
            }
            if (kf.I != null) {
                kf.I.a(bl2, rb.rb_e, ca.ca_kb, true, false);
            }
            if (null == ce.C) continue;
            ce.C.a(bl2, rb.rb_e, ca.ca_kb, true, false);
        } while (1 < ca.ca_kb && !jb.jb_a && ~ca.ca_kb < ~(++rb.rb_e));
        if (1 < ca.ca_kb) {
            if (rb.rb_e >= ca.ca_kb) {
                ck ck2 = pa.U;
                pa.U = sg.sg_b;
                jb.jb_a = true;
                rb.rb_e = 0;
                sg.sg_b = ck2;
            }
            le.le_m.a((byte)-113);
            pa.U.e(0, 0);
        }
        if (null != kf.I) {
            kf.I.a(bl2, rb.rb_e, ca.ca_kb, false, false);
        }
        if (ce.C != null) {
            ce.C.a(bl2, rb.rb_e, ca.ca_kb, false, false);
        }
        if (!am.am_c && !uh.uh_b) {
            kf.G.a(false);
            boolean bl5 = false;
            if (null != pd.pd_d) {
                bl5 = true;
                pd.pd_d.c((byte)-75);
            }
            if (h.h_d != null) {
                bl5 = true;
                h.h_d.h((byte)99);
            }
            if (null != cl.B) {
                cl.B.b((byte)-48);
                bl5 = true;
            }
            if (null != am.am_a) {
                am.am_a.i(123);
                bl5 = true;
            }
            if (null != ca.ca_wb) {
                ca.ca_wb.d((byte)45);
                bl5 = true;
            }
            if (f.f_s != null) {
                f.f_s.c(2);
                bl5 = true;
            }
            if (gi.gi_b && hh.hh_a == ue.ue_b && !bl5) {
                pb.a(390);
            }
        }
        boolean bl6 = fm.fm_b && jg.jg_i;
        tf.a((byte)88, !bl6 && kf.G == null && cb.a((byte)-128));
        if (bl6) {
            da.a(false, cb.a((byte)-128));
        }
        if (n2 != 320) {
            B = null;
        }
        if ((am.am_c || uh.uh_b) && kf.G != null) {
            hk.d(0, 0, 640, 480);
            kf.G.f(-26325);
            if (f.f_s != null) {
                f.f_s.c(2);
            }
        }
        if (cn.f((byte)99)) {
            hk.a(320 + -(wk.b(3) / 2) - 34, -(pj.d(20) / 2) + 240 - 24, wk.b(3) + 68, pj.d(126) - -48, 0, 200);
            vk.a(pj.d(n2 + -356) - -60, (byte)50, a.a_n, wk.b(3) + 80, 240 - pj.d(-5) / 2 + -30, 320 - wk.b(3) / 2 - 40);
            uh.b(32659);
        }
        if (!ai.f((byte)94)) {
            if (pk.d(67)) {
                t.a(112, cl.cl_v == null ? qc.N : true);
            }
        } else {
            hk.a(-34 + -(vd.a(480) / 2) + 320, -24 + (-(dj.a(110) / 2) + 240), 68 + vd.a(480), 48 + dj.a(110), 0, 200);
            vk.a(dj.a(113) - -60, (byte)50, a.a_n, 80 + vd.a(480), 210 + -(dj.a(108) / 2), 320 - (vd.a(n2 ^ 0xA0) / 2 - -40));
            cl.a(true);
        }
        if (gb.Ob != gb.Vb && -1 > ~(n3 = 256 * rf.rf_f / 16)) {
            hk.a(0, 0, hk.hk_j, hk.hk_i, 0, n3);
        }
        if (2 <= te.te_p) {
            long l2 = Runtime.getRuntime().totalMemory() / 1024L;
            long l3 = -(Runtime.getRuntime().freeMemory() / 1024L) + l2;
            se.S.a("FPS: " + jf.jf_c, 12, 38, 0xFFFFFF, 1);
            se.S.a(l3 + "/" + l2 + " kB", 12, 52, 0xFFFFFF, 1);
        }
        mf.a(1, 0, 0, canvas);
    }

    @Override
    final void c(int n2) {
        int n3;
        int n4;
        boolean bl2 = A;
        for (n4 = 0; 8 > n4; ++n4) {
            pg.pg_a[n4] = false;
            ah.ah_b[n4] = false;
            kd.kd_s[0][n4] = 9 * kd.kd_s[0][n4] / 10;
            kd.kd_s[1][n4] = 9 * kd.kd_s[1][n4] / 10;
        }
        this.i((byte)51);
        n4 = n3 = 0;
        if (n2 != 11978) {
            return;
        }
        while (8 > n3) {
            int n5;
            if (!pg.pg_a[n3] && wf.wf_l[n3] != null) {
                wf.wf_l[n3].f(0);
                if (!wf.wf_l[n3].a((byte)78)) {
                    wf.wf_l[n3] = null;
                }
            }
            if (!ah.ah_b[n3] && null != ik.ik_c[n3]) {
                ik.ik_c[n3].g(en.en_o / 50);
                ik.ik_c[n3] = null;
            }
            if (sk.sk_a[0][n3] != null) {
                n5 = kd.kd_s[0][n3];
                if (0 == n5) {
                    sk.sk_a[0][n3].g(en.en_o / 50);
                    sk.sk_a[0][n3] = null;
                } else {
                    sk.sk_a[0][n3].e(en.en_o / 50, pb.pb_d * n5);
                }
            }
            if (null != sk.sk_a[1][n3]) {
                n5 = kd.kd_s[1][n3];
                if (0 == n5) {
                    sk.sk_a[1][n3].g(en.en_o / 50);
                    sk.sk_a[1][n3] = null;
                } else {
                    sk.sk_a[1][n3].e(en.en_o / 50, n5 * pb.pb_d);
                }
            }
            ++n3;
        }
    }

    @Override
    final void b(boolean bl2) {
        this.a(5, 94, 31, 0, 1, 12, 2, bl2);
        en.a(22050, true, 10);
        km.z = en.a(lf.lf_e, jh.jh_b, 0, 22050);
        cj.cj_b = en.a(lf.lf_e, jh.jh_b, 1, 1024);
        dg.dg_c = new mi();
        cj.cj_b.b(dg.dg_c);
        sh.sh_a = new mi();
        km.z.b(sh.sh_a);
        this.a(false, true, true, false, true, true, false);
        mk.mk_c[66] = 2;
        mk.mk_c[74] = 1;
        mk.mk_c[64] = -2;
        mk.mk_c[68] = 1;
        mk.mk_c[10] = -1;
        mk.mk_c[70] = 1;
        mk.mk_c[73] = 1;
        mk.mk_c[58] = -2;
        mk.mk_c[9] = -1;
        mk.mk_c[62] = 2;
        mk.mk_c[72] = 1;
        bc.D = hm.hm_e;
        mk.mk_c[71] = 1;
        mk.mk_c[63] = -1;
        mk.mk_c[59] = -2;
        mk.mk_c[65] = 1;
        mk.mk_c[75] = -1;
        mk.mk_c[76] = 1;
        mk.mk_c[69] = 1;
        ik.ik_h = dj.T;
        uc.uc_a = true;
        mg.Ob = fl.fl_d;
        mk.mk_c[61] = -2;
        mk.mk_c[67] = -1;
        pa.U = new ck(640, 480);
        sg.sg_b = new ck(640, 480);
        ak.ak_d = 1;
        rb.rb_e = 0;
        ca.ca_kb = 1;
    }

    static final void a(int n2, int n3, boolean bl2, int n4, boolean bl3, int n5, byte by) {
        boolean bl4 = A;
        boolean bl5 = gf.gf_c.a(2 * (kf.O - -2), (kf.O * 4 + 8) * n2, -15230, ki.ki_w == gf.gf_c, 2, bl2);
        vj vj2 = gf.gf_c.Ob.M;
        if (by > -48) {
            client.j((byte)82);
        }
        long l2 = ik.a(4);
        w w2 = null;
        ve ve2 = (ve)vj2.c((byte)-101);
        while (null != ve2) {
            String string;
            int n6;
            int n7;
            boolean bl6 = false;
            if (null == ve2.M) {
                n7 = n4 | n3;
                ve2.Pb = new w(0L, fc.fc_f);
                ve2.a(ve2.Pb, -16834);
                ve2.Pb.X = 1;
                ve2.Bc = new w(0L, gg.G);
                ve2.a(ve2.Bc, -16834);
                ve2.Dc = new w(0L, fc.fc_f);
                ve2.a(ve2.Dc, -16834);
                ve2.Dc.w_ub = 0;
                ve2.ve_ec = new w(0L, fc.fc_f);
                ve2.a(ve2.ve_ec, -16834);
                ve2.ve_ec.w_ub = 0;
                ve2.ve_jc = new w(0L, gg.G);
                ve2.a(ve2.ve_jc, -16834);
                ve2.ve_jc.X = 2;
                ve2.zc = new w(0L, !pd.pd_a ? gg.G : fc.fc_f);
                ve2.a(ve2.zc, -16834);
                ve2.ve_fc = new w[j.j_b];
                ve2.ve_pc = new w(0L, null);
                if (~(n7 & 1 << u.u_f) != -1) {
                    ve2.zc.a(ve2.ve_pc, -16834);
                }
                ve2.Ac = new w(0L, null);
                if (-1 != ~(n7 & 1 << u.u_b)) {
                    ve2.zc.a(ve2.Ac, -16834);
                }
                ve2.Tb = new w(0L, null);
                if (~(1 << rf.rf_a & n7) != -1) {
                    ve2.zc.a(ve2.Tb, -16834);
                }
                ve2.Fc = new w(0L, null);
                if (~(1 << ul.ul_f & n7) != -1) {
                    ve2.zc.a(ve2.Fc, -16834);
                }
                w w3 = ve2.ve_pc;
                w w4 = ve2.Fc;
                ve2.Tb.W = 1;
                w w5 = ve2.Ac;
                w5.W = 1;
                w4.W = 1;
                w3.W = 1;
                int n8 = 0;
                while (~j.j_b < ~n8) {
                    ve2.ve_fc[n8] = new w(0L, null);
                    if (~(1 << n8 + um.um_a & n7) != -1) {
                        ve2.zc.a(ve2.ve_fc[n8], -16834);
                    }
                    ve2.ve_fc[n8].W = 1;
                    ++n8;
                }
                ve2.yc = new w(0L, pd.pd_a ? gg.G : fc.fc_f);
                ve2.a(ve2.yc, -16834);
                ve2.yc.X = 2;
                ve2.Sb = new w(0L, gg.G);
                ve2.a(ve2.Sb, -16834);
                ve2.Ec = new w(0L, df.df_ab);
                ve2.a(ve2.Ec, -16834);
                ve2.ve_bc = new w(0L, df.df_ab);
                ve2.a(ve2.ve_bc, -16834);
                ve2.ve_sc = new w(0L, ua.H);
                ve2.a(ve2.ve_sc, -16834);
                ve2.d(-69);
                ve2.Yb = new w(0L, lj.lj_c);
                bl6 = true;
                ve2.a(ve2.Yb, -16834);
            }
            n7 = !ve2.ve_lc ? n3 : n4;
            ve2.Pb.Y = null;
            ve2.Pb.N = 0;
            w w6 = ve2.Pb;
            w6.w_mb = 0;
            ve2.Yb.Y = null;
            ve2.Yb.N = 0;
            w w7 = ve2.Yb;
            w7.w_mb = 0;
            ve2.Bc.Y = null;
            ve2.Bc.N = 0;
            w w8 = ve2.Bc;
            w8.w_mb = 0;
            ve2.Dc.Y = null;
            w w9 = ve2.Dc;
            ve2.Dc.N = 0;
            w9.w_mb = 0;
            ve2.ve_ec.Y = null;
            w w10 = ve2.ve_ec;
            ve2.ve_ec.N = 0;
            w10.w_mb = 0;
            ve2.ve_jc.Y = null;
            w w11 = ve2.ve_jc;
            ve2.ve_jc.N = 0;
            ve2.zc.Y = null;
            w11.w_mb = 0;
            ve2.zc.N = 0;
            w w12 = ve2.zc;
            w12.w_mb = 0;
            for (int i2 = 0; j.j_b > i2; ++i2) {
                ve2.ve_fc[i2].I = null;
                w w13 = ve2.ve_fc[i2];
                ve2.ve_fc[i2].N = 0;
                w13.w_mb = 0;
            }
            ve2.ve_pc.I = null;
            ve2.ve_pc.N = 0;
            w w14 = ve2.ve_pc;
            w14.w_mb = 0;
            ve2.Fc.I = null;
            w w15 = ve2.Fc;
            ve2.Fc.N = 0;
            ve2.Ac.I = null;
            w15.w_mb = 0;
            w w16 = ve2.Ac;
            ve2.Ac.N = 0;
            w16.w_mb = 0;
            ve2.Tb.I = null;
            ve2.Tb.N = 0;
            w w17 = ve2.Tb;
            w17.w_mb = 0;
            ve2.yc.Y = null;
            ve2.yc.N = 0;
            w w18 = ve2.yc;
            w18.w_mb = 0;
            ve2.Sb.Y = null;
            ve2.Sb.N = 0;
            w w19 = ve2.Sb;
            ve2.Ec.Y = null;
            w19.w_mb = 0;
            ve2.Ec.N = 0;
            w w20 = ve2.Ec;
            w20.w_mb = 0;
            ve2.ve_bc.Y = null;
            ve2.ve_bc.N = 0;
            w w21 = ve2.ve_bc;
            ve2.ve_sc.Y = null;
            w21.w_mb = 0;
            ve2.ve_sc.N = 0;
            w w22 = ve2.ve_sc;
            w22.w_mb = 0;
            ve2.w_mb = gf.gf_c.Ob.w_mb;
            int n9 = 0;
            String string2 = ve2.Vb;
            if (!ve2.i((byte)126)) {
                int n10;
                int n11;
                int n12;
                int n13;
                int n14;
                if (ve2.ve_lc) {
                    if (~ve2.Nb <= -1) {
                        ve2.Pb.Y = uf.uf_t;
                    } else if (!ve2.ve_wc || !ve2.gc && !ve2.Zb) {
                        if (-3 == ~ve2.ve_qc) {
                            ve2.Yb.Y = gd.gd_h;
                        } else {
                            ve2.Pb.Y = ak.ak_i;
                        }
                    } else {
                        ve2.Yb.Y = gb.gb_ac;
                    }
                } else if (ve2.gc || ve2.Zb) {
                    ve2.Yb.Y = gb.gb_ac;
                } else {
                    ve2.Pb.Y = ve2.Cc ? cd.cd_l : pc.pc_d;
                }
                if (null == ve2.Yb.Y) {
                    ve2.Pb.a(68, 0, n9, kf.O, 0);
                } else {
                    ve2.Yb.a(68, 0, n9, kf.O, 0);
                }
                ve2.Bc.Y = mm.a(ve2.Bc.J, string2, 78);
                ve2.Bc.a(78, 0, n9, kf.O, 70);
                if (ve2.Bc.w_jb && !ve2.Bc.Y.equals(string2)) {
                    sl.sl_g = string2;
                }
                ve2.Dc.Y = Integer.toString(ve2.ve_rc);
                if (ve2.ve_wc) {
                    ve2.Dc.X = 2;
                    ve2.ve_ec.Y = "/" + ve2.ve_mc;
                    n14 = (-ve2.ve_ec.J.a("/") + 348) / 2;
                    ve2.Dc.a(n14 - 150, 0, n9, kf.O, 150);
                    ve2.ve_ec.a(198 - n14, 0, n9, kf.O, n14);
                } else {
                    ve2.Dc.X = 1;
                    ve2.Dc.a(48, 0, n9, kf.O, 150);
                }
                ve2.ve_jc.Y = Integer.toString(ve2.Ub);
                ve2.ve_jc.a(48, 0, n9, kf.O, 200);
                n14 = pd.pd_a ? 250 : 200;
                ve2.zc.a(-2 + (-n14 + 365), 0, n9, kf.O, n14);
                n6 = j.j_c;
                if (0 != (n7 & 1 << u.u_f)) {
                    ck ck2;
                    ve2.ve_pc.I = ck2 = fj.fj_a[ve2.Wb];
                    ve2.ve_pc.a(ck2.K, 0, 0, ve2.zc.N, n6);
                    n6 += ck2.K - -j.j_c;
                }
                if (0 != (n7 & 1 << u.u_b)) {
                    ck ck3;
                    n13 = ve2.gc || ve2.Zb ? 1 : 0;
                    ve2.Ac.I = ck3 = x[n13 != 0 ? 1 : 0];
                    ve2.Ac.a(ck3.K, 0, 0, ve2.zc.N, n6);
                    n6 += ck3.K - -j.j_c;
                }
                if ((1 << rf.rf_a & n7) != 0) {
                    ck ck4;
                    ve2.Tb.I = ck4 = bb.bb_b[-1 + ve2.ve_qc];
                    ve2.Tb.a(ck4.K, 0, 0, ve2.zc.N, n6);
                    n6 += j.j_c + ck4.K;
                }
                if (~(1 << ul.ul_f & n7) != -1) {
                    ck ck5;
                    ve2.Fc.I = ck5 = si.si_d[ve2.Ic ? 1 : 0];
                    ve2.Fc.a(ck5.K, 0, 0, ve2.zc.N, n6);
                    n6 += j.j_c + ck5.K;
                }
                if (null != be.be_u) {
                    for (n13 = 0; j.j_b > n13; ++n13) {
                        ck ck6;
                        if (be.be_u[n13] == null || (n7 & 1 << um.um_a - -n13) == 0) continue;
                        ck ck7 = ck6 = be.be_u[n13][ve2.ve_kc[n13] & 0xFF];
                        ve2.ve_fc[n13].I = ck6;
                        ve2.ve_fc[n13].a(ck7.K, 0, 0, ve2.zc.N, n6);
                        n6 += ck7.K + j.j_c;
                    }
                }
                n13 = (-n6 + ve2.zc.w_mb) / 2;
                if (n13 > 0) {
                    ve2.ve_pc.w_vb += n13;
                    ve2.Ac.w_vb += n13;
                    ve2.Tb.w_vb += n13;
                    ve2.Fc.w_vb += n13;
                    n12 = 0;
                    while (~j.j_b < ~n12) {
                        ve2.ve_fc[n12].w_vb += n13;
                        ++n12;
                    }
                }
                if (ve2.ve_lc) {
                    n12 = ve2.Nb;
                    if (-1 < ~n12) {
                        n12 = (int)(l2 + -ve2.ve_tc);
                    }
                    n11 = n12 / 1000;
                    n10 = n11 / 60;
                    n11 %= 60;
                    if (~n10 <= -61) {
                        int n15 = n10 / 60;
                        ve2.yc.Y = n15 + ":" + (n10 %= 60) / 10 + n10 % 10 + ":" + n11 / 10 + n11 % 10;
                    } else {
                        ve2.yc.Y = n10 + ":" + n11 / 10 + n11 % 10;
                    }
                }
                ve2.yc.a(ve2.w_mb + -365, 0, n9, kf.O, 365);
                n9 += kf.O;
                if (null != ve2.xc) {
                    String string3;
                    n9 += 2;
                    StringBuilder stringBuilder = new StringBuilder(64);
                    stringBuilder.append(jg.jg_c);
                    stringBuilder.append(ve2.xc[0]);
                    for (n11 = 1; n11 < ve2.ve_rc; ++n11) {
                        stringBuilder.append(", ");
                        stringBuilder.append(ve2.xc[n11]);
                    }
                    ve2.Sb.Y = string3 = stringBuilder.toString();
                    n10 = ve2.Sb.J.a(string3, ve2.w_mb + -(2 * ve2.Sb.w_ub));
                    ve2.Sb.a(ve2.w_mb, 0, n9, n10 * kf.O, 0);
                    n9 += kf.O * n10;
                }
                if (ve2.Zb) {
                    ve2.Ec.Y = cm.a((byte)121, li.li_g, new String[]{string2});
                    ve2.Ec.a(-(2 * nk.nk_b) + ve2.w_mb, 0, n9, kf.O, nk.nk_b);
                    n9 += kf.O;
                }
                if (ve2.Ob) {
                    ve2.ve_bc.Y = cm.a((byte)106, qe.qe_b, new String[]{string2});
                    ve2.ve_bc.a(-(nk.nk_b * 2) + ve2.w_mb, 0, n9, kf.O, nk.nk_b);
                    n9 += kf.O;
                }
            }
            if ((string = vk.a(string2, ve2.ve_oc, true)) != null) {
                n6 = ve2.ve_sc.J.a(string, -nk.nk_b + (ve2.w_mb - nk.nk_b));
                ve2.ve_sc.w_wb = ve2.Rb * 256 / oa.oa_a;
                ve2.ve_sc.Y = string;
                ve2.ve_sc.a(-(nk.nk_b * 2) + ve2.w_mb, 0, n9, n6 * kf.O, nk.nk_b);
                n9 += kf.O * n6;
            }
            if (!bl5) {
                ve2.F = n9 - ve2.N;
            }
            if (bl6) {
                gf.gf_c.Ob.a(w2, ve2, 2, 0);
            }
            n6 = 0;
            while (~n6 > ~j.j_b) {
                if (ve2.ve_fc[n6].w_jb) {
                    String string4 = hb.Qb == null ? null : (null != hb.Qb[n6] ? hb.Qb[n6][ve2.ve_kc[n6] & 0xFF] : null);
                    sl.sl_g = string4 != null ? pa.pa_db[n6] + " - " + string4 : pa.pa_db[n6];
                }
                ++n6;
            }
            if (ve2.ve_pc.w_jb) {
                String string5 = ~ve2.Wb == -2 ? bh.bh_j : ed.ed_b[ve2.Wb];
                sl.sl_g = hl.hl_c + " - " + string5;
            }
            if (ve2.Fc.w_jb) {
                String string6 = sl.sl_g = !ve2.Ic ? si.si_k : cl.cl_s;
            }
            if (ve2.Ac.w_jb) {
                String string7 = ve2.gc || ve2.Zb ? wa.wa_f : (sl.sl_g = ve2.ve_wc ? bh.bh_c : ec.ec_b);
            }
            if (ve2.Tb.w_jb) {
                String string8 = sl.sl_g = ve2.ve_qc == 2 ? tl.tl_r : bc.F;
            }
            if (~ve2.w_ob != -1) {
                if (ve2.i((byte)100)) {
                    ve2 = (ve)vj2.d(true);
                    continue;
                }
                if (-1 != ~ve2.Yb.w_ob) {
                    if (!ve2.ve_lc || ve2.ve_wc && (ve2.gc || ve2.Zb)) {
                        cg.a(ve2.e(-36), (byte)-9, n5);
                    } else {
                        ga.a(false, ve2.e(-87), n5);
                    }
                } else {
                    hd.a(0, bl3, ve2, string2);
                }
            }
            ve2 = (ve)vj2.d(true);
        }
    }

    private final boolean n(int n2) {
        boolean bl2 = A;
        if (null != jj.jj_c) {
            fh.b((byte)-123);
            qi.a(65.0f, n2 + 98, rf.rf_p);
            this.d(320);
            ka.N = new pl(jj.jj_c, ah.ah_d);
            pg.pg_d = ka.N.a("", "fruit_step", n2 ^ 0);
            F = ka.N.a("", "cooked_fruit_step", 0);
            ib.ib_ob = ka.N.a("", "db_loose_shape_rotate", 0);
            bj.bj_e = ka.N.a("", "db_loose_shape_land_squish", 0);
            fh.fh_c = ka.N.a("", "db_group_shape_land", 0);
            hm.hm_d = ka.N.a("", "fruit_move", 0);
            wd.wd_c = ka.N.a("", "db_loose_tiles_pop", 0);
            sa.sa_w = ka.N.a("", "db_solid_tiles_pop2", 0);
            jm.jm_v[0] = ka.N.a("", "db_combo_1", 0);
            jm.jm_v[1] = ka.N.a("", "db_combo_2", n2 + 0);
            jm.jm_v[2] = ka.N.a("", "db_combo_3", qm.b(n2, 0));
            jm.jm_v[3] = ka.N.a("", "db_combo_4", qm.b(n2, 0));
            bf.bf_w = ka.N.a("", "db_simultaneous_bonus2", 0);
            ob.ob_n = ka.N.a((byte)101, "", "db_loose_drill");
            fj.fj_k = ka.N.a((byte)101, "", "db_bucket_water_capsule2");
            pk.pk_q = ka.N.a("", "db_quake", n2 ^ 0);
            ee.ee_g = ka.N.a("", "db_special_item_explode", n2 ^ 0);
            je je2 = new je(22050, 11025);
            pk.pk_q = pk.pk_q.a(je2);
            ee.ee_g = ee.ee_g.a(je2);
            w.Eb = ka.N.a("", "db_poison", n2 ^ 0);
            qa.qa_s = ka.N.a("", "db_glass_lower", 0);
            ha.Pb[2] = ka.N.a("", "db_bucket_glass_crack2_2", n2 + 0);
            ha.Pb[1] = ka.N.a("", "db_bucket_glass_crack3", n2 + 0);
            ha.Pb[0] = ka.N.a((byte)101, "", "db_bucket_glass_explode");
            ie.ie_e = ka.N.a("", "db_bucket_explode", 0);
            jg.jg_j = ka.N.a("", "db_bucket_debris", 0);
            bf.bf_u = ka.N.a("", "db_loose_shape_fall_looped", 0);
            rc.rc_i = ka.N.a("", "db_loose_shape_fall_quake_looped", 0);
            ak.ak_b = ka.N.a("", "db_suck_into_machine", 0);
            kf.P = ka.N.a("", "microwave_motor_2", 0);
            ul.ul_i = ka.N.a("", "db_shape_out_of_machine2", n2 ^ 0);
            ig.ig_ac = ka.N.a("", "db_last_shape_out", 0);
            jj.jj_c = null;
            ah.ah_d = null;
            vj.a(true);
            return false;
        }
        if (wg.wg_h != null) {
            qi.a(75.0f, -96, v.v_b);
            this.d(320);
            jg.jg_a = oh.a(wg.wg_h, 91, "", ka.N, "music/Deko Bloko Titlescreen");
            sb.sb_u[0][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/Ant_and_Deko_remix_NORMAL");
            sb.sb_u[0][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/Ant_and_Deko_remix_PANIC");
            sb.sb_u[0][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/Ant_and_Deko_remix_REALLY_PANIC");
            sb.sb_u[0][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/Ant_and_Deko_remix_FINISH_THEM");
            sb.sb_u[1][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/Art_Deko_remix_NORMAL");
            sb.sb_u[1][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/Art_Deko_remix_PANIC");
            sb.sb_u[1][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/Art_Deko_remix_REALLY_PANIC");
            sb.sb_u[1][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/Art_Deko_remix_FINISH_THEM");
            sb.sb_u[2][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/Bokonosis!_remix_NORMAL");
            sb.sb_u[2][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/Bokonosis!_remix_PANIC");
            sb.sb_u[2][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/Bokonosis!_remix_REALLY_PANIC");
            sb.sb_u[2][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/Bokonosis!_remix_FINISH_THEM");
            sb.sb_u[6][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/Deko_Rating_remix_NORMAL");
            sb.sb_u[6][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/Deko_Rating_remix_PANIC");
            sb.sb_u[6][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/Deko_Rating_remix_REALLY_PANIC");
            sb.sb_u[6][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/Deko_Rating_remix_FINISH_THEM");
            sb.sb_u[7][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/double_deko_NORMAL");
            sb.sb_u[7][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/double_deko_PANIC");
            sb.sb_u[7][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/double_deko_REALLY_PANIC");
            sb.sb_u[7][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/double_deko_FINISH_THEM");
            sb.sb_u[4][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/making_connections_remix_NORMAL");
            sb.sb_u[4][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/making_connections_remix_PANIC");
            sb.sb_u[4][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/making_connections_remix_REALLY_PANIC");
            sb.sb_u[4][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/making_connections_remix_FINISH_THEM");
            sb.sb_u[3][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/Oh No Boko!_remix_NORMAL");
            sb.sb_u[3][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/Oh No Boko!_remix_PANIC");
            sb.sb_u[3][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/Oh No Boko!_remix_REALLY_PANIC");
            sb.sb_u[3][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/Oh No Boko!_remix_FINISH_THEM");
            sb.sb_u[5][0] = oh.a(wg.wg_h, 91, "", ka.N, "music/Swab the Deks!_remix_NORMAL");
            sb.sb_u[5][1] = oh.a(wg.wg_h, 91, "", ka.N, "music/Swab the Deks!_remix_PANIC");
            sb.sb_u[5][2] = oh.a(wg.wg_h, 91, "", ka.N, "music/Swab the Deks!_remix_REALLY_PANIC");
            sb.sb_u[5][3] = oh.a(wg.wg_h, 91, "", ka.N, "music/Swab the Deks!_remix_FINISH_THEM");
            ee.ee_a[0] = oh.a(wg.wg_h, 91, "", ka.N, "music/momentum_remix_NORMAL");
            ee.ee_a[1] = oh.a(wg.wg_h, 91, "", ka.N, "music/momentum_remix_PANIC");
            ee.ee_a[2] = oh.a(wg.wg_h, 91, "", ka.N, "music/momentum_remix_REALLY_PANIC");
            ee.ee_a[3] = oh.a(wg.wg_h, 91, "", ka.N, "music/momentum_remix_FINISH_THEM");
            hb.Ub = oh.a(wg.wg_h, 91, "", ka.N, "music/Deko Bloko Game Win");
            rm.rm_b = oh.a(wg.wg_h, 91, "", ka.N, "music/Deko Bloko Game Lose");
            wg.wg_h = null;
            vj.a(true);
            return false;
        }
        if (null != ph.Db) {
            int n3;
            int n4;
            int n5;
            int n6;
            byte[] byArray;
            qi.a(90.0f, 96, vd.vd_o);
            this.d(320);
            se.S = cd.a("", qc.qc_vb, ah.ah_i, (byte)108, "arial13");
            pi[] piArray = t.a("", ah.ah_i, false, "arialbold14");
            byte[] byArray2 = qc.qc_vb.a(0, "", "arialbold14");
            w.w_kb = gg.a(piArray, 55, byArray2);
            km.A = ge.a((byte)-49, 0xFFFFFF, 1, piArray, byArray2, 1);
            pi[] piArray2 = t.a("tinybloko", ii.ii_t, false, "");
            byte[] byArray3 = ph.Db.a(n2 ^ 0, "tinybloko", "");
            in.in_n = gg.a(piArray2, n2 ^ 0x6F, byArray3);
            int n7 = 0;
            while (~piArray2.length < ~n7) {
                pi pi2 = piArray2[n7];
                byArray = new byte[4 * (pi2.lc_i * pi2.lc_b)];
                for (n6 = 0; n6 < pi2.lc_i; ++n6) {
                    for (n5 = 0; pi2.lc_b > n5; ++n5) {
                        n4 = pi2.pi_k[pi2.lc_b * n6 + n5];
                        n3 = 2 * n5 + 4 * pi2.lc_b * n6;
                        byArray[n3] = (byte)n4;
                        byArray[1 + n3] = (byte)n4;
                        byArray[n3 + 2 * pi2.lc_b] = (byte)n4;
                        byArray[pi2.lc_b * 2 + n3 - -1] = (byte)n4;
                    }
                }
                pi2.lc_d *= 2;
                pi2.lc_g *= 2;
                pi2.lc_a *= 2;
                pi2.lc_b *= 2;
                pi2.lc_i *= 2;
                pi2.pi_k = byArray;
                pi2.lc_c *= 2;
                ++n7;
            }
            n7 = 0;
            while (~n7 > ~byArray3.length) {
                int n8 = n7++;
                byArray3[n8] = (byte)(byArray3[n8] * 2);
            }
            a.a_t = gg.a(piArray2, n2 ^ 0x67, byArray3);
            eh.eh_j = ge.a((byte)100, 16694016, 2, piArray2, byArray3, 1);
            eh.eh_j.X[1] = new int[]{0, 0xFFFFFF, 1};
            n7 = 0;
            while (~n7 > ~piArray2.length) {
                pi pi3 = piArray2[n7];
                byArray = new byte[pi3.lc_b * pi3.lc_i * 9 / 4];
                n6 = 0;
                while (~pi3.lc_i < ~n6) {
                    for (n5 = 0; n5 < pi3.lc_b; n5 += 2) {
                        n4 = pi3.pi_k[n5 + pi3.lc_b * n6];
                        n3 = pi3.lc_b * (n6 * 9) / 4 + 3 * n5 / 2;
                        byArray[n3] = (byte)n4;
                        byArray[1 + n3] = (byte)n4;
                        byArray[2 + n3] = (byte)n4;
                        byArray[n3 - -(3 * pi3.lc_b / 2)] = (byte)n4;
                        byArray[1 + n3 + pi3.lc_b * 3 / 2] = (byte)n4;
                        byArray[2 + (n3 - -(3 * pi3.lc_b / 2))] = (byte)n4;
                        byArray[n3 + 3 * pi3.lc_b] = (byte)n4;
                        byArray[n3 - -(3 * pi3.lc_b) - -1] = (byte)n4;
                        byArray[n3 + (3 * pi3.lc_b + 2)] = (byte)n4;
                    }
                    n6 += 2;
                }
                pi3.lc_d = 3 * pi3.lc_d / 2;
                pi3.lc_i = pi3.lc_i * 3 / 2;
                pi3.pi_k = byArray;
                pi3.lc_c = pi3.lc_c * 3 / 2;
                pi3.lc_g = pi3.lc_g * 3 / 2;
                pi3.lc_b = pi3.lc_b * 3 / 2;
                pi3.lc_a = pi3.lc_a * 3 / 2;
                ++n7;
            }
            n7 = 0;
            while (~byArray3.length < ~n7) {
                byArray3[n7] = (byte)(byArray3[n7] * 3 / 2);
                ++n7;
            }
            hn.hn_g = gg.a(piArray2, 121, byArray3);
            a.a_n = db.a("ui_frame_vbrick", "ui_frame_hbrick", ii.ii_t, true, "ui_frame_corner");
            on.on_e = ek.a("ui_button_up", "", n2 ^ 0xFFFFFFA1, ii.ii_t);
            im.im_i = ek.a("ui_button_highlight", "", -114, ii.ii_t);
            ce.ce_s = bj.a(112, ii.ii_t, "", "chat_toggle_button");
            gd.gd_g = bj.a(112, ii.ii_t, "", "chat_toggle_button_highlight");
            vg.vg_h = id.a(ah.ah_i, "unachieved", "basic", 8192);
            wg.wg_c = id.a(ah.ah_i, "locked", "basic", n2 + 8192);
            db.db_f = new ck(32, 32);
            db.db_f.a();
            vg.vg_h.a(0, 0, 32, 32);
            gf.gf_a = new ck(32, 32);
            gf.gf_a.a();
            wg.wg_c.a(0, 0, 32, 32);
            le.le_m.a((byte)-84);
            ck ck2 = id.a(ah.ah_i, "orbcoin", "basic", 8192);
            rn.rn_c = new ck(20, 20);
            rn.rn_c.a();
            ck2.a(0, 0, 20, 20);
            le.le_m.a((byte)-106);
            ck2 = null;
            gf.gf_f = t.a("solid_mask", ii.ii_t, false, "");
            oa.oa_b = bj.a(112, ii.ii_t, "", "pop");
            qf.qf_h = si.a(n2 ^ 0x6574, false, bj.a(112, ii.ii_t, "", "explode"), false);
            qm.qm_c = me.a(id.a(ii.ii_t, "wildcard", "", 8192), false, (byte)-28, false);
            kd.kd_t = qm.qm_c.c();
            ck[] ckArray = bj.a(112, ii.ii_t, "", "specialitems");
            int n9 = 0;
            while (-7 < ~n9) {
                for (n6 = 0; 4 > n6; ++n6) {
                    ik.ik_b[n9][n6] = me.a(ckArray[n9 * 4 - -n6], false, (byte)-55, false);
                }
                ++n9;
            }
            n9 = 0;
            while (~n9 > -9) {
                ckArray = bj.a(n2 + 112, ii.ii_t, "", ri.ri_f[n9] + "_tiles");
                for (n6 = 0; 7 > n6; ++n6) {
                    fb.fb_c[n9][n6] = me.a(ckArray[n6], false, (byte)-63, false);
                }
                fb.fb_c[n9][7] = kd.kd_t;
                n6 = 0;
                while (-8 < ~n6) {
                    ck ck3 = me.a(ckArray[n6 + 7], true, (byte)-124, true);
                    n4 = 0;
                    while (-17 < ~n4) {
                        ck ck4 = ck3.c();
                        ck4.a();
                        fb.fb_c[n9][n6].b(6, 6, 24, 24);
                        ck3.c(0, 0, 128);
                        pi pi4 = gf.gf_f[n4];
                        for (int i2 = 0; 1296 > i2; ++i2) {
                            int n10 = pi4.pi_l[pi4.pi_k[i2] & 0xFF] & 0xFF;
                            int n11 = ck4.D[i2];
                            if (n10 > 128) {
                                int n12 = 131586 * (n10 - 128);
                                int n13 = n11;
                                int n14 = n13 + n12;
                                n12 = (0xFF00FF & n13) + (0xFF00FF & n12);
                                n13 = (-n12 + n14 & 0x10000) + (0x1000100 & n12);
                                n11 = n14 - n13 | n13 + -(n13 >>> -74352984);
                            } else {
                                n11 = ((n11 & 0xFF00FF) * n10 >> 1802741479 & 0xFF00FF) + (((0xFF00 & n11) * n10 & 0x7F8024) >> -816570233);
                            }
                            if (n11 == 0) {
                                n11 = 1;
                            }
                            ck4.D[i2] = n11;
                        }
                        ob.ob_j[n9][n6][n4] = ck4;
                        ++n4;
                    }
                    ++n6;
                }
                s.Qb[n9] = id.a(ii.ii_t, ri.ri_f[n9] + "_bucketback", "", 8192);
                s.Qb[n9].b();
                ++n9;
            }
            le.le_m.a((byte)-114);
            for (n9 = 0; 8 > n9; ++n9) {
                byte[] byArray4 = eg.eg_e.a(n2 + 0, "", ri.ri_f[n9] + ".jpg");
                dn.dn_p[n9] = new ck(byArray4, jh.jh_b);
            }
            byte[] byArray5 = eg.eg_e.a(n2 + 0, "", "menu2.jpg");
            tc.Tb = new ck(byArray5, jh.jh_b);
            byte[] byArray6 = eg.eg_e.a(0, "", "achievements.jpg");
            uf.y = fc.a(31, new ck(byArray6, jh.jh_b), -10241);
            ck[] ckArray2 = bj.a(112, ii.ii_t, "", "achievements");
            n4 = 0;
            while (-32 < ~n4) {
                ckArray2[n4].b();
                mg.a(0, ckArray2[n4], uf.y[n4]);
                ckArray2[n4] = null;
                ++n4;
            }
            ckArray2 = null;
            tl.tl_w = new ck[31];
            n4 = 0;
            while (-32 < ~n4) {
                tl.tl_w[n4] = new ck(32, 32);
                tl.tl_w[n4].a();
                uf.y[n4].a(0, 0, 32, 32);
                ++n4;
            }
            le.le_m.a((byte)-108);
            pg.pg_e = id.a(ii.ii_t, "ui_clouds", "", 8192);
            dk.dk_h = id.a(ii.ii_t, "ui_border_tl", "", 8192);
            jh.jh_d = id.a(ii.ii_t, "ui_border_t", "", 8192);
            sk.sk_g = id.a(ii.ii_t, "ui_border_tr", "", 8192);
            fl.fl_f = id.a(ii.ii_t, "ui_border_l", "", n2 ^ 0x2000);
            wm.wm_n = id.a(ii.ii_t, "ui_border_r", "", 8192);
            vg.x = id.a(ii.ii_t, "ui_border_bl", "", 8192);
            pg.pg_f = id.a(ii.ii_t, "ui_border_b", "", 8192);
            wc.wc_r = id.a(ii.ii_t, "ui_border_br", "", n2 ^ 0x2000);
            wk.wk_l = id.a(ii.ii_t, "ui_menu_title", "", 8192);
            ve.ve_dc = id.a(ii.ii_t, "ui_lobby_logo", "", 8192);
            ij.ij_d = mg.a(0xFFFC00, 16743168, ul.ul_b, in.in_n, 6, 0, (byte)107);
            wh.wh_f = mg.a(0xFFFC00, 16743168, ak.ak_e, in.in_n, 6, 0, (byte)120);
            client.C[0] = mg.a(0xFFFC00, 16743168, mf.P, in.in_n, 6, 0, (byte)120);
            client.C[1] = mg.a(0xFFFC00, 16743168, qf.qf_k, in.in_n, 6, 0, (byte)114);
            client.C[2] = mg.a(0xFFFC00, 16743168, ad.z, in.in_n, 6, 0, (byte)104);
            ng.ng_b = mg.a(0xFFFC00, 16743168, de.P, in.in_n, 6, 0, (byte)102);
            l.l_j = mg.a(0xFFFC00, 16743168, im.im_g, in.in_n, 6, 0, (byte)99);
            ad.ad_g = mg.a(0xFFFC00, 16743168, u.u_g, in.in_n, 6, 0, (byte)88);
            ve.ve_uc[0] = bj.a(112, ii.ii_t, "", "fruit_buckettop");
            uj.uj_d[0] = si.a(25972, true, bj.a(112, ii.ii_t, "", "fruit_lefttex"), true);
            bb.bb_a[0] = si.a(25972, true, bj.a(112, ii.ii_t, "", "fruit_leftsidetex"), true);
            cc.cc_f[0] = t.a("fruit_leftmask", ii.ii_t, false, "");
            rb.rb_d[0] = si.a(25972, true, bj.a(112, ii.ii_t, "", "fruit_righttex"), true);
            dg.dg_d[0] = si.a(qm.b(n2, 25972), true, bj.a(112, ii.ii_t, "", "fruit_rightsidetex"), true);
            sc.sc_j[0] = t.a("fruit_rightmask", ii.ii_t, false, "");
            ad.ad_j[0] = si.a(25972, true, bj.a(112, ii.ii_t, "", "fruit_bottomtex"), true);
            fk.G[0] = t.a("fruit_bottommask", ii.ii_t, false, "");
            ve.ve_uc[1] = bj.a(112, ii.ii_t, "", "animals_buckettop");
            rb.rb_j[1] = si.a(25972, false, bj.a(112, ii.ii_t, "", "animals_sidespr"), true);
            hf.hf_e[1] = rb.rb_j[1];
            bh.bh_d[1] = si.a(25972, true, bj.a(n2 + 112, ii.ii_t, "", "animals_bottomspecial"), false);
            fk.G[1] = t.a("animals_bottommask", ii.ii_t, false, "");
            ve.ve_uc[2] = bj.a(112, ii.ii_t, "", "breakfast_buckettop");
            uj.uj_d[2] = si.a(25972, true, bj.a(112, ii.ii_t, "", "breakfast_lefttex"), true);
            bb.bb_a[2] = si.a(25972, true, bj.a(112, ii.ii_t, "", "breakfast_leftsidetex"), true);
            cc.cc_f[2] = t.a("breakfast_leftmask", ii.ii_t, false, "");
            rb.rb_d[2] = si.a(25972, true, bj.a(112, ii.ii_t, "", "breakfast_righttex"), true);
            dg.dg_d[2] = si.a(qm.b(n2, 25972), true, bj.a(112, ii.ii_t, "", "breakfast_rightsidetex"), true);
            sc.sc_j[2] = t.a("breakfast_rightmask", ii.ii_t, false, "");
            ad.ad_j[2] = si.a(25972, true, bj.a(112, ii.ii_t, "", "breakfast_bottomtex"), true);
            fk.G[2] = t.a("breakfast_bottommask", ii.ii_t, false, "");
            ve.ve_uc[3] = bj.a(112, ii.ii_t, "", "bugs_buckettop");
            rb.rb_j[3] = si.a(25972, false, bj.a(112, ii.ii_t, "", "bugs_sidespr"), true);
            hf.hf_e[3] = rb.rb_j[3];
            bh.bh_d[3] = si.a(qm.b(n2, 25972), true, bj.a(n2 + 112, ii.ii_t, "", "bugs_bottomspecial"), false);
            fk.G[3] = t.a("bugs_bottommask", ii.ii_t, false, "");
            ve.ve_uc[4] = bj.a(qm.b(n2, 112), ii.ii_t, "", "flowers_buckettop");
            uj.uj_d[4] = si.a(25972, true, bj.a(112, ii.ii_t, "", "flowers_lefttex"), true);
            bb.bb_a[4] = si.a(25972, true, bj.a(qm.b(n2, 112), ii.ii_t, "", "flowers_leftsidetex"), true);
            cc.cc_f[4] = t.a("flowers_leftmask", ii.ii_t, false, "");
            rb.rb_d[4] = si.a(qm.b(n2, 25972), true, bj.a(112, ii.ii_t, "", "flowers_righttex"), true);
            dg.dg_d[4] = si.a(25972, true, bj.a(112, ii.ii_t, "", "flowers_rightsidetex"), true);
            sc.sc_j[4] = t.a("flowers_rightmask", ii.ii_t, false, "");
            ad.ad_j[4] = si.a(25972, true, bj.a(112, ii.ii_t, "", "flowers_bottomtex"), true);
            fk.G[4] = t.a("flowers_bottommask", ii.ii_t, false, "");
            ve.ve_uc[5] = bj.a(112, ii.ii_t, "", "undersea_buckettop");
            rb.rb_j[5] = si.a(25972, false, bj.a(112, ii.ii_t, "", "undersea_sidespr"), true);
            hf.hf_e[5] = rb.rb_j[5];
            bh.bh_d[5] = si.a(qm.b(n2, 25972), true, bj.a(112, ii.ii_t, "", "undersea_bottomspecial"), false);
            fk.G[5] = t.a("undersea_bottommask", ii.ii_t, false, "");
            ve.ve_uc[6] = bj.a(112, ii.ii_t, "", "city_buckettop");
            uj.uj_d[6] = si.a(n2 + 25972, true, bj.a(n2 + 112, ii.ii_t, "", "city_lefttex"), true);
            bb.bb_a[6] = si.a(25972, true, bj.a(112, ii.ii_t, "", "city_leftsidetex"), true);
            cc.cc_f[6] = t.a("city_leftmask", ii.ii_t, false, "");
            rb.rb_d[6] = si.a(25972, true, bj.a(112, ii.ii_t, "", "city_righttex"), true);
            dg.dg_d[6] = si.a(25972, true, bj.a(qm.b(n2, 112), ii.ii_t, "", "city_rightsidetex"), true);
            sc.sc_j[6] = t.a("city_rightmask", ii.ii_t, false, "");
            ad.ad_j[6] = si.a(25972, true, bj.a(112, ii.ii_t, "", "city_bottomtex"), true);
            fk.G[6] = t.a("city_bottommask", ii.ii_t, false, "");
            ve.ve_uc[7] = bj.a(112, ii.ii_t, "", "eightbit_buckettop");
            uj.uj_d[7] = si.a(25972, true, bj.a(112, ii.ii_t, "", "eightbit_lefttex"), true);
            bb.bb_a[7] = si.a(25972, true, bj.a(n2 + 112, ii.ii_t, "", "eightbit_leftsidetex"), true);
            cc.cc_f[7] = t.a("eightbit_leftmask", ii.ii_t, false, "");
            rb.rb_d[7] = si.a(25972, true, bj.a(112, ii.ii_t, "", "eightbit_righttex"), true);
            dg.dg_d[7] = si.a(qm.b(n2, 25972), true, bj.a(qm.b(n2, 112), ii.ii_t, "", "eightbit_rightsidetex"), true);
            sc.sc_j[7] = t.a("eightbit_rightmask", ii.ii_t, false, "");
            ad.ad_j[7] = si.a(qm.b(n2, 25972), true, bj.a(112, ii.ii_t, "", "eightbit_bottomtex"), true);
            fk.G[7] = t.a("eightbit_bottommask", ii.ii_t, false, "");
            n4 = 0;
            while (-9 < ~n4) {
                on.a(uj.uj_d[n4], 19264);
                on.a(rb.rb_d[n4], n2 + 19264);
                on.a(ad.ad_j[n4], 19264);
                uh.a(cc.cc_f[n4], (byte)115);
                uh.a(sc.sc_j[n4], (byte)-118);
                uh.a(fk.G[n4], (byte)114);
                int n15 = 0;
                while (~n15 > ~ve.ve_uc[n4].length) {
                    ve.ve_uc[n4][n15].b();
                    ++n15;
                }
                ++n4;
            }
            uf.uf_w = id.a(ii.ii_t, "machine_buttons1", "", 8192);
            bn.bn_e = id.a(ii.ii_t, "machine_front", "", n2 ^ 0x2000);
            cd.cd_k = id.a(ii.ii_t, "machine_glass", "", 8192);
            e.e_b = id.a(ii.ii_t, "machine_glasslit", "", n2 ^ 0x2000);
            ca.ca_qb = id.a(ii.ii_t, "machine_lights1", "", 8192);
            ln.ln_c = id.a(ii.ii_t, "machine_mouth", "", 8192);
            aa.aa_e = id.a(ii.ii_t, "machine_next", "", n2 + 8192);
            jc.jc_f = id.a(ii.ii_t, "machine_nextlit", "", 8192);
            bb.bb_c = id.a(ii.ii_t, "machine_pipe", "", 8192);
            u.u_h = id.a(ii.ii_t, "machine_portal", "", n2 + 8192);
            bc.J = id.a((ji)ii.ii_t, (String)"blobmatch_scorecols", (String)"", (int)8192).D;
            a.a_u = id.a((ji)ii.ii_t, (String)"eliminatetile_scorecols", (String)"", (int)(n2 ^ 0x2000)).D;
            jg.jg_f = id.a((ji)ii.ii_t, (String)"simultaneous_scorecols", (String)"", (int)8192).D;
            nf.nf_f = id.a((ji)ii.ii_t, (String)"chain_scorecols", (String)"", (int)8192).D;
            oh.oh_c = id.a((ji)ii.ii_t, (String)"bomb_scorecols", (String)"", (int)(n2 ^ 0x2000)).D;
            vl.G = id.a((ji)ii.ii_t, (String)"bombardmessagecols", (String)"", (int)8192).D;
            ph.yb = bj.a(112, ii.ii_t, "", "instructions_keys");
            ma.K = id.a(ii.ii_t, "instructions_arrow", "", 8192);
            aj.aj_c = id.a(ii.ii_t, "instructions_inmultiplayer", "", 8192);
            li.li_i = id.a(ii.ii_t, "instructions_insingleplayer", "", n2 + 8192);
            ck[][] ckArray3 = new ck[5][];
            ck[][] ckArray4 = new ck[5][];
            ckArray3[0] = ckArray4[0] = bj.a(112, ii.ii_t, "", "bucketsize_icons");
            ckArray3[1] = ckArray4[1] = bj.a(112, ii.ii_t, "", "speed_icons");
            ckArray3[4] = ckArray4[4] = bj.a(n2 + 112, ii.ii_t, "", "shapefeedback_icons");
            lf.lf_h = ckArray4[4];
            ckArray3[2] = ckArray4[2] = bj.a(112, ii.ii_t, "", "colours_icons");
            ckArray3[3] = ckArray4[3] = bj.a(112, ii.ii_t, "", "specialitems_icons");
            bg.a(vl.A, nd.nd_a, si.si_f, pf.pf_d, 8, qd.Pb, ah.ah_i, 5, 25150, qc.qc_vb, ckArray3, ckArray4, true, vb.S, tg.tg_d);
            gm.a(-3504, 200);
            qf.a(ah.ah_i, qc.qc_vb, -96);
            rf.a(ac.z, 0, 180, -94, 16694016, this);
            qc.qc_vb = null;
            ph.Db = null;
            vj.a(true);
            return false;
        }
        if (cl.y != null) {
            ge.a((byte)-93, new jk(cl.y.a(0, "huffman", "")));
            cl.y = null;
            vj.a(true);
            return false;
        }
        bj.a(320, on.on_e, eh.eh_j, true, km.A, 20, n2, 4, 1, 20, 20, 20, a.a_n, 14, 480, 240, im.im_i, 32, 16, 0, 5);
        ie.a(on.on_e, km.A, a.a_n, 320, 20, 0, 32, 20, 240, 4, 5, 20, eh.eh_j, im.im_i, 1, 14, 10406, 0, 16, 20);
        kf.G = f.a(false, false, 0, false, false, 32357, false, false);
        bd.a(50, -27096);
        le.a((byte)86, 50);
        af.a(n2 + 4, 50);
        nn.a(256, jg.jg_a, true);
        vj.a(true);
        return true;
    }

    static final boolean a(int n2, String string) {
        if (n2 <= 79) {
            String string2 = null;
            client.a(string2, -100);
        }
        return null == string || string.length() < mc.mc_f || string.length() > dn.dn_r;
    }

    @Override
    public final void init() {
        this.a(-2990, 32, "dekobloko");
    }

    static {
        an.a(D, 0, 65536, (byte)-128);
        E = "Theme <%0> strategy";
        y = "Show all private chat";
        C = new ck[3];
        B = "Use this alternative as your account name";
    }
}
