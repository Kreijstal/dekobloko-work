/*
 * Decompiled with CFR 0.152.
 */
final class qa
extends wk {
    static String qa_w;
    static String qa_u;
    static int x;
    static ud qa_s;
    static qd[][] qa_v;
    static int y;
    static volatile int qa_t;
    static float[] qa_r;

    static final w d(int n) {
        if (n != 5) {
            return null;
        }
        return tb.tb_b.Ob;
    }

    static final void a(int n, int n2) {
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n3 = uf2.wl_n;
        uf2.a(true, 5);
        uf2.a(true, cd.cd_m.ve_mc);
        if (n2 != 1850462342) {
            qa.e(-25);
        }
        int n4 = (cd.cd_m.ve_qc << 1850462342) + cd.cd_m.Wb;
        uf2.a(true, n4);
        uf2.a(false, cd.cd_m.ve_kc.length, cd.cd_m.ve_kc, 0);
        uf2.b(uf2.wl_n + -n3, true);
    }

    public static void e(int n) {
        if (n != -30349) {
            qa.a(99, -109);
        }
        qa_u = null;
        qa_s = null;
        qa_r = null;
        qa_w = null;
        qa_v = null;
    }

    qa(long l, String string) {
        super(l, string);
    }

    @Override
    final gh a(int n) {
        if (n != 18) {
            return null;
        }
        return gf.gf_j;
    }

    static {
        qa_u = "Stage:";
        qa_w = "Waiting for backgrounds";
        qa_r = new float[8];
        qa_t = 0;
    }
}
