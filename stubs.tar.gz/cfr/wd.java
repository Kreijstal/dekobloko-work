/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class wd {
    static ud wd_c;
    static String wd_a;
    static boolean wd_d;
    static String wd_b;
    static String wd_e;

    public static void a(int n) {
        wd_c = null;
        if (n != 1) {
            wd.a(-30, false, false);
        }
        wd_a = null;
        wd_e = null;
        wd_b = null;
    }

    static final String a(Applet applet, byte by, String string) {
        boolean bl = client.A;
        try {
            String string2 = (String)nc.a(true, "getcookies", applet);
            String[] stringArray = ji.a(';', (byte)66, string2);
            if (by != -1) {
                wd_e = null;
            }
            int n = 0;
            while (~stringArray.length < ~n) {
                int n2 = stringArray[n].indexOf(61);
                if (0 <= n2 && stringArray[n].substring(0, n2).trim().equals(string)) {
                    return stringArray[n].substring(n2 + 1).trim();
                }
                ++n;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    static final ke a(int n, boolean bl, boolean bl2) {
        ke ke2;
        ke ke3 = ke2 = new ke(2);
        if (!bl2) {
            ke3.a(new ec(17), n + 10);
            int n2 = a.a_t.a(ji.ji_c);
            int n3 = a.a_t.a(ik.ik_g);
            if (n3 > n2) {
                n2 = n3;
            }
            if (~n2 > ~(n3 = a.a_t.a(k.k_h))) {
                n2 = n3;
            }
            n3 = a.a_t.a(wj.Kb);
            if (n3 > n2) {
                n2 = n3;
            }
            n3 = a.a_t.a(sc.sc_h);
            if (~n3 < ~n2) {
                n2 = n3;
            }
            if (~n2 > ~(n3 = a.a_t.a(rc.rc_g))) {
                n2 = n3;
            }
            n3 = a.a_t.a(ig.Xb);
            if (~n2 > ~n3) {
                n2 = n3;
            }
            if ((n3 = a.a_t.a(di.E)) > n2) {
                n2 = n3;
            }
            ke2.ke_f[-1 + ke2.ke_b.sk_l].ec_n = 46 + n2;
        }
        ke3.a(new ec(18, om.om_b, a.a_t), 104);
        ke3.a(-1, bl, -129);
        ke3.a(n, 320, false, -117, 28);
        return ke3;
    }

    static {
        wd_a = "You appear to be telling someone your password - please don't!";
        wd_d = false;
        wd_b = "Enter a password for this account. Try to pick a strong password that can't easily be guessed.";
        wd_e = "Here you can set up a rated game. If you win, your rating will go up. If<nbsp>you lose, it will go down!<br><br>Please specify your preferences and click '<%0>'. Our system will then attempt to find a suitable opponent in under a minute, depending on how busy the lobby<nbsp>is.<br><br>This is an excellent way to get to know new people!";
    }
}
