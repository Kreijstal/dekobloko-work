/*
 * Decompiled with CFR 0.152.
 */
final class tl
extends wm {
    private boolean tl_p = false;
    static ck[] tl_u;
    static String x;
    static String tl_s;
    static ck[] tl_w;
    static int[] tl_q;
    static String tl_r;
    private String tl_t = "";
    private re tl_v;

    static final boolean b(int n, int n2, int n3) {
        if (13 == wh.wh_c) {
            qn.l(n2 + -89);
            return true;
        }
        if (wh.wh_c == n2) {
            mg.mg_bc.e(0);
            return true;
        }
        return null != mg.mg_bc && mg.mg_bc.b(n3, 15028, n);
    }

    @Override
    final tb b(String string, byte by) {
        if (this.tl_v.b(string, by) == vm.vm_u) {
            return vm.vm_u;
        }
        if (!string.equals(this.tl_t)) {
            ta ta2 = ik.a(103, string);
            if (!ta2.a(103)) {
                return jb.jb_j;
            }
            this.tl_t = string;
            this.tl_p = ta2.b(-3348);
        }
        return !this.tl_p ? vm.vm_u : dc.dc_b;
    }

    public static void g(byte by) {
        tl_w = null;
        tl_r = null;
        if (by >= -59) {
            tl_w = null;
        }
        tl_s = null;
        x = null;
        tl_q = null;
        tl_u = null;
    }

    tl(rk rk2, rk rk3) {
        super(rk2);
        this.tl_v = new re(rk2, rk3);
    }

    @Override
    final String wm_a_string(String string, byte by) {
        if (by != -11) {
            tl_s = null;
        }
        if (this.tl_v.b(string, (byte)-40) == vm.vm_u) {
            return this.tl_v.wm_a_string(string, (byte)-11);
        }
        if (this.b(string, (byte)-40) == vm.vm_u) {
            return dd.dd_m;
        }
        return li.li_a;
    }

    static {
        x = "This option cannot be combined with the current settings for:  ";
        tl_q = new int[5];
        tl_s = "Ignore";
        tl_r = "You can spectate this game";
    }
}
