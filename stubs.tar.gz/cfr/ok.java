/*
 * Decompiled with CFR 0.152.
 */
final class ok {
    private static int ok_b;
    private static int ok_h;
    private static int ok_d;
    private static int[] ok_f;
    private static int ok_e;
    private static int ok_g;
    private static int ok_a;
    private static int ok_c;

    private static final void c() {
        ok_d = 0;
    }

    public static void d() {
        ok_f = null;
    }

    static final void a(int[] nArray, int n, int n2) {
        ok.a(nArray, 0, nArray.length, n, n2, null, null);
    }

    private static final void a(int n, int n2, int[] nArray, int[] nArray2) {
        ok.a();
        while (ok.b()) {
            int n3 = ok_a;
            int n4 = ok_e;
            int n5 = ok_h;
            if (nArray != null) {
                int n6 = n5 - hk.hk_h;
                if (n3 < nArray[n6] + hk.hk_c) {
                    n3 = nArray[n6] + hk.hk_c;
                }
                if (n4 > nArray[n6] + nArray2[n6] + hk.hk_c) {
                    n4 = nArray[n6] + nArray2[n6] + hk.hk_c;
                }
            }
            hk.c(n3, n5, n4 - n3, n, n2);
        }
    }

    private static final void a() {
        int n;
        int n2;
        if (ok_d < 0) {
            ok_g = 0;
            ok_b = 0;
            ok_c = 0;
            ok_h = 0x7FFFFFFE;
            return;
        }
        ok.a(0, ok_d);
        int n3 = ok_f[1];
        if (n3 < hk.hk_h) {
            n3 = hk.hk_h;
        }
        int n4 = 0;
        for (n2 = 0; n2 < ok_d && n3 >= (n = ok_f[n2 + 1]); n2 += 4) {
            int n5 = ok_f[n2];
            int n6 = ok_f[n2 + 2];
            int n7 = ok_f[n2 + 3];
            int n8 = (n6 - n5 << 16) / (n7 - n);
            int n9 = (n5 << 16) + 32768;
            ok.ok_f[n2] = n9 + (n3 - n) * n8;
            ok.ok_f[n2 + 2] = n8;
        }
        ok_c = n4;
        ok_b = n2;
        ok_g = n2;
        ok_h = n3 - 1;
    }

    private static final void b(int n, int n2) {
        while (n2 >= n + 8) {
            boolean bl = true;
            for (int i = n + 4; i < n2; i += 4) {
                int n3 = ok_f[i - 4];
                int n4 = ok_f[i];
                if (n3 <= n4) continue;
                bl = false;
                ok.ok_f[i - 4] = n4;
                ok.ok_f[i] = n3;
                n3 = ok_f[i - 2];
                ok.ok_f[i - 2] = ok_f[i + 2];
                ok.ok_f[i + 2] = n3;
                n3 = ok_f[i - 1];
                ok.ok_f[i - 1] = ok_f[i + 3];
                ok.ok_f[i + 3] = n3;
            }
            if (!bl) {
                n2 -= 4;
                continue;
            }
            return;
        }
    }

    private static final boolean b() {
        int n = ok_b;
        int n2 = ok_g;
        int n3 = ok_h;
        while (n2 >= n) {
            int n4;
            int n5;
            int n6;
            ok_h = ++n3;
            if (n3 >= hk.hk_b) {
                return false;
            }
            int n7 = ok_c;
            while (n < ok_d && n3 >= (n6 = ok_f[n + 1])) {
                int n8;
                n5 = ok_f[n];
                int n9 = ok_f[n + 2];
                int n10 = ok_f[n + 3];
                int n11 = (n9 - n5 << 16) / (n10 - n6);
                ok.ok_f[n] = n8 = (n5 << 16) + 32768;
                ok.ok_f[n + 2] = n11;
                n += 4;
            }
            n6 = n4 = n7;
            while (n4 < n) {
                n5 = ok_f[n4 + 3];
                if (n3 >= n5) {
                    ok.ok_f[n4] = ok_f[n7];
                    ok.ok_f[n4 + 1] = ok_f[n7 + 1];
                    ok.ok_f[n4 + 2] = ok_f[n7 + 2];
                    ok.ok_f[n4 + 3] = ok_f[n7 + 3];
                    n7 += 4;
                }
                n4 += 4;
            }
            if (n7 == ok_d) {
                ok_d = 0;
                return false;
            }
            ok.b(n7, n);
            ok_c = n7;
            ok_b = n;
            n2 = n7;
        }
        ok_a = ok_f[n2] >> 16;
        ok_e = ok_f[n2 + 4] >> 16;
        int n12 = n2;
        ok_f[n12] = ok_f[n12] + ok_f[n2 + 2];
        int n13 = n2 + 4;
        ok_f[n13] = ok_f[n13] + ok_f[n2 + 6];
        ok_g = n2 += 8;
        return true;
    }

    private static final void a(int n, int n2) {
        if (n2 <= n + 4) {
            return;
        }
        int n3 = n;
        int n4 = ok_f[n3];
        int n5 = ok_f[n3 + 1];
        int n6 = ok_f[n3 + 2];
        int n7 = ok_f[n3 + 3];
        for (int i = n + 4; i < n2; i += 4) {
            int n8 = ok_f[i + 1];
            if (n8 >= n5) continue;
            ok.ok_f[n3] = ok_f[i];
            ok.ok_f[n3 + 1] = n8;
            ok.ok_f[n3 + 2] = ok_f[i + 2];
            ok.ok_f[n3 + 3] = ok_f[i + 3];
            ok.ok_f[i] = ok_f[n3 += 4];
            ok.ok_f[i + 1] = ok_f[n3 + 1];
            ok.ok_f[i + 2] = ok_f[n3 + 2];
            ok.ok_f[i + 3] = ok_f[n3 + 3];
        }
        ok.ok_f[n3] = n4;
        ok.ok_f[n3 + 1] = n5;
        ok.ok_f[n3 + 2] = n6;
        ok.ok_f[n3 + 3] = n7;
        ok.a(n, n3);
        ok.a(n3 + 4, n2);
    }

    static final void a(int[] nArray, int n) {
        ok.a(nArray, 0, nArray.length, n);
    }

    private static final void a(int[] nArray, int n, int n2, int n3) {
        ok.c();
        ok.b(nArray, n, n2);
        ok.a(n3);
    }

    private static final void a(int n) {
        ok.a();
        while (ok.b()) {
            int n2 = ok_a;
            int n3 = ok_e;
            int n4 = ok_h;
            hk.a(n2, n4, n3 - n2, n);
        }
    }

    private static final void a(int[] nArray, int n, int n2, int n3, int n4, int[] nArray2, int[] nArray3) {
        if (nArray2 != null && hk.hk_b - hk.hk_h != nArray2.length) {
            throw new IllegalStateException();
        }
        ok.c();
        ok.b(nArray, n, n2);
        ok.a(n3, n4, nArray2, nArray3);
    }

    private static final void b(int[] nArray, int n, int n2) {
        int n3;
        int n4;
        int n5 = ok_d + (n2 << 1);
        if (ok_f == null || ok_f.length < n5) {
            int[] nArray2 = new int[n5];
            for (n4 = 0; n4 < ok_d; ++n4) {
                nArray2[n4] = ok_f[n4];
            }
            ok_f = nArray2;
        }
        int n6 = (n2 += n) - 2;
        n4 = n3 = n;
        while (n3 < n2) {
            int n7 = nArray[n6 + 1];
            int n8 = nArray[n3 + 1];
            if (n7 < n8) {
                ok.ok_f[ok.ok_d++] = nArray[n6];
                ok.ok_f[ok.ok_d++] = n7;
                ok.ok_f[ok.ok_d++] = nArray[n3];
                ok.ok_f[ok.ok_d++] = n8;
            } else if (n8 < n7) {
                ok.ok_f[ok.ok_d++] = nArray[n3];
                ok.ok_f[ok.ok_d++] = n8;
                ok.ok_f[ok.ok_d++] = nArray[n6];
                ok.ok_f[ok.ok_d++] = n7;
            }
            n6 = n3;
            n3 += 2;
        }
    }
}
