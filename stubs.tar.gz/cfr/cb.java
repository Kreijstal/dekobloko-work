/*
 * Decompiled with CFR 0.152.
 */
final class cb {
    static String cb_k;
    private pb[] cb_f = new pb[16];
    static boolean[][] cb_e;
    static String cb_d;
    private int cb_b;
    String cb_a;
    static String cb_h;
    float cb_l;
    private int cb_j;
    static String cb_i;
    private int cb_g;
    static int cb_c;

    private final void a(String string, int n, String string2, String string3, int n2, ji ji2) {
        pb pb2;
        if (this.cb_g >= this.cb_f.length) {
            Object[] objectArray = new pb[2 * this.cb_g];
            an.a(this.cb_f, 0, objectArray, 0, this.cb_g);
            this.cb_f = (pb[])objectArray;
        }
        pb pb3 = pb2 = new pb();
        pb3.pb_j = string3;
        if (n != 2) {
            this.cb_a = null;
        }
        pb3.pb_a = string2;
        pb3.pb_b = string;
        pb3.pb_h = n2;
        pb3.pb_g = ji2;
        this.cb_f[this.cb_g++] = pb2;
    }

    public static void b(int n) {
        cb_e = null;
        if (n != 12623) {
            return;
        }
        cb_k = null;
        cb_h = null;
        cb_i = null;
        cb_d = null;
    }

    final boolean a(int n) {
        boolean bl = client.A;
        if (n > -48) {
            this.a(88);
        }
        while (~this.cb_j > ~this.cb_g) {
            pb pb2 = this.cb_f[this.cb_j];
            if (!pb2.pb_g.a((byte)121)) {
                this.a(pb2, 30993, 0);
                return false;
            }
            if (~pb2.pb_h <= -1 && !pb2.pb_g.b(pb2.pb_h, (byte)-106)) {
                this.a(pb2, 30993, pb2.pb_g.a((byte)34, pb2.pb_h));
                return false;
            }
            if (null != pb2.pb_b && !pb2.pb_g.a(pb2.pb_b, (byte)-103)) {
                this.a(pb2, 30993, pb2.pb_g.a(20, pb2.pb_b));
                return false;
            }
            if (-1 < ~pb2.pb_h && pb2.pb_b == null && null != pb2.pb_a && !pb2.pb_g.a(false)) {
                this.a(pb2, 30993, pb2.pb_g.b((byte)-100));
                return false;
            }
            ++this.cb_j;
        }
        return true;
    }

    static final boolean a(byte by) {
        if (by != -128) {
            CharSequence charSequence = null;
            cb.a((byte)49, charSequence);
        }
        return cd.a(8192) && (8 & uf.A) == 0;
    }

    private final void a(pb pb2, int n, int n2) {
        if (n != 30993) {
            return;
        }
        float f = (float)(this.cb_j - -1) + (float)n2 / 100.0f;
        this.cb_l = f * (float)this.cb_b / (float)(this.cb_g + 1);
        this.cb_a = ~n2 == -1 ? pb2.pb_j : pb2.pb_a + " - " + n2 + "%";
    }

    final void a(String string, ji ji2, String string2, byte by, String string3) {
        int n = -19 / ((by - 43) / 42);
        this.a(string, 2, string2, string3, -1, ji2);
    }

    static final void a(hl hl2, boolean bl) {
        String string;
        sl.a(hl2.hl_o, null, (byte)100, null, hl2.hl_f, hl2.hl_p, hl2.hl_r, hl2.hl_m, -2 != ~hl2.hl_m ? 0 : hl2.hl_k);
        if (0 == hl2.hl_m && !ne.b(-18163) && cd.cd_m == null && null == g.N) {
            if (!wl.wl_p) {
                pf pf2 = w.H;
                string = wk.wk_p;
                pf2.pf_h.a(string, 14, -61);
            }
            pf pf3 = w.H;
            string = re.re_t;
            pf3.pf_h.a(string, 20, 91);
        }
        if (-2 == ~hl2.hl_m && !ne.b(-18163) && null != cd.cd_m && ~hl2.hl_k == ~cd.cd_m.e(125)) {
            if (!wl.wl_p) {
                pf pf4 = w.H;
                string = ob.ob_l;
                pf4.pf_h.a(string, 14, 121);
            }
            pf pf5 = w.H;
            string = eb.eb_r;
            pf5.pf_h.a(string, 20, -57);
        }
        w.H.b(-92);
        w.H.a(bl, 29072);
        w.H.a(hl2.hl_m, (byte)-43, hl2.hl_q);
        w.H.a(17);
        w.H.a((byte)-51, hl2);
        pf pf6 = w.H;
        int n = he.S;
        int n2 = nf.nf_h;
        pf6.pf_h.b(n2, n, 121, 0, 0);
    }

    final void a(String string, byte by, ji ji2, String string2) {
        this.a(null, 2, string2, string, -1, ji2);
        int n = 73 / ((6 - by) / 37);
    }

    static final boolean a(boolean bl, CharSequence charSequence, int n) {
        int n2;
        boolean bl2 = client.A;
        if (charSequence == null) {
            return false;
        }
        if (n != 4564) {
            cb_c = 77;
        }
        if (-2 < ~(n2 = charSequence.length()) || ~n2 < -13) {
            return false;
        }
        String string = kf.a(charSequence, (byte)2);
        if (string == null || ~string.length() > -2) {
            return false;
        }
        if (ug.a(string.charAt(0), 32) || ug.a(string.charAt(string.length() + -1), 32)) {
            return false;
        }
        int n3 = 0;
        for (int i = 0; charSequence.length() > i; ++i) {
            char c = charSequence.charAt(i);
            n3 = ug.a(c, 32) ? ++n3 : 0;
            if (-3 < ~n3 || bl) continue;
            return false;
        }
        return -1 <= ~n3;
    }

    cb(int n) {
        this.cb_b = n;
    }

    static final void b(byte by) {
        block2: {
            boolean bl = client.A;
            bf.bf_o = ~gi.gi_c <= -1 ? (bf.bf_o += -gi.gi_c >> 467911937) : (bf.bf_o -= gi.gi_c >> 33324641);
            gi.gi_c = 0 > (gi.gi_c += bf.bf_o) ? (gi.gi_c -= gi.gi_c >> -858222876) : (gi.gi_c += -gi.gi_c >> -1859306780);
            wg.wg_d = 0 > nf.nf_e ? (wg.wg_d -= nf.nf_e >> -727063359) : (wg.wg_d += -nf.nf_e >> -2045972351);
            nf.nf_e = (nf.nf_e += wg.wg_d) >= 0 ? (nf.nf_e += -nf.nf_e >> 1697152068) : (nf.nf_e -= nf.nf_e >> 117175588);
            if (by != 71) {
                hl hl2 = null;
                cb.a(hl2, false);
            }
            if (nf.nf_e <= 0) break block2;
            if (wg.wg_d > 0) {
                wg.wg_d = -wg.wg_d;
            }
            nf.nf_e = 0;
        }
    }

    static final int a(byte by, CharSequence charSequence) {
        int n = 96 % ((3 - by) / 35);
        return s.a(true, 4, 10, charSequence);
    }

    static {
        cb_d = "Breaking real-world laws";
        cb_k = "Game full";
        cb_h = "Name";
        cb_i = "OH NO!";
    }
}
