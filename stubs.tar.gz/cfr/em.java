/*
 * Decompiled with CFR 0.152.
 */
final class em {
    private la em_c = new la(64);
    static String em_b = "<%0> has withdrawn the request to join.";
    private ji em_a;
    private ji em_d;

    public static void a(byte by) {
        if (by != 82) {
            em.a((byte)15);
        }
        em_b = null;
    }

    static final boolean b(byte by) {
        if (by >= -107) {
            return true;
        }
        return !jj.jj_f.a(80);
    }

    static final void a(int n) {
        ah.ah_c.c(true);
        if (pk.pk_v == null) {
            pk.pk_v = new qn(ah.ah_c, ed.ed_d);
        }
        if (n != -1199770620) {
            em_b = null;
        }
        ah.ah_c.a((byte)-119, (ce)pk.pk_v);
    }

    final ac a(int n, int n2) {
        ac ac2 = (ac)this.em_c.a((long)n2, (byte)-30);
        if (null != ac2) {
            return ac2;
        }
        int n3 = 57 / ((n - -79) / 38);
        byte[] byArray = ~n2 > -32769 ? this.em_d.a(n2, 63, 0) : this.em_a.a(Short.MAX_VALUE & n2, 49, 0);
        ac2 = new ac();
        if (byArray != null) {
            ac2.me_a_wl((byte)-4, new wl(byArray));
        }
        if (-32769 >= ~n2) {
            ac2.c(-1);
        }
        this.em_c.a(ac2, n2, 69);
        return ac2;
    }

    static final void a(vg vg2, boolean bl2, int n, byte by, int n2) {
        block9: {
            int n3;
            int n4;
            boolean bl3 = client.A;
            int n5 = s.b((byte)127, (-n2 + n) * 3);
            int n6 = n2 * 3;
            int n7 = n5 + -10;
            rd.c(0);
            if (0 < vg2.B && null != vg2.Q) {
                ci.a((byte)127);
            }
            ta.ta_d = 0;
            int n8 = 0;
            while (~vg2.L < ~n8) {
                block8: {
                    int n9;
                    int n10;
                    int n11;
                    int n12;
                    int n13;
                    int n14;
                    n4 = vg2.M[n8];
                    n3 = vg2.vg_c[n8];
                    short s2 = vg2.A[n8];
                    if (!(bl2 && (n14 = rn.rn_b[s2] - (n13 = rn.rn_b[n4])) * (n12 = -(n11 = kl.kl_n[n4]) + kl.kl_n[n3]) - (n10 = kl.kl_n[s2] - n11) * (n9 = -n13 + rn.rn_b[n3]) >= 0 || Integer.MAX_VALUE == ~(n11 = vg.G[n4]) || (n13 = vg.G[n3]) == Integer.MIN_VALUE || ~(n12 = vg.G[s2]) == Integer.MAX_VALUE)) {
                        n10 = n12 + (n13 + n11) + -n6;
                        n9 = -(0 <= n7 ? n10 >> n7 : n10 << -n7) + a.a_r.length + -1;
                        n14 = a.a_r[n9];
                        while (-1 != ~(n14 >> -1153113212)) {
                            if (~(--n9) > -1) {
                                System.err.println("Out of range!");
                                break block8;
                            }
                            n14 = a.a_r[n9];
                        }
                        int n15 = n14 + (n9 << -1199770620);
                        hb.Vb[n15] = n8;
                        a.a_r[n9] = n14 + 1;
                        if (-1 > ~vg2.B && vg2.Q != null) {
                            byte by2 = vg2.Q[n8];
                            nm.Nb[by2] = nm.Nb[by2] + 1;
                        }
                        ++ta.ta_d;
                    }
                }
                ++n8;
            }
            if (-1 > ~vg2.B && null != vg2.Q) {
                int n16;
                n8 = 0;
                n4 = n16 = 0;
                while (~nm.Nb.length < ~n16) {
                    n3 = nm.Nb[n16];
                    nm.Nb[n16] = n8;
                    n8 += n3;
                    ++n16;
                }
            }
            if (by >= 44) break block9;
            em_b = null;
        }
    }

    static final int[] a(int n, int n2, byte by) {
        if (by != 90) {
            em.a(107, 61, (byte)-72);
        }
        int n3 = sk.a(n2, -104);
        int n4 = ue.a(n2, 92);
        int n5 = sk.a(n, -122);
        int n6 = ue.a(n, -63);
        int n7 = (int)((long)n5 * (long)n3 >> -70246256);
        int n8 = (int)((long)n6 * (long)n3 >> 1547803216);
        int n9 = (int)((long)n5 * (long)n4 >> 1673413456);
        int n10 = (int)((long)n6 * (long)n4 >> 1909378640);
        return new int[]{0, 0, 0, n6, 0, n5, n7, n4, -n8, -n9, n3, n10};
    }

    static final void a(byte by, ji ji2) {
        ck ck2 = new ck(ji2.a(0, "", "final_frame.jpg"), jh.jh_b);
        int n = ck2.I;
        int n2 = ck2.H;
        uh.a(-9074);
        re.re_r = new ck(n, 3 * n2 / 4);
        re.re_r.a();
        ck2.e(0, 0);
        qj.qj_d = new ck(n, -re.re_r.H + n2);
        qj.qj_d.a();
        ck2.e(0, -re.re_r.H);
        if (by != -113) {
            em.a(16, 35, (byte)0);
        }
        qj.qj_d.z = re.re_r.H;
        mk.a((byte)-5);
    }

    em(int n, ji ji2, ji ji3) {
        this.em_a = ji3;
        this.em_d = ji2;
        if (null != this.em_d) {
            this.em_d.b(-5228, 0);
        }
        if (this.em_a != null) {
            this.em_a.b(-5228, 0);
        }
    }
}
