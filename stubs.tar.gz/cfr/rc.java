/*
 * Decompiled with CFR 0.152.
 */
final class rc
implements Runnable {
    volatile en[] rc_l = new en[2];
    volatile boolean rc_b = false;
    volatile boolean rc_j = false;
    fd rc_f;
    static vj rc_e;
    static int rc_a;
    static ui rc_d;
    static ji rc_k;
    static String rc_h;
    static String rc_g;
    static sg[] rc_c;
    static ud rc_i;

    static final int[] a(int[] nArray, byte by, int[] nArray2) {
        int[] nArray3;
        boolean bl = client.A;
        int[] nArray4 = nArray3 = new int[8];
        if (by != 47) {
            return null;
        }
        for (int i = 0; 8 > i; ++i) {
            nArray3[i] = lb.a(~nArray2[i], nArray[i]);
        }
        return nArray3;
    }

    public static void a(int n) {
        rc_h = null;
        rc_e = null;
        rc_k = null;
        rc_c = null;
        if (n >= -103) {
            return;
        }
        rc_g = null;
        rc_d = null;
        rc_i = null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public final void run() {
        boolean bl = client.A;
        this.rc_b = true;
        try {
            while (!this.rc_j) {
                int n = 0;
                while (~n > -3) {
                    en en2 = this.rc_l[n];
                    if (en2 != null) {
                        en2.g();
                    }
                    ++n;
                }
                ua.a(10L, -128);
                db.a(-68, null, this.rc_f);
            }
        }
        catch (Exception exception) {
            qb.a(exception, 16408, null);
        }
        finally {
            this.rc_b = false;
        }
    }

    static final boolean a(boolean bl) {
        if (bl) {
            rc.a(true);
        }
        return kf.Q != null;
    }

    static final ke a(boolean bl, boolean bl2, boolean bl3, byte by, boolean bl4) {
        ke ke2;
        ke ke3 = ke2 = new ke(2);
        ke3.ke_s = bl2;
        if (by > 0) {
            rc.a(-21);
        }
        ke3.ke_j = bl3;
        ke3.ke_r = bl;
        ke3.a(new ec(20, qn.qn_rb, a.a_t), 115);
        ke3.a(new ec(21, lg.T, a.a_t), 102);
        ke2.ke_f[0].ec_l = 320 + -(ke2.ke_f[0].ec_n / 2);
        ke2.ke_f[0].ec_m = 150;
        ke2.ke_f[1].ec_m = 250;
        ke2.ke_f[1].ec_l = 320 - ke2.ke_f[1].ec_n / 2;
        ke3.a(-1, bl4, -129);
        int n = ke2.ke_f[0].ec_n;
        int n2 = ke2.ke_f[1].ec_n;
        if (~n > ~n2) {
            n = n2;
        }
        if ((n2 = w.w_kb.a(si.si_g)) > n) {
            n = n2;
        }
        if (~n > ~(n2 = w.w_kb.a(gf.a(-127, bl2, bl3, bl)))) {
            n = n2;
        }
        n2 = w.w_kb.a(ri.a(0, bl2, bl3, bl));
        if (~n2 < ~n) {
            n = n2;
        }
        if (n < (n2 = w.w_kb.a(kk.a(bl3, bl2, bl, true)))) {
            n = n2;
        }
        ke3.z = 76;
        ke3.ke_w = -(n / 2) + 280;
        ke3.ke_q = 260;
        ke3.y = -ke3.ke_w + (n / 2 + 360);
        return ke3;
    }

    rc() {
    }

    static {
        rc_a = 0;
        rc_h = "Left";
        rc_e = new vj();
        rc_c = new sg[255];
        rc_g = "Cancel unrated rematch";
        int n = 0;
        while (~n > ~rc_c.length) {
            rc.rc_c[n] = new sg();
            ++n;
        }
    }
}
