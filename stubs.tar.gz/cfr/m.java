/*
 * Decompiled with CFR 0.152.
 */
interface m
extends kg {
    public void a(int var1, boolean var2, ce var3);
}
