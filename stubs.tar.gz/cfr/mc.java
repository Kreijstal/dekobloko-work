/*
 * Decompiled with CFR 0.152.
 */
final class mc {
    static nk mc_a;
    static int[] mc_b;
    static int mc_f;
    static String mc_e;
    static String mc_d;
    static String mc_c;

    static final void a(boolean bl, ff ff2, int n) {
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n2 = uf2.wl_n;
        uf2.a(true, 1);
        uf2.a(bl, ff2.ff_q);
        uf2.b(17, ff2.ff_r);
        uf2.a(ff2.ff_p, false);
        uf2.a(ff2.ff_n, false);
        uf2.a(ff2.ff_s, false);
        uf2.a(ff2.ff_t, false);
        uf2.a((byte)-15, n2);
        uf2.b(uf2.wl_n + -n2, true);
    }

    public static void a(int n) {
        mc_b = null;
        mc_e = null;
        if (n != 0) {
            return;
        }
        mc_d = null;
        mc_c = null;
        mc_a = null;
    }

    static final void a(ve ve2, boolean bl, int n, byte by) {
        block79: {
            int n2;
            int n3;
            int n4;
            boolean bl2 = client.A;
            boolean bl3 = !bl ? ig.b(true) && !ve2.ve_lc : !fj.fj_h;
            boolean bl4 = false;
            if (!bl) {
                n4 = 0;
                while (~n4 > -6) {
                    if (bl3 && ~qa.qa_v[0][n4 + 1].w_ob != -1 && n4 != ve2.Wb) {
                        ve2.Wb = n4;
                        bl4 = true;
                    }
                    qa.qa_v[0][1 + n4].Hb = bl3;
                    if (!pd.pd_a && 3 == n4) {
                        qa.qa_v[0][n4 - -1].Hb = false;
                    }
                    qa.qa_v[0][1 + n4].w_ab = ve2.Wb == n4;
                    ++n4;
                }
                if (qa.qa_v[0][2].Kb) {
                    sl.sl_g = ig.b(true) ? kf.J : cm.a((byte)82, bh.bh_h, new String[]{cd.cd_m.Vb});
                }
            }
            if (2 <= b.P.length) {
                int n5;
                int n6 = n4 = bl && 0 != ~rk.V ? 1 : 0;
                if (n4 != 0) {
                    n3 = rk.V;
                    n5 = 0;
                    while (~kk.kk_l.length < ~n5) {
                        kk.kk_l[n5] = 0;
                        ++n5;
                    }
                    kk.kk_l[n3 / 8] = (byte)de.b(kk.kk_l[n3 / 8], 1 << n3 % 8);
                }
                int n7 = n3 = bl ? -1 : 0;
                while (~n3 > ~b.P.length) {
                    int n8 = n5 = n4 != 0 && ~rk.V != ~n3 ? 1 : 0;
                    if (bl3 && ~qa.qa_v[1][n3 - -1].w_ob != -1) {
                        if (!bl) {
                            n2 = b.P[n3];
                            if (~ve2.ve_mc != ~n2) {
                                bl4 = true;
                                ve2.ve_mc = n2;
                            }
                        } else if (n4 == 0) {
                            if (n3 != -1) {
                                kk.kk_l[n3 / 8] = (byte)qm.b(kk.kk_l[n3 / 8], 1 << lb.a(n3, 7));
                            } else {
                                n2 = 0;
                                while (~n2 > ~kk.kk_l.length) {
                                    kk.kk_l[n2] = 0;
                                    ++n2;
                                }
                            }
                        }
                    }
                    if (bl) {
                        if (~n3 == 0) {
                            qa.qa_v[1][1 + n3].w_ab = true;
                            n2 = 0;
                            while (~b.P.length < ~n2) {
                                qa.qa_v[1][n3 + 1].w_ab = qa.qa_v[1][n3 + 1].w_ab & 0 == (kk.kk_l[n2 / 8] & 1 << (7 & n2));
                                ++n2;
                            }
                        } else {
                            qa.qa_v[1][1 + n3].w_ab = -1 != ~(kk.kk_l[n3 / 8] & 1 << (n3 & 7));
                        }
                    } else {
                        n2 = b.P[n3];
                        qa.qa_v[1][1 + n3].w_ab = ve2.ve_mc == n2;
                    }
                    qa.qa_v[1][1 + n3].Hb = bl3 && n5 == 0;
                    ++n3;
                }
            }
            if (by >= -121) {
                ve ve3 = null;
                mc.a(ve3, false, -56, (byte)50);
            }
            int n9 = n4 = bl ? 0 : 1;
            while (n4 < 3) {
                qd qd2 = qa.qa_v[2][n4];
                if (bl3 && ~qd2.w_ob != -1) {
                    if (bl) {
                        jb.jb_c = ~n4 == -1 ? 0 : (jb.jb_c ^= n4);
                    } else if (n4 != ve2.ve_qc) {
                        bl4 = true;
                        ve2.ve_qc = n4;
                    }
                }
                qd2.w_ab = bl ? (~n4 != -1 ? 0 != (n4 & jb.jb_c) : -1 == ~jb.jb_c) : -1 != ~(n4 & ve2.ve_qc);
                qd2.Hb = bl3;
                ++n4;
            }
            if (bl && 1 < mg.Vb) {
                for (n4 = 0; n4 < mg.Vb - -1; ++n4) {
                    qd qd3 = qa.qa_v[3][n4];
                    if (bl3 && ~qd3.w_ob != -1) {
                        qa.x = n4;
                    }
                    if (qd3.Kb && 0 < n4) {
                        String string;
                        String string2 = string = null != jj.jj_a ? jj.jj_a[-1 + n4] : null;
                        if (string != null) {
                            sl.sl_g = string;
                        }
                    }
                    qd3.w_ab = qa.x == n4;
                    qd3.Hb = bl3;
                }
            }
            n4 = 0;
            n3 = 0;
            while (~j.j_b < ~n3) {
                qd[] qdArray;
                qd[] qdArray2 = qdArray = qa.qa_v[4 - -n3];
                int n10 = n2 = bl ? -1 : 0;
                while (~n2 > ~(-1 + qdArray.length)) {
                    int n11;
                    int n12;
                    boolean bl5 = false;
                    boolean bl6 = false;
                    boolean bl7 = false;
                    boolean bl8 = false;
                    boolean bl9 = false;
                    int n13 = 0;
                    if (bl3 && 0 <= n2) {
                        if (af.af_b != null && null != af.af_b[n3] && 0 < (af.af_b[n3][n2] & ~uc.uc_d)) {
                            n13 = wb.b((byte)-93, ~uc.uc_d & af.af_b[n3][n2]);
                            bl9 = true;
                        }
                        if (null != cb.cb_e && null != cb.cb_e[n3] && 0 >= eh.eh_a && cb.cb_e[n3][n2]) {
                            bl5 = true;
                        }
                        if (mg.Ob != null && mg.Ob[n3] != null) {
                            n12 = mg.Ob[n3][n2];
                            if (n12 > 0 && n12 > de.R) {
                                bl7 = true;
                            }
                            if (-1 != ~n12 && !uc.uc_a && -1 <= ~eh.eh_a) {
                                bl5 = true;
                            }
                        }
                        if (null != ik.ik_h && ik.ik_h[n3] != null) {
                            n12 = ik.ik_h[n3][n2];
                            if (0 != n12 && !uc.uc_a && 0 >= eh.eh_a) {
                                bl5 = true;
                            }
                            if (~n12 < -1 && n12 > rf.rf_o) {
                                bl6 = true;
                            }
                        }
                        boolean bl10 = bl8 = bl && null != eh.eh_h && eh.eh_h[n3] != null && eh.eh_h[n3][n2];
                    }
                    if (te.te_p >= 2 && bj.bj_d[12]) {
                        bl8 = false;
                        bl6 = false;
                        bl7 = false;
                        bl9 = false;
                        bl5 = false;
                    }
                    n12 = bl5 || bl6 || bl7 || bl8 || bl9 ? 1 : 0;
                    ve.ve_ac = true;
                    if (!(n12 != 0 || n2 < 0 || bc.D == null || bl && fj.fj_h)) {
                        if (null == km.D) {
                            rd.rd_c = new boolean[j.j_b];
                            km.D = new byte[j.j_b];
                        }
                        gd.gd_b = false;
                        ve.ve_ac = false;
                        for (int k = 0; n3 > k; ++k) {
                            rd.rd_c[k] = false;
                        }
                        uc.a(-1, bl, -1, 0, n2, n3, ve2, false);
                        if (2 <= te.te_p && bj.bj_d[12]) {
                            ve.ve_ac = true;
                        }
                        if (!ve.ve_ac) {
                            n12 = 1;
                        }
                    }
                    qd qd4 = qdArray[1 + n2];
                    if (bl3 && ~qd4.w_ob != -1) {
                        if (bl) {
                            if (n2 != -1) {
                                v.v_a[(n4 + n2) / 8] = (byte)qm.b(v.v_a[(n4 + n2) / 8], 1 << lb.a(n2 + n4, 7));
                            } else {
                                for (n11 = n4; n11 < qdArray.length + n4 - 1; ++n11) {
                                    v.v_a[n11 / 8] = (byte)lb.a(v.v_a[n11 / 8], ~(1 << lb.a(n11, 7)));
                                }
                            }
                        } else if (n12 == 0 && (byte)n2 != ve2.ve_kc[n3]) {
                            ve2.ve_kc[n3] = (byte)n2;
                            bl4 = true;
                        }
                    }
                    if (bl && n12 != 0) {
                        v.v_a[(n4 + n2) / 8] = (byte)lb.a(v.v_a[(n4 + n2) / 8], ~(1 << lb.a(n2 + n4, 7)));
                    }
                    if (~n2 <= -1 && qd4.Kb) {
                        String string = gn.gn_c == null ? null : (gn.gn_c[n3] == null ? null : gn.gn_c[n3][n2]);
                        String string3 = hb.Qb != null ? (null != hb.Qb[n3] ? hb.Qb[n3][n2] : null) : null;
                        String string4 = null;
                        if (string3 != null && !string3.equals(string)) {
                            string4 = string3;
                        }
                        String string5 = null;
                        if (!bl8) {
                            if (!bl5) {
                                if (bl6) {
                                    int n14 = -rf.rf_o + ik.ik_h[n3][n2];
                                    string5 = n14 == 1 ? pl.pl_f : cm.a((byte)81, eb.eb_g, new String[]{Integer.toString(n14)});
                                }
                                if (bl7) {
                                    String string6 = cm.a((byte)110, wl.wl_q, new String[]{Integer.toString(de.R), Integer.toString(mg.Ob[n3][n2])});
                                    string5 = string5 == null ? string6 : string5 + "<br>" + string6;
                                }
                                if (bl9) {
                                    String string7 = ig.Sb;
                                    if (0 < n13 && lc.lc_e != null && ~n13 >= ~lc.lc_e.length && lc.lc_e[n13 - 1] != null) {
                                        string7 = lc.lc_e[n13 + -1][0];
                                    }
                                    string5 = string5 == null ? string7 : string5 + "<br>" + string7;
                                }
                            } else {
                                string5 = pj.F;
                            }
                        } else {
                            string5 = gd.gd_d;
                        }
                        if (bl3 && !ve.ve_ac) {
                            String string8 = null;
                            boolean bl11 = false;
                            if (gd.gd_b) {
                                string8 = "</col>" + hb.Pb + "<col=A00000>";
                            }
                            for (int k = 0; n3 > k; ++k) {
                                if (!rd.rd_c[k]) continue;
                                String string9 = "</col>" + pa.pa_db[k] + "<col=A00000>";
                                if (string8 == null) {
                                    string8 = string9;
                                    continue;
                                }
                                string8 = string8 + ", " + string9;
                                bl11 = true;
                            }
                            string5 = bl11 ? tl.x + string8 : cm.a((byte)115, ai.T, new String[]{string8});
                        }
                        if (null != string5) {
                            string5 = "<col=A00000>" + string5;
                            string5 = j.a("<br>", string5, "<br><col=A00000>", 0);
                            string4 = string4 == null ? string5 : string4 + "<br>" + string5;
                        }
                        if (string4 != null) {
                            sl.sl_g = string4;
                        }
                    }
                    if (bl) {
                        if (0 == ~n2) {
                            int n15;
                            qd4.w_ab = true;
                            n11 = n15 = n4;
                            while (n15 < -1 + (qdArray.length + n4)) {
                                qd4.w_ab = qd4.w_ab & 0 == (v.v_a[n15 / 8] & 1 << (n15 & 7));
                                ++n15;
                            }
                        } else {
                            qd4.w_ab = -1 != ~(v.v_a[(n2 + n4) / 8] & 1 << (n4 - -n2 & 7));
                        }
                    } else {
                        qd4.w_ab = ve.ve_ac && (byte)n2 == ve2.ve_kc[n3];
                    }
                    qd4.Hb = bl3 && n12 == 0;
                    ++n2;
                }
                n4 += 0xFF & rb.rb_k[n3];
                ++n3;
            }
            if (!bl4 || bl) break block79;
            qa.a(n, 1850462342);
        }
    }

    static final boolean a(String string, byte by) {
        boolean bl = client.A;
        char c = string.charAt(0);
        int n = 1;
        if (by >= -99) {
            ve ve2 = null;
            mc.a(ve2, false, -98, (byte)-9);
        }
        while (string.length() > n) {
            if (string.charAt(n) != c) {
                return false;
            }
            ++n;
        }
        return true;
    }

    static {
        mc_b = new int[]{2053254, 7976409, 15906096, 11781092, 41672};
        mc_f = 5;
        mc_d = "Off";
        mc_c = "Start Game";
    }
}
