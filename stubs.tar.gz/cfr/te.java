/*
 * Decompiled with CFR 0.152.
 */
final class te
extends wm {
    private rk te_s;
    private rk te_u;
    static String te_t = null;
    static int te_w;
    static volatile int te_r;
    static int te_p;
    static boolean[] te_v;
    static String te_q;

    @Override
    final String wm_a_string(String string, byte by) {
        String string2 = this.te_s.E.toLowerCase();
        String string3 = string.toLowerCase();
        if (string3.length() == 0) {
            return null;
        }
        String string4 = string3;
        if (client.a(by + 111, string4)) {
            return pe.pe_c;
        }
        if (qf.a(string4, 0)) {
            return uk.y;
        }
        if (mc.a(string4, (byte)-121)) {
            return lf.lf_b;
        }
        if (this.c(string, (byte)14)) {
            return bg.bg_f;
        }
        if (by != -11) {
            String string5 = null;
            this.wm_a_string(string5, (byte)-103);
        }
        if (string2.length() > 0) {
            if (nn.a(false, string2, string4)) {
                return rb.rb_g;
            }
            if (ij.a(string4, string2, (byte)-126)) {
                return ng.ng_j;
            }
            if (he.a(string2, (byte)-11, string4)) {
                return rb.rb_g;
            }
            return pe.pe_c;
        }
        return e.e_c;
    }

    te(rk rk2, rk rk3, rk rk4) {
        super(rk2);
        this.te_u = rk4;
        this.te_s = rk3;
    }

    public static void e(int n) {
        te_q = null;
        if (n != 0) {
            mm mm2 = null;
            te.a(null, 15, -79, null, mm2);
        }
        te_v = null;
        te_t = null;
    }

    private final boolean c(String string, byte by) {
        int n;
        if (by != 14) {
            te.e(-108);
        }
        String string2 = this.te_u.E.toLowerCase();
        String string3 = string.toLowerCase();
        if (0 < string2.length() && string3.length() > 0 && (n = string2.lastIndexOf("@")) >= 0 && n < -1 + string2.length()) {
            String string4 = string2.substring(0, n);
            String string5 = string2.substring(n - -1);
            if (~string3.indexOf(string4) <= -1) {
                return true;
            }
            if (string3.indexOf(string5) >= 0) {
                return true;
            }
        }
        return false;
    }

    static final int a(String string, int n, int n2, String[] stringArray, mm mm2) {
        int n3;
        block5: {
            boolean bl = client.A;
            int n4 = mm2.a(string);
            if (~n4 >= ~n2 && string.indexOf("<br>") == -1) {
                stringArray[0] = string;
                return 1;
            }
            n3 = (n2 + n4 + -1) / n2;
            n2 = n4 / n3;
            n3 = 0;
            int n5 = 0;
            int n6 = string.length();
            int n7 = 0;
            while (~n7 > ~n6) {
                String string2;
                int n8;
                char c2 = string.charAt(n7);
                if ((' ' == c2 || '-' == c2) && n2 <= (n8 = mm2.a(string2 = string.substring(n5, n7 + 1).trim()))) {
                    n5 = n7 + 1;
                    stringArray[n3++] = string2;
                }
                if ('>' == c2 && string.regionMatches(n7 - 3, "<br>", 0, 4)) {
                    stringArray[n3++] = string.substring(n5, -3 + n7).trim();
                    n5 = n7 + 1;
                }
                ++n7;
            }
            if (~n5 > ~n6) {
                stringArray[n3++] = string.substring(n5, n6).trim();
            }
            if (n > 65) break block5;
            te_t = null;
        }
        return n3;
    }

    @Override
    final tb b(String string, byte by) {
        String string2 = this.te_s.E.toLowerCase();
        String string3 = string.toLowerCase();
        if (0 == string3.length()) {
            return vm.vm_u;
        }
        if (!gf.a(-118, string2, string3)) {
            return vm.vm_u;
        }
        if (by != -40) {
            te_w = -71;
        }
        if (this.c(string, (byte)14)) {
            return vm.vm_u;
        }
        return dc.dc_b;
    }

    static {
        te_r = -1;
        te_v = new boolean[64];
    }
}
