/*
 * Decompiled with CFR 0.152.
 */
final class ng {
    static String ng_g;
    private bh[] ng_h;
    private int ng_d = 0;
    static String ng_e;
    private int ng_f;
    static String ng_j;
    static long ng_a;
    static w ng_i;
    static ck ng_b;
    static String ng_l;
    private bh ng_k;
    private bh ng_c;

    static final void a(ck[] ckArray, int n, int n2, int n3, int n4) {
        boolean bl = client.A;
        if (null != ckArray) {
            if (~n >= -1) {
                return;
            }
            int n5 = ckArray[0].K;
            int n6 = ckArray[2].K;
            if (n3 != -1) {
                ng_g = null;
            }
            int n7 = ckArray[1].K;
            ckArray[0].c(n4, n2);
            ckArray[2].c(n4 - -n - n6, n2);
            hk.b(kh.kh_e);
            hk.f(n5 + n4, n2, n4 + (n - n6), n2 + ckArray[1].C);
            int n8 = n5 + n4;
            int n9 = -n6 + n4 + n;
            for (n4 = n8; n4 < n9; n4 += n7) {
                ckArray[1].c(n4, n2);
            }
            hk.a(kh.kh_e);
            return;
        }
    }

    public static void a(int n) {
        ng_i = null;
        ng_g = null;
        if (n > -26) {
            return;
        }
        ng_j = null;
        ng_b = null;
        ng_l = null;
        ng_e = null;
    }

    final void a(long l, int n, bh bh2) {
        if (null != bh2.bh_a) {
            bh2.b((byte)116);
        }
        bh bh3 = this.ng_h[(int)((long)(this.ng_f + n) & l)];
        bh2.bh_a = bh3.bh_a;
        bh2.bh_b = bh3;
        bh2.bh_a.bh_b = bh2;
        bh2.bh_b.bh_a = bh2;
        bh2.bh_i = l;
    }

    final bh a(long l, int n) {
        boolean bl = client.A;
        bh bh2 = this.ng_h[(int)((long)(this.ng_f - 1) & l)];
        this.ng_k = bh2.bh_b;
        while (this.ng_k != bh2) {
            if ((this.ng_k.bh_i ^ 0xFFFFFFFFFFFFFFFFL) == (l ^ 0xFFFFFFFFFFFFFFFFL)) {
                bh bh3 = this.ng_k;
                this.ng_k = this.ng_k.bh_b;
                return bh3;
            }
            this.ng_k = this.ng_k.bh_b;
        }
        this.ng_k = null;
        if (n >= 48) {
            return null;
        }
        return null;
    }

    static final jc a(int n, String string) {
        boolean bl = client.A;
        int n2 = string.length();
        if (n2 == 0) {
            return hm.hm_a;
        }
        if (~n2 < -65) {
            return ga.ga_e;
        }
        if (n != -1) {
            ck[] ckArray = null;
            ng.a(ckArray, 38, -12, 7, -118);
        }
        if (string.charAt(0) == '\"') {
            if (string.charAt(n2 + -1) != '\"') {
                return be.x;
            }
            boolean bl2 = false;
            int n3 = 1;
            while (true) {
                if (~(n2 + -1) >= ~n3) {
                    return null;
                }
                char c = string.charAt(n3);
                if (c == '\\') {
                    bl2 = !bl2;
                } else {
                    if (c == '\"' && !bl2) {
                        return be.x;
                    }
                    bl2 = false;
                }
                ++n3;
            }
        }
        boolean bl3 = false;
        int n4 = 0;
        while (n2 > n4) {
            char c = string.charAt(n4);
            if ('.' == c) {
                if (0 == n4 || n4 == -1 + n2 || bl3) {
                    return be.x;
                }
                bl3 = true;
            } else {
                if (-1 == nm.Pb.indexOf(c)) {
                    return be.x;
                }
                bl3 = false;
            }
            ++n4;
        }
        return null;
    }

    final bh a(byte by) {
        block0: {
            this.ng_d = 0;
            if (by == 126) break block0;
            this.b((byte)112);
        }
        return this.b((byte)49);
    }

    final bh b(byte by) {
        bh bh2;
        bh bh3;
        boolean bl = client.A;
        if (~this.ng_d < -1 && this.ng_h[-1 + this.ng_d] != this.ng_c) {
            bh bh4 = this.ng_c;
            this.ng_c = bh4.bh_b;
            return bh4;
        }
        if (by < 37) {
            return null;
        }
        do {
            if (this.ng_f <= this.ng_d) {
                return null;
            }
            bh2 = bh3 = this.ng_h[this.ng_d++].bh_b;
        } while (bh3 == this.ng_h[-1 + this.ng_d]);
        this.ng_c = bh2.bh_b;
        return bh2;
    }

    ng(int n) {
        this.ng_f = n;
        this.ng_h = new bh[n];
        int n2 = 0;
        while (~n < ~n2) {
            bh bh2;
            this.ng_h[n2] = bh2 = new bh();
            bh2.bh_b = bh2;
            bh2.bh_a = bh2;
            ++n2;
        }
    }

    static {
        ng_e = "Please check if address is correct";
        ng_g = "Stage";
        ng_j = "This password is part of your Player Name, and would be easy to guess";
        ng_l = "Waiting for graphics";
    }
}
