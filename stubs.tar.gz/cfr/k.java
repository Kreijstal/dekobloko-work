/*
 * Decompiled with CFR 0.152.
 */
final class k {
    static String k_d;
    static w k_a;
    static sk k_f;
    static String k_h;
    static String k_e;
    static int[] k_g;
    static mh k_c;
    static s k_b;

    public static void a(int n) {
        k_d = null;
        if (n != -5161) {
            k_b = null;
        }
        k_g = null;
        k_h = null;
        k_c = null;
        k_e = null;
        k_a = null;
        k_b = null;
        k_f = null;
    }

    static final boolean a(String string, boolean bl) {
        if (!bl) {
            return false;
        }
        return h.h_c.equals(kf.a(string, (byte)2));
    }

    static final void a(byte by) {
        if (by != -36) {
            k_c = null;
        }
        jg.a(se.h(25144), 0);
    }

    static {
        k_h = "Accept rematch";
        k_d = "Security";
        k_f = new sk(1);
        k_e = null;
    }
}
