/*
 * Decompiled with CFR 0.152.
 */
final class qm {
    static qm qm_g;
    static w qm_a;
    static String qm_e;
    int qm_d;
    static ck qm_c;
    int qm_f;
    static String qm_b;

    static final void a(boolean bl, int n, boolean bl2, byte by) {
        block7: {
            boolean bl3 = client.A;
            pa.g((byte)104);
            fn.fn_g.Y = ~de.R <= -1 ? cm.a((byte)94, ke.ke_n, new String[]{Integer.toString(de.R)}) : null;
            g.R.a(false, bl && !bl2 && !ve.Qb && null == cd.cd_m && g.N == null);
            wm.wm_h.a(false, bl && !bl2 && !ve.Qb && cd.cd_m == null && null == g.N);
            tc.Ob.a(false, bl && !bl2 && ve.Qb);
            dc.dc_e.ak_h.b(false);
            if (~uh.uh_c.w_ob != -1) {
                nh.nh_a = true;
            }
            if (by != -8) {
                return;
            }
            if (0 != o.o_a.w_ob) {
                if (uc.uc_a || 0 < eh.eh_a || 2 <= te.te_p && bj.bj_d[12]) {
                    bf.b(-20861, n);
                } else {
                    sn.sn_g = true;
                }
            }
            if (0 != se.U.w_ob) {
                if (1 == b.P.length && hd.hd_u != b.P[0]) {
                    hd.hd_u = b.P[0];
                }
                ad.a(ne.ne_c, n, true, hd.hd_u, 0, true);
            }
            if (-1 == ~ce.A.w_ob) break block7;
            ve.Qb = false;
        }
    }

    public static void a(int n) {
        qm_e = null;
        if (n != 2) {
            return;
        }
        qm_a = null;
        qm_g = null;
        qm_c = null;
        qm_b = null;
    }

    static final int a(byte by) {
        boolean bl2 = client.A;
        ah.ah_c.a(of.of_i, true, kf.K, 29166);
        ah.ah_c.g(0);
        while (ab.c((byte)-128)) {
            ah.ah_c.a(wh.wh_c, el.G, (byte)123);
        }
        if (~ai.P != 0) {
            int n = ai.P;
            hm.a(-1, (byte)-120);
            return n;
        }
        if (mg.Nb) {
            return 3;
        }
        if (ka.P == pa.V) {
            return 1;
        }
        if (!jj.jj_f.a(102)) {
            return 1;
        }
        if (by != 57) {
            qm.a((byte)-99);
        }
        if (pa.V == sh.sh_d) {
            return 2;
        }
        return -1;
    }

    static int b(int n, int n2) {
        return n ^ n2;
    }

    static final ck[] a(int n, int n2) {
        ck[] ckArray;
        ck[] ckArray2 = ckArray = new ck[n];
        ckArray[4] = sm.a((byte)-126, 64, n2);
        return ckArray2;
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    static final void a(int n, int n2, int n3, int n4) {
        hd.hd_s = n3;
        int n5 = 22 % ((-8 - n2) / 37);
        ie.ie_b = n4;
        i.i_c = n;
    }

    qm(int n, int n2, int n3, int n4) {
        this.qm_d = n;
        this.qm_f = n4;
    }

    static {
        qm_b = "Public";
        qm_g = new qm(13, 0, 1, 0);
    }
}
