/*
 * Decompiled with CFR 0.152.
 */
final class ia
extends rh {
    private int ia_ab;
    private int[] ia_hb;
    private int H;
    private int ia_u = 0;
    private int[] P;
    private int ia_pb = 0;
    private int[] F;
    private int[] z;
    private int U = 256;
    private int[] ia_s;
    private int[] D;
    private int N = -1;
    private ui I;
    private int[] ia_r;
    private int L;
    private int[] T;
    private int[] ia_v;
    private int[] ia_gb;
    private int[] ia_tb;
    private int C;
    private int[] ia_mb;
    private int ia_rb = -1;
    private int[] ia_jb;
    private int ia_ib = 0;
    private ui V = null;
    private int[] ia_p;
    private int R = 0;
    private int[] ia_ob;
    private int[] G;
    private int[] ia_eb;
    private int[] Y;
    private int[] y;
    private static int[] ia_nb;
    private int X;
    private int ia_t;
    private int[] B;
    private int[] ia_lb;
    private int[] x;
    private int[] ia_sb;
    private static int[] K;
    private int ia_qb = 0;
    private int[] ia_q;
    private int[] E;
    private int Z = 0;
    private int[] Q;
    private ei[] ia_fb;
    private int[] ia_cb;
    private int[] S;
    private int[] ia_kb;
    private int[] ia_db;
    private int A = 64;
    private int W;
    private boolean ia_w = true;
    private int[] J;
    private int M = -1;
    private boolean[] O;
    private int[] ia_bb;

    private final void e() {
        this.ia_lb = new int[this.I.H];
        this.x = new int[this.I.H];
        this.T = new int[this.I.H];
        this.F = new int[this.I.H];
        this.ia_s = new int[this.I.H];
        this.y = new int[this.I.H];
        this.ia_sb = new int[this.I.H];
        this.ia_eb = new int[this.I.H];
        this.ia_gb = new int[this.I.H];
        this.Y = new int[this.I.H];
        this.B = new int[this.I.H];
        this.D = new int[this.I.H];
        this.ia_mb = new int[this.I.H];
        this.ia_cb = new int[this.I.H];
        this.S = new int[this.I.H];
        this.ia_db = new int[this.I.H];
        this.ia_r = new int[this.I.H];
        this.ia_tb = new int[this.I.H];
        this.E = new int[this.I.H];
        this.ia_ob = new int[this.I.H];
        this.z = new int[this.I.H];
        this.ia_v = new int[this.I.H];
        this.P = new int[this.I.H];
        this.ia_kb = new int[this.I.H];
        this.ia_bb = new int[this.I.H];
        this.ia_p = new int[this.I.H];
        this.ia_hb = new int[this.I.H];
        this.G = new int[this.I.H];
        this.ia_jb = new int[this.I.H];
        this.ia_q = new int[this.I.H];
        this.J = new int[this.I.H];
        this.Q = new int[this.I.H];
        this.O = new boolean[this.I.H];
        this.ia_fb = new ei[this.I.H];
        this.d();
    }

    private final void d(int n) {
        if (this.ia_fb[n] != null) {
            this.ia_fb[n].g(en.en_o >> 7);
            this.ia_fb[n] = null;
            return;
        }
    }

    final synchronized void a(ui ui2, int n, int n2, int n3) {
        this.ia_ib = n3;
        if (ui2 != null) {
            this.V = ui2;
        }
        this.M = n;
        this.ia_rb = n2;
    }

    @Override
    final void b() {
        for (int i = 0; i < this.I.H; ++i) {
            if (this.ia_fb[i] == null) continue;
            this.rh_n.a(this.ia_fb[i]);
        }
    }

    private final void d() {
        int n;
        int n2;
        this.R = 0;
        this.ia_pb = 0;
        this.X = 0;
        this.ia_ab = 0;
        this.H = 0;
        this.ia_t = 0;
        this.C = this.I.ui_k;
        this.L = this.I.ui_m;
        this.W = 64;
        for (n2 = 0; n2 < this.I.H; ++n2) {
            this.ia_sb[n2] = 0;
            this.ia_eb[n2] = 0;
            this.ia_gb[n2] = 0;
            this.Y[n2] = 0;
            this.B[n2] = 0;
            this.D[n2] = 0;
            this.ia_mb[n2] = 0;
            this.ia_cb[n2] = 0;
            this.S[n2] = 0;
            this.ia_db[n2] = 0;
            this.ia_r[n2] = 0;
            this.ia_tb[n2] = 0;
            this.E[n2] = 0;
            this.ia_ob[n2] = 0;
            this.z[n2] = 0;
            this.ia_v[n2] = 0;
            this.P[n2] = -1;
            this.ia_kb[n2] = 0;
            this.ia_bb[n2] = 0;
            this.ia_p[n2] = 0;
            this.ia_hb[n2] = 0;
            this.G[n2] = 0;
            this.ia_jb[n2] = 0;
            this.Q[n2] = 0;
            this.ia_q[n2] = 0;
            this.J[n2] = 0;
            this.F[n2] = 0;
            this.ia_lb[n2] = 0;
            this.x[n2] = 128;
            this.T[n2] = 0;
            this.ia_s[n2] = -1;
        }
        this.ia_ib = 0;
        this.V = null;
        this.M = -1;
        this.ia_rb = -1;
        this.ia_qb = 0;
        this.ia_u = 0;
        this.N = -1;
        this.Z = 0;
        n2 = n = 0;
        while (n < this.I.H) {
            this.ia_fb[n] = null;
            this.O[n] = false;
            ++n;
        }
        this.ia_pb = 1;
    }

    final synchronized void a(int n) {
        this.A = n;
    }

    private final void a(int n, int n2, int n3) {
        if (this.ia_fb[n] != null) {
            if (n2 < 0) {
                n2 = 0;
            } else if (n2 > 64) {
                n2 = 64;
            }
            if (n3 < 0) {
                n3 = 0;
            } else if (n3 > 256) {
                n3 = 256;
            }
            this.ia_fb[n].a(en.en_o >> 7, n2 * this.W * this.A >> 12, n3);
            return;
        }
    }

    @Override
    final void a() {
        for (int i = 0; i < this.I.H; ++i) {
            if (this.ia_fb[i] == null) continue;
            this.rh_n.b(this.ia_fb[i]);
        }
    }

    public static void f() {
        ia_nb = null;
        K = null;
    }

    private final boolean c() {
        int n;
        int n2;
        int n3;
        int n4 = 0;
        if (this.ia_pb != 1 && this.ia_pb != 2) {
            this.R = 0;
            return false;
        }
        boolean bl = false;
        if (this.R == 0) {
            if (this.ia_pb == 1) {
                this.ia_pb = 2;
                this.H = 0;
                this.ia_ab = 0;
                this.ia_t = this.I.ui_s[this.H];
                this.X = 0;
            }
            if (this.ia_ab >= this.I.ui_d[this.ia_t] || this.Z == 1 || this.ia_qb != 0 && this.ia_ab % this.ia_qb == 0 || this.ia_ib > 0 && this.ia_ab % this.ia_ib == 0) {
                if (this.ia_qb != 0) {
                    if (this.ia_u <= this.H) {
                        bl = true;
                    }
                    this.H = this.ia_u;
                } else {
                    ++this.H;
                }
                if (this.N != -1) {
                    this.H = this.N;
                    this.N = -1;
                }
                if (this.H >= this.I.ui_i) {
                    this.H = 0;
                    bl = true;
                }
                this.ia_ab = 0;
                if (this.Z == 1) {
                    this.ia_u = this.ia_u / 16 * 10 + this.ia_u % 16;
                    if (this.ia_u >= this.I.ui_d[this.ia_t]) {
                        this.ia_u = 0;
                    }
                    this.ia_ab = this.ia_u;
                }
                if (this.M >= 0 && (this.ia_ib >= 0 || bl)) {
                    n3 = this.M;
                    n2 = this.ia_rb;
                    if (this.V != null) {
                        for (n = 0; n < this.I.H; ++n) {
                            this.d(n);
                        }
                        this.I = this.V;
                        this.e();
                        this.ia_pb = 2;
                    }
                    this.H = n3;
                    this.ia_ab = n2;
                    bl = false;
                    this.ia_ib = 0;
                    this.M = -1;
                    this.ia_rb = -1;
                    this.V = null;
                }
                this.ia_t = this.I.ui_s[this.H];
                this.X = 0;
                for (int i = 0; i < this.ia_ab; ++i) {
                    for (n3 = 0; n3 < this.I.H; ++n3) {
                        n2 = this.I.ui_e[this.ia_t][this.X] & 0xFF;
                        ++this.X;
                        if (n2 < 128) {
                            --this.X;
                            n2 = 31;
                        } else {
                            n2 -= 128;
                        }
                        if ((n2 & 1) == 1) {
                            ++this.X;
                        }
                        if ((n2 & 2) == 2) {
                            ++this.X;
                        }
                        if ((n2 & 4) == 4) {
                            ++this.X;
                        }
                        if ((n2 & 8) == 8) {
                            ++this.X;
                        }
                        if ((n2 & 0x10) != 16) continue;
                        ++this.X;
                    }
                }
                this.N = -1;
                this.Z = 0;
                this.ia_qb = 0;
            }
            ++this.ia_ab;
        }
        for (n3 = 0; n3 < this.I.H; ++n3) {
            int n5;
            if (this.R == 0) {
                n2 = this.X;
            } else {
                if (this.P[n3] < 0) continue;
                n2 = this.P[n3];
            }
            this.P[n3] = -1;
            n = n2;
            int n6 = -1;
            int n7 = -1;
            int n8 = -1;
            int n9 = -1;
            int n10 = -1;
            int n11 = 0;
            int n12 = this.I.ui_e[this.ia_t][n2] & 0xFF;
            ++n2;
            if (n12 < 128) {
                --n2;
                n12 = 31;
            } else {
                n12 -= 128;
            }
            if ((n12 & 1) == 1) {
                n6 = this.I.ui_e[this.ia_t][n2] & 0xFF;
                ++n2;
            }
            if ((n12 & 2) == 2) {
                n7 = (this.I.ui_e[this.ia_t][n2] & 0xFF) - 1;
                ++n2;
            }
            if ((n12 & 4) == 4) {
                n8 = (this.I.ui_e[this.ia_t][n2] & 0xFF) - 16;
                ++n2;
            }
            if ((n12 & 8) == 8) {
                n10 = this.I.ui_e[this.ia_t][n2] & 0xFF;
                ++n2;
            }
            if ((n12 & 0x10) == 16) {
                n11 = this.I.ui_e[this.ia_t][n2] & 0xFF;
                ++n2;
            }
            if (this.R == 0) {
                this.X = n2;
            }
            if (this.O[n3]) continue;
            if (n10 == 14) {
                n10 = n10 * 16 + n11 / 16;
                n11 &= 0xF;
            }
            if (n10 == 236) {
                if (n11 == 0) {
                    n6 = 97;
                } else if (this.R == n11) {
                    n6 = 97;
                    n10 = -1;
                    n9 = -1;
                    n8 = -1;
                    n7 = -1;
                    n11 = 0;
                } else {
                    this.P[n3] = n;
                }
            }
            if (n10 == 237 && this.R < n11) {
                this.P[n3] = n;
                continue;
            }
            if (n8 >= 80 && n8 < 96) {
                this.ia_q[n3] = 2;
                this.ia_sb[n3] = 80 - n8;
                n8 = -1;
            }
            if (n8 >= 96 && n8 < 112) {
                this.ia_q[n3] = 2;
                this.ia_sb[n3] = n8 - 96;
                n8 = -1;
            }
            if (n8 >= 112 && n8 < 128) {
                if ((n8 = this.ia_lb[n3] - (n8 - 112)) < 0) {
                    n8 = 0;
                } else if (n8 > 64) {
                    n8 = 64;
                }
            }
            if (n8 >= 128 && n8 < 136) {
                if ((n8 = this.ia_lb[n3] + (n8 - 128)) < 0) {
                    n8 = 0;
                } else if (n8 > 64) {
                    n8 = 64;
                }
            }
            if (n8 >= 176 && n8 < 192) {
                n9 = (n8 - 176) * 17;
                n8 = -1;
            }
            if (n8 >= 192 && n8 < 208) {
                this.J[n3] = 2;
                this.ia_eb[n3] = 192 - n8;
                n8 = -1;
            }
            if (n8 >= 208 && n8 < 224) {
                this.J[n3] = 2;
                this.ia_eb[n3] = n8 - 208;
                n8 = -1;
            }
            if (n8 > 64) {
                n8 = -1;
            }
            if (n10 == 13) {
                if (this.ia_qb <= 1) {
                    this.Z = 1;
                    this.ia_u = n11;
                } else {
                    this.ia_qb = 1;
                }
            }
            if (n10 == 15) {
                if (n11 < 32) {
                    this.C = n11;
                } else {
                    this.L = n11;
                }
            }
            if (n10 == 16) {
                this.W = n11;
            }
            if (n10 == 12) {
                n8 = n11;
            }
            if (n10 == 8) {
                n9 = n11;
            }
            if (n10 == 11 && this.ia_qb <= 1) {
                this.ia_qb = 1;
                this.ia_u = n11;
            }
            if (n10 == 20) {
                n6 = 97;
            }
            if (n10 == 21) {
                this.ia_kb[n3] = n11;
                if (this.ia_kb[n3] >= this.I.ui_q[n4][this.I.ui_q[n4].length - 1]) {
                    this.ia_kb[n3] = this.I.ui_q[n4][this.I.ui_q[n4].length - 1] - 1;
                }
                this.ia_bb[n3] = n11;
                if (this.ia_bb[n3] >= this.I.ui_c[n4][this.I.ui_c[n4].length - 1]) {
                    this.ia_bb[n3] = this.I.ui_c[n4][this.I.ui_c[n4].length - 1] - 1;
                }
            }
            if (n7 >= 0 && n6 <= 96) {
                this.ia_kb[n3] = 0;
                this.ia_bb[n3] = 0;
                this.ia_hb[n3] = 1;
                this.G[n3] = 0;
            }
            if (n10 == 3 && n8 < 0 && n7 != -1) {
                n8 = this.I.G[this.F[n3]];
            }
            if (n10 == 3 && n9 < 0 && n7 != -1) {
                n9 = this.I.ui_n[this.F[n3]];
            }
            if (n6 >= 0 && n6 <= 96 && n10 != 3) {
                if (n7 == -1 && n8 < 0) {
                    n8 = this.ia_lb[n3];
                }
                if (n7 == -1 && n9 < 0) {
                    n9 = this.x[n3];
                }
                if (n7 == -1) {
                    n7 = this.F[n3];
                } else {
                    this.ia_s[n3] = n7;
                    n7 = n6 < 96 ? this.I.ui_p[n7][n6] : this.I.ui_p[n7][95];
                }
                if (n8 < 0) {
                    n8 = this.I.G[n7];
                }
                if (n9 < 0) {
                    n9 = this.I.ui_n[n7];
                }
                if ((n5 = 7680 - (n6 + this.I.ui_b[n7]) * 64 - this.I.ui_l[n7] / 2) < 0) {
                    n5 = 0;
                } else if (n5 > 7999) {
                    n5 = 7999;
                }
                this.z[n3] = n5;
                int n13 = ia_nb[n5];
                this.F[n3] = n7;
                this.ia_lb[n3] = n8;
                this.x[n3] = n9;
                this.T[n3] = n5;
                int n14 = 0;
                if (n10 == 9) {
                    n14 = n11 * 256 > this.I.B[n7] ? this.I.B[n7] : n11 * 256;
                }
                this.a(n3, n7, n14, n13, n8, n9);
                this.B[n3] = 0;
            } else if (n6 > 96) {
                if (this.ia_p[n3] == 1) {
                    this.ia_hb[n3] = 0;
                } else {
                    this.d(n3);
                }
            } else if (n8 >= 0 || n9 >= 0) {
                if (n8 >= 0) {
                    this.ia_lb[n3] = n8;
                }
                if (n9 >= 0) {
                    this.x[n3] = n9;
                }
            }
            if (n10 == 3) {
                this.ia_jb[n3] = 1;
                if (n6 >= 0 && n6 <= 96) {
                    n7 = this.F[n3];
                    n5 = 7680 - (n6 + this.I.ui_b[n7]) * 64 - this.I.ui_l[n7] / 2;
                    if (n5 < 0) {
                        n5 = 0;
                    } else if (n5 > 7999) {
                        n5 = 7999;
                    }
                    this.z[n3] = n5;
                }
                if (n11 != 0) {
                    this.ia_v[n3] = n11;
                    if (this.I.N == 0) {
                        this.ia_v[n3] = this.ia_v[n3] * 2;
                    }
                }
            } else if (n10 != 5) {
                this.ia_jb[n3] = 0;
            }
            if (n10 == 4) {
                this.D[n3] = 1;
                if (n11 / 16 > 0) {
                    this.ia_gb[n3] = n11 / 16;
                }
                if ((n11 & 0xF) > 0) {
                    this.Y[n3] = n11 & 0xF;
                }
            } else if (n10 != 6) {
                if (this.D[n3] != 0) {
                    n5 = ia_nb[this.T[n3]];
                    this.b(n3, n5);
                }
                this.B[n3] = 0;
                this.D[n3] = 0;
            }
            if (n10 == 17) {
                this.Q[n3] = 1;
                if (n11 != 0) {
                    this.y[n3] = (n11 & 0xF0) / 16 - (n11 & 0xF);
                }
            } else {
                this.Q[n3] = 0;
            }
            if (n10 == 10 || n10 == 6 || n10 == 5) {
                this.ia_q[n3] = 1;
                if (n11 != 0) {
                    this.ia_sb[n3] = (n11 & 0xF0) / 16 - (n11 & 0xF);
                }
            } else {
                this.ia_q[n3] = this.ia_q[n3] == 2 ? 1 : 0;
            }
            if (n10 == 25) {
                this.J[n3] = 1;
                if (n11 != 0) {
                    this.ia_eb[n3] = (n11 & 0xF0) / 16 - (n11 & 0xF);
                }
            } else {
                this.J[n3] = this.J[n3] == 2 ? 1 : 0;
            }
            if (n10 == 234) {
                if (n11 == 0) {
                    n11 = this.ia_mb[n3];
                } else {
                    this.ia_mb[n3] = n11;
                }
                int n15 = n3;
                this.ia_lb[n15] = this.ia_lb[n15] + n11;
                if (this.ia_lb[n3] < 0) {
                    this.ia_lb[n3] = 0;
                } else if (this.ia_lb[n3] > 64) {
                    this.ia_lb[n3] = 64;
                }
            }
            if (n10 == 235) {
                if (n11 == 0) {
                    n11 = this.ia_db[n3];
                } else {
                    this.ia_db[n3] = n11;
                }
                int n16 = n3;
                this.ia_lb[n16] = this.ia_lb[n16] - n11;
                if (this.ia_lb[n3] < 0) {
                    this.ia_lb[n3] = 0;
                } else if (this.ia_lb[n3] > 64) {
                    this.ia_lb[n3] = 64;
                }
            }
            if (n10 == 1) {
                if (n11 != 0) {
                    this.E[n3] = n11;
                }
            } else {
                this.E[n3] = 0;
            }
            if (n10 == 2) {
                if (n11 != 0) {
                    this.ia_ob[n3] = n11;
                }
            } else {
                this.ia_ob[n3] = 0;
            }
            if (n10 == 225) {
                if (n11 == 0) {
                    n11 = this.ia_cb[n3];
                } else {
                    this.ia_cb[n3] = n11;
                }
                int n17 = n3;
                this.T[n17] = this.T[n17] - n11 * 4;
                if (this.T[n3] < 0) {
                    this.T[n3] = 0;
                } else if (this.T[n3] > 7999) {
                    this.T[n3] = 7999;
                }
                n5 = ia_nb[this.T[n3]];
                this.b(n3, n5);
            }
            if (n10 == 226) {
                if (n11 == 0) {
                    n11 = this.ia_r[n3];
                } else {
                    this.ia_r[n3] = n11;
                }
                int n18 = n3;
                this.T[n18] = this.T[n18] + n11 * 4;
                if (this.T[n3] < 0) {
                    this.T[n3] = 0;
                } else if (this.T[n3] > 7999) {
                    this.T[n3] = 7999;
                }
                n5 = ia_nb[this.T[n3]];
                this.b(n3, n5);
            }
            if (n10 != 33) continue;
            if (n11 / 16 == 1) {
                if ((n11 &= 0xF) == 0) {
                    n11 = this.S[n3];
                } else {
                    this.S[n3] = n11;
                }
                int n19 = n3;
                this.T[n19] = this.T[n19] - n11;
                if (this.T[n3] < 0) {
                    this.T[n3] = 0;
                } else if (this.T[n3] > 7999) {
                    this.T[n3] = 7999;
                }
                n5 = ia_nb[this.T[n3]];
                this.b(n3, n5);
                continue;
            }
            if ((n11 &= 0xF) == 0) {
                n11 = this.ia_tb[n3];
            } else {
                this.ia_tb[n3] = n11;
            }
            int n20 = n3;
            this.T[n20] = this.T[n20] + n11;
            if (this.T[n3] < 0) {
                this.T[n3] = 0;
            } else if (this.T[n3] > 7999) {
                this.T[n3] = 7999;
            }
            n5 = ia_nb[this.T[n3]];
            this.b(n3, n5);
        }
        if (this.R > 0) {
            for (n3 = 0; n3 < this.I.H; ++n3) {
                if (this.O[n3]) continue;
                if (this.Q[n3] != 0) {
                    this.W += this.y[n3];
                    if (this.W < 0) {
                        this.W = 0;
                    } else if (this.W > 64) {
                        this.W = 64;
                    }
                }
                if (this.ia_q[n3] != 0 || this.J[n3] != 0) {
                    int n21 = n3;
                    this.ia_lb[n21] = this.ia_lb[n21] + this.ia_sb[n3];
                    if (this.ia_lb[n3] < 0) {
                        this.ia_lb[n3] = 0;
                    } else if (this.ia_lb[n3] > 64) {
                        this.ia_lb[n3] = 64;
                    }
                    int n22 = n3;
                    this.x[n22] = this.x[n22] + this.ia_eb[n3];
                    if (this.x[n3] < 0) {
                        this.x[n3] = 0;
                    } else if (this.x[n3] > 255) {
                        this.x[n3] = 255;
                    }
                }
                if (this.D[n3] == 1) {
                    this.B[n3] = (this.B[n3] + this.ia_gb[n3]) % 68;
                    int n23 = K[this.B[n3]] * this.Y[n3] >> 8;
                    n2 = this.T[n3] + n23;
                    this.b(n3, ia_nb[n2]);
                }
                if (this.E[n3] > 0) {
                    int n24 = n3;
                    this.T[n24] = this.T[n24] - this.E[n3] * 4;
                    if (this.T[n3] < 0) {
                        this.T[n3] = 0;
                    } else if (this.T[n3] > 7999) {
                        this.T[n3] = 7999;
                    }
                    n2 = ia_nb[this.T[n3]];
                    this.b(n3, n2);
                }
                if (this.ia_ob[n3] > 0) {
                    int n25 = n3;
                    this.T[n25] = this.T[n25] + this.ia_ob[n3] * 4;
                    if (this.T[n3] < 0) {
                        this.T[n3] = 0;
                    } else if (this.T[n3] > 7999) {
                        this.T[n3] = 7999;
                    }
                    n2 = ia_nb[this.T[n3]];
                    this.b(n3, n2);
                }
                if (this.ia_jb[n3] <= 0) continue;
                if (this.T[n3] < this.z[n3]) {
                    int n26 = n3;
                    this.T[n26] = this.T[n26] + this.ia_v[n3] * 4;
                    if (this.T[n3] > this.z[n3]) {
                        this.T[n3] = this.z[n3];
                    }
                }
                if (this.T[n3] > this.z[n3]) {
                    int n27 = n3;
                    this.T[n27] = this.T[n27] - this.ia_v[n3] * 4;
                    if (this.T[n3] < this.z[n3]) {
                        this.T[n3] = this.z[n3];
                    }
                }
                if (this.T[n3] < 0) {
                    this.T[n3] = 0;
                } else if (this.T[n3] > 7999) {
                    this.T[n3] = 7999;
                }
                n2 = ia_nb[this.T[n3]];
                this.b(n3, n2);
            }
        }
        for (n3 = 0; n3 < this.I.H; ++n3) {
            if (this.O[n3]) continue;
            n2 = this.ia_lb[n3];
            n = this.x[n3];
            this.ia_p[n3] = 0;
            if (this.ia_s[n3] >= 0) {
                int n28;
                int n29;
                int n30;
                int n31;
                int n32;
                int n33;
                n4 = this.ia_s[n3];
                if ((this.I.z[this.ia_s[n3]] & 1) == 1) {
                    this.ia_p[n3] = 1;
                    n33 = this.ia_kb[n3];
                    n32 = 0;
                    while (this.I.ui_q[n4][n32 + 1] < n33) {
                        ++n32;
                    }
                    n31 = this.I.ui_q[n4][n32];
                    n30 = this.I.ui_q[n4][n32 + 1];
                    n29 = this.I.F[n4][n32];
                    n28 = this.I.F[n4][n32 + 1];
                    if (n30 == n31) {
                        ++n30;
                    }
                    int n34 = ((n30 - n33) * n29 + (n33 - n31) * n28) / (n30 - n31);
                    int n35 = 32768 - this.G[n3];
                    if (n35 < 0) {
                        n35 = 0;
                    }
                    n2 = n2 * n34 * n35 >> 21;
                    if ((this.I.z[n4] & 2) == 2 && this.ia_hb[n3] == 1 && this.ia_kb[n3] == this.I.ui_q[n4][this.I.ui_r[n4]]) {
                        int n36 = n3;
                        this.ia_kb[n36] = this.ia_kb[n36] - 1;
                    }
                    if (this.ia_kb[n3] == this.I.ui_q[n4][this.I.ui_q[n4].length - 1]) {
                        int n37 = n3;
                        this.ia_kb[n37] = this.ia_kb[n37] - 1;
                    }
                    if (this.ia_hb[n3] == 0) {
                        int n38 = n3;
                        this.G[n38] = this.G[n38] + this.I.ui_v[n4];
                    }
                    int n39 = n3;
                    this.ia_kb[n39] = this.ia_kb[n39] + 1;
                    if ((this.I.z[n4] & 4) == 4 && this.ia_kb[n3] == this.I.ui_q[n4][this.I.K[n4]]) {
                        this.ia_kb[n3] = this.I.ui_q[n4][this.I.ui_j[n4]];
                    }
                }
                if ((this.I.O[this.ia_s[n3]] & 1) == 1) {
                    n33 = this.ia_bb[n3];
                    n32 = 0;
                    while (this.I.ui_c[n4][n32 + 1] < n33) {
                        ++n32;
                    }
                    n31 = this.I.ui_c[n4][n32];
                    n30 = this.I.ui_c[n4][n32 + 1];
                    n29 = this.I.ui_a[n4][n32];
                    n28 = this.I.ui_a[n4][n32 + 1];
                    if (n30 == n31) {
                        ++n30;
                    }
                    int n40 = ((n30 - n33) * n29 + (n33 - n31) * n28) / (n30 - n31);
                    n += (n40 - 32) * (128 - Math.abs(n - 128)) >> 5;
                    if ((this.I.O[n4] & 2) == 2 && this.ia_hb[n3] == 1 && this.ia_bb[n3] == this.I.ui_c[n4][this.I.J[n4]]) {
                        int n41 = n3;
                        this.ia_bb[n41] = this.ia_bb[n41] - 1;
                    }
                    if (this.ia_bb[n3] == this.I.ui_c[n4][this.I.ui_c[n4].length - 1]) {
                        int n42 = n3;
                        this.ia_bb[n42] = this.ia_bb[n42] - 1;
                    }
                    int n43 = n3;
                    this.ia_bb[n43] = this.ia_bb[n43] + 1;
                    if ((this.I.O[n4] & 4) == 4 && this.ia_bb[n3] == this.I.ui_c[n4][this.I.I[n4]]) {
                        this.ia_bb[n3] = this.I.ui_c[n4][this.I.C[n4]];
                    }
                }
            }
            this.a(n3, n2, n);
        }
        ++this.R;
        if (this.R >= this.C) {
            this.R = 0;
        }
        return bl;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        this.d(n);
        if (n4 > ia_nb[7999]) {
            if (n4 >= ia_nb[0]) {
                return;
            }
            if (n5 < 0) {
                n5 = 0;
            } else if (n5 > 64) {
                n5 = 64;
            }
            if (n6 < 0) {
                n6 = 0;
            } else if (n6 > 255) {
                n6 = 255;
            }
            ei ei2 = ei.b(this.I.ui_g[n2], n4 * 256 / en.en_o, n3 != 0 ? 0 : n5 * this.W * this.A >> 12, n6);
            ei2.f(this.I.ui_w[n2], this.I.ui_f[n2]);
            ei2.f(this.I.M[n2] != 0 ? -1 : 0);
            ei2.a(this.I.M[n2] == 2);
            if (n3 != 0) {
                ei2.e(n3);
                ei2.a(en.en_o >> 7, n5 * this.W * this.A >> 12, n6);
            }
            this.ia_fb[n] = ei2;
            if (this.rh_n != null) {
                mi mi2 = this.rh_n;
                synchronized (mi2) {
                    this.rh_n.a(ei2);
                }
                return;
            }
        }
    }

    @Override
    final int a(mi mi2) {
        if (this.c() && !this.ia_w) {
            return -1;
        }
        int n = en.en_o;
        int n2 = (n << 9) + (n << 7);
        return n2 / (this.L * this.U);
    }

    private final void b(int n, int n2) {
        if (this.ia_fb[n] != null) {
            this.ia_fb[n].d(n2 * 256 / en.en_o);
            return;
        }
    }

    final synchronized void c(int n) {
        this.U = n;
    }

    ia(ui ui2) {
        this.I = ui2;
        this.e();
    }

    static {
        int n;
        ia_nb = new int[8000];
        K = new int[68];
        for (n = 0; n < 8000; ++n) {
            ia.ia_nb[n] = (int)(8363.0 * Math.pow(2.0, (double)(4608 - n) / 768.0));
        }
        for (n = 0; n < 68; ++n) {
            ia.K[n] = (int)(-2048.0 * Math.sin((double)n * 0.0923998));
        }
    }
}
