/*
 * Decompiled with CFR 0.152.
 */
final class tb {
    static nm tb_b;
    static w tb_c;
    static String tb_a;

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        block10: {
            boolean bl2 = client.A;
            if (n6 <= n) {
                if (~n <= ~n2) {
                    if (n2 > n6) {
                        ib.a(n5, n2, n3, n, n4, (byte)117, n8, n6, hk.hk_l);
                    } else {
                        ib.a(n8, n6, n3, n, n4, (byte)117, n5, n2, hk.hk_l);
                    }
                } else {
                    ib.a(n5, n, n8, n2, n4, (byte)117, n3, n6, hk.hk_l);
                }
            } else if (n2 <= n6) {
                if (~n > ~n2) {
                    ib.a(n3, n2, n5, n6, n4, (byte)117, n8, n, hk.hk_l);
                } else {
                    ib.a(n8, n, n5, n6, n4, (byte)117, n3, n2, hk.hk_l);
                }
            } else {
                ib.a(n3, n6, n8, n2, n4, (byte)117, n5, n, hk.hk_l);
            }
            if (n7 > 8) break block10;
            tb_c = null;
        }
    }

    static final void a(int n, int n2, int n3) {
        block0: {
            af.af_f = n;
            kk.kk_e = n3;
            if (n2 == -25073) break block0;
            tb.a(-106, -58, 44, 19, 93, -115, 108, -54);
        }
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    static final void a(boolean bl2, ck ck2) {
        block0: {
            uh.a(-9074);
            hk.a(ck2.D, ck2.K, ck2.C);
            if (bl2) break block0;
            tb.a(60, 93, -89);
        }
    }

    public static void a(int n) {
        block0: {
            tb_b = null;
            tb_c = null;
            tb_a = null;
            if (n == 20908) break block0;
            tb_c = null;
        }
    }

    static {
        tb_a = "NEW THEME<br>UNLOCKED!";
    }
}
