/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ColorModel;
import java.awt.image.DirectColorModel;
import java.awt.image.ImageConsumer;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

final class wf
extends eh
implements ImageProducer,
ImageObserver {
    private ColorModel wf_t;
    static um wf_p = new um();
    static um wf_u;
    private ImageConsumer wf_r;
    static String wf_m;
    static mm wf_q;
    static int[] wf_o;
    static String wf_n;
    static ei[] wf_l;
    static String wf_k;
    static Font wf_s;

    static final void a(int n, int n2, int n3, boolean bl) {
        block0: {
            wm.wm_l = n2;
            gn.gn_a = n;
            wa.wa_c = n3;
            if (bl) break block0;
            wf.f(-31);
        }
    }

    @Override
    public final synchronized void addConsumer(ImageConsumer imageConsumer) {
        this.wf_r = imageConsumer;
        imageConsumer.setDimensions(this.eh_g, this.eh_i);
        imageConsumer.setProperties(null);
        imageConsumer.setColorModel(this.wf_t);
        imageConsumer.setHints(14);
    }

    private final synchronized void e(int n) {
        if (n >= -113) {
            this.e(-60);
        }
        if (null == this.wf_r) {
            return;
        }
        this.wf_r.setPixels(0, 0, this.eh_g, this.eh_i, this.wf_t, this.eh_f, 0, this.eh_g);
        this.wf_r.imageComplete(2);
    }

    static final w c(int n) {
        int n2 = 12 % ((-44 - n) / 51);
        return k.k_b.Sb;
    }

    @Override
    final void a(int n, byte by, int n2, Component component) {
        this.eh_g = n;
        this.eh_f = new int[1 + n * n2];
        if (by != 83) {
            wf_n = null;
        }
        this.eh_i = n2;
        this.wf_t = new DirectColorModel(32, 0xFF0000, 65280, 255);
        this.eh_c = component.createImage(this);
        this.e(-117);
        component.prepareImage(this.eh_c, this);
        this.e(-123);
        component.prepareImage(this.eh_c, this);
        this.e(by ^ 0xFFFFFFD2);
        component.prepareImage(this.eh_c, this);
        this.a((byte)-98);
    }

    @Override
    public final void requestTopDownLeftRightResend(ImageConsumer imageConsumer) {
    }

    @Override
    public final synchronized boolean isConsumer(ImageConsumer imageConsumer) {
        return this.wf_r == imageConsumer;
    }

    @Override
    public final void startProduction(ImageConsumer imageConsumer) {
        this.addConsumer(imageConsumer);
    }

    public static void f(int n) {
        wf_s = null;
        wf_o = null;
        wf_p = null;
        int n2 = 4 / ((n - 24) / 42);
        wf_k = null;
        wf_m = null;
        wf_u = null;
        wf_l = null;
        wf_n = null;
        wf_q = null;
    }

    @Override
    public final synchronized void removeConsumer(ImageConsumer imageConsumer) {
        block0: {
            if (this.wf_r != imageConsumer) break block0;
            this.wf_r = null;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final void d(int n2) {
        block4: {
            if (f.f_r != null) {
                n n3 = f.f_r;
                synchronized (n3) {
                    f.f_r = null;
                }
            }
            if (n2 >= 88) break block4;
            wf_s = null;
        }
    }

    static final void a(int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, boolean bl, int n14, int n15, int n16) {
        block10: {
            boolean bl2 = client.A;
            if (~n3 >= ~n13) {
                if (~n13 <= ~n10) {
                    if (~n10 >= ~n3) {
                        oj.a(n7, n9, n12, n3, n6, n4, n16, (byte)-39, n11, n14, n15, n10, hk.hk_l, n2, n13, n5, n8);
                    } else {
                        oj.a(n7, n8, n16, n10, n15, n4, n12, (byte)-95, n5, n14, n6, n3, hk.hk_l, n2, n13, n11, n9);
                    }
                } else {
                    oj.a(n5, n2, n16, n13, n4, n15, n14, (byte)-52, n7, n12, n6, n3, hk.hk_l, n8, n10, n11, n9);
                }
            } else if (~n10 >= ~n3) {
                if (n10 <= n13) {
                    oj.a(n11, n2, n12, n13, n4, n6, n14, (byte)-120, n7, n16, n15, n10, hk.hk_l, n9, n3, n5, n8);
                } else {
                    oj.a(n11, n8, n14, n10, n15, n6, n12, (byte)-101, n5, n16, n4, n13, hk.hk_l, n9, n3, n7, n2);
                }
            } else {
                oj.a(n5, n9, n14, n3, n6, n15, n16, (byte)-105, n11, n12, n4, n13, hk.hk_l, n8, n10, n7, n2);
            }
            if (bl) break block10;
            wf_p = null;
        }
    }

    static final boolean a(boolean bl2) {
        if (la.la_d) {
            return true;
        }
        if (!ii.ii_t.a("benefits", (byte)-75)) {
            return false;
        }
        if (bl2) {
            return true;
        }
        ck ck2 = id.a(ii.ii_t, "borders", "benefits", 8192);
        ck ck3 = id.a(ii.ii_t, "price", "benefits", 8192);
        ck ck4 = id.a(ii.ii_t, "logo", "benefits", 8192);
        ck[] ckArray = bj.a(112, ii.ii_t, "benefits", "screenshots");
        ik.a(200, ck2, ph.Gb);
        id.a(103, 92, 2, -2400, 35, 13, 8192, ck3, 15);
        ib.a((byte)-108, ckArray);
        wj.a(ck4, 369179521);
        la.la_d = true;
        return true;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final void b(int n2) {
        boolean bl2 = client.A;
        n n3 = f.f_r;
        synchronized (n3) {
            if (n2 != 19012) {
                wf_p = null;
            }
            sf.B = ea.ea_n;
            ++om.om_d;
            if (wi.wi_b >= 0) {
                while (~wi.wi_b != ~rc.rc_a) {
                    int n4 = la.la_h[rc.rc_a];
                    rc.rc_a = 1 + rc.rc_a & 0x7F;
                    if (0 <= n4) {
                        bj.bj_d[n4] = true;
                        continue;
                    }
                    bj.bj_d[n4 ^ 0xFFFFFFFF] = false;
                }
            } else {
                int n5;
                int n6 = n5 = 0;
                while (~n5 > -113) {
                    bj.bj_d[n5] = false;
                    ++n5;
                }
                wi.wi_b = rc.rc_a;
            }
            ea.ea_n = jh.jh_e;
        }
    }

    wf() {
    }

    @Override
    final void a(byte by, Graphics graphics, int n2, int n3) {
        block0: {
            this.e(-127);
            graphics.drawImage(this.eh_c, n2, n3, this);
            if (by >= 38) break block0;
            ImageConsumer imageConsumer = null;
            this.requestTopDownLeftRightResend(imageConsumer);
        }
    }

    @Override
    public final boolean imageUpdate(Image image, int n2, int n3, int n4, int n5, int n6) {
        return true;
    }

    static {
        wf_m = "Loading...";
        wf_u = new um();
        wf_l = new ei[8];
        wf_k = "Account created successfully!";
    }
}
