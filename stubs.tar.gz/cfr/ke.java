/*
 * Decompiled with CFR 0.152.
 */
final class ke {
    boolean ke_j;
    static int ke_d;
    int ke_o;
    private int ke_k = -1;
    static String ke_n;
    boolean ke_p;
    sk ke_b;
    int ke_c;
    int ke_i;
    boolean ke_g;
    private int ke_t;
    private cl ke_a;
    int y;
    ec[] ke_f;
    boolean ke_r;
    boolean ke_s;
    private int ke_u;
    int ke_l;
    int ke_m;
    int ke_q;
    int[] ke_v;
    static int[] ke_h;
    private kc ke_e;
    private int x;
    int ke_w;
    int z;

    static final void e(byte by) {
        uf uf2;
        uf uf3;
        int n;
        boolean bl = client.A;
        if (by != 48) {
            ke_d = 90;
        }
        if (~(n = (uf3 = (uf2 = de.V)).d((byte)-106)) != -1) {
            if (n != 1) {
                qb.a(null, 16408, "HS1: " + qk.d((byte)30));
                si.a(122);
            } else {
                kn kn2;
                int n2 = uf3.e(3);
                long l = uf3.f((byte)-108);
                kn kn3 = kn2 = (kn)pb.pb_c.c((byte)114);
                while (kn2 != null && ~kn2.kn_u != ~n2) {
                    kn3 = (kn)pb.pb_c.d(true);
                }
                if (null == kn3) {
                    si.a(103);
                    return;
                }
                kn3.kn_o = l;
                kn3.b((byte)101);
            }
        } else {
            kc kc2;
            int n3 = uf3.e(by + -45);
            kc kc3 = kc2 = (kc)dg.dg_e.c((byte)-104);
            while (null != kc2 && ~kc2.kc_n != ~n3) {
                kc3 = (kc)dg.dg_e.d(true);
            }
            if (null == kc3) {
                si.a(by ^ 0x79);
                return;
            }
            int n4 = uf3.d((byte)-19);
            if (~n4 != -1) {
                int n5 = kc3.kc_o;
                rc.rc_c[0].sg_c = false;
                rc.rc_c[0].sg_i = oa.oa_f;
                int n6 = kc3.kc_v;
                rc.rc_c[0].sg_f = null;
                for (int i = 1; i < n4; ++i) {
                    rc.rc_c[i].sg_i = uf2.c((byte)-38);
                    rc.rc_c[i].sg_c = false;
                    rc.rc_c[i].sg_f = ~uf3.d((byte)-48) == -2 ? uf3.c((byte)-38) : null;
                }
                kc3.kc_r = new String[3][n5];
                String[][] stringArray = kc3.kc_r;
                String[][] stringArray2 = new String[3][n5];
                kc3.kc_t = new long[3][n5];
                long[][] lArray = kc3.kc_t;
                kc3.kc_u = new int[3][n5 * n6];
                int[][] nArray = kc3.kc_u;
                int n7 = 0;
                int n8 = 0;
                int n9 = 0;
                int n10 = 0;
                int n11 = 0;
                int n12 = 0;
                int n13 = uf3.d((byte)-68);
                if (0 < n13) {
                    for (int i = 0; i < n13; ++i) {
                        int n14;
                        int n15 = uf2.d((byte)-21);
                        String string = rc.rc_c[n15].sg_i;
                        long l = uf3.f((byte)-108);
                        int n16 = uf3.wl_n;
                        if (n5 > i) {
                            stringArray[0][n7] = string;
                            stringArray2[0][n7] = rc.rc_c[n15].sg_f;
                            lArray[0][n7] = l;
                            for (n14 = 0; n6 > n14; ++n14) {
                                nArray[0][n10++] = uf2.i(qm.b(by, 7601));
                            }
                            ++n7;
                        }
                        if (null != string && k.a(string, true)) {
                            stringArray[1][n8] = oa.oa_f;
                            stringArray2[1][n8] = null;
                            lArray[1][n8] = l;
                            ++n8;
                            uf3.wl_n = n16;
                            n14 = 0;
                            while (~n14 > ~n6) {
                                nArray[1][n11++] = uf2.i(7553);
                                ++n14;
                            }
                        }
                        if (n9 >= n5 || rc.rc_c[n15].sg_c) continue;
                        rc.rc_c[n15].sg_c = true;
                        stringArray[2][n9] = string;
                        stringArray2[2][n9] = rc.rc_c[n15].sg_f;
                        lArray[2][n9] = l;
                        ++n9;
                        uf3.wl_n = n16;
                        n14 = 0;
                        while (~n6 < ~n14) {
                            nArray[2][n12++] = uf2.i(7553);
                            ++n14;
                        }
                    }
                }
            }
            kc3.kc_p = true;
            kc3.b((byte)107);
        }
    }

    final void g(int n) {
        boolean bl = client.A;
        if (20 == this.ke_o) {
            h.a(-109);
        }
        h.a(this, (byte)95);
        while (ab.c((byte)-128)) {
            this.ke_b.d(0);
            if (-14 == ~wh.wh_c) {
                nm.f(115);
                nk.nk_k = false;
                kf.G.c(n + -2825, false);
                return;
            }
            if ((96 == wh.wh_c || wh.wh_c == 98) && 0 < this.ke_t) {
                this.m(n ^ 0xFFFFDFC1);
                this.ke_b.a(1, (byte)-90);
                this.ke_b.sk_o = false;
            }
            if ((-98 == ~wh.wh_c || wh.wh_c == 99) && 3 > this.ke_t) {
                this.n(87);
                this.ke_b.a(1, (byte)-66);
                this.ke_b.sk_o = false;
            }
            if (!this.a(false, (byte)-33)) continue;
            return;
        }
        this.ke_b.a(this.a(n ^ 0xA98, bh.bh_g, pm.pm_f), -20563, this.a(400, he.S, nf.nf_h));
        if (n != 2824) {
            this.ke_m = 44;
        }
        this.a(true, (byte)-33);
    }

    final void f(byte by) {
        boolean bl2 = client.A;
        h.a(this, (byte)95);
        int n = 74 / ((71 - by) / 39);
        while (ab.c((byte)-119)) {
            if (~wh.wh_c == -14) {
                nm.f(-26);
                mg.Zb = false;
                qi.a(false, (byte)-108);
                return;
            }
            if (!ph.n(-30146)) {
                this.ke_b.d(0);
                if (wh.wh_c == 96) {
                    fc.fc_e = (3 + fc.fc_e + -1) % 3;
                    this.ke_b.a(fc.fc_e, (byte)-79);
                    nm.f(124);
                    this.ke_b.sk_o = false;
                }
                if (wh.wh_c == 97) {
                    fc.fc_e = (1 + fc.fc_e) % 3;
                    this.ke_b.a(fc.fc_e, (byte)-81);
                    nm.f(117);
                    this.ke_b.sk_o = false;
                }
                if (~wh.wh_c == -99) {
                    if (3 == this.ke_b.sk_h) {
                        this.ke_b.a(fc.fc_e, (byte)-103);
                    } else {
                        this.ke_b.a(3, (byte)-125);
                    }
                }
                if (99 == wh.wh_c) {
                    if (~this.ke_b.sk_h <= -1 && -4 < ~this.ke_b.sk_h) {
                        this.ke_b.a(3, (byte)-95);
                    } else {
                        this.ke_b.a(fc.fc_e, (byte)-110);
                    }
                }
            } else {
                this.ke_b.a(-38);
            }
            if (!this.b(false, 1)) continue;
            return;
        }
        this.ke_b.a(this.a(400, bh.bh_g, pm.pm_f), -20563, this.a(400, he.S, nf.nf_h));
        this.b(true, 1);
    }

    private final int a(int n, int n2, int n3) {
        boolean bl2 = client.A;
        int n4 = 640 - (640 * this.ke_o * this.ke_o / n + (this.ke_u >> 1482415394));
        n2 -= n4;
        int n5 = 0;
        while (~n5 > ~this.ke_b.sk_l) {
            ec ec2 = this.ke_f[n5];
            if (~ec2.ec_l >= ~n2 && ~(ec2.ec_n + ec2.ec_l) < ~n2 && ec2.ec_m <= n3 && ~n3 > ~(ec2.ec_m - -ec2.ec_r)) {
                return n5;
            }
            ++n5;
        }
        return -1;
    }

    private final int b(boolean bl2, byte by) {
        boolean bl3 = client.A;
        int n = -(640 * this.ke_o * this.ke_o / 400) + (640 + -(this.ke_u >> -1950206750));
        int n2 = -1;
        int[] nArray = rc.a(cm.cm_b, (byte)47, this.ke_v);
        int[] nArray2 = rc.a(cm.cm_a, (byte)47, nArray);
        int n3 = -((jh.a(nArray2, 120) - 1) * 18) + 304;
        if (by != -51) {
            return 9;
        }
        int n4 = 80;
        if (~this.ke_i != -1) {
            int[] nArray3 = eg.a(cm.cm_a, this.ke_v, (byte)106);
            n3 = 304 - (jh.a(nArray3, by + 146) - 1) * 18;
            if (!tf.a((byte)103, nArray3)) {
                n4 -= 20;
            }
            if (af.a(by + 51, nArray3, this.ke_v)) {
                n4 += 20;
            }
        }
        n3 += n;
        for (int i = 0; 31 > i; ++i) {
            if (i == 15) {
                n3 = 34;
                n4 += 40;
                if (this.ke_i != 0) {
                    int[] nArray4 = eg.a(this.ke_v, cm.cm_h, (byte)105);
                    n3 = -(18 * jh.a(nArray4, 96)) + 18 + 304;
                }
                n3 += n;
            }
            if (0 != this.ke_i && fb.a(i, 0x9933FF, this.ke_v) || rb.a(-23, i, nArray)) continue;
            if (!bl2) {
                if (i == this.ke_k) {
                    if (!rb.a(-112, i, this.ke_v)) {
                        vg.vg_h.b(-4 + n3, n4 - 4, 40, 40);
                    } else {
                        uf.y[i].a(n3 - 4, -4 + n4, 40, 40);
                    }
                } else if (bh.bh_g >= n3 && ~(32 + n3) < ~bh.bh_g && ~n4 >= ~pm.pm_f && pm.pm_f < 32 + n4) {
                    if (rb.a(-113, i, this.ke_v)) {
                        uf.y[i].a(n3 - 2, -2 + n4, 36, 36);
                    } else {
                        vg.vg_h.b(-2 + n3, n4 - 2, 36, 36);
                    }
                    n2 = i;
                } else if (rb.a(by + 23, i, this.ke_v)) {
                    tl.tl_w[i].c(n3, n4);
                } else {
                    vg.vg_h.b(n3, n4, 32, 32);
                }
            } else if (~n3 >= ~he.S && he.S < 32 + n3 && nf.nf_h >= n4 && ~nf.nf_h > ~(32 + n4)) {
                this.ke_k = i == this.ke_k ? -1 : i;
            }
            n3 += 36;
        }
        if (this.ke_k >= 0) {
            n2 = this.ke_k;
        }
        return n2;
    }

    final void j(byte by) {
        boolean bl2 = client.A;
        int n = Integer.MAX_VALUE;
        int n2 = Integer.MAX_VALUE;
        int n3 = Integer.MIN_VALUE;
        int n4 = Integer.MIN_VALUE;
        int n5 = -99 % ((-41 - by) / 33);
        int n6 = 0;
        while (~this.ke_b.sk_l < ~n6) {
            if (n > this.ke_f[n6].ec_l) {
                n = this.ke_f[n6].ec_l;
            }
            if (this.ke_f[n6].ec_n + this.ke_f[n6].ec_l > n3) {
                n3 = this.ke_f[n6].ec_l - -this.ke_f[n6].ec_n;
            }
            if (~n4 > ~(this.ke_f[n6].ec_r + this.ke_f[n6].ec_m)) {
                n4 = this.ke_f[n6].ec_m - -this.ke_f[n6].ec_r;
            }
            if (~this.ke_f[n6].ec_m > ~n2) {
                n2 = this.ke_f[n6].ec_m;
            }
            ++n6;
        }
        this.ke_w = -30 + n;
        this.z = -20 + n2;
        this.y = n3 - -30 + -this.ke_w;
        this.ke_q = n4 - (-20 - -this.z);
    }

    final void c(int n) {
        block0: {
            this.e(16687906);
            this.b(58);
            if (n == 2) break block0;
            this.k(-125);
        }
    }

    private final boolean a(boolean bl2, byte by) {
        if (by != -33) {
            this.ke_o = -121;
        }
        this.h(by + 132);
        int n = -1;
        if (0 <= this.ke_b.sk_h) {
            n = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (-27 == ~n && ~this.ke_t == -4) {
            n = -1;
        }
        if (-26 == ~n && -1 == ~this.ke_t) {
            n = -1;
        }
        if ((n == 13 || !bl2) && this.ke_b.b((byte)114)) {
            nk.nk_k = false;
            kf.G.c(-1, bl2);
            nm.f(123);
            return true;
        }
        if (25 == n && this.ke_b.b((byte)114)) {
            this.m(-11063);
        }
        if (n == 26) {
            if (!this.ke_b.b((byte)114)) {
                return false;
            }
            this.n(-77);
        }
        return false;
    }

    static final void o(int n) {
        pk.pk_r = n;
        jg.jg_i = true;
    }

    final void a(ec ec2, int n) {
        if (n <= 98) {
            this.b(98);
        }
        this.ke_f[this.ke_b.sk_l++] = ec2;
    }

    static final void a(int n, int n2, int n3, int n4, byte by) {
        int n5;
        boolean bl2 = client.A;
        hk.a(n, n2, 1 + n3, 0x989898);
        hk.a(n, n4 + n2, 1 + n3, 0xB8B8B8);
        int n6 = 1;
        if (n2 - -n6 < hk.hk_h) {
            n6 = -n2 + hk.hk_h;
        }
        if (n2 + (n5 = n4) > hk.hk_b) {
            n5 = -n2 + hk.hk_b;
        }
        if (by < 98) {
            ke_n = null;
        }
        int n7 = n6;
        while (~n5 < ~n7) {
            int n8;
            int n9 = 152 - -(n7 * 48 / n4);
            hk.hk_l[(n2 - -n7) * hk.hk_j + n] = n8 = n9 << 943748912 | n9 << 392551496 | n9;
            hk.hk_l[n + (n7 + n2) * hk.hk_j + n3] = n8;
            ++n7;
        }
    }

    final void b(int n, int n2) {
        int n3;
        boolean bl2 = client.A;
        int n4 = 0;
        while (~n4 > ~this.ke_b.sk_l) {
            this.ke_f[n4].ec_m += n;
            ++n4;
        }
        this.ke_b.a(this.a(400, bh.bh_g, pm.pm_f), -20563, this.a(400, he.S, nf.nf_h));
        n4 = n3 = 0;
        while (this.ke_b.sk_l > n3) {
            this.ke_f[n3].ec_m -= n;
            ++n3;
        }
        if (n2 <= 120) {
            this.ke_i = 13;
        }
        this.p(-1);
    }

    private final void b(int n) {
        int n2 = -(this.ke_u >> 952971650) + (640 + -(640 * (this.ke_o * this.ke_o) / 400));
        if (n < 49) {
            this.ke_r = false;
        }
        ck ck2 = ng.ng_b;
        ck2.c(320 - ck2.K / 2, -(n2 >> -492469630) + (50 + -(ck2.C / 2)));
        hk.a(n2 + 4 + this.ke_w, this.z + 4, -8 + this.y, -8 + this.ke_q, 0, 150);
        vk.a(this.ke_q, (byte)50, a.a_n, this.y, this.z, n2 + this.ke_w);
        kn.a(w.w_kb, (byte)-39, 362, ve.c(this.ke_t, 26135), 0xFFFFFF, 560 + n2);
        wk.a(72, this.ke_t, n2);
    }

    final void h(byte by) {
        block9: {
            boolean bl2 = client.A;
            this.a(~this.ke_b.sk_l <= -4, 15764);
            int n = 640 + (-(640 * (this.ke_o * this.ke_o) / 400) + -(this.ke_u >> -1169742078));
            ck ck2 = client.C[this.ke_i];
            if (by < 23) {
                this.z = -77;
            }
            ck2.c(-(ck2.K / 2) + 320, -(ck2.C / 2) + 40 - (n >> 740753666));
            int n2 = this.b(false, (byte)-51);
            if (~n2 <= -1) {
                boolean bl3;
                ed.a(0xFFFFFF, 320 - -n, qk.qk_s[n2], 200, (byte)75, w.w_kb);
                boolean bl4 = rb.a(-35, n2, this.ke_v);
                boolean bl5 = bl3 = !bl4 && rb.a(-28, n2, cm.cm_g);
                if (bl4) {
                    uf.y[n2].c(n + 256, 210);
                } else {
                    vg.vg_h.c(256 + n, 210);
                }
                String string = bl3 ? sb.sb_t : jh.jh_c[n2];
                int n3 = se.S.a(string, 171);
                ga.a(171, 0, -se.S.R + 274 + -(n3 * 8), string, 16, 1000, 16769088, se.S, (byte)-124, 0, n + 80);
                fl.a(8 * n3 + 282, 256, 0xFFFFFF, !bl4 ? j.j_a : ne.ne_b, 80 + n, w.w_kb);
                kn.a(se.S, (byte)-39, 271, jd.Xb, 0xFFFFFF, n + 500);
                kn.a(se.S, (byte)-39, 289, me.B, 0xFFFFFF, 500 - -n);
                if (bl3) {
                    fl.a(271, 256, 16769088, "???", 500 - -n, se.S);
                    fl.a(289, 256, 16769088, "???", n + 500, se.S);
                } else {
                    fl.a(271, 256, 16769088, Integer.toString(on.on_g[n2]), n + 500, se.S);
                    for (int i = 0; vb.X[n2] > i; ++i) {
                        rn.rn_c.c(i * 5 + (n + 500), 274);
                    }
                }
            } else {
                ed.a(0xFFFFFF, n + 320, v.v_e, 200, (byte)75, w.w_kb);
            }
            if (ph.n(-30146)) {
                ed.a(0xFFFFFF, n + 320, lf.lf_d, 360, (byte)75, se.S);
            }
            if (!rb.a(-80, 5, this.ke_v)) break block9;
            ed.a(0xFFFFFF, 320 - -n, ph.Cb, 360, (byte)75, se.S);
        }
    }

    private final boolean a(int n, boolean bl2) {
        this.h(118);
        if (n != -14845) {
            this.b(true, 36);
        }
        int n2 = -1;
        if (~this.ke_b.sk_h <= -1) {
            n2 = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (-21 == ~n2 && this.ke_b.b((byte)114)) {
            og.a(false, 6, true);
            nm.f(124);
            return true;
        }
        if ((n2 == 13 || !bl2) && this.ke_b.b((byte)114)) {
            ve.Hc = false;
            qi.a(bl2, (byte)-111);
            nm.f(n ^ 0xFFFFC60C);
            return true;
        }
        if (bl2 && -1 != ~ig.Yb && this.ke_b.sk_h != -1) {
            cj.cj_c = this.ke_b.sk_h;
            this.ke_b.a(cj.cj_c, (byte)-109);
            nm.f(125);
            return true;
        }
        return false;
    }

    final void b(byte by) {
        block14: {
            int n;
            block13: {
                int n2;
                boolean bl2 = client.A;
                n = -(this.ke_u >> -977993822) + (-(640 * this.ke_o * this.ke_o / 400) + 640);
                this.a(false, 15764);
                ck ck2 = ij.ij_d;
                ck2.c(320 + -(ck2.K / 2), 45 - ck2.C / 2 + -(n >> 8543042));
                if (null == this.ke_e && !ph.n(-30146)) {
                    this.ke_e = am.a(3, false, 1, 0, 10);
                }
                int n3 = bf.a((byte)107, gh.gh_e, fc.fc_e, this.ke_e);
                fl.a(105, 256, 0xFFFFFF, vm.x, n + 125, w.w_kb);
                fl.a(105, 256, 0xFFFFFF, a.x, 333 + n, w.w_kb);
                kn.a(w.w_kb, (byte)-39, 105, sl.sl_b, 0xFFFFFF, 545 - -n);
                if (by > -42) {
                    return;
                }
                int n4 = 0;
                while (~n4 > -11) {
                    n2 = 0xFFFFFF;
                    kn.a(w.w_kb, (byte)-39, 130 + 20 * n4, 1 + n4 + ".", n2, n + 115);
                    ++n4;
                }
                String string = le.le_r;
                n2 = 1;
                if (null != this.ke_e) {
                    if (!this.ke_e.kc_p) {
                        string = wm.wm_k;
                    } else {
                        int n5;
                        if (null == this.ke_e.kc_r) {
                            string = dn.dn_s;
                        } else {
                            String[] stringArray = this.ke_e.kc_r[fc.fc_e];
                            int[] nArray = this.ke_e.kc_u[fc.fc_e];
                            n5 = 0;
                            while (~n5 > -11) {
                                if (stringArray[n5] != null) {
                                    string = null;
                                    int n6 = 16769088;
                                    int n7 = nArray[n5];
                                    int n8 = n7 % 8;
                                    int n9 = n7 / 8;
                                    if (~n3 == ~n5) {
                                        n6 = 0xFFFFFF;
                                    }
                                    fl.a(n5 * 20 + 130, 256, n6, stringArray[n5], 125 - -n, se.S);
                                    kn.a(se.S, (byte)-39, 130 + n5 * 20, cm.a((byte)106, kk.kk_q, new String[]{Integer.toString(n8 + 1)}), n6, 350 - -n);
                                    fl.a(130 - -(n5 * 20), 256, n6, md.U[n8], n + 350, se.S);
                                    kn.a(se.S, (byte)-39, 20 * n5 + 130, Integer.toString(n9), n6, 545 + n);
                                }
                                ++n5;
                            }
                        }
                        if (0 > n3 && gh.gh_e != null && gh.gh_e.x == 0) {
                            fl.a(330, 256, 0xFFFFFF, oa.oa_f, 125 + n, se.S);
                            int n10 = gh.gh_e.kn_s[0];
                            int n11 = n10 % 8;
                            n5 = n10 / 8;
                            kn.a(se.S, (byte)-39, 330, cm.a((byte)81, kk.kk_q, new String[]{Integer.toString(1 + n11)}), 0xFFFFFF, n + 350);
                            fl.a(330, 256, 0xFFFFFF, md.U[n11], 350 + n, se.S);
                            kn.a(se.S, (byte)-39, 330, Integer.toString(n5), 0xFFFFFF, n + 545);
                            n2 = 0;
                        }
                    }
                }
                if (null != string) {
                    ed.a(0xFFFFFF, 320 - -n, string, 220, (byte)75, w.w_kb);
                }
                if (ph.n(-30146)) break block13;
                if (n2 == 0) break block14;
                ed.a(0xFFFFFF, n + 320, af.af_e, 330, (byte)75, se.S);
                break block14;
            }
            ed.a(0xFFFFFF, 320 - -n, lf.lf_d, 330, (byte)75, se.S);
        }
    }

    final void f(int n) {
        this.a(true, n ^ 0xFFFFA4BF);
        int n2 = -(this.ke_u >> -2029436830) + 640 + -(640 * this.ke_o * this.ke_o / 400);
        ck ck2 = l.l_j;
        ck2.c(320 - ck2.K / 2, -(n2 >> -1455322462) + (this.z / 2 - (-2 - -(ck2.C / 2))));
        if (n != -26325) {
            this.ke_q = -96;
        }
        int n3 = !this.ke_g ? 0 : 23;
        hk.a(n2 + (4 + this.ke_w), -8 + (this.ke_q + this.z), -8 + this.y, n3 + 142, 0, 150);
        vk.a(n3 + 150, (byte)50, a.a_n, this.y, -13 + this.z + this.ke_q, n2 + this.ke_w);
        fc.a(this.ke_q + this.z, (byte)5, this.ke_g, n2 + 185);
        nf.a(this.ke_l, n2 + 333, (byte)74, this.ke_q + this.z, this.ke_m);
    }

    final void k(int n) {
        boolean bl2 = client.A;
        h.a(this, (byte)95);
        if (n != 128) {
            this.ke_v = null;
        }
        if (mn.mn_c) {
            return;
        }
        while (ab.c((byte)26)) {
            if (13 == wh.wh_c && this.ke_p) {
                nm.f(27);
                cd.a(true);
                return;
            }
            this.ke_b.a(-127);
            if (!this.d(-109, false)) continue;
            return;
        }
        this.ke_b.a(this.a(400, bh.bh_g, pm.pm_f), -20563, this.a(n + 272, he.S, nf.nf_h));
        this.d(-108, true);
    }

    final void d(byte by) {
        block13: {
            boolean bl2 = client.A;
            int n = -(this.ke_u >> 685015522) + (-(this.ke_o * (this.ke_o * 640) / 400) + 640);
            this.a(false, 15764);
            ck ck2 = ad.ad_g;
            ck2.c(-(ck2.K / 2) + 320, -(ck2.C / 2) + (45 + -(n >> 886031138)));
            if (this.ke_a == null && !ph.n(-30146)) {
                this.ke_a = ai.a(7, 10, (byte)-111, 0);
            }
            int n2 = -4 == ~kd.kd_p ? 305 : 310;
            int n3 = -4 != ~kd.kd_p ? 380 : 372;
            int n4 = ~kd.kd_p != -4 ? 435 : 427;
            int n5 = -4 != ~kd.kd_p ? 490 : 488;
            fl.a(105, 256, 0xFFFFFF, vm.x, 125 + n, w.w_kb);
            kn.a(w.w_kb, (byte)-39, 105, ga.ga_a, 0xFFFFFF, n2 - -n);
            if (by != 45) {
                this.ke_w = -41;
            }
            kn.a(w.w_kb, (byte)-39, 105, om.om_c, 0xFFFFFF, n + n3);
            kn.a(w.w_kb, (byte)-39, 105, hd.hd_o, 0xFFFFFF, n4 - -n);
            kn.a(w.w_kb, (byte)-39, 105, vd.vd_r, 0xFFFFFF, n + n5);
            kn.a(w.w_kb, (byte)-39, 105, sh.sh_h, 0xFFFFFF, 545 - -n);
            int n6 = -1;
            String string = hf.hf_g;
            if (this.ke_a != null) {
                if (!this.ke_a.A) {
                    string = wm.wm_k;
                } else if (this.ke_a.x != null) {
                    String[] stringArray = this.ke_a.x[cj.cj_c];
                    int[] nArray = this.ke_a.cl_u[cj.cj_c];
                    int n7 = 0;
                    while (-11 < ~n7) {
                        if (stringArray[n7] != null) {
                            string = null;
                            int n8 = 16769088;
                            if (k.a(stringArray[n7], true)) {
                                n6 = n7;
                                n8 = 0xFFFFFF;
                            }
                            this.a(se.S, n8, nArray[4 * n7 + 2], nArray[4 * n7 - -3], by + -5373, 130 - -(20 * n7), nArray[1 + 4 * n7], stringArray[n7], nArray[4 * n7], n);
                        }
                        ++n7;
                    }
                    if (n6 < 0) {
                        n7 = 0xFFFFFF;
                        this.a(se.S, n7, this.ke_a.cl_w, this.ke_a.cl_p, -5328, 330, this.ke_a.cl_o, oa.oa_f, this.ke_a.cl_t, n);
                    }
                } else {
                    string = dn.dn_s;
                }
            }
            for (int i = 0; 10 > i; ++i) {
                int n9 = 0xFFFFFF;
                kn.a(w.w_kb, (byte)-39, 130 + i * 20, i + 1 + ".", n9, n + 115);
            }
            if (null != string) {
                ed.a(0xFFFFFF, 320 + n, string, 220, (byte)75, w.w_kb);
            }
            if (!ph.n(-30146)) break block13;
            ed.a(0xFFFFFF, n + 320, lf.lf_d, 330, (byte)75, se.S);
        }
    }

    private final void m(int n) {
        block1: {
            if (n != -11063) {
                this.a(false, 73);
            }
            if (0 >= this.ke_t) break block1;
            --this.ke_t;
            nm.f(-65);
            ac.f((byte)-76);
        }
    }

    private final boolean b(int n, boolean bl2) {
        this.h(94);
        int n2 = n;
        if (-1 >= ~this.ke_b.sk_h) {
            n2 = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (20 == n2 && this.ke_b.b((byte)114)) {
            og.a(false, 4, true);
            nm.f(n + 37);
            return true;
        }
        if (n2 == 21 && this.ke_b.b((byte)114)) {
            s.b(true);
            ba.ba_c = false;
            qi.a(bl2, (byte)-104);
            nm.f(n ^ 0xFFFFFF82);
            return true;
        }
        return false;
    }

    final void a(boolean bl2) {
        if (bl2) {
            ke.e((byte)-98);
        }
        this.a(true, 15764);
        int n = -(this.ke_o * this.ke_o * 640 / 400) + (640 - (this.ke_u >> -2066854142));
        wk.wk_l.c(320 + -(wk.wk_l.I / 2), -(n >> -2060126462) + 20);
    }

    final void a(int n, int n2, boolean bl2, int n3, int n4) {
        int n5;
        int n6;
        boolean bl3 = client.A;
        int n7 = -41 % ((-31 - n3) / 62);
        int n8 = 0;
        for (n6 = 0; this.ke_b.sk_l > n6; ++n6) {
            ec ec2 = this.ke_f[n6];
            int n9 = ec2.ec_n;
            if (6 == ec2.ec_d || 7 == ec2.ec_d) {
                n9 += 133;
            }
            ec2.ec_m = n6 * n4 + n;
            if (n8 < n9) {
                n8 = n9;
            }
            if (!bl2) continue;
            if (-1 > ~n6) {
                ec2.ec_r -= 3;
                ec2.ec_m += 3;
            }
            if (~n6 <= ~(-1 + this.ke_b.sk_l)) continue;
            ec2.ec_r -= 3;
        }
        n6 = n5 = 0;
        while (this.ke_b.sk_l > n5) {
            this.ke_f[n5].ec_n = n8;
            this.ke_f[n5].ec_l = n2 + -(n8 / 2);
            ++n5;
        }
    }

    final void k(byte by) {
        block0: {
            this.ke_u += this.ke_c / 2;
            this.ke_c = 7 * this.ke_c / 8;
            this.ke_c -= this.ke_u;
            if (by > 107) break block0;
            ke.a(103, -21, -87, 6, (byte)-30);
        }
    }

    final void d(int n) {
        boolean bl2 = client.A;
        h.a(this, (byte)95);
        while (ab.c((byte)-18)) {
            if (wh.wh_c == 13) {
                nm.f(n + 8749);
                ve.Hc = false;
                qi.a(false, (byte)-112);
                return;
            }
            if (!ph.n(-30146)) {
                this.ke_b.d(n ^ 0xFFFFDE52);
                if (-97 == ~wh.wh_c) {
                    cj.cj_c = (cj.cj_c + 1) % 2;
                    this.ke_b.a(cj.cj_c, (byte)-91);
                    nm.f(126);
                    this.ke_b.sk_o = false;
                }
                if (-98 == ~wh.wh_c) {
                    cj.cj_c = (cj.cj_c + 1) % 2;
                    this.ke_b.a(cj.cj_c, (byte)-113);
                    nm.f(n + 8601);
                    this.ke_b.sk_o = false;
                }
                if (~wh.wh_c == -99) {
                    if (this.ke_b.sk_h != 2) {
                        this.ke_b.a(2, (byte)-98);
                    } else {
                        this.ke_b.a(cj.cj_c, (byte)-69);
                    }
                }
                if (wh.wh_c == 99) {
                    if (~this.ke_b.sk_h > -1 || 2 <= this.ke_b.sk_h) {
                        this.ke_b.a(cj.cj_c, (byte)-101);
                    } else {
                        this.ke_b.a(2, (byte)-109);
                    }
                }
            } else {
                this.ke_b.a(-31);
            }
            if (!this.a(-14845, false)) continue;
            return;
        }
        if (n != -8622) {
            this.ke_w = 87;
        }
        this.ke_b.a(this.a(400, bh.bh_g, pm.pm_f), -20563, this.a(400, he.S, nf.nf_h));
        this.a(-14845, true);
    }

    private final void e(int n) {
        block2: {
            boolean bl2 = client.A;
            int n2 = -(this.ke_u >> -1889653886) + (640 + -(640 * (this.ke_o * this.ke_o) / 400));
            int n3 = this.ke_t <= 0 ? 1 : 0;
            int n4 = 3 <= this.ke_t ? this.ke_b.sk_l + -1 : this.ke_b.sk_l;
            for (int i = n3; i < n4; ++i) {
                vk.a(this.ke_f[i].ec_r, (byte)50, on.on_e, this.ke_f[i].ec_n, this.ke_f[i].ec_m, this.ke_f[i].ec_l + n2);
                int n5 = 16687906;
                if (i == this.ke_b.sk_h) {
                    n5 = 0xFFFFFF;
                }
                ec ec2 = this.ke_f[i];
                String string = ec2.ec_o;
                ga.a(ec2.ec_n, 1, ec2.ec_m, string, 1, ec2.ec_r, n5, a.a_t, (byte)-125, 1, n2 + ec2.ec_l);
            }
            if (n == 16687906) break block2;
            this.ke_c = 100;
        }
    }

    private final boolean c(boolean bl2, int n) {
        this.h(118);
        int n2 = -1;
        if (-1 >= ~this.ke_b.sk_h) {
            n2 = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (20 == n2 && this.ke_b.b((byte)114)) {
            og.a(false, 5, true);
            nm.f(-72);
            return true;
        }
        if ((~n2 == -20 || ~n2 == -11 || 3 == n2 || 13 == n2 || !bl2) && this.ke_b.b((byte)114)) {
            if (-14 == ~n2) {
                he.he_db = false;
            }
            lk.F = false;
            if (~n2 == -4 || 13 == n2) {
                fm.fm_e = false;
                mg.Zb = false;
            }
            qi.a(bl2, (byte)-102);
            nm.f(115);
            return true;
        }
        if (n < 119) {
            this.b((byte)-109);
        }
        return false;
    }

    static final void a(byte by) {
        block49: {
            boolean bl2;
            uf uf2;
            block50: {
                block51: {
                    tj tj2;
                    block52: {
                        ve ve2;
                        block55: {
                            int n;
                            block59: {
                                block60: {
                                    block61: {
                                        block58: {
                                            block57: {
                                                block56: {
                                                    block54: {
                                                        block53: {
                                                            block48: {
                                                                tj tj3;
                                                                uf uf3;
                                                                boolean bl3 = client.A;
                                                                if (by < 85) {
                                                                    ke_n = null;
                                                                }
                                                                if (-1 != ~(n = (uf2 = (uf3 = de.V)).d((byte)-114)) && ~n != -2 && -3 != ~n && n != 3 && n != 4) break block48;
                                                                tj tj4 = tj3 = (tj)oc.oc_b.c((byte)117);
                                                                while (tj3 != null) {
                                                                    tj3.b((byte)110);
                                                                    tj3.e((byte)73);
                                                                    tj4 = (tj)oc.oc_b.d(true);
                                                                }
                                                                tj4 = (tj)ob.ob_i.c(-9443);
                                                                while (null != tj4) {
                                                                    if (tj4.tj_bc || tj4.tj_fc) {
                                                                        if (tj4.tj_fc) {
                                                                            tj4.tj_fc = false;
                                                                            --cj.cj_a;
                                                                        }
                                                                        tj4.tj_bc = false;
                                                                        wk.a((byte)94, tj4);
                                                                    }
                                                                    tj4 = (tj)ob.ob_i.b(-99);
                                                                }
                                                                if (n == 1 && cd.cd_m != null) {
                                                                    ub.ub_c = cd.cd_m.Vb;
                                                                }
                                                                if (4 != n) {
                                                                    cd.cd_m = null;
                                                                } else {
                                                                    int n2 = uf2.e(3);
                                                                    cd.cd_m = new ve(j.j_b);
                                                                    cd.cd_m.a((long)n2, (byte)111);
                                                                    wg.a(false, uf2, cd.cd_m, (byte)-49);
                                                                    km.C = 0L;
                                                                }
                                                                if (2 != n && 3 != n) {
                                                                    g.N = null;
                                                                } else if (g.N == null) {
                                                                    g.N = new ve(j.j_b);
                                                                }
                                                                if (n != 3) {
                                                                    fj.fj_h = false;
                                                                } else {
                                                                    int n3;
                                                                    fj.fj_h = true;
                                                                    for (n3 = 0; kk.kk_l.length > n3; ++n3) {
                                                                        kk.kk_l[n3] = uf3.g((byte)-101);
                                                                    }
                                                                    qa.x = uf2.d((byte)-95);
                                                                    jb.jb_c = uf2.d((byte)-128);
                                                                    n3 = 0;
                                                                    while (~v.v_a.length < ~n3) {
                                                                        v.v_a[n3] = uf3.g((byte)-119);
                                                                        ++n3;
                                                                    }
                                                                }
                                                                break block49;
                                                            }
                                                            if (n == 5) break block50;
                                                            if (~n == -7) break block51;
                                                            if (-8 == ~n) break block52;
                                                            if (8 != n) break block53;
                                                            int n4 = uf2.e(3);
                                                            ve ve3 = (ve)tg.tg_b.a(24710, n4);
                                                            if (ve3 == null) {
                                                                ve3 = new ve(j.j_b);
                                                                tg.tg_b.a(ve3, -1, n4);
                                                            }
                                                            wg.a(true, uf2, ve3, (byte)-89);
                                                            pj.a(ve3, (byte)-50);
                                                            break block49;
                                                        }
                                                        if (-10 != ~n) break block54;
                                                        int n5 = uf2.e(3);
                                                        int n6 = uf2.d((byte)-41);
                                                        ve ve4 = (ve)tg.tg_b.a(24710, n5);
                                                        if (ve4 == null) break block49;
                                                        if (~n6 != -1) {
                                                            ve4.Rb = oa.oa_a;
                                                            ve4.ve_oc = n6;
                                                        } else {
                                                            ve4.b((byte)127);
                                                        }
                                                        ve4.e((byte)98);
                                                        break block49;
                                                    }
                                                    if (-11 == ~n) break block55;
                                                    if (~n != -12 && 12 != n) break block56;
                                                    int n7 = uf2.e(3);
                                                    ve ve5 = (ve)tg.tg_b.a(24710, n7);
                                                    if (ve5 == null) break block49;
                                                    if (~n == -12) {
                                                        ve5.Zb = true;
                                                    } else {
                                                        ve5.Ob = true;
                                                    }
                                                    pj.a(ve5, (byte)-50);
                                                    break block49;
                                                }
                                                if (~n != -14) break block57;
                                                int n8 = uf2.e(3);
                                                int n9 = uf2.d((byte)-49);
                                                ve ve6 = (ve)tg.tg_b.a(24710, n8);
                                                if (ve6 == null) break block49;
                                                ve ve7 = ve6;
                                                ve6.Ob = false;
                                                ve7.Zb = false;
                                                if (0 != n9) {
                                                    ve6.Rb = oa.oa_a;
                                                    ve6.ve_oc = n9;
                                                }
                                                pj.a(ve6, (byte)-50);
                                                break block49;
                                            }
                                            if (n != 14 && n != 16) break block58;
                                            long l2 = uf2.f((byte)-108);
                                            tj tj5 = ma.a(-119, l2);
                                            if (tj5 != null) {
                                                if (14 != n) {
                                                    if (!tj5.tj_fc) {
                                                        tj5.tj_fc = true;
                                                        ++cj.cj_a;
                                                    }
                                                } else {
                                                    tj5.tj_bc = true;
                                                }
                                                wk.a((byte)57, tj5);
                                            }
                                            break block49;
                                        }
                                        if (~n == -16 || ~n == -18) break block59;
                                        if (18 == n) break block60;
                                        if (19 == n) break block61;
                                        if (20 == n) {
                                            wg.a(false, uf2, cd.cd_m, (byte)-103);
                                        } else if (21 != n) {
                                            if (22 == n) {
                                                de.R = uf2.e(3);
                                                rf.rf_o = uf2.a(-104);
                                            } else if (23 == n) {
                                                uc.uc_g = uf2.f((byte)-108);
                                            } else {
                                                qb.a(null, 16408, "L1: " + qk.d((byte)49));
                                                si.a(117);
                                            }
                                        } else {
                                            int n10 = uf2.e(3);
                                            km.C = -1 == ~n10 ? 0L : ik.a(4) + (long)n10;
                                        }
                                        break block49;
                                    }
                                    long l3 = uf2.f((byte)-108);
                                    int n11 = uf2.d((byte)-41);
                                    tj tj6 = bj.a(l3, (byte)79);
                                    if (null == tj6) break block49;
                                    if (n11 != 0) {
                                        tj6.tj_hc = n11;
                                        tj6.Qb = oa.oa_a;
                                    } else {
                                        tj6.b((byte)105);
                                    }
                                    tj6.e((byte)84);
                                    --cd.cd_m.ve_rc;
                                    break block49;
                                }
                                long l4 = uf2.f((byte)-108);
                                String string = uf2.c((byte)-38);
                                String string2 = uf2.c((byte)-38);
                                tj tj7 = bj.a(l4, (byte)63);
                                if (tj7 == null) {
                                    tj7 = new tj(string, string2, l4);
                                    hn.hn_h.a(tj7, -1, l4);
                                    ++cd.cd_m.ve_rc;
                                }
                                tj7.Ub = uf2.e(3);
                                int n12 = uf2.a(-69);
                                tj7.Xb = n12 >> 1139399329;
                                tj7.tj_ec = ~(1 & n12) != -1;
                                tj7.tj_dc = uf2.d((byte)-29);
                                tj7.Sb = uf2.d((byte)-79);
                                oc.oc_b.a(tj7, 2777);
                                break block49;
                            }
                            long l5 = uf2.f((byte)-108);
                            int n13 = uf2.d((byte)-87);
                            tj tj8 = ma.a(-119, l5);
                            if (tj8 == null) break block49;
                            if (-1 != ~n13) {
                                tj8.Qb = oa.oa_a;
                                tj8.tj_hc = n13;
                            }
                            if (~n == -16) {
                                tj8.tj_bc = false;
                            } else if (tj8.tj_fc) {
                                --cj.cj_a;
                                tj8.tj_fc = false;
                            }
                            wk.a((byte)34, tj8);
                            break block49;
                        }
                        ve ve8 = ve2 = (ve)h.h_b.c((byte)121);
                        while (ve2 != null) {
                            ve2.b((byte)115);
                            ve2.e((byte)118);
                            ve8 = (ve)h.h_b.d(true);
                        }
                        break block49;
                    }
                    tj tj9 = tj2 = (tj)i.i_b.c((byte)43);
                    while (null != tj2) {
                        tj2.b((byte)108);
                        tj2.e((byte)112);
                        tj9 = (tj)i.i_b.d(true);
                    }
                    cj.cj_a = 0;
                    break block49;
                }
                long l6 = uf2.f((byte)-108);
                int n = uf2.d((byte)-89);
                tj tj10 = ma.a(-122, l6);
                if (tj10 == null) break block49;
                if (tj10.tj_fc) {
                    tj10.tj_fc = false;
                    --cj.cj_a;
                }
                if (-1 != ~n) {
                    tj10.tj_hc = n;
                    tj10.Qb = oa.oa_a;
                } else {
                    tj10.b((byte)114);
                }
                tj10.e((byte)95);
                break block49;
            }
            long l7 = uf2.f((byte)-108);
            String string = uf2.c((byte)-38);
            String string3 = uf2.c((byte)-38);
            String string4 = uf2.c((byte)-38);
            tj tj11 = ma.a(-102, l7);
            boolean bl4 = bl2 = !string3.equals("");
            if (null == tj11) {
                tj11 = new tj(string, string4, l7);
                ob.ob_i.a(tj11, -1, l7);
            } else if (bl2) {
                tj11.a((byte)19, string4, string);
            }
            tj11.Nb = ik.a(4) - (long)uf2.i(7553);
            tj11.Ub = uf2.e(3);
            int n = uf2.a(-28);
            tj11.tj_ec = ~(n & 1) != -1;
            tj11.Xb = n >> -125735103;
            tj11.tj_dc = uf2.d((byte)-98);
            tj11.Sb = uf2.d((byte)-128);
            wk.a((byte)112, tj11);
        }
    }

    static final int a(int n, int n2) {
        block0: {
            if (n == 2047) break block0;
            ke_h = null;
        }
        return qg.qg_b[n2 & 0x7FF];
    }

    final void c(byte by) {
        if (by != -75) {
            this.ke_r = true;
        }
        this.a(false, 15764);
        int n = 640 + (-(this.ke_o * this.ke_o * 640 / 400) - (this.ke_u >> -1363351294));
        ed.a(0xFFFFFF, n + 320, si.si_g, 120, (byte)75, w.w_kb);
        ed.a(0xFFFFFF, n + 320, gf.a(-125, this.ke_s, this.ke_j, this.ke_r), 140, (byte)75, w.w_kb);
        ed.a(0xFFFFFF, 320 + n, ri.a(by ^ 0xFFFFFFB5, this.ke_s, this.ke_j, this.ke_r), 240, (byte)75, w.w_kb);
        ed.a(0xFFFFFF, n + 320, kk.a(this.ke_j, this.ke_s, this.ke_r, true), 300, (byte)75, w.w_kb);
    }

    final void i(int n) {
        block12: {
            int n2;
            int n3;
            block11: {
                boolean bl2 = client.A;
                n3 = -(this.ke_u >> 174174562) + (-(640 * this.ke_o * this.ke_o / 400) + 640);
                this.a(false, 15764);
                ck ck2 = wh.wh_f;
                ck2.c(-(ck2.K / 2) + 320, 45 + (-(ck2.C / 2) - (n3 >> -1906814366)));
                if (null == this.ke_e && !ph.n(-30146)) {
                    this.ke_e = am.a(3, false, 1, 1, 10);
                }
                int n4 = -44 / ((63 - n) / 44);
                int n5 = bf.a((byte)107, gh.gh_e, fc.fc_e, this.ke_e);
                fl.a(105, 256, 0xFFFFFF, vm.x, 125 - -n3, w.w_kb);
                kn.a(w.w_kb, (byte)-39, 105, ng.ng_g, 0xFFFFFF, n3 + 400);
                kn.a(w.w_kb, (byte)-39, 105, sl.sl_b, 0xFFFFFF, 545 + n3);
                int n6 = 0;
                while (-11 < ~n6) {
                    n2 = 0xFFFFFF;
                    kn.a(w.w_kb, (byte)-39, 130 + n6 * 20, 1 + n6 + ".", n2, n3 + 115);
                    ++n6;
                }
                String string = le.le_r;
                n2 = 1;
                if (null != this.ke_e) {
                    if (!this.ke_e.kc_p) {
                        string = wm.wm_k;
                    } else {
                        int n7;
                        if (null == this.ke_e.kc_r) {
                            string = dn.dn_s;
                        } else {
                            String[] stringArray = this.ke_e.kc_r[fc.fc_e];
                            int[] nArray = this.ke_e.kc_u[fc.fc_e];
                            for (n7 = 0; 10 > n7; ++n7) {
                                if (null == stringArray[n7]) continue;
                                string = null;
                                int n8 = 16769088;
                                int n9 = nArray[n7];
                                int n10 = n9 >>> 869777032;
                                if (~n5 == ~n7) {
                                    n8 = 0xFFFFFF;
                                }
                                int n11 = 1 + n9 % 256;
                                fl.a(130 + 20 * n7, 256, n8, stringArray[n7], 125 - -n3, se.S);
                                kn.a(se.S, (byte)-39, 20 * n7 + 130, Integer.toString(n11), n8, n3 + 400);
                                kn.a(se.S, (byte)-39, n7 * 20 + 130, Integer.toString(n10), n8, n3 + 545);
                            }
                        }
                        if (-1 < ~n5 && null != gh.gh_e && ~gh.gh_e.x == -2) {
                            fl.a(330, 256, 0xFFFFFF, oa.oa_f, n3 + 125, se.S);
                            int n12 = gh.gh_e.kn_s[0];
                            int n13 = n12 % 256 + 1;
                            kn.a(se.S, (byte)-39, 330, Integer.toString(n13), 0xFFFFFF, 400 + n3);
                            n7 = n12 >>> -1510192632;
                            n2 = 0;
                            kn.a(se.S, (byte)-39, 330, Integer.toString(n7), 0xFFFFFF, n3 + 545);
                        }
                    }
                }
                if (null != string) {
                    ed.a(0xFFFFFF, 320 - -n3, string, 220, (byte)75, w.w_kb);
                }
                if (!ph.n(-30146)) break block11;
                ed.a(0xFFFFFF, 320 + n3, lf.lf_d, 330, (byte)75, se.S);
                break block12;
            }
            if (n2 == 0) break block12;
            ed.a(0xFFFFFF, n3 + 320, af.af_e, 330, (byte)75, se.S);
        }
    }

    final void i(byte by) {
        if (by != 39) {
            return;
        }
        this.ke_b.a(-115);
        this.p(-1);
    }

    private final void a(boolean bl2, int n) {
        boolean bl3 = client.A;
        int n2 = -(this.ke_u >> -134113438) + (640 - this.ke_o * (this.ke_o * 640) / 400);
        hk.a(4 + this.ke_w - -n2, this.z - -4, this.y - 8, -8 + this.ke_q, 0, 150);
        vk.a(this.ke_q, (byte)50, a.a_n, this.y, this.z, this.ke_w + n2);
        if (n != 15764) {
            this.ke_r = false;
        }
        int n3 = 0;
        while (~n3 > ~this.ke_b.sk_l) {
            int n4;
            int n5;
            ec ec2 = this.ke_f[n3];
            String string = ec2.ec_o;
            int n6 = ec2.ec_m;
            int n7 = ec2.ec_r;
            if (bl2) {
                n5 = n6;
                n4 = n7;
                if (-1 > ~n3) {
                    n6 -= 3;
                    n7 += 3;
                }
                if (this.ke_b.sk_l - 1 > n3) {
                    n7 += 3;
                }
                hk.b(0, n5, 640, n4 + n5);
            }
            n5 = 16694016;
            if (~n3 == ~this.ke_b.sk_h) {
                n5 = 0xFFFFFF;
                vk.a(n7, (byte)50, im.im_i, ec2.ec_n, n6, n2 + ec2.ec_l);
            } else {
                vk.a(n7, (byte)50, on.on_e, ec2.ec_n, n6, n2 + ec2.ec_l);
            }
            if (-16 == ~ec2.ec_d) {
                if ((kf.I.qc_g.eb_d & 1 << kf.I.P) == 0) {
                    if (~kf.I.qc_g.eb_d != -1) {
                        string = pg.pg_c;
                        if (-1 == ~(uf.A & 0x10)) {
                            n5 = 0xFFFFFF;
                        }
                    } else {
                        string = kf.R;
                    }
                } else {
                    string = e.e_a;
                }
            }
            if (ec2.ec_d == 17) {
                qc qc2;
                qc qc3 = qc2 = kf.I != null ? kf.I : ce.C;
                if (!qc2.W) {
                    if (0 != (1 << qc2.P & qc2.qc_g.eb_a)) {
                        string = sc.sc_h;
                    } else if (qc2.qc_g.eb_a != 0) {
                        if ((uf.A & 0x10) == 0) {
                            n5 = 0xFFFFFF;
                        }
                        string = k.k_h;
                    } else {
                        string = ~((1 << qc2.qc_g.eb_b) + -1) == ~(qc2.yb | 1 << qc2.P) ? ig.Xb : ji.ji_c;
                    }
                } else if ((qc2.qc_g.eb_a & 1 << qc2.P) != 0) {
                    string = rc.rc_g;
                } else if (-1 != ~qc2.qc_g.eb_a) {
                    string = wj.Kb;
                    if (0 == (uf.A & 0x10)) {
                        n5 = 0xFFFFFF;
                    }
                } else {
                    string = (1 << qc2.qc_g.eb_b) - 1 != (1 << qc2.P | qc2.yb) ? ik.ik_g : di.E;
                }
            }
            if (-7 != ~ec2.ec_d && ec2.ec_d != 7) {
                if (-23 == ~ec2.ec_d && ~n3 == ~fc.fc_e) {
                    n5 = 0xFFFFFF;
                }
                if (~ec2.ec_d == -24 && n3 == cj.cj_c) {
                    n5 = 0xFFFFFF;
                }
                ga.a(ec2.ec_n, 1, n6, string, 20, n7, n5, a.a_t, (byte)-128, 1, ec2.ec_l - -n2);
            } else {
                n4 = a.a_t.a(pm.pm_c);
                int n8 = a.a_t.a(fj.fj_f);
                if (n8 > n4) {
                    n4 = n8;
                }
                int n9 = (n4 + 5 + (-128 + ec2.ec_n)) / 2 + ec2.ec_l;
                hk.a(-1 + n9 + n2, n6 + 11, 130, 8, 65793);
                hk.a(1 + (n9 + n2), 13 + n6, 126, 4, n5);
                int n10 = -7 == ~ec2.ec_d ? pb.pb_d * 128 / 128 : a.a_g * 128 / 128;
                ga.a(-5 + n9 - ec2.ec_l, 1, n6, string, 20, n7, n5, a.a_t, (byte)-124, 2, ec2.ec_l - -n2);
                int n11 = -7 != ~ec2.ec_d ? 3 : 1;
                tg.a(true, n11).c(n2 + (-9 + n9) - -n10, 6 + n6, 18, 18);
            }
            if (~ec2.ec_d == -3 && (-4 < ~id.P || h.a(false))) {
                hk.c(8 + (n2 + ec2.ec_l), n6 + 3, ec2.ec_n - 16, 2);
                hk.c(4 + (n2 + ec2.ec_l), n6 - -5, ec2.ec_n + -8, -10 + n7);
                hk.c(8 + (n2 + ec2.ec_l), -5 + (n7 + n6), -16 + ec2.ec_n, 2);
            }
            ++n3;
        }
        hk.d();
    }

    final void c(int n, boolean bl2) {
        block0: {
            this.ke_b.a(bl2, 117, this.a(400, bh.bh_g, pm.pm_f));
            if (n == -1) break block0;
            this.z = -92;
        }
    }

    final void l(byte by) {
        boolean bl2 = client.A;
        int n = 39 / ((47 - by) / 51);
        h.a(this, (byte)95);
        while (ab.c((byte)-124)) {
            if (~wh.wh_c == -14) {
                nm.f(-77);
                fm.fm_e = false;
                qi.a(false, (byte)-107);
                return;
            }
            if (!ph.n(-30146)) {
                this.ke_b.d(0);
                if (~wh.wh_c == -97) {
                    fc.fc_e = (-1 + (3 + fc.fc_e)) % 3;
                    this.ke_b.a(fc.fc_e, (byte)-113);
                    nm.f(4);
                    this.ke_b.sk_o = false;
                }
                if (~wh.wh_c == -98) {
                    fc.fc_e = (fc.fc_e - -1) % 3;
                    this.ke_b.a(fc.fc_e, (byte)-75);
                    nm.f(-117);
                    this.ke_b.sk_o = false;
                }
                if (wh.wh_c == 98) {
                    if (this.ke_b.sk_h < 3) {
                        this.ke_b.a(-1 + this.ke_b.sk_l, (byte)-76);
                    } else if (this.ke_b.sk_h != 3) {
                        this.ke_b.a(this.ke_b.sk_h + -1, (byte)-110);
                    } else {
                        this.ke_b.a(fc.fc_e, (byte)-113);
                    }
                }
                if (-100 == ~wh.wh_c) {
                    if (~this.ke_b.sk_h <= -1 && -1 + this.ke_b.sk_l != this.ke_b.sk_h) {
                        if (-4 < ~this.ke_b.sk_h) {
                            this.ke_b.a(3, (byte)-126);
                        } else {
                            this.ke_b.a(this.ke_b.sk_h + 1, (byte)-95);
                        }
                    } else {
                        this.ke_b.a(fc.fc_e, (byte)-123);
                    }
                }
            } else {
                this.ke_b.a(-113);
            }
            if (!this.c(false, (byte)-96)) continue;
            return;
        }
        this.ke_b.a(this.a(400, bh.bh_g, pm.pm_f), -20563, this.a(400, he.S, nf.nf_h));
        this.c(true, (byte)-76);
    }

    final void a(int n, byte by) {
        int n2;
        int n3;
        boolean bl2 = client.A;
        for (n3 = 0; this.ke_b.sk_l > n3; ++n3) {
            this.ke_f[n3].ec_m += n;
        }
        this.a(false, 15764);
        n3 = n2 = 0;
        if (by != -54) {
            this.ke_v = null;
        }
        while (~this.ke_b.sk_l < ~n2) {
            this.ke_f[n2].ec_m -= n;
            ++n2;
        }
    }

    private final boolean c(boolean bl2, byte by) {
        this.h(123);
        int n = -1;
        if (~this.ke_b.sk_h <= -1) {
            n = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (20 == n && this.ke_b.b((byte)114)) {
            og.a(false, 8, true);
            nm.f(-11);
            return true;
        }
        if ((n == 3 || ~n == -14 || !bl2) && this.ke_b.b((byte)114)) {
            fm.fm_e = false;
            if (n == 13) {
                he.he_db = false;
            }
            qi.a(bl2, (byte)-103);
            nm.f(11);
            return true;
        }
        if (bl2 && ~ig.Yb != -1 && this.ke_b.sk_h != -1) {
            fc.fc_e = this.ke_b.sk_h;
            this.ke_b.a(fc.fc_e, (byte)-103);
            nm.f(119);
            return true;
        }
        if (by > -41) {
            ke_h = null;
        }
        return false;
    }

    private final void a(lm lm2, int n, int n2, int n3, int n4, int n5, int n6, String string, int n7, int n8) {
        block1: {
            int n9 = n6 + (n3 - -n2);
            if (~n9 != -1) {
                n6 = (n9 + n6 * 200) / (n9 * 2);
                n3 = (n9 + n3 * 200) / (2 * n9);
                n2 = (n9 + 200 * n2) / (n9 * 2);
            }
            int n10 = ~kd.kd_p == -4 ? 305 : 310;
            int n11 = 3 == kd.kd_p ? 372 : 380;
            int n12 = kd.kd_p != 3 ? 435 : 427;
            int n13 = 3 == kd.kd_p ? 488 : 490;
            fl.a(n5, 256, n, string, 125 - -n8, lm2);
            kn.a(lm2, (byte)-39, n5, Integer.toString(n7), n, n10 - -n8);
            kn.a(lm2, (byte)-39, n5, Integer.toString(n9), n, n11 - -n8);
            kn.a(lm2, (byte)-39, n5, n6 + "%", n, n12 + n8);
            kn.a(lm2, (byte)-39, n5, n3 + "%", n, n8 + n13);
            kn.a(lm2, (byte)-39, n5, n2 + "%", n, n8 + 545);
            if (n4 == -5328) break block1;
            this.ke_u = 81;
        }
    }

    private final void n(int n) {
        if (this.ke_t < 3) {
            ++this.ke_t;
            nm.f(120);
            ac.f((byte)-87);
        }
        int n2 = 116 % ((n - 18) / 61);
    }

    private final boolean p(int n) {
        this.h(115);
        int n2 = n;
        if (0 <= this.ke_b.sk_h) {
            n2 = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (17 == n2 && this.ke_b.b((byte)114)) {
            kf.I.c(n ^ 0xFFFFFFB3);
            nm.f(-72);
            return true;
        }
        if (-19 == ~n2 && this.ke_b.b((byte)114)) {
            if (fm.fm_b) {
                tg.a((byte)-46);
            }
            if (fa.fa_n) {
                ga.a(false, 0, 11);
            }
            nm.f(127);
            return true;
        }
        return false;
    }

    final void j(int n) {
        block4: {
            boolean bl2 = client.A;
            h.a(this, (byte)95);
            while (ab.c((byte)10)) {
                if (13 == wh.wh_c) {
                    nm.f(118);
                    lk.F = false;
                    qi.a(false, (byte)-117);
                    return;
                }
                this.ke_b.a(-36);
                if (!this.c(false, 121)) continue;
                return;
            }
            this.ke_b.a(this.a(400, bh.bh_g, pm.pm_f), -20563, this.a(400, he.S, nf.nf_h));
            boolean bl3 = this.c(true, 126);
            if (n >= -78) {
                this.j((byte)-93);
            }
            if (bl3) {
                return;
            }
            if (ig.Yb == 0) break block4;
            this.b(true, (byte)-51);
        }
    }

    final void g(byte by) {
        block2: {
            boolean bl2 = client.A;
            h.a(this, (byte)95);
            while (ab.c((byte)-126)) {
                this.ke_b.a(-118);
                if (!this.b(-1, false)) continue;
                return;
            }
            this.ke_b.a(this.a(400, bh.bh_g, pm.pm_f), by + -20467, this.a(400, he.S, nf.nf_h));
            if (this.b(-1, true)) {
                return;
            }
            if (by == -96) break block2;
            ke_d = 58;
        }
    }

    private final boolean d(int n2, boolean bl2) {
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        boolean bl3 = client.A;
        this.h(111);
        int n8 = -1;
        if (~this.ke_b.sk_h <= -1) {
            n8 = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (~n8 == -2 && this.ke_b.b((byte)114)) {
            nm.f(120);
            pn.a(false, false, true);
            return true;
        }
        if (-3 == ~n8 && this.ke_b.b((byte)114)) {
            nm.f(40);
            vk.a(bl2, (byte)-73);
            return true;
        }
        if (n8 == 3 && this.ke_b.b((byte)114)) {
            nm.f(-80);
            jm.a(0, bl2);
            return true;
        }
        if (n8 == 4 && this.ke_b.b((byte)114)) {
            nk.nk_k = true;
            f.f_s = ek.a(bl2, this.ke_p, 640);
            nm.f(7);
            return true;
        }
        if (n8 == 5 && this.ke_b.b((byte)114)) {
            kf.I.d((byte)-68);
            cd.a(true);
            nm.f(116);
            return true;
        }
        int n9 = -97 / ((n2 - -46) / 55);
        if (n8 == 6) {
            if (!this.ke_b.a(true)) {
                if (this.ke_b.b((byte)114)) {
                    ik.c(93);
                }
            } else {
                n7 = a.a_t.a(pm.pm_c);
                n6 = a.a_t.a(fj.fj_f);
                if (~n6 < ~n7) {
                    n7 = n6;
                }
                n5 = (n7 + -128 + (this.ke_f[this.ke_b.sk_h].ec_n - -5)) / 2 + this.ke_f[this.ke_b.sk_h].ec_l;
                n4 = bh.bh_g + -n5;
                n3 = 128 * n4 / 128;
                if (n3 >= 0) {
                    if (n3 > 128) {
                        n3 = 128;
                    }
                } else {
                    n3 = 0;
                }
                if (pb.pb_d != n3) {
                    pb.pb_d = n3;
                    if (uf.A + -this.x >= 5) {
                        ik.c(106);
                        this.x = uf.A;
                    }
                }
            }
            if (this.ke_b.c(114)) {
                pb.pb_d = 0;
                ik.c(64);
            }
            if (this.ke_b.a((byte)-51)) {
                pb.pb_d = 128;
                ik.c(111);
            }
            if (this.ke_b.b(true) && -1 > ~pb.pb_d) {
                pb.pb_d = 0xFFFFFFF0 & -1 + pb.pb_d;
                ik.c(98);
            }
            if (this.ke_b.b(-20) && ~pb.pb_d > -129) {
                pb.pb_d = 16 + pb.pb_d & 0xFFFFFFF0;
                ik.c(120);
            }
        }
        if (7 == n8) {
            if (this.ke_b.a(true)) {
                n7 = a.a_t.a(pm.pm_c);
                n6 = a.a_t.a(fj.fj_f);
                if (~n6 < ~n7) {
                    n7 = n6;
                }
                n5 = (n7 + (-128 + this.ke_f[this.ke_b.sk_h].ec_n + 5)) / 2 + this.ke_f[this.ke_b.sk_h].ec_l;
                n4 = bh.bh_g - n5;
                n3 = n4 * 128 / 128;
                sa.x = true;
                a.a_g = n3 < 0 ? 0 : (~n3 < -129 ? 128 : n3);
            }
            if (this.ke_b.c(122)) {
                a.a_g = 0;
                sa.x = true;
            }
            if (this.ke_b.a((byte)-51)) {
                sa.x = true;
                a.a_g = 128;
            }
            if (this.ke_b.b(true)) {
                if ((a.a_g = a.a_g + -1 & 0xFFFFFFF0) < 0) {
                    a.a_g = 0;
                }
                sa.x = true;
            }
            if (this.ke_b.b(101)) {
                if ((a.a_g = 0xFFFFFFF0 & 16 + a.a_g) > 128) {
                    a.a_g = 128;
                }
                sa.x = true;
            }
        }
        if (n8 == 8 && this.ke_b.b((byte)114)) {
            if (cl.cl_v != null) {
                sn.a(false);
            } else {
                jk.a(2, bl2);
            }
            nm.f(119);
            return true;
        }
        if (~n8 == -10 && this.ke_b.b((byte)114)) {
            ve.Hc = true;
            ca.ca_wb = oj.a(bl2, 415);
            nm.f(-105);
            return true;
        }
        if (~n8 == -11 && this.ke_b.b((byte)114)) {
            mg.Zb = true;
            cl.B = qj.a(-108, bl2);
            nm.f(127);
            return true;
        }
        if (19 == n8 && this.ke_b.b((byte)114)) {
            fm.fm_e = true;
            am.am_a = ib.a((byte)-80, bl2);
            nm.f(-14);
            return true;
        }
        if (11 == n8 && this.ke_b.b((byte)114)) {
            lk.F = true;
            h.h_d = uh.a(o.o_g, bl2, 0, -128);
            nm.f(114);
            return true;
        }
        if (12 == n8 && this.ke_b.b((byte)114)) {
            nm.f(-38);
            sn.a(false);
            pk.me_a_applet((byte)-17, se.h(25144));
        }
        if (-14 == ~n8 && this.ke_b.b((byte)114)) {
            nm.f(13);
            cd.a(true);
            return true;
        }
        if (-15 == ~n8 && this.ke_b.b((byte)114)) {
            kf.I.c((byte)100);
            am.am_c = false;
            kf.G = f.a(false, false, 0, false, kf.I.qc_wb, 32357, false, false);
            un.a((byte)-30);
            dc.a(bl2, 95);
            nm.f(126);
            return true;
        }
        if (n8 == 15 && this.ke_b.b((byte)114)) {
            kf.I.b(-62);
            cd.a(true);
            nm.f(124);
            return true;
        }
        if (n8 == 16 && this.ke_b.b((byte)114)) {
            kf.I.f(-49);
            cd.a(true);
            nm.f(-19);
            return true;
        }
        if (~n8 == -18 && this.ke_b.b((byte)114)) {
            kf.I.c(-89);
            cd.a(true);
            nm.f(122);
            return true;
        }
        if (-19 == ~n8 && this.ke_b.b((byte)114)) {
            if (fm.fm_b) {
                tg.a((byte)-115);
            }
            if (fa.fa_n) {
                ga.a(false, 0, 11);
            }
            cd.a(true);
            nm.f(-42);
            return true;
        }
        return false;
    }

    private final void h(int n2) {
        block1: {
            if (n2 < 93) {
                this.b(68, true);
            }
            if (!this.ke_b.sk_o) break block1;
            fj.a(32, (byte)-89, pg.pg_d);
        }
    }

    final int a(int n2) {
        if (n2 != -1) {
            this.ke_q = -13;
        }
        int n3 = -(this.ke_u >> 1480277474) + 640 - 640 * this.ke_o * this.ke_o / 400;
        return n3;
    }

    public static void l(int n2) {
        block0: {
            ke_n = null;
            ke_h = null;
            if (n2 >= 106) break block0;
            ke.e((byte)27);
        }
    }

    final void a(int n2, boolean bl2, int n3) {
        block0: {
            this.ke_b.a(n2, 0, this.a(400, bh.bh_g, pm.pm_f), bl2);
            if (n3 == -129) break block0;
            this.n(53);
        }
    }

    private final boolean b(boolean bl2, int n2) {
        this.h(95);
        int n3 = -1;
        if (~this.ke_b.sk_h <= -1) {
            n3 = this.ke_f[this.ke_b.sk_h].ec_d;
        }
        if (20 == n3 && this.ke_b.b((byte)114)) {
            og.a(false, 6, true);
            return true;
        }
        if ((-14 == ~n3 || !bl2) && this.ke_b.b((byte)114)) {
            mg.Zb = false;
            qi.a(bl2, (byte)-103);
            nm.f(122);
            return true;
        }
        if (bl2 && ~ig.Yb != -1 && ~this.ke_b.sk_h != 0) {
            fc.fc_e = this.ke_b.sk_h;
            this.ke_b.a(fc.fc_e, (byte)-112);
            nm.f(n2 + -34);
            return true;
        }
        if (n2 != 1) {
            this.ke_m = -102;
        }
        return false;
    }

    ke(int n2) {
        this.ke_f = new ec[n2];
        this.ke_b = new sk();
    }

    static {
        ke_n = "Your rating is <%0>";
        ke_h = new int[8192];
    }
}
