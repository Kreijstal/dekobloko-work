/*
 * Decompiled with CFR 0.152.
 */
interface na
extends kg {
    public void a(se var1, id var2, byte var3);
}
