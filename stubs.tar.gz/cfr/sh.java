/*
 * Decompiled with CFR 0.152.
 */
final class sh {
    static cb sh_g;
    static String sh_h;
    static boolean sh_j;
    static String sh_b;
    static String sh_e;
    static String sh_c;
    static mi sh_a;
    static long sh_f;
    static int sh_i;
    static af sh_d;

    public static void a(byte by) {
        if (by >= -17) {
            sh_a = null;
        }
        sh_d = null;
        sh_h = null;
        sh_c = null;
        sh_e = null;
        sh_a = null;
        sh_b = null;
        sh_g = null;
    }

    static final void a(int n) {
        k.k_e = null;
        wd.wd_d = false;
        pa.Z = -1;
        dh.dh_e = -1;
        jc.jc_g = n;
    }

    static final void a(byte[] byArray, int n, int n2, int[] nArray, int n3) {
        block2: {
            boolean bl = client.A;
            int n4 = 0;
            while (~n4 > ~a.a_r.length) {
                n2 = a.a_r[n4];
                int n5 = n4 << 423294052;
                while (0 != n2--) {
                    n3 = hb.Vb[n5++];
                    byte by = byArray[n3];
                    int n6 = nArray[by];
                    nArray[by] = n6 + 1;
                    hb.Vb[n6] = n3;
                }
                ++n4;
            }
            if (n == -25724) break block2;
            sh.a(-65);
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, ck ck2, int n8) {
        int n9 = n4 + (ck2.F + n7 - n);
        int n10 = n5 + (n4 + ck2.F) + n7;
        if (n3 != 25547) {
            sh.a(null, 13, 74, null, -77);
        }
        int n11 = n8 + ck2.z + (ck2.H >> -1694860959);
        hk.f(n9, 0, n10, n11 + n6);
        ck2.f(-1 + n4, n8 + -1, n2);
        ck2.f(n4 - 1, n8 + 1, n2);
        hk.a(he.V);
        hk.f(n9 - -1, 0, n10 + 1, n6 + n11);
        ck2.f(n4 - -1, -1 + n8, n2);
        ck2.f(1 + n4, n8 - -1, n2);
        hk.a(he.V);
        n10 = -n + -n7 + n4 + ck2.F + ck2.I;
        n9 = -n5 + (-n7 + ck2.I + ck2.F) - -n4;
        hk.f(n9, -n6 + n11, n10, 480);
        ck2.f(n4 - 1, -1 + n8, n2);
        ck2.f(n4 - 1, 1 + n8, n2);
        hk.a(he.V);
        hk.f(1 + n9, n11 + -n6, n10 + 1, 480);
        ck2.f(1 + n4, -1 + n8, n2);
        ck2.f(n4 + 1, n8 - -1, n2);
        hk.a(he.V);
    }

    static final void a(boolean bl2, ji ji2) {
        pc.pc_b = ji2;
        byte[] byArray = kb.a(-24, "gamename");
        if (byArray != null) {
            ph.Gb = qj.a(byArray, 2);
        }
        byArray = kb.a(-18, "benefits,0");
        if (null != byArray) {
            ac.z[0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-116, "benefits,1");
        if (null != byArray) {
            ac.z[1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-72, "benefits,2");
        if (null != byArray) {
            ac.z[2] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-52, "benefits,3")) != null) {
            ac.z[3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-30, "benefits,4");
        if (byArray != null) {
            ac.z[4] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-29, "benefits,5"))) {
            ac.z[5] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-58, "waitingfor_backgrounds"))) {
            qa.qa_w = qj.a(byArray, 2);
        }
        byArray = kb.a(-68, "loading_backgrounds");
        if (null != byArray) {
            ga.ga_b = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-75, "mp_x_players_wanttodraw")) != null) {
            we.we_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-77, "press_esc_to_accept");
        if (byArray != null) {
            cg.cg_b = qj.a(byArray, 2);
        }
        byArray = kb.a(-112, "keycode_rotateleft");
        if (null != byArray) {
            oh.oh_n = byArray[0] & 0xFF;
        }
        byArray = kb.a(-90, "keycode_rotateright");
        if (null != byArray) {
            um.um_d = byArray[0] & 0xFF;
        }
        byArray = kb.a(-76, "rated_membersonly");
        if (byArray != null) {
            uj.uj_g = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-97, "staminamode"))) {
            gn.gn_d = qj.a(byArray, 2);
        }
        byArray = kb.a(-63, "masterchallenge");
        if (byArray != null) {
            b.Q = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-54, "challenge_highscores"))) {
            ul.ul_b = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-103, "stamina_highscores"))) {
            ak.ak_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-125, "multiplayer_rankings");
        if (null != byArray) {
            u.u_g = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-113, "player"))) {
            ub.ub_e = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-106, "status"))) {
            tf.tf_ab = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-46, "position")) != null) {
            p.p_d = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-126, "winner"))) {
            oi.oi_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-111, "drawn");
        if (byArray != null) {
            oi.oi_b = qj.a(byArray, 2);
        }
        byArray = kb.a(-78, "playing");
        if (null != byArray) {
            eg.eg_a = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-116, "resigned"))) {
            v.v_f = qj.a(byArray, 2);
        }
        byArray = kb.a(-119, "left");
        if (null != byArray) {
            rc.rc_h = qj.a(byArray, 2);
        }
        byArray = kb.a(-108, "defeated");
        if (byArray != null) {
            wl.wl_s = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-58, "rematch_request")) != null) {
            we.we_g = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-95, "draw_request")) != null) {
            sk.sk_b = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-21, "ready"))) {
            ub.ub_b = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-82, "steady"))) {
            ui.ui_o = qj.a(byArray, 2);
        }
        byArray = kb.a(-80, "total");
        if (byArray != null) {
            n.n_a = qj.a(byArray, 2);
        }
        byArray = kb.a(-31, "settling_score");
        if (byArray != null) {
            th.th_a = qj.a(byArray, 2);
        }
        byArray = kb.a(-44, "matching_score");
        if (byArray != null) {
            t.t_bb = qj.a(byArray, 2);
        }
        if (bl2) {
            return;
        }
        byArray = kb.a(-42, "eliminate_score");
        if (null != byArray) {
            ii.ii_p = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-51, "simultaneous_bonus"))) {
            jc.jc_b = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-117, "chain_bonus")) != null) {
            wm.wm_m = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-105, "special_item_bonus")) != null) {
            on.on_a = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-23, "fast_drop_bonus"))) {
            qi.L = qj.a(byArray, 2);
        }
        byArray = kb.a(-21, "press_space_or_enter");
        if (byArray != null) {
            ak.ak_c = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-102, "shape_feedback"))) {
            eh.eh_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-126, "colours_in_play");
        if (null != byArray) {
            sh_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-17, "specials_enabled");
        if (byArray != null) {
            md.Y = qj.a(byArray, 2);
        }
        byArray = kb.a(-86, "stage_colon");
        if (null != byArray) {
            qa.qa_u = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-127, "theme_colon")) != null) {
            re.re_s = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-29, "theme_x_strategy"))) {
            client.E = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-65, "hs_theme")) != null) {
            a.x = qj.a(byArray, 2);
        }
        byArray = kb.a(-33, "fruit");
        if (null != byArray) {
            vf.vf_c = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-90, "animals"))) {
            t.t_ib = qj.a(byArray, 2);
        }
        byArray = kb.a(-80, "breakfast");
        if (null != byArray) {
            u.u_c = qj.a(byArray, 2);
        }
        byArray = kb.a(-111, "bugs");
        if (byArray != null) {
            kl.kl_w = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-24, "flowers")) != null) {
            dn.dn_j = qj.a(byArray, 2);
        }
        byArray = kb.a(-16, "undersea");
        if (byArray != null) {
            ea.y = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-21, "city")) != null) {
            l.l_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-47, "eightbit");
        if (byArray != null) {
            pa.W = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-29, "hs_stage"))) {
            ng.ng_g = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-38, "stage_x")) != null) {
            dl.L = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-125, "number_colon_name"))) {
            id.O = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-61, "number_colon")) != null) {
            kk.kk_q = qj.a(byArray, 2);
        }
        byArray = kb.a(-115, "unlock_masterchallenge_free");
        if (byArray != null) {
            qj.a(byArray, 2);
        }
        byArray = kb.a(-18, "unlock_masterchallenge_members");
        if (null != byArray) {
            rg.rg_f = qj.a(byArray, 2);
        }
        byArray = kb.a(-21, "achievement_names,0");
        if (byArray != null) {
            qk.qk_s[0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-30, "achievement_names,1")) != null) {
            qk.qk_s[1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-34, "achievement_names,2"))) {
            qk.qk_s[2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-59, "achievement_names,3");
        if (null != byArray) {
            qk.qk_s[3] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-39, "achievement_names,4")) != null) {
            qk.qk_s[4] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-123, "achievement_names,5")) != null) {
            qk.qk_s[5] = qj.a(byArray, 2);
        }
        byArray = kb.a(-105, "achievement_names,6");
        if (null != byArray) {
            qk.qk_s[6] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-119, "achievement_names,7"))) {
            qk.qk_s[7] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-68, "achievement_names,8")) != null) {
            qk.qk_s[8] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-51, "achievement_names,9")) != null) {
            qk.qk_s[9] = qj.a(byArray, 2);
        }
        byArray = kb.a(-18, "achievement_names,10");
        if (byArray != null) {
            qk.qk_s[10] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-25, "achievement_names,11"))) {
            qk.qk_s[11] = qj.a(byArray, 2);
        }
        byArray = kb.a(-60, "achievement_names,12");
        if (null != byArray) {
            qk.qk_s[12] = qj.a(byArray, 2);
        }
        byArray = kb.a(-105, "achievement_names,13");
        if (null != byArray) {
            qk.qk_s[13] = qj.a(byArray, 2);
        }
        byArray = kb.a(-21, "achievement_names,14");
        if (byArray != null) {
            qk.qk_s[14] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-119, "achievement_names,15"))) {
            qk.qk_s[15] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-26, "achievement_names,16"))) {
            qk.qk_s[16] = qj.a(byArray, 2);
        }
        byArray = kb.a(-110, "achievement_names,17");
        if (byArray != null) {
            qk.qk_s[17] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-91, "achievement_names,18")) != null) {
            qk.qk_s[18] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-30, "achievement_names,19"))) {
            qk.qk_s[19] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-49, "achievement_names,20")) != null) {
            qk.qk_s[20] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-79, "achievement_names,21"))) {
            qk.qk_s[21] = qj.a(byArray, 2);
        }
        byArray = kb.a(-40, "achievement_names,22");
        if (null != byArray) {
            qk.qk_s[22] = qj.a(byArray, 2);
        }
        byArray = kb.a(-108, "achievement_names,23");
        if (byArray != null) {
            qk.qk_s[23] = qj.a(byArray, 2);
        }
        byArray = kb.a(-78, "achievement_names,24");
        if (null != byArray) {
            qk.qk_s[24] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-118, "achievement_names,25")) != null) {
            qk.qk_s[25] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-76, "achievement_names,26"))) {
            qk.qk_s[26] = qj.a(byArray, 2);
        }
        byArray = kb.a(-57, "achievement_names,27");
        if (null != byArray) {
            qk.qk_s[27] = qj.a(byArray, 2);
        }
        byArray = kb.a(-118, "achievement_names,28");
        if (byArray != null) {
            qk.qk_s[28] = qj.a(byArray, 2);
        }
        byArray = kb.a(-42, "achievement_names,29");
        if (byArray != null) {
            qk.qk_s[29] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-39, "achievement_names,30"))) {
            qk.qk_s[30] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-96, "achievement_criteria,0")) != null) {
            jh.jh_c[0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-40, "achievement_criteria,1")) != null) {
            jh.jh_c[1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-18, "achievement_criteria,2");
        if (byArray != null) {
            jh.jh_c[2] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-54, "achievement_criteria,3"))) {
            jh.jh_c[3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-85, "achievement_criteria,4");
        if (null != byArray) {
            jh.jh_c[4] = qj.a(byArray, 2);
        }
        byArray = kb.a(-72, "achievement_criteria,5");
        if (null != byArray) {
            jh.jh_c[5] = qj.a(byArray, 2);
        }
        byArray = kb.a(-93, "achievement_criteria,6");
        if (byArray != null) {
            jh.jh_c[6] = qj.a(byArray, 2);
        }
        byArray = kb.a(-88, "achievement_criteria,7");
        if (null != byArray) {
            jh.jh_c[7] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-128, "achievement_criteria,8"))) {
            jh.jh_c[8] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-117, "achievement_criteria,9"))) {
            jh.jh_c[9] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-75, "achievement_criteria,10"))) {
            jh.jh_c[10] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-86, "achievement_criteria,11"))) {
            jh.jh_c[11] = qj.a(byArray, 2);
        }
        byArray = kb.a(-94, "achievement_criteria,12");
        if (null != byArray) {
            jh.jh_c[12] = qj.a(byArray, 2);
        }
        byArray = kb.a(-40, "achievement_criteria,13");
        if (byArray != null) {
            jh.jh_c[13] = qj.a(byArray, 2);
        }
        byArray = kb.a(-28, "achievement_criteria,14");
        if (byArray != null) {
            jh.jh_c[14] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-46, "achievement_criteria,15"))) {
            jh.jh_c[15] = qj.a(byArray, 2);
        }
        byArray = kb.a(-82, "achievement_criteria,16");
        if (byArray != null) {
            jh.jh_c[16] = qj.a(byArray, 2);
        }
        byArray = kb.a(-61, "achievement_criteria,17");
        if (null != byArray) {
            jh.jh_c[17] = qj.a(byArray, 2);
        }
        byArray = kb.a(-87, "achievement_criteria,18");
        if (byArray != null) {
            jh.jh_c[18] = qj.a(byArray, 2);
        }
        byArray = kb.a(-62, "achievement_criteria,19");
        if (byArray != null) {
            jh.jh_c[19] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-123, "achievement_criteria,20")) != null) {
            jh.jh_c[20] = qj.a(byArray, 2);
        }
        byArray = kb.a(-97, "achievement_criteria,21");
        if (byArray != null) {
            jh.jh_c[21] = qj.a(byArray, 2);
        }
        byArray = kb.a(-111, "achievement_criteria,22");
        if (null != byArray) {
            jh.jh_c[22] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-38, "achievement_criteria,23")) != null) {
            jh.jh_c[23] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-86, "achievement_criteria,24")) != null) {
            jh.jh_c[24] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-51, "achievement_criteria,25")) != null) {
            jh.jh_c[25] = qj.a(byArray, 2);
        }
        byArray = kb.a(-117, "achievement_criteria,26");
        if (byArray != null) {
            jh.jh_c[26] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-109, "achievement_criteria,27"))) {
            jh.jh_c[27] = qj.a(byArray, 2);
        }
        byArray = kb.a(-21, "achievement_criteria,28");
        if (null != byArray) {
            jh.jh_c[28] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-16, "achievement_criteria,29"))) {
            jh.jh_c[29] = qj.a(byArray, 2);
        }
        byArray = kb.a(-97, "achievement_criteria,30");
        if (byArray != null) {
            jh.jh_c[30] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-68, "gameoptlabels,0")) != null) {
            si.si_f[0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-72, "gameoptlabels,1");
        if (null != byArray) {
            si.si_f[1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-25, "gameoptlabels,2");
        if (null != byArray) {
            si.si_f[2] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-126, "gameoptlabels,3"))) {
            si.si_f[3] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-90, "gameoptlabels,4")) != null) {
            si.si_f[4] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-58, "gameopt_buttonnames,0,0"))) {
            tg.tg_d[0][0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-116, "gameopt_buttonnames,0,1")) != null) {
            tg.tg_d[0][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-64, "gameopt_buttonnames,1,0");
        if (null != byArray) {
            tg.tg_d[1][0] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-104, "gameopt_buttonnames,1,1"))) {
            tg.tg_d[1][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-77, "gameopt_buttonnames,1,2");
        if (null != byArray) {
            tg.tg_d[1][2] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-25, "gameopt_buttonnames,1,3"))) {
            tg.tg_d[1][3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-37, "gameopt_buttonnames,1,4");
        if (byArray != null) {
            tg.tg_d[1][4] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-105, "gameopt_buttonnames,2,0"))) {
            tg.tg_d[2][0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-37, "gameopt_buttonnames,2,1");
        if (byArray != null) {
            tg.tg_d[2][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-37, "gameopt_buttonnames,2,2");
        if (byArray != null) {
            tg.tg_d[2][2] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-46, "gameopt_buttonnames,2,3"))) {
            tg.tg_d[2][3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-101, "gameopt_buttonnames,2,4");
        if (null != byArray) {
            tg.tg_d[2][4] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-50, "gameopt_buttonnames,3,0")) != null) {
            tg.tg_d[3][0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-106, "gameopt_buttonnames,3,1");
        if (null != byArray) {
            tg.tg_d[3][1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-63, "gameopt_buttonnames,3,2"))) {
            tg.tg_d[3][2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-49, "gameopt_buttonnames,3,3");
        if (null != byArray) {
            tg.tg_d[3][3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-79, "gameopt_buttonnames,3,4");
        if (null != byArray) {
            tg.tg_d[3][4] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-89, "gameopt_buttonnames,4,0")) != null) {
            tg.tg_d[4][0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-36, "gameopt_buttonnames,4,1");
        if (byArray != null) {
            tg.tg_d[4][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-82, "gameopt_buttonnames,4,2");
        if (null != byArray) {
            tg.tg_d[4][2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-18, "gameopt_buttonnames,4,3");
        if (null != byArray) {
            tg.tg_d[4][3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-121, "gameopt_tooltipnames,0,0");
        if (byArray != null) {
            qd.Pb[0][0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-62, "gameopt_tooltipnames,0,1");
        if (null != byArray) {
            qd.Pb[0][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-71, "gameopt_tooltipnames,1,0");
        if (byArray != null) {
            qd.Pb[1][0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-103, "gameopt_tooltipnames,1,1")) != null) {
            qd.Pb[1][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-38, "gameopt_tooltipnames,1,2");
        if (null != byArray) {
            qd.Pb[1][2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-123, "gameopt_tooltipnames,1,3");
        if (byArray != null) {
            qd.Pb[1][3] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-128, "gameopt_tooltipnames,1,4"))) {
            qd.Pb[1][4] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-86, "gameopt_tooltipnames,2,0")) != null) {
            qd.Pb[2][0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-43, "gameopt_tooltipnames,2,1")) != null) {
            qd.Pb[2][1] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-107, "gameopt_tooltipnames,2,2")) != null) {
            qd.Pb[2][2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-80, "gameopt_tooltipnames,2,3");
        if (byArray != null) {
            qd.Pb[2][3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-46, "gameopt_tooltipnames,2,4");
        if (null != byArray) {
            qd.Pb[2][4] = qj.a(byArray, 2);
        }
        byArray = kb.a(-45, "gameopt_tooltipnames,3,0");
        if (null != byArray) {
            qd.Pb[3][0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-17, "gameopt_tooltipnames,3,1");
        if (null != byArray) {
            qd.Pb[3][1] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-51, "gameopt_tooltipnames,3,2")) != null) {
            qd.Pb[3][2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-83, "gameopt_tooltipnames,3,3");
        if (null != byArray) {
            qd.Pb[3][3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-118, "gameopt_tooltipnames,3,4");
        if (null != byArray) {
            qd.Pb[3][4] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-79, "gameopt_tooltipnames,4,0")) != null) {
            qd.Pb[4][0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-116, "gameopt_tooltipnames,4,1");
        if (byArray != null) {
            qd.Pb[4][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-63, "gameopt_tooltipnames,4,2");
        if (null != byArray) {
            qd.Pb[4][2] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-28, "instructions_titles_thebasics")) != null) {
            kc.kc_s = qj.a(byArray, 2);
        }
        byArray = kb.a(-46, "instructions_titles_thecontrols");
        if (null != byArray) {
            ug.ug_n = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-116, "instructions_titles_thetwist")) != null) {
            bj.bj_c = qj.a(byArray, 2);
        }
        byArray = kb.a(-58, "instructions_titles_inmultiplayer");
        if (null != byArray) {
            kc.kc_q = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-94, "instructions_titles_insingleplayer"))) {
            fm.fm_c = qj.a(byArray, 2);
        }
        byArray = kb.a(-36, "instructions_titles_specialitems");
        if (null != byArray) {
            mb.mb_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-28, "instructions_titles_activatingspecialitems");
        if (byArray != null) {
            hg.hg_d = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-89, "instructions_piecesarefalling"))) {
            cc.cc_d = qj.a(byArray, 2);
        }
        byArray = kb.a(-42, "instructions_matchthepieces");
        if (null != byArray) {
            dn.dn_q = qj.a(byArray, 2);
        }
        byArray = kb.a(-121, "instructions_machinetransforms");
        if (byArray != null) {
            rf.rf_i = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-62, "instructions_clearingsolids"))) {
            rk.N = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-52, "instructions_multiplayer_solids")) != null) {
            di.D = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-69, "instructions_singleplayer_solids"))) {
            ah.ah_g = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-122, "instructions_wildcard"))) {
            nk.nk_c = qj.a(byArray, 2);
        }
        byArray = kb.a(-122, "instructions_gettingspecials");
        if (byArray != null) {
            kb.kb_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-33, "instructions_activatingspecials");
        if (byArray != null) {
            dk.dk_f = qj.a(byArray, 2);
        }
        byArray = kb.a(-65, "instructions_multiplayer_specials");
        if (null != byArray) {
            ki.ki_u = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-47, "instructions_itemdescriptions,0,0")) != null) {
            nk.nk_d[0][0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-17, "instructions_itemdescriptions,0,1")) != null) {
            nk.nk_d[0][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-98, "instructions_itemdescriptions,1,0");
        if (byArray != null) {
            nk.nk_d[1][0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-103, "instructions_itemdescriptions,1,1")) != null) {
            nk.nk_d[1][1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-27, "instructions_itemdescriptions,2,0"))) {
            nk.nk_d[2][0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-82, "instructions_itemdescriptions,2,1");
        if (byArray != null) {
            nk.nk_d[2][1] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-53, "instructions_itemdescriptions,3,0")) != null) {
            nk.nk_d[3][0] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-128, "instructions_itemdescriptions,3,1"))) {
            nk.nk_d[3][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-79, "instructions_itemdescriptions,4,0");
        if (byArray != null) {
            nk.nk_d[4][0] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-123, "instructions_itemdescriptions,4,1"))) {
            nk.nk_d[4][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-62, "instructions_itemdescriptions,5,0");
        if (byArray != null) {
            nk.nk_d[5][0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-60, "instructions_itemdescriptions,5,1")) != null) {
            nk.nk_d[5][1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-102, "instructions_itemdescriptions,6,0"))) {
            nk.nk_d[6][0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-55, "instructions_itemdescriptions,6,1")) != null) {
            nk.nk_d[6][1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-124, "instructions_controls,0");
        if (null != byArray) {
            vk.vk_b[0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-92, "instructions_controls,1")) != null) {
            vk.vk_b[1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-117, "instructions_controls,2");
        if (byArray != null) {
            vk.vk_b[2] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-108, "instructions_controls,3")) != null) {
            vk.vk_b[3] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-61, "instructions_controls,4")) != null) {
            vk.vk_b[4] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-61, "instructions_controls,5"))) {
            vk.vk_b[5] = qj.a(byArray, 2);
        }
        byArray = kb.a(-31, "instructions_controls,6");
        if (byArray != null) {
            vk.vk_b[6] = qj.a(byArray, 2);
        }
        byArray = kb.a(-53, "didyouknow_title");
        if (null != byArray) {
            o.o_c = qj.a(byArray, 2);
        }
        byArray = kb.a(-87, "didyouknow,0");
        if (null != byArray) {
            jg.jg_k[0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-89, "didyouknow,1");
        if (byArray != null) {
            jg.jg_k[1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-112, "didyouknow,2"))) {
            jg.jg_k[2] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-72, "didyouknow,3"))) {
            jg.jg_k[3] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-127, "didyouknow,4"))) {
            jg.jg_k[4] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-32, "didyouknow,5")) != null) {
            jg.jg_k[5] = qj.a(byArray, 2);
        }
        byArray = kb.a(-116, "didyouknow,6");
        if (null != byArray) {
            jg.jg_k[6] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-97, "didyouknow,7"))) {
            jg.jg_k[7] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-117, "didyouknow,8")) != null) {
            jg.jg_k[8] = qj.a(byArray, 2);
        }
        byArray = kb.a(-112, "didyouknow,9");
        if (null != byArray) {
            jg.jg_k[9] = qj.a(byArray, 2);
        }
        byArray = kb.a(-99, "didyouknow,10");
        if (null != byArray) {
            jg.jg_k[10] = qj.a(byArray, 2);
        }
        byArray = kb.a(-57, "didyouknow,11");
        if (byArray != null) {
            jg.jg_k[11] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-104, "tutorial,0")) != null) {
            rk.O[0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-90, "tutorial,1");
        if (null != byArray) {
            rk.O[1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-77, "tutorial,2");
        if (null != byArray) {
            rk.O[2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-76, "tutorial,3");
        if (byArray != null) {
            rk.O[3] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-97, "to_activate_specials"))) {
            qe.qe_j = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-49, "premultiplayer_tutorial,0"))) {
            sg.sg_h[0] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-42, "premultiplayer_tutorial,1")) != null) {
            sg.sg_h[1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-36, "masterchallengeintro,0"))) {
            uj.uj_f[0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-52, "masterchallengeintro,1");
        if (byArray != null) {
            uj.uj_f[1] = qj.a(byArray, 2);
        }
        byArray = kb.a(-78, "showtutorialagain");
        if (byArray != null) {
            vb.T = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-83, "challengestrategy,0"))) {
            jj.jj_d[0] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-39, "challengestrategy,1"))) {
            jj.jj_d[1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-73, "challengestrategy,2"))) {
            jj.jj_d[2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-75, "challengestrategy,3");
        if (byArray != null) {
            jj.jj_d[3] = qj.a(byArray, 2);
        }
        byArray = kb.a(-54, "challengestrategy,4");
        if (null != byArray) {
            jj.jj_d[4] = qj.a(byArray, 2);
        }
        byArray = kb.a(-96, "challengestrategy,5");
        if (byArray != null) {
            jj.jj_d[5] = qj.a(byArray, 2);
        }
        byArray = kb.a(-67, "challengestrategy,6");
        if (null != byArray) {
            jj.jj_d[6] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-60, "challengestrategy,7"))) {
            jj.jj_d[7] = qj.a(byArray, 2);
        }
        byArray = kb.a(-16, "x_at_once");
        if (null != byArray) {
            on.on_h = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-59, "x_chain")) != null) {
            e.e_d = qj.a(byArray, 2);
        }
        byArray = kb.a(-35, "x_shapes");
        if (null != byArray) {
            uj.uj_b = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-95, "start"))) {
            sk.sk_i = qj.a(byArray, 2);
        }
        byArray = kb.a(-72, "challenge");
        if (null != byArray) {
            ka.M = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-89, "new_theme_unlocked"))) {
            tb.tb_a = qj.a(byArray, 2);
        }
        byArray = kb.a(-110, "speedup");
        if (byArray != null) {
            eb.eb_c = qj.a(byArray, 2);
        }
        byArray = kb.a(-61, "panic");
        if (byArray != null) {
            bn.bn_c = qj.a(byArray, 2);
        }
        byArray = kb.a(-90, "fight");
        if (null != byArray) {
            cf.cf_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-93, "finish_name");
        if (byArray != null) {
            pc.pc_a = qj.a(byArray, 2);
        }
        byArray = kb.a(-60, "you_win");
        if (byArray != null) {
            cn.T = qj.a(byArray, 2);
        }
        byArray = kb.a(-36, "name_wins");
        if (null != byArray) {
            fh.fh_b = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-107, "draw"))) {
            ri.ri_k = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-100, "well_done"))) {
            ua.D = qj.a(byArray, 2);
        }
        byArray = kb.a(-101, "oh_no");
        if (byArray != null) {
            cb.cb_i = qj.a(byArray, 2);
        }
        byArray = kb.a(-61, "thefinal");
        if (byArray != null) {
            ji.ji_h = qj.a(byArray, 2);
        }
        byArray = kb.a(-70, "name_is_out");
        if (null != byArray) {
            a.a_e = qj.a(byArray, 2);
        }
        byArray = kb.a(-40, "main_menu_ticker,0");
        if (null != byArray) {
            pb.pb_f[0] = qj.a(byArray, 2);
        }
        byArray = kb.a(-59, "main_menu_ticker,1");
        if (null != byArray) {
            pb.pb_f[1] = qj.a(byArray, 2);
        }
        if (null != (byArray = kb.a(-34, "main_menu_ticker,2"))) {
            pb.pb_f[2] = qj.a(byArray, 2);
        }
        byArray = kb.a(-87, "main_menu_ticker,3");
        if (null != byArray) {
            pb.pb_f[3] = qj.a(byArray, 2);
        }
        if ((byArray = kb.a(-101, "devquote")) != null) {
            ph.Cb = qj.a(byArray, 2);
        }
        pc.pc_b = null;
    }

    static {
        sh_h = "Drawn";
        sh_e = "Colours in play:";
        sh_b = "<%0> has dropped out.";
        sh_c = "Retry";
    }
}
