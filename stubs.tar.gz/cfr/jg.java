/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class jg {
    private boolean jg_l;
    static int[] jg_f;
    static String[] jg_k;
    static boolean jg_i;
    private String jg_d;
    static int jg_g;
    static ud jg_j;
    static int[] jg_h;
    static String jg_c;
    static byte[][][] jg_b;
    static volatile boolean jg_e;
    static ui jg_a;

    public static void b(byte by) {
        jg_k = null;
        jg_f = null;
        jg_h = null;
        jg_a = null;
        jg_j = null;
        int n = 26 / ((-24 - by) / 49);
        jg_b = null;
        jg_c = null;
    }

    static final void a(Applet applet, int n) {
        vf.vf_a = true;
        if (n != 0) {
            jg_f = null;
        }
        String string = "tuhstatbut";
        String string2 = "rvnadlm";
        long l = -1L;
        pf.a(applet, string, l, (byte)89, string2);
    }

    final boolean a(boolean bl) {
        block0: {
            if (bl) break block0;
            jg.a(-65);
        }
        return this.jg_l;
    }

    static final void a(boolean bl, String string) {
        hl.hl_a = string;
        if (!bl) {
            return;
        }
        hm.a(12, (byte)-111);
    }

    static final ui a(boolean bl, pl pl2, int n, int n2, ji ji2) {
        byte[] byArray = ji2.a(n, 108, n2);
        if (!bl) {
            String string = null;
            jg.a(false, string);
        }
        if (byArray == null) {
            return null;
        }
        return new ui(new wl(byArray), pl2);
    }

    static final w b(boolean bl) {
        block0: {
            if (!bl) break block0;
            ji ji2 = null;
            jg.a(true, null, 58, 53, ji2);
        }
        return gf.gf_c.Ob;
    }

    static long a(long l, long l2) {
        return l & l2;
    }

    jg(String string, boolean bl) {
        block1: {
            this.jg_d = string;
            if (this.jg_d == null) {
                this.jg_d = "";
            }
            this.jg_l = bl;
            if (~this.jg_d.length() != -1) break block1;
            this.jg_l = false;
        }
    }

    final String a(byte by) {
        block0: {
            if (by == 56) break block0;
            ji ji2 = null;
            jg.a(true, null, -94, -75, ji2);
        }
        return this.jg_d;
    }

    jg(String string) {
        this(string, false);
    }

    static final void a(int n) {
        block0: {
            pl.a(3970);
            if (n < -38) break block0;
            jg_h = null;
        }
    }

    static {
        jg_i = true;
        jg_g = 0;
        jg_k = new String[]{"This shape is called a Deko:", "This shape is called a Bloko:", "You can activate special items by popping shapes next to them.", "Using 'Z' and 'X' for rotation will give you more control.", "If you pop 2 or more shapes in one go, you will be awarded a special item!", "If you pop 4 or more shapes in one go, you will be awarded 2 special items!", "If you pop 7 or more shapes in one go, you will be awarded 4 special items!", "In multiplayer, any special items you earn will be given to both you and your victim.", "Dropping shapes quickly using the 'DOWN' arrow will give you 'fast drop' bonus points.", "Try popping several shapes simultaneously for bonus points!", "Try popping several shapes in a row for bonus points! This is called a chain.", "A chain of 2 will give you 1000 points, but a chain of 4 will give you 6000 points!"};
        jg_c = "Players: ";
        jg_h = new int[8192];
        jg_e = false;
    }
}
