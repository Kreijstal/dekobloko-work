/*
 * Decompiled with CFR 0.152.
 */
import java.util.zip.CRC32;

final class ab {
    static String ab_a = "Resign";
    static int ab_e = 64;
    static CRC32 ab_c = new CRC32();
    private be ab_b;
    static int ab_f;
    private be ab_g;
    static String ab_d;

    static final int e(int n) {
        int n2 = 0;
        if (lg.W > n2) {
            n2 = lg.W;
        }
        if (~n2 > ~bf.bf_r) {
            n2 = bf.bf_r;
        }
        if (n != -28199) {
            ab_e = -18;
        }
        if (tg.tg_e > n2) {
            n2 = tg.tg_e;
        }
        return n2;
    }

    final be b(byte by) {
        be be2 = this.ab_g;
        if (be2 == this.ab_b) {
            this.ab_g = null;
            return null;
        }
        if (by != 20) {
            return null;
        }
        this.ab_g = be2.be_p;
        return be2;
    }

    final void a(be be2, int n) {
        block1: {
            if (be2.be_v != null) {
                be2.e((byte)101);
            }
            be2.be_p = this.ab_b;
            be2.be_v = this.ab_b.be_v;
            be2.be_v.be_p = be2;
            be2.be_p.be_v = be2;
            if (n == -7267) break block1;
            be be3 = null;
            this.a(be3, 54);
        }
    }

    final be a(byte by) {
        be be2 = this.ab_b.be_p;
        if (this.ab_b == be2) {
            return null;
        }
        be2.e((byte)94);
        int n = 27 / ((1 - by) / 39);
        return be2;
    }

    final be b(int n) {
        be be2;
        if (n != -2198) {
            this.b(61);
        }
        if (this.ab_b == (be2 = this.ab_b.be_p)) {
            this.ab_g = null;
            return null;
        }
        this.ab_g = be2.be_p;
        return be2;
    }

    static final long a(int n, CharSequence charSequence) {
        boolean bl = client.A;
        long l = 0L;
        int n2 = charSequence.length();
        int n3 = 0;
        while (~n3 > ~n2) {
            l *= 37L;
            char c2 = charSequence.charAt(n3);
            if (c2 >= 'A' && c2 <= 'Z') {
                l += (long)(-65 + c2 + 1);
            } else if ('a' <= c2 && c2 <= 'z') {
                l += (long)(-97 + (c2 + '\u0001'));
            } else if (c2 >= '0' && '9' >= c2) {
                l += (long)(c2 + 27 - 48);
            }
            if (l >= 177917621779460413L) break;
            ++n3;
        }
        if (n <= 95) {
            ab_f = -6;
        }
        while (0L == l % 37L && l != 0L) {
            l /= 37L;
        }
        return l;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final boolean c(byte by) {
        int n2 = 108 % ((-69 - by) / 50);
        n n3 = f.f_r;
        synchronized (n3) {
            if (~ea.ea_n == ~sf.B) {
                return false;
            }
            wh.wh_c = pf.pf_i[sf.B];
            el.G = bl.Z[sf.B];
            sf.B = 1 + sf.B & 0x7F;
            return true;
        }
    }

    public static void d(int n2) {
        ab_c = null;
        ab_a = null;
        if (n2 != 1) {
            ab.e(-99);
        }
        ab_d = null;
    }

    final int a(int n2) {
        boolean bl2 = client.A;
        int n3 = n2;
        be be2 = this.ab_b.be_p;
        while (be2 != this.ab_b) {
            ++n3;
            be2 = be2.be_p;
        }
        return n3;
    }

    static final boolean c(int n2) {
        if (n2 != 48) {
            ab.c((byte)45);
        }
        return null != kb.kb_i || jh.jh_h;
    }

    public ab() {
        this.ab_b.be_v = this.ab_b = new be();
        this.ab_b.be_p = this.ab_b;
    }

    static {
        ab_d = "Unfortunately you are not eligible to create an account.";
    }
}
