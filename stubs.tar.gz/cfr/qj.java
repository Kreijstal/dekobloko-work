/*
 * Decompiled with CFR 0.152.
 */
final class qj
implements gl {
    private int qj_a;
    private int qj_c;
    static String qj_g = "On";
    static boolean qj_k;
    private int qj_f;
    static String qj_e;
    private int qj_h;
    private int qj_i;
    private mm qj_j;
    static ck qj_d;
    private int qj_b;

    static final void a(byte by) {
        if (null != dj.dj_cb) {
            try {
                dj.dj_cb.a(0L, (byte)-109);
                dj.dj_cb.a(de.V.wl_r, (byte)117, de.V.wl_n, 24);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if (by != 64) {
            return;
        }
        de.V.wl_n += 24;
    }

    static final ke a(int n, boolean bl2) {
        ke ke2;
        block2: {
            ec ec2;
            ke ke3;
            ke2 = ke3 = new ke(4);
            if (ph.n(-30146)) {
                ec2 = new ec(20, qn.qn_rb, a.a_t);
                ec2.ec_l = 320 - ec2.ec_n / 2;
                ec2.ec_m = 372;
                ke2.a(ec2, 122);
            } else {
                ec ec3;
                ke3.a(new ec(22, sf.E[0], a.a_t), 127);
                ke3.a(new ec(22, sf.E[1], a.a_t), 120);
                ke3.a(new ec(22, sf.E[2], a.a_t), 117);
                ec2 = ec3 = ke3.ke_f[0];
                ec ec4 = ke3.ke_f[1];
                ke3.ke_f[2].ec_n = 185;
                ec4.ec_n = 185;
                ec3.ec_n = 185;
                ke3.ke_f[0].ec_l = 120 + -(ke3.ke_f[0].ec_n / 2);
                ke3.ke_f[1].ec_l = -(ke3.ke_f[1].ec_n / 2) + 320;
                ke3.ke_f[2].ec_l = -(ke3.ke_f[2].ec_n / 2) + 520;
                ec ec5 = ke3.ke_f[0];
                ec ec6 = ke3.ke_f[1];
                ke3.ke_f[2].ec_m = 372;
                ec6.ec_m = 372;
                ec5.ec_m = 372;
            }
            ec2 = new ec(13, pc.pc_f, a.a_t);
            ec2.ec_l = -(ec2.ec_n / 2) + 320;
            ec2.ec_m = 415;
            ke2.a(ec2, 115);
            ke2.ke_q = 272;
            ke2.y = 500;
            ke2.ke_w = 70;
            ke2.z = 76;
            ke2.a(fc.fc_e, bl2, -129);
            if (n <= -3) break block2;
            qj_e = null;
        }
        return ke2;
    }

    @Override
    public final void a(boolean bl2, int n, int n2, byte by, ce ce2) {
        block3: {
            boolean bl3 = client.A;
            b b2 = (b)(!(ce2 instanceof b) ? null : ce2);
            hk.a(ce2.ce_u + n, n2 - -ce2.D, ce2.ce_t, ce2.y, this.qj_b);
            if (null == b2) {
                // empty if block
            }
            int n3 = -(2 * b2.L) + ce2.ce_t;
            int n4 = b2.L + ce2.ce_u + n;
            int n5 = ce2.D + n2 + b2.K;
            hk.b(n4, n5, n3 + n4, n5, this.qj_i);
            if (by > -60) {
                return;
            }
            int n6 = -1 + b2.b(true);
            while (-1 >= ~n6) {
                hk.e(b2.b(-1, n6) * n3 / b2.i(-15317) + n4, n5, this.qj_h, this.qj_a);
                --n6;
            }
            if (null == this.qj_j) break block3;
            this.qj_j.b(b2.E, n4 - -(n3 / 2), b2.K + this.qj_j.S + n5, this.qj_f, this.qj_c);
        }
    }

    public static void b(byte by) {
        qj_d = null;
        qj_g = null;
        if (by <= 118) {
            return;
        }
        qj_e = null;
    }

    static final String a(byte[] byArray, int n) {
        block0: {
            if (n == 2) break block0;
            qj_k = false;
        }
        return un.a(byArray, 0, 0, byArray.length);
    }

    qj(mm mm2, int n, int n2, int n3, int n4, int n5, int n6) {
        this.qj_f = n;
        this.qj_h = n5;
        this.qj_a = n6;
        this.qj_c = n2;
        this.qj_b = n4;
        this.qj_j = mm2;
        this.qj_i = n3;
    }

    static {
        qj_e = "Location";
    }
}
