/*
 * Decompiled with CFR 0.152.
 */
final class v {
    static String v_g;
    static String v_c;
    static boolean v_d;
    static String v_b;
    static String v_f;
    static String v_e;
    static byte[] v_a;

    static final boolean a(char c, int n) {
        if (n != -24380) {
            v.a(null, true, null, -23);
        }
        return c >= 'A' && c <= 'Z' || c >= 'a' && 'z' >= c;
    }

    static final void b(int n) {
        if (n != 0) {
            v.b(118);
        }
        be.a((byte)123, vk.vk_a);
    }

    public static void a(int n) {
        v_c = null;
        v_b = null;
        v_a = null;
        v_g = null;
        v_f = null;
        if (n != -66) {
            v_d = true;
        }
        v_e = null;
    }

    static final short[] a(uf uf2, boolean bl, short[] sArray, int n) {
        int n2;
        boolean bl2 = client.A;
        if (!bl) {
            v.a('\u000e', -20);
        }
        if (~(n2 = uf2.a(n, (byte)110)) == -1) {
            return null;
        }
        if (sArray == null || ~sArray.length != ~n2) {
            sArray = new short[n2];
        }
        int n3 = uf2.a(4, (byte)123);
        short s = (short)uf2.a(16, (byte)46);
        if (n3 <= 0) {
            int n4 = 0;
            while (~n2 < ~n4) {
                sArray[n4] = s;
                ++n4;
            }
        } else {
            for (int i = 0; n2 > i; ++i) {
                sArray[i] = (short)(uf2.a(n3, (byte)99) + s);
            }
        }
        return sArray;
    }

    static {
        v_c = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        v_g = "Email: ";
        v_b = "Unpacking music";
        v_d = true;
        v_f = "Resigned";
        v_e = "Mouse over an icon for details";
    }
}
