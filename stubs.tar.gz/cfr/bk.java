/*
 * Decompiled with CFR 0.152.
 */
final class bk
extends w {
    static String Nb = "Game options";
    static w Rb;
    private w Pb;
    static String Qb;
    static String Ob;

    public static void e(int n) {
        if (n != 15338) {
            Nb = null;
        }
        Nb = null;
        Ob = null;
        Qb = null;
        Rb = null;
    }

    bk(w w2, w w3, w w4, w w5, w w6, w w7) {
        w w8 = new w(0L, w3, gk.Gb.toUpperCase());
        w8.X = 1;
        this.Pb = new w(0L, w4);
        w w9 = new w(0L, w5);
        w w10 = new w(0L, w5, dc.dc_c);
        w10.X = 1;
        int n = 50;
        int n2 = 0;
        for (int i = 0; i < dk.dk_j.length; ++i) {
            w w11 = new w(0L, w5, uf.B[i]);
            w w12 = new w(0L, w5, dk.dk_j[i]);
            int n3 = w5.J.a(dk.dk_j[i]);
            if (n3 > n2) {
                n2 = n3;
            }
            w11.a(65, 0, n, 15, 20);
            w12.a(640, 0, n, 15, 90);
            w9.a(w11, -16834);
            w9.a(w12, -16834);
            n += 30;
        }
        w8.a(20 + n2 - -90, 0, 0, 24, 0);
        this.a(w8.w_mb, 0, 100, (n += 15) - -w8.N, 100);
        this.Pb.a(15, 0, 5, 15, w8.w_mb + -20);
        w9.a(this.w_mb, 0, w8.N, this.N - w8.N, 0);
        w10.a(this.w_mb, 0, 20, 15, 0);
        w9.w_lb = ea.a(0x202020, -20982, 3, w9.N, 0x808080, 0xB0B0B0);
        w8.a(this.Pb, -16834);
        w9.a(w10, -16834);
        this.a(w8, -16834);
        this.a(w9, -16834);
        this.w_vb = -(this.w_mb >> 1562314049) + 320;
        n = -(this.N >> 757186753) + 240;
    }

    final boolean b(int n, boolean bl) {
        if (n != -1) {
            vj vj2 = null;
            bk.a((byte)4, 96, vj2);
        }
        this.a(false, true);
        return -1 != ~ig.Yb && -1 == ~this.w_ob || -1 != ~this.Pb.w_ob;
    }

    static final void a(byte by, int n, vj vj2) {
        uk uk2;
        boolean bl = client.A;
        if (by != -93) {
            bk.e(40);
        }
        uk uk3 = uk2 = (uk)vj2.c((byte)-119);
        while (uk2 != null) {
            uk2.b(11976, n);
            uk3 = (uk)vj2.d(true);
        }
    }

    static {
        Qb = "Elapsed time";
        Ob = "Waiting for extra data";
    }
}
