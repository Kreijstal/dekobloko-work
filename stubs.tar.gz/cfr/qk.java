/*
 * Decompiled with CFR 0.152.
 */
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

final class qk
implements Runnable {
    private fd qk_j;
    static int qk_d;
    private InputStream qk_o;
    private boolean qk_g = false;
    static int qk_a;
    private int qk_r;
    private mh qk_p;
    static int qk_n;
    static int qk_m;
    private Socket qk_l;
    private int qk_q = 0;
    private boolean qk_c = false;
    private OutputStream qk_b;
    static String[] qk_s;
    static int qk_i;
    private byte[] qk_h;
    static int qk_k;
    static String[] qk_e;
    private int qk_f = 0;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final void a(int n, int n2, int n3, byte[] byArray) throws IOException {
        boolean bl = client.A;
        if (this.qk_g) {
            return;
        }
        if (n3 != 1) {
            qk_s = null;
        }
        if (this.qk_c) {
            this.qk_c = false;
            throw new IOException();
        }
        if (this.qk_h == null) {
            this.qk_h = new byte[this.qk_r];
        }
        qk qk2 = this;
        synchronized (qk2) {
            for (int i = 0; i < n2; ++i) {
                this.qk_h[this.qk_f] = byArray[n + i];
                this.qk_f = (1 + this.qk_f) % this.qk_r;
                if (this.qk_f != (this.qk_r + this.qk_q + -100) % this.qk_r) continue;
                throw new IOException();
            }
            if (null == this.qk_p) {
                this.qk_p = this.qk_j.a((byte)-45, 3, this);
            }
            this.notifyAll();
        }
    }

    final int c(byte by) throws IOException {
        if (this.qk_g) {
            return 0;
        }
        int n = -99 % ((-44 - by) / 41);
        return this.qk_o.read();
    }

    static final String d(byte by) {
        boolean bl = client.A;
        String string = "(" + lg.U + " " + bb.bb_d + " " + kf.L + ") " + bh.bh_k;
        if (by < 14) {
            return null;
        }
        if (-1 > ~sm.sm_e) {
            string = string + ":";
            for (int i = 0; i < sm.sm_e; ++i) {
                string = string + ' ';
                int n = de.V.wl_r[i] & 0xFF;
                int n2 = n >> -1389597532;
                n2 = n2 < 10 ? (n2 += 48) : (n2 += 55);
                string = string + (char)n2;
                n = -11 < ~(n &= 0xF) ? (n += 48) : (n += 55);
                string = string + (char)n;
            }
        }
        return string;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final void a(int n) {
        boolean bl = client.A;
        if (this.qk_g) {
            return;
        }
        qk qk2 = this;
        synchronized (qk2) {
            this.qk_g = true;
            this.notifyAll();
        }
        if (n != 0) {
            return;
        }
        if (null != this.qk_p) {
            while (this.qk_p.mh_c == 0) {
                ua.a(1L, n ^ 0xFFFFFF80);
            }
            if (1 == this.qk_p.mh_c) {
                try {
                    ((Thread)this.qk_p.mh_b).join();
                }
                catch (InterruptedException interruptedException) {
                    // empty catch block
                }
            }
        }
        this.qk_p = null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public final void run() {
        boolean bl = client.A;
        try {
            while (true) {
                int n;
                int n2;
                qk qk2 = this;
                synchronized (qk2) {
                    if (~this.qk_f == ~this.qk_q) {
                        if (this.qk_g) {
                            break;
                        }
                        try {
                            this.wait();
                        }
                        catch (InterruptedException interruptedException) {
                            // empty catch block
                        }
                    }
                    n2 = this.qk_q;
                    n = this.qk_q <= this.qk_f ? this.qk_f + -this.qk_q : this.qk_r - this.qk_q;
                }
                if (~n >= -1) continue;
                try {
                    this.qk_b.write(this.qk_h, n2, n);
                }
                catch (IOException iOException) {
                    this.qk_c = true;
                }
                this.qk_q = (n + this.qk_q) % this.qk_r;
                try {
                    if (this.qk_f != this.qk_q) continue;
                    this.qk_b.flush();
                }
                catch (IOException iOException) {
                    this.qk_c = true;
                }
            }
            try {
                if (null != this.qk_o) {
                    this.qk_o.close();
                }
                if (null != this.qk_b) {
                    this.qk_b.close();
                }
                if (null != this.qk_l) {
                    this.qk_l.close();
                }
            }
            catch (IOException iOException) {
                // empty catch block
            }
            this.qk_h = null;
        }
        catch (Exception exception) {
            qb.a(exception, 16408, null);
        }
    }

    protected final void finalize() {
        this.a(0);
    }

    static final Object a(byte[] byArray, int n, boolean bl) {
        if (null == byArray) {
            return null;
        }
        if (136 < byArray.length) {
            fn fn2 = new fn();
            ((mk)fn2).a(byArray, true);
            return fn2;
        }
        if (n != -1389597532) {
            qk_i = 67;
        }
        if (bl) {
            return jd.a(0, byArray);
        }
        return byArray;
    }

    final int b(int n) throws IOException {
        if (this.qk_g) {
            return 0;
        }
        if (n != 0) {
            return -106;
        }
        return this.qk_o.available();
    }

    public static void c(int n) {
        qk_e = null;
        if (n != -11657) {
            return;
        }
        qk_s = null;
    }

    final void a(int n, int n2, byte by, byte[] byArray) throws IOException {
        block3: {
            boolean bl = client.A;
            if (this.qk_g) {
                return;
            }
            while (-1 > ~n) {
                int n3 = this.qk_o.read(byArray, n2, n);
                if (0 >= n3) {
                    throw new EOFException();
                }
                n2 += n3;
                n -= n3;
            }
            if (by == 17) break block3;
            this.a(31);
        }
    }

    final void b(byte by) throws IOException {
        if (this.qk_g) {
            return;
        }
        if (by > -21) {
            return;
        }
        if (this.qk_c) {
            this.qk_c = false;
            throw new IOException();
        }
    }

    qk(Socket socket, fd fd2) throws IOException {
        this(socket, fd2, 5000);
    }

    static final void a(byte by) {
        block0: {
            dj.dj_ab.setLength(0);
            pk.pk_r = 0;
            if (by == 94) break block0;
            qk_d = -4;
        }
    }

    private qk(Socket socket, fd fd2, int n) throws IOException {
        this.qk_j = fd2;
        this.qk_l = socket;
        this.qk_l.setSoTimeout(30000);
        this.qk_l.setTcpNoDelay(true);
        this.qk_o = this.qk_l.getInputStream();
        this.qk_b = this.qk_l.getOutputStream();
        this.qk_r = n;
    }

    static {
        qk_s = new String[]{"Deko Bloko", "Double Deko", "Triple Deko", "Mega Deko", "Double Bloko", "Triple Bloko", "Mini Bombo", "Maxi Bombo", "Tower Bloko", "Massive Attako", "Clean Sweepo", "Uh-Oh Bloko", "Floral Bloko", "Urban Bloko", "Retro Bloko", "Bronze Blokker", "Silver Blokker", "Gold Blokker", "Blok of Beginning", "Blok of Victory", "Blok of Supremacy", "Deko Pwnage", "Ultimate Pwnage", "Quick Deko", "Safe Deko", "Deko Modo", "Shape Mover", "Shape Sender", "Shape Dispatcher", "Shape Consigner", "Shape Shifter"};
        qk_e = new String[]{null, "to discard it and<nbsp>continue.", "to discard it and<nbsp>continue.", "to discard them and<nbsp>continue.", "to discard them and<nbsp>continue.", "to discard them and<nbsp>continue.", "to discard them and<nbsp>continue.", "to discard them and<nbsp>continue."};
    }
}
