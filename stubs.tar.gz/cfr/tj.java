/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;

final class tj
extends w {
    long Nb;
    static String tj_ac = "Show chat";
    boolean tj_ec;
    int tj_dc;
    w Ob;
    boolean tj_fc;
    static boolean Vb;
    static int[][] tj_jc;
    String Rb;
    w Tb;
    int Ub;
    int Sb;
    static int Pb;
    boolean tj_bc;
    w Zb;
    long tj_cc;
    int Xb;
    int Qb;
    w gc;
    w Wb;
    static String tj_ic;
    String Yb;
    int tj_hc;

    static final int a(int n, int n2, byte[] byArray) {
        if (n2 != 0) {
            return -27;
        }
        return pe.a(byArray, n, n2 + -112, 0);
    }

    final boolean a(int n, tj tj2) {
        if (!tj2.tj_fc == this.tj_fc) {
            return this.tj_fc;
        }
        if (n != -985) {
            this.tj_fc = false;
        }
        if (tj2.tj_bc == !this.tj_bc) {
            return this.tj_bc;
        }
        return (this.Nb ^ 0xFFFFFFFFFFFFFFFFL) > (tj2.Nb ^ 0xFFFFFFFFFFFFFFFFL);
    }

    static final void a(boolean bl, int n) {
        sc.sc_n = 0;
        if (n < 97) {
            tj.e(-61);
        }
        rb.rb_b = 0;
        ac.F = dk.dk_i;
        wh.wh_a = 0;
        rg.rg_a = new sk(2);
        rg.rg_a.a(-1, 0, ak.a(bh.bh_g, pm.pm_f, (byte)7), bl);
    }

    final boolean g(byte by) {
        if (by <= 29) {
            this.Xb = 50;
        }
        return !this.d((byte)-68);
    }

    static final void a(boolean bl, Canvas canvas) {
        block1: {
            rf.a(12, canvas);
            if (bl) {
                return;
            }
            qf.a((byte)-35, canvas);
            if (uc.uc_e == null) break block1;
            uc.uc_e.a(68, canvas);
        }
    }

    public static void e(int n) {
        tj_jc = null;
        if (n != -18263) {
            return;
        }
        tj_ic = null;
        tj_ac = null;
    }

    static final void h(byte by) {
        if (by > -22) {
            return;
        }
        aj.aj_a = new w(0L, null);
        if (pd.pd_a) {
            aj.aj_a.a(fn.fn_g, -16834);
        }
        aj.aj_a.a(gg.y, -16834);
        dc.dc_e = new ak(uc.uc_b, aj.aj_a);
        g.R = new w(0L, null);
        g.R.a(dc.dc_e.ak_h, -16834);
        g.R.a(uh.uh_c, -16834);
        mf.h(5);
    }

    tj(String string, String string2, long l) {
        super(0L, null);
        this.Rb = string;
        this.Yb = string2;
        this.tj_cc = l;
        kf.a(this.Rb, (byte)2);
    }

    final void a(byte by, String string, String string2) {
        this.Rb = string2;
        if (by < 10) {
            this.Wb = null;
        }
        this.Yb = string;
        kf.a(this.Rb, (byte)2);
    }

    static {
        tj_ic = "Unfortunately we are unable to create an account for you at this time.";
    }
}
