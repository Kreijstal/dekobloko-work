/*
 * Decompiled with CFR 0.152.
 */
final class lb {
    static String lb_a;
    static boolean lb_b;
    int lb_e;
    static String lb_c;
    vj lb_g;
    static ck lb_h;
    static String lb_i;
    int lb_f;
    static long lb_d;

    public static void a(int n) {
        lb_a = null;
        lb_c = null;
        if (n != -19893) {
            lb.a(101);
        }
        lb_h = null;
        lb_i = null;
    }

    static int a(int n, int n2) {
        return n & n2;
    }

    lb() {
    }

    static {
        lb_b = true;
        lb_a = "You must play <%1> more rated games before playing with the current options.";
        lb_c = "Show chat (1 unread message)";
        lb_i = "Inviting <%0>";
    }
}
