/*
 * Decompiled with CFR 0.152.
 */
final class ug
extends bh {
    static int[] ug_q;
    int ug_o;
    static String ug_n;
    int ug_p;

    static final void a(vg vg2, int n, int n2, int n3, boolean bl, int n4, int n5, int n6) {
        int n7;
        int n8;
        int n9;
        int[] nArray;
        boolean bl2 = client.A;
        vg vg3 = vg2;
        if (bl) {
            ug_q = null;
        }
        if (vg3.Q != null && ~vg3.B < -2) {
            byte[] byArray = vg3.Q;
            sh.a(byArray, -25724, 0, nm.Nb, 0);
        } else {
            kh.a(2);
        }
        int[] nArray2 = nArray = new int[vg2.D];
        int[] nArray3 = new int[vg2.D];
        int[] nArray4 = id.M;
        int[] nArray5 = bc.I;
        int[] nArray6 = sf.C;
        int n10 = 0;
        while (~vg2.D < ~n10) {
            n9 = nArray5[n10] * n + nArray4[n10] * n3 + nArray6[n10] * n5 >> 227238920;
            if (~n9 > -1) {
                n9 = -n9;
            }
            n9 = 0 <= n9 ? (n9 >= 128 ? 256 : n9 + 128) : 128;
            n8 = n2 * nArray4[n10] + nArray5[n10] * n6 - -(nArray6[n10] * n4) >> -1816498232;
            n8 = ch.ch_b[-1 < ~n8 ? -n8 : n8];
            nArray[n10] = n9 = (256 + -n8) * n9 >>> 1268162184;
            nArray3[n10] = n8;
            ++n10;
        }
        n10 = n7 = 0;
        while (n7 < ta.ta_d) {
            int n11;
            int n12;
            int n13;
            int n14;
            int n15;
            int n16;
            n9 = hb.Vb[n7];
            n8 = vg2.M[n9];
            short s2 = vg2.vg_c[n9];
            short s3 = vg2.A[n9];
            int n17 = id.M.length <= vg2.F[n9] ? -1 : vg2.F[n9];
            int n18 = id.M.length <= vg2.vg_t[n9] ? -1 : vg2.vg_t[n9];
            int n19 = ~id.M.length < ~vg2.vg_r[n9] ? vg2.vg_r[n9] : -1;
            dh dh2 = null != l.l_i && null != vg2.vg_j && ~vg2.vg_j.length < ~n9 && 0 != ~vg2.vg_j[n9] && l.l_i.length > vg2.vg_j[n9] ? l.l_i[vg2.vg_j[n9]] : null;
            int n20 = kl.kl_n[n8];
            int n21 = rn.rn_b[n8];
            int n22 = kl.kl_n[s2];
            int n23 = rn.rn_b[s2];
            int n24 = kl.kl_n[s3];
            int n25 = rn.rn_b[s3];
            if (n17 != n18 || ~n19 != ~n18) {
                n16 = nArray[n17];
                n15 = nArray[n18];
                n14 = nArray[n19];
                n13 = nArray3[n17];
                n12 = nArray3[n18];
                n11 = nArray3[n19];
                int n26 = dh2 == null ? 0x7F7F7F : dh2.dh_a;
                int n27 = n26 & 0xFF00FF;
                int n28 = n26 & 0xFF00;
                int n29 = (0xFF0082 & n28 * n16) >>> -1017884856 | (n27 * n16 & 0xFF00FF39) >>> 1795278632;
                int n30 = n27 * n15 >>> 770485128 & 0x10FF00FF | n28 * n15 >>> 853475976 & 0x4D00FF00;
                int n31 = 0xD2FF00FF & n27 * n14 >>> -1925801080 | n28 * n14 >>> -1947323704 & 0x8600FF00;
                wf.a((n29 += n13 * 65793) & 0xFF, n23, n20, (n31 += n11 * 65793) >> 225006032, n22, n29 >> 2099190608, n31 & 0xFF, 0xFF & (n30 += n12 * 65793), n25, n30 >> 281414704, n31 >> 1640941864 & 0xFF, n21, !bl, n29 >> -1725201496 & 0xFF, n24, 0xFF & n30 >> -522552696);
            } else {
                n16 = nArray[n17];
                n15 = nArray3[n17];
                n14 = dh2 == null ? 0x7F7F7F : dh2.dh_a;
                n13 = n14 & 0xFF00FF;
                n12 = n14 & 0xFF00;
                n11 = 0x5800FF00 & n12 * n16 >>> -1357940280 | 0xEFFF00FF & n13 * n16 >>> 1730230664;
                tb.a(n21, n25, n20, (n11 += 65793 * n15) >> 626219073 & 0x7F7F7F, n22, n23, 127, n24);
            }
            ++n7;
        }
    }

    static final boolean a(CharSequence charSequence, boolean bl, int n) {
        boolean bl2 = client.A;
        if (!cb.a(bl, charSequence, 4564)) {
            return false;
        }
        int n2 = 0;
        while (~n2 > ~charSequence.length()) {
            if (!ci.a(charSequence.charAt(n2), (byte)82)) {
                return false;
            }
            ++n2;
        }
        int n3 = -86 % ((-31 - n) / 56);
        return true;
    }

    public static void a(int n) {
        ug_q = null;
        if (n != -21771) {
            CharSequence charSequence = null;
            ug.a(charSequence, false, -92);
        }
        ug_n = null;
    }

    private ug() throws Throwable {
        throw new Error();
    }

    static final boolean a(char c, int n) {
        if (n != 32) {
            return false;
        }
        return '\u00a0' == c || c == ' ' || c == '_' || c == '-';
    }

    static {
        ug_n = "The Controls";
    }
}
