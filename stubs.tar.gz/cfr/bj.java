/*
 * Decompiled with CFR 0.152.
 */
final class bj {
    static String bj_c = "The Twist";
    static boolean[] bj_d = new boolean[112];
    static mm bj_f;
    static boolean bj_a;
    static ud bj_e;
    static String bj_b;

    public static void a(int n) {
        block0: {
            bj_d = null;
            bj_f = null;
            bj_e = null;
            bj_b = null;
            bj_c = null;
            if (n == 112) break block0;
            bj_b = null;
        }
    }

    static final void a(int n2, ck[] ckArray, mm mm2, boolean bl, mm mm3, int n3, int n4, int n5, int n6, int n7, int n8, int n9, ck[] ckArray2, int n10, int n11, int n12, ck[] ckArray3, int n13, int n14, int n15, int n16) {
        block0: {
            n.a(n14, new cc(ckArray2), mm3, n4, n16, new cc(ckArray), n10, mm2, n11, n15, new cc(ckArray3), n5, -6, n13, n12, n2, n8, n6, n3, n9, n7);
            if (bl) break block0;
            bj_e = null;
        }
    }

    static final ck[] a(int n2, ji ji2, String string, String string2) {
        if (n2 != 112) {
            return null;
        }
        int n3 = ji2.b(n2 + -113, string);
        int n4 = ji2.a(n3, 13030, string2);
        return we.a(ji2, -126, n4, n3);
    }

    static final tj a(long l, byte by) {
        if (by < 47) {
            return null;
        }
        return (tj)hn.hn_h.a(24710, l);
    }

    static {
        bj_b = "<%0> cannot join; the game is full.";
    }
}
