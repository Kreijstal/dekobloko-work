/*
 * Decompiled with CFR 0.152.
 */
final class ak {
    static ud ak_b;
    static String ak_g;
    static String ak_e;
    tc ak_h;
    static String ak_c;
    static String ak_f;
    static String ak_a;
    static int ak_d;
    static String ak_i;

    static final int a(int n, int n2, byte by) {
        if (c.c_i == null) {
            return -1;
        }
        if (~dm.dm_a >= ~n && c.c_i.I + dm.dm_a > n && ~sk.sk_k >= ~n2 && n2 < sk.sk_k + c.c_i.H) {
            return 0;
        }
        if (by != 7) {
            ak.a(32, 49, false, -4);
        }
        if (sk.sk_e <= n && ~(c.c_i.I + sk.sk_e) < ~n && n2 >= dg.dg_b && ~(c.c_i.H + dg.dg_b) < ~n2) {
            return 1;
        }
        return -1;
    }

    static final void a(int n, int n2, boolean bl, int n3) {
        block5: {
            c.c_i.c(n, n2);
            if (bl) {
                int n4 = rb.rb_b % c.c_i.I * 2;
                if (c.c_i.I <= n4) {
                    n4 = c.c_i.I - (n4 + -c.c_i.I);
                }
                if (n4 >= 10) {
                    if (n4 > -40 + c.c_i.I) {
                        n4 = c.c_i.I - 40;
                    }
                } else {
                    n4 = 10;
                }
                sh.a(0, 80, 25547, n, 30, 0, n4, c.c_i, n2);
            }
            if (n3 == 40) break block5;
            ak.a(43, 33, true, -46);
        }
    }

    public static void a(byte by) {
        block0: {
            ak_g = null;
            ak_b = null;
            ak_a = null;
            ak_e = null;
            ak_c = null;
            ak_f = null;
            ak_i = null;
            if (by == -112) break block0;
            ak.a(-56, -90, (byte)-84);
        }
    }

    final void a(int n, int n2, int n3, int n4, int n5) {
        int n6 = 24;
        int n7 = 5;
        this.ak_h.a(n, n5, n2, n7, n6, n3, -53);
        if (n4 < 97) {
            ak.a(127, 8, false, -33);
        }
        jc.jc_c.a(tb.tb_c.w_mb, 0, 0, kf.O, 0);
        tc.Ub.a(-2 + -vh.vh_e + (tb.tb_c.w_mb + -80) - 2, 0, kf.O + 2, 18, 0);
        cf.cf_d.a(vh.vh_e + 82, 0, 2 + kf.O, 18, -80 + -vh.vh_e + (tb.tb_c.w_mb - 2));
        k.k_b.a(0, 1, -kf.O + (tb.tb_c.N - 22), kf.O - -22, vh.vh_e, 2, tb.tb_c.w_mb, 20);
        ge.ge_f.a(vh.vh_e, 20, 2, 16);
    }

    ak(String string, w w2) {
        String[] stringArray = new String[]{string, al.al_a, tl.tl_s};
        w[] wArray = new w[]{w2, tb.tb_c, ge.ge_f};
        this.ak_h = new tc(0L, ec.ec_i, stringArray, fb.fb_b, wArray, 0);
    }

    static final dc[] a(byte by, fd fd2) {
        dc[] dcArray;
        block4: {
            boolean bl = client.A;
            if (!fd2.b(-86)) {
                return new dc[0];
            }
            mh mh2 = fd2.a((byte)123);
            while (~mh2.mh_c == -1) {
                ua.a(10L, -128);
            }
            if (~mh2.mh_c == -3) {
                return new dc[0];
            }
            int[] nArray = (int[])mh2.mh_b;
            dcArray = new dc[nArray.length >> 465277314];
            for (int j = 0; j < dcArray.length; ++j) {
                dc dc2;
                dcArray[j] = dc2 = new dc();
                dc2.dc_f = nArray[j << 789348322];
                dc2.dc_j = nArray[1 + (j << -1273691358)];
                dc2.dc_h = nArray[(j << -330762750) - -2];
                dc2.dc_a = nArray[3 + (j << 1002693154)];
            }
            if (by == -109) break block4;
            ak.a(94, -113, true, 89);
        }
        return dcArray;
    }

    static {
        ak_e = "Stamina Highscores";
        ak_g = "Connection lost - attempting to reconnect";
        ak_a = "Rating";
        ak_i = "Playing";
        ak_c = "Press 'SPACE' or 'ENTER' to continue";
        ak_f = "This entry doesn't match";
    }
}
