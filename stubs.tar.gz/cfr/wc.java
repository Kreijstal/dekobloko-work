/*
 * Decompiled with CFR 0.152.
 */
final class wc
extends bh {
    int wc_v;
    int[] wc_t;
    static String wc_q;
    int wc_p;
    static boolean wc_n;
    static ck wc_r;
    int wc_u;
    int wc_s;
    int wc_o;
    int wc_w;

    final void a(byte by, int n, int[] nArray, int n2, int n3, int n4, int n5, int n6) {
        this.wc_s = n;
        if (by != 37) {
            CharSequence charSequence = null;
            wc.a(false, charSequence, -40);
        }
        this.wc_p = n4;
        this.wc_t = nArray;
        this.wc_u = n6;
        this.wc_w = n2;
        this.wc_v = n5;
        this.wc_o = n3;
    }

    public static void a(int n) {
        wc_q = null;
        if (n != 2) {
            wc.a(64, -36, -122);
        }
        wc_r = null;
    }

    static final String a(boolean bl, CharSequence charSequence, int n) {
        boolean bl2 = client.A;
        String string = rb.a(bl, (byte)19, charSequence);
        if (string != null) {
            return string;
        }
        int n2 = n;
        while (~charSequence.length() < ~n2) {
            if (!ci.a(charSequence.charAt(n2), (byte)90)) {
                return jk.jk_g;
            }
            ++n2;
        }
        return null;
    }

    static final void a(int n, int n2, int n3) {
        boolean bl = client.A;
        if (n <= n2 - -5) {
            return;
        }
        int n4 = n2;
        int n5 = gn.gn_e[n4];
        int n6 = gn.gn_e[n4 + 1];
        int n7 = gn.gn_e[2 + n4];
        int n8 = gn.gn_e[n4 - -3];
        int n9 = gn.gn_e[4 + n4];
        int n10 = n2 + 5;
        while (~n10 > ~n) {
            int n11 = gn.gn_e[3 + n10];
            if (n8 < n11) {
                gn.gn_e[n4] = gn.gn_e[n10];
                gn.gn_e[n4 - -1] = gn.gn_e[n10 + 1];
                gn.gn_e[2 + n4] = gn.gn_e[2 + n10];
                gn.gn_e[3 + n4] = n11;
                gn.gn_e[4 + n4] = gn.gn_e[n10 - -4];
                gn.gn_e[n10] = gn.gn_e[n4 += 5];
                gn.gn_e[1 + n10] = gn.gn_e[n4 + 1];
                gn.gn_e[n10 + 2] = gn.gn_e[n4 + 2];
                gn.gn_e[n10 - -3] = gn.gn_e[3 + n4];
                gn.gn_e[4 + n10] = gn.gn_e[4 + n4];
            }
            n10 += 5;
        }
        gn.gn_e[n4] = n5;
        gn.gn_e[n4 - -1] = n6;
        gn.gn_e[n4 + 2] = n7;
        gn.gn_e[n4 - -3] = n8;
        gn.gn_e[4 + n4] = n9;
        wc.a(n4, n2, n3);
        wc.a(n, 5 + n4, n3 + 0);
    }

    wc() {
    }

    static {
        wc_n = true;
        wc_q = "<%0> is not on your friend list.";
    }
}
