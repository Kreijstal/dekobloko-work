/*
 * Decompiled with CFR 0.152.
 */
final class ob
extends fm {
    private String ob_h;
    static int ob_g;
    static String ob_l;
    static ud ob_n;
    private String ob_m;
    static ck[][][] ob_j;
    static boolean ob_k;
    static nk ob_i;

    static final jg b(byte by) {
        int n = 82 % ((by - -59) / 56);
        return new jg(f.a(116), em.b((byte)-126));
    }

    @Override
    final void a(wl wl2, byte by) {
        wl2.b(8, this.ob_m);
        if (by < 34) {
            ob.a(-10, 21);
        }
        wl2.a(this.ob_h, true);
    }

    static final ve a(int n, int n2) {
        if (n2 != 8) {
            ob_l = null;
        }
        return (ve)(tg.tg_b != null ? tg.tg_b.a(n2 ^ 0x608E, n) : null);
    }

    static final ck[] a(int n, int n2, int n3, int n4) {
        ck[] ckArray;
        boolean bl = client.A;
        ck[] ckArray2 = ckArray = new ck[9];
        ckArray[0] = sm.a((byte)-99, n4, n);
        for (int i = 1; i < 9; ++i) {
            ckArray[i] = ckArray[0];
        }
        if (n3 != -3932) {
            ob.a((byte)72);
        }
        ckArray[4] = sm.a((byte)-122, 64, n2);
        return ckArray2;
    }

    @Override
    final gh a(int n) {
        if (n != 18) {
            return null;
        }
        return pb.pb_i;
    }

    static final void a(int n, ui ui2, byte by) {
        block4: {
            boolean bl = client.A;
            if (rc.rc_d == ui2) {
                wj.Ob.c(n);
            } else if (rc.rc_d != null && null != ui2) {
                wj.Ob.a(ui2, 0, 0, 16);
                rc.rc_d = ui2;
                wj.Ob.c(n);
            } else {
                nn.a(n, ui2, true);
            }
            if (by >= 45) break block4;
            ob_g = 64;
        }
    }

    public static void a(byte by) {
        ob_i = null;
        ob_j = null;
        ob_l = null;
        if (by < 86) {
            ob.a(-105, -21, 61, -11);
        }
        ob_n = null;
    }

    static final void b(int n, int n2, int n3, int n4) {
        block2: {
            if (256 == n3) {
                pg.pg_e.f(n, n4, 64);
            } else {
                pg.pg_e.f(n, n4, n3 >> -299374302);
            }
            if (n2 == -299374302) break block2;
            ob.a((byte)0);
        }
    }

    ob(String string, String string2) {
        this.ob_m = string;
        this.ob_h = string2;
    }

    static {
        ob_l = "Message game";
        ob_j = new ck[8][7][16];
    }
}
