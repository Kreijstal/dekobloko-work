/*
 * Decompiled with CFR 0.152.
 */
import java.util.Hashtable;

abstract class ma
extends ce
implements ra {
    static w J;
    static String[] H;
    static w G;
    static int I;
    ce L;
    static ck K;

    @Override
    void a(int n, int n2, int n3, ce ce2, int n4, int n5) {
        block1: {
            if (n2 != 64) {
                ce ce3 = null;
                this.a(ce3, (byte)-1);
            }
            if (this.L == null) break block1;
            this.L.a(n, 64, n3 + this.ce_u, ce2, this.D + n4, n5);
        }
    }

    @Override
    void a(int n, int n2, int n3, int n4) {
        block2: {
            if (-1 == ~n3 && this.ce_p != null) {
                this.ce_p.a(true, n, n4, (byte)-98, this);
            }
            if (this.L != null) {
                this.L.a(n + this.ce_u, -119, n3, n4 - -this.D);
            }
            if (n2 <= -103) break block2;
            G = null;
        }
    }

    @Override
    final void b(int n, int n2, int n3, int n4, int n5) {
        super.b(n, n2, n3, n4, n5);
        this.b(true);
    }

    @Override
    final int d(int n) {
        int n2 = 99 / ((36 - n) / 51);
        return this.L != null ? this.L.d(125) : 0;
    }

    @Override
    String c(byte by) {
        String string;
        String string2 = super.c(by);
        if (this.L != null && (string = this.L.c((byte)113)) != null) {
            return string;
        }
        return string2;
    }

    ce a(int n) {
        ce ce2 = this.L;
        if (ce2 != null && ce2.a(true)) {
            return ce2;
        }
        if (n == 14) {
            return null;
        }
        return null;
    }

    @Override
    void a(ce ce2, int n, int n2, int n3) {
        block1: {
            super.a(ce2, 119, n2, n3);
            if (this.L != null) {
                this.L.a(ce2, 110, n2 - -this.D, this.ce_u + n3);
            }
            if (n > 38) break block1;
            this.b(false);
        }
    }

    private final boolean a(ce ce2, byte by) {
        if (by != -112) {
            ce ce3 = null;
            this.a(112, -42, ce3, -60, 72, 122, (byte)63);
        }
        return this.L != null && !this.L.a(true) && this.L.a(false, ce2);
    }

    @Override
    final boolean a(boolean bl, ce ce2) {
        if (bl) {
            return true;
        }
        return null != this.L && this.L.a(false, ce2);
    }

    @Override
    final boolean a(int n, int n2, int n3, ce ce2, int n4, int n5, boolean bl) {
        if (bl) {
            this.L = null;
        }
        return this.L != null && this.L.a(!bl) && this.L.a(n, n2, n3, ce2, n4, n5, false);
    }

    static final wb a(int n2, boolean bl2, byte by) {
        boolean bl3 = client.A;
        if (by <= 54) {
            ma.e((byte)-34);
        }
        boolean bl4 = k.k_b.Rb.a(kf.O - -2, (kf.O + 2) * (3 * n2), -15230, k.k_b.Rb == ki.ki_w, 2, bl2);
        vj vj2 = k.k_b.Sb.M;
        wb wb2 = null;
        if (-3 != ~jj.jj_b) {
            tb.tb_c.Hb = false;
            jc.jc_c.Y = wm.wm_k;
            k.k_b.Rb.Rb.Y = 1 == jj.jj_b ? si.si_m : wf.wf_m;
            gk.a(k.k_b.Sb, true);
        } else {
            tb.tb_c.Hb = true;
            jc.jc_c.Y = cm.a((byte)98, ve.ve_cc, new String[]{f.f_w});
            k.k_b.Rb.Rb.Y = null;
            wb wb3 = null;
            wb wb4 = (wb)vj2.c((byte)-108);
            while (null != wb4) {
                int n3;
                int n4;
                boolean bl5 = false;
                if (wb4.M == null) {
                    wb4.Sb = new w(0L, gg.G);
                    wb4.a(wb4.Sb, -16834);
                    wb4.Yb = new w(0L, fc.fc_f);
                    wb4.a(wb4.Yb, -16834);
                    wb4.Wb = new w(0L, gg.G);
                    wb4.a(wb4.Wb, -16834);
                    wb4.Yb.X = 2;
                    wb4.d(-112);
                    bl5 = true;
                }
                wb4.w_mb = k.k_b.Sb.w_mb;
                int n5 = 0;
                if (wb4.Vb == null) {
                    n4 = 0xCC0000;
                    n3 = 0xFF6666;
                } else if (f.f_w == wb4.Vb) {
                    n4 = 52224;
                    n3 = 0x66FF66;
                } else {
                    n3 = 0xFFFF66;
                    n4 = 0xCCCC00;
                }
                boolean bl6 = false;
                if (wb4.Tb != null && !wb4.Tb.equals("")) {
                    wb4.Wb.Bb = n3;
                    wb4.Wb.I = a.a_p;
                    wb4.Wb.a(3 + a.a_p.K, 0, n5, kf.O, 0);
                    bl6 = true;
                }
                wb4.Sb.G = wb4.Yb.G = n4;
                wb4.Sb.w_fb = wb4.Yb.w_fb = n3;
                wb4.Sb.w_rb = wb4.Yb.w_rb = n3;
                wb4.Sb.Bb = wb4.Yb.Bb = n3;
                int n6 = 0;
                int n7 = -2 + (wb4.w_mb - 80);
                if (bl6) {
                    n6 = a.a_p.K + 3;
                    n7 -= n6;
                }
                wb4.Sb.Y = 0 < n7 ? mm.a(wb4.Sb.J, wb4.Ob, n7) : wb4.Ob;
                wb4.Sb.a(n7, 0, n5, kf.O, n6);
                wb4.Yb.Y = null == wb4.Vb ? rg.rg_b : wb4.Vb;
                wb4.Yb.a(80, 0, n5, kf.O, wb4.w_mb + -80);
                boolean bl7 = !wb4.Sb.Y.equals(wb4.Ob);
                n5 += kf.O;
                if (!bl4) {
                    wb4.F = n5 - wb4.N;
                }
                if (bl5) {
                    k.k_b.Sb.a(wb3, wb4, 2, 0);
                }
                if (wb4.Wb == null || !wb4.Wb.w_jb) {
                    if (wb4.w_ob != 0) {
                        String string = wb4.Ob;
                        sl.a(string, null, (byte)101, k.k_b.Rb, wb4, null, 0L, -1, -1);
                        wb2 = wb4;
                        if (wb4.Vb != null && !wi.a(-103, w.H.pf_b) && !wc.wc_n) {
                            String string2;
                            if (!wl.wl_p) {
                                pf pf2 = w.H;
                                string2 = cm.a((byte)111, ai.M, new String[]{string});
                                pf2.pf_h.a(string2, 8, 80);
                            }
                            pf pf3 = w.H;
                            string2 = cm.a((byte)99, wa.wa_e, new String[]{string});
                            pf3.pf_h.a(string2, 18, 65);
                        }
                    } else if (wb4.Sb.w_jb) {
                        if (!bl7) {
                            wb3 = wb4;
                            wb4 = (wb)vj2.d(true);
                            continue;
                        }
                        sl.sl_g = wb4.Ob;
                    }
                } else {
                    sl.sl_g = wb4.Tb;
                }
                wb3 = wb4;
                wb4 = (wb)vj2.d(true);
            }
            if (k.k_b.Ob.w_ob != 0) {
                vh.vh_h = new hb(k.k_b.Ob.E, k.k_b.Ob.w_pb, k.k_b.Ob.w_mb, k.k_b.Ob.N, h.h_g, ah.ah_h, ua.H, ua.H);
                of.of_d = 0;
            }
            if (~k.k_b.Nb.w_ob != -1) {
                vh.vh_h = new hb(k.k_b.Nb.E, k.k_b.Nb.w_pb, k.k_b.Nb.w_mb, k.k_b.Nb.N, fj.fj_b, ah.ah_h, ua.H, ua.H);
                of.of_d = 1;
            }
        }
        return wb2;
    }

    @Override
    final boolean a(boolean bl2) {
        if (!bl2) {
            ce ce2 = null;
            this.a(-67, 8, ce2, -37, -30, 67, (byte)-40);
        }
        return null != this.a(14);
    }

    static final pi a(ji ji2, int n2, int n3, int n4) {
        if (n4 != 21828) {
            ma.a(-121, true, (byte)-35);
        }
        if (!gb.a(n2, ji2, n3, 78)) {
            return null;
        }
        return a.b(0);
    }

    @Override
    final boolean a(int n2, int n3, ce ce2, char c) {
        if (this.L != null && this.L.a(true) && this.L.a(-125, n3, ce2, c)) {
            return true;
        }
        int n4 = n3;
        if (-81 == ~n4) {
            return !bj.bj_d[81] ? this.b(false, ce2) : this.a(ce2, (byte)-112);
        }
        n4 = 24 / ((n2 - -22) / 49);
        return false;
    }

    private final boolean b(boolean bl2, ce ce2) {
        if (bl2) {
            return false;
        }
        return null != this.L && !this.L.a(!bl2) && this.L.a(false, ce2);
    }

    static final tj a(int n2, long l) {
        block0: {
            if (n2 < -98) break block0;
            G = null;
        }
        return (tj)ob.ob_i.a(24710, l);
    }

    ma(int n2, int n3, int n4, int n5, gl gl2, kg kg2) {
        super(n2, n3, n4, n5, gl2, kg2);
    }

    final void a(byte by, int n2, StringBuilder stringBuilder, Hashtable hashtable) {
        boolean bl2 = client.A;
        stringBuilder.append('\n');
        if (by > -37) {
            ce ce2 = null;
            this.a(36, -51, ce2, -111, 8, 107, (byte)-44);
        }
        for (int i = 0; i <= n2; ++i) {
            stringBuilder.append(' ');
        }
        if (this.L == null) {
            stringBuilder.append("null");
        } else {
            this.L.a(hashtable, n2 + 1, stringBuilder, true);
        }
    }

    void b(boolean bl2) {
        block1: {
            if (null != this.L) {
                this.L.f(112);
            }
            if (bl2) break block1;
            this.a(true);
        }
    }

    @Override
    final void d(byte by) {
        block1: {
            if (by != -95) {
                return;
            }
            if (this.L == null) break block1;
            this.L.d((byte)-95);
        }
    }

    public static void e(byte by) {
        if (by >= -78) {
            H = null;
        }
        J = null;
        G = null;
        H = null;
        K = null;
    }

    @Override
    boolean a(int n2, int n3, ce ce2, int n4, int n5, int n6, byte by) {
        if (by != -55) {
            this.a(59);
        }
        return this.L != null && this.L.a(n2, n3, ce2, n4, this.D + n5, this.ce_u + n6, (byte)-55);
    }

    @Override
    StringBuilder a(Hashtable hashtable, int n2, StringBuilder stringBuilder, boolean bl2) {
        if (this.a(0, n2, hashtable, stringBuilder)) {
            this.a((byte)72, stringBuilder, hashtable, n2);
            this.a((byte)-116, n2, stringBuilder, hashtable);
        }
        if (!bl2) {
            return null;
        }
        return stringBuilder;
    }

    static final int a(int n2, byte by) {
        if (0 == n2) {
            return 0;
        }
        if (~n2 < -1) {
            int n3 = 1;
            if (n2 > 65535) {
                n2 >>= 16;
                n3 += 16;
            }
            if (-256 > ~n2) {
                n2 >>= 8;
                n3 += 8;
            }
            if (-16 > ~n2) {
                n2 >>= 4;
                n3 += 4;
            }
            if (~n2 < -4) {
                n3 += 2;
                n2 >>= 2;
            }
            if (1 < n2) {
                n2 >>= 1;
                ++n3;
            }
            return n3;
        }
        if (by < 46) {
            return 45;
        }
        int n4 = 2;
        if (65535 < ~n2) {
            n2 >>= 16;
            n4 += 16;
        }
        if (n2 < -256) {
            n2 >>= 8;
            n4 += 8;
        }
        if (15 < ~n2) {
            n4 += 4;
            n2 >>= 4;
        }
        if (~n2 > 3) {
            n4 += 2;
            n2 >>= 2;
        }
        if (1 < ~n2) {
            n2 >>= 1;
            ++n4;
        }
        return n4;
    }

    static {
        H = new String[]{"\u00a33.20", "\u20ac4.25", "US$ 5.00", "Can$ 4.95", "Aus$ 6.50", "Krn 29.95", "", "Rp 160", "Rng 17.95", "NZ$ 7.95", "SG$ 6.95", "Krn 44.95", "R$ 7,00"};
    }
}
