/*
 * Decompiled with CFR 0.152.
 */
final class tg
implements gl {
    static String[] tg_g;
    static lm tg_a;
    static nk tg_b;
    static w tg_i;
    static w tg_f;
    static int tg_c;
    static String[][] tg_d;
    static w tg_h;
    static int tg_e;

    public static void a(boolean bl) {
        tg_d = null;
        tg_g = null;
        tg_i = null;
        tg_a = null;
        tg_f = null;
        if (bl) {
            return;
        }
        tg_b = null;
        tg_h = null;
    }

    @Override
    public final void a(boolean bl, int n, int n2, byte by, ce ce2) {
        block2: {
            int n3 = n + ce2.ce_u;
            int n4 = ce2.D + n2;
            ke.a(n3, n4, ce2.ce_t, ce2.y, (byte)101);
            ck ck2 = tl.tl_u[1];
            if (ce2 instanceof ek && ((ek)ce2).H) {
                ck2.f((ce2.ce_t + -ck2.K >> -1290148639) + n3 - -1, 1 + n4 + (ce2.y + -ck2.C >> -1784257663), 256);
            }
            if (ce2.a(true)) {
                kd.a(-4 + ce2.ce_t, 2 + n3, (byte)124, 2 + n4, ce2.y + -4);
            }
            if (by < -60) break block2;
            tg.a(false);
        }
    }

    static final void a(byte by) {
        block0: {
            md.a(9, 11, cd.cd_m.e(102));
            wk.wk_i = true;
            if (by < -2) break block0;
            tg_i = null;
        }
    }

    static final ck a(boolean bl, int n) {
        if (!bl) {
            return null;
        }
        return ik.ik_b[n][(0xC & uf.A) >> -2019195358];
    }

    static {
        tg_d = new String[][]{{"Standard", "Large"}, {"Slow", "Medium", "Fast", "Maximum", "Panic!"}, {"3", "4", "5", "6", "7"}, {"None", "W/cards", "+Drills", "+Bombs", "All"}, {"Level 1", "Level 2", "Level 3", "Off"}};
    }
}
