/*
 * Decompiled with CFR 0.152.
 */
final class ph
extends ca {
    static String Bb;
    static String[] Eb;
    static ji Db;
    static String Hb;
    static ji Fb;
    static ck[] yb;
    static String Cb;
    static um xb;
    static boolean Ab;
    static String Gb;
    static String zb;

    @Override
    final void c(ce ce2, byte by) {
        block0: {
            super.c(ce2, (byte)31);
            if (by >= 10) break block0;
            ph.n(39);
        }
    }

    static final boolean n(int n) {
        block0: {
            if (n == -30146) break block0;
            ph.a(false, -84, 71, true, false, false, false, -53, -127, 124);
        }
        return v.v_d;
    }

    ph(ka ka2, ce ce2) {
        super(ka2, ce2, 33, 20, 30);
    }

    public static void m(byte by) {
        Bb = null;
        Db = null;
        zb = null;
        Gb = null;
        xb = null;
        Fb = null;
        Eb = null;
        int n = -79 / ((-72 - by) / 41);
        yb = null;
        Hb = null;
        Cb = null;
    }

    static final void a(int n, int n2, boolean bl2, boolean bl3) {
        block0: {
            uc.a(n, true, bl3, n2);
            if (!bl2) break block0;
            Gb = null;
        }
    }

    static final void a(boolean bl2, int n, int n2, boolean bl3, boolean bl4, boolean bl5, boolean bl6, int n3, int n4, int n5) {
        boolean bl7 = client.A;
        if (!(bl5 || wj.Lb == hk.hk_j && vk.vk_f == hk.hk_i || ~hk.hk_i != ~le.le_m.eh_i || le.le_m.eh_g != hk.hk_j)) {
            if (cd.cd_m != null) {
                vb.a(false, -2);
            } else if (g.N == null) {
                mf.h(5);
            } else {
                vb.a(true, -2);
            }
        }
        vh.vh_g = !bl5 ? (-640 + wj.Lb) / 2 : ea.ea_t;
        hg.a(bl5, -1843);
        if (n3 > ~lg.W) {
            qm.a(bl4, n5, bl5, (byte)-8);
        }
        tg.tg_i.X = 1;
        tg.tg_i.w_ub = fc.fc_c.w_ub;
        if (-1 > ~bf.bf_r) {
            vg.a(n5, bl4, bl5, 48);
        }
        if (0 < tg.tg_e) {
            mn.a(0, bl6, bl4, bl5, n5);
        }
        if (dn.dn_k && ~cd.cd_m.ve_mc >= ~cd.cd_m.ve_rc) {
            gg.y.Hb = false;
            ec.ec_k.Rb.Y = cb.cb_k;
            gk.a(ec.ec_k.Ob, true);
        } else {
            gg.y.Hb = true;
            ec.ec_k.Rb.Y = null;
            cl.a(n, -17339, n5, ec.ec_k, bl2);
        }
        client.a(n, n2, bl2, n4, bl3, n5, (byte)-119);
        cl.a(n, -17339, n5, tb.tb_b, bl2);
        ++oe.G;
    }

    static {
        Hb = "To report a player, click on the most suitable option from the Rules of Conduct. Please do not abuse this form.";
        Bb = "<%0> is already on your ignore list.";
        Ab = false;
        Cb = "\"I think it's shaping up quite nicely!\" - Ian T";
        Gb = "Deko Bloko";
        zb = "No adverts";
    }
}
