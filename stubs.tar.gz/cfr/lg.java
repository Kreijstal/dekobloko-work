/*
 * Decompiled with CFR 0.152.
 */
final class lg
extends kf
implements vn {
    static se Y;
    private ek V;
    private ek S;
    private ek X = new ek(i.i_f, null);
    static int W;
    static String T;
    static int U;

    public lg() {
        super(0, 0, 476, 225, null);
        this.S = new ek(ec.ec_q, null);
        this.V = new ek(ic.ic_b, null);
        fk fk2 = new fk();
        this.X.ce_p = fk2;
        this.S.ce_p = fk2;
        this.V.ce_p = fk2;
        int n = 4;
        int n2 = 326;
        int n3 = n2 + -n >> -176982079;
        this.S.b(30, n3, -n2 + this.ce_t >> 389726337, -n + (this.y - 48), -16555);
        this.V.b(30, n3, n3 + ((-n2 + this.ce_t >> 485816257) + n), -48 + (this.y - n), -16555);
        this.X.b(30, n2, this.ce_t + -n2 >> -18885599, -(2 * n) + -78 + this.y, -16555);
        this.S.ce_v = this;
        this.X.ce_v = this;
        this.X.B = tm.tm_h;
        this.V.ce_v = this;
        this.V.B = kh.kh_c;
        this.b(this.S, (byte)-55);
        this.b(this.X, (byte)-55);
        this.b(this.V, (byte)-55);
    }

    public static void f(byte by) {
        if (by != 1) {
            T = null;
        }
        T = null;
        Y = null;
    }

    static final int a(int n, boolean bl) {
        boolean bl2 = client.A;
        sc.sc_n += 65536;
        while (um.a(dk.dk_c, sc.sc_n, n + 11469) >= 65536) {
            sc.sc_n -= dk.dk_c;
            ++rb.rb_b;
        }
        int n2 = -1;
        if (null == d.d_h) {
            if (vi.z != null) {
                n2 = vi.z.length;
            }
        } else {
            n2 = d.d_h.length;
        }
        if (-1 != n2) {
            if (ac.F < dk.dk_g) {
                if (dk.dk_i >= ++ac.F || null != d.d_h && d.d_h[wh.wh_a] != null) {
                    if (ac.F >= dk.dk_g && d.d_h[(1 + wh.wh_a) % n2] == null) {
                        --ac.F;
                    }
                } else {
                    --ac.F;
                }
            }
            if (~dk.dk_g >= ~ac.F) {
                bh.bh_m = wh.wh_a--;
                if (!lb.lb_b) {
                    if (wh.wh_a < 0) {
                        wh.wh_a += n2;
                    }
                } else if (++wh.wh_a >= n2) {
                    wh.wh_a -= n2;
                }
                ac.F -= dk.dk_g;
            }
            if (~dk.dk_i > ~ac.F) {
                lb.lb_b = true;
            }
        }
        if (ge.ge_h != null) {
            int n3 = -(ge.ge_h.C / 2) + 357;
            boolean bl3 = false;
            if (~ig.Yb != -1 && ~nf.nf_h < ~n3 && nf.nf_h < ge.ge_h.H + n3) {
                if (~he.S < ~(269 + -ge.ge_h.I) && he.S < 269) {
                    lb.lb_b = false;
                    bl3 = true;
                    ac.F = dk.dk_g;
                }
                if (-587 > ~he.S && ~he.S > ~(ge.ge_h.I + 586)) {
                    lb.lb_b = true;
                    bl3 = true;
                    ac.F = dk.dk_g;
                }
            }
            if (!bl3 && ~ac.F < ~dk.dk_i && n3 < pm.pm_f && pm.pm_f < ge.ge_h.H + n3) {
                if (269 - ge.ge_h.I < bh.bh_g && bh.bh_g < 269) {
                    ac.F = dk.dk_i;
                }
                if (-587 > ~bh.bh_g && bh.bh_g < 586 - -ge.ge_h.I) {
                    ac.F = dk.dk_i;
                }
            }
        }
        if (n != 0) {
            return 81;
        }
        if (bl) {
            rg.rg_a.a(ak.a(bh.bh_g, pm.pm_f, (byte)7), -20563, ak.a(he.S, nf.nf_h, (byte)7));
            if (rg.rg_a.b((byte)114)) {
                if (-1 == ~rg.rg_a.sk_h) {
                    return 3;
                }
                if (~rg.rg_a.sk_h == -2) {
                    return 2;
                }
            }
            while (ab.c((byte)-125)) {
                rg.rg_a.a((byte)58, 0);
                if (rg.rg_a.b((byte)114)) {
                    if (rg.rg_a.sk_h == 0) {
                        return 3;
                    }
                    if (1 == rg.rg_a.sk_h) {
                        return 1;
                    }
                }
                if (wh.wh_c != 13) continue;
                return 1;
            }
        }
        return 0;
    }

    static final void a(int n) {
        if (n != 8927) {
            Y = null;
        }
        hm.a(4, (byte)-111);
    }

    static final void a(boolean bl, int n) {
        block1: {
            if (n > -101) {
                return;
            }
            if (null == kb.kb_i) break block1;
            hk.d(hk.hk_c, hk.hk_h, hk.hk_g + -hk.hk_c, hk.hk_b - hk.hk_h);
            kb.kb_i.a(1141039778, bl);
        }
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        if (n2 >= -103) {
            W = 48;
        }
        int n5 = n + this.ce_u;
        int n6 = this.D - -n4;
        hh.hh_e.a(hh.hh_c, n5 - -20, n6 + 20, this.ce_t - 40, this.y + -50, 0xFFFFFF, -1, 1, 0, hh.hh_e.R);
        super.a(n, -109, n3, n4);
    }

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        block5: {
            boolean bl = client.A;
            if (this.S != ek2) {
                if (ek2 == this.X) {
                    ha.e(0);
                } else if (this.V == ek2) {
                    rk.c(false);
                }
            } else {
                vb.g((byte)105);
            }
            if (by == 67) break block5;
            T = null;
        }
    }

    @Override
    final boolean a(int n, int n2, ce ce2, char c) {
        if (super.a(95, n2, ce2, c)) {
            return true;
        }
        if (~n2 == -99) {
            return this.a(ce2, (byte)-74);
        }
        if (-100 == ~n2) {
            return this.a(32, ce2);
        }
        int n3 = 86 / ((n - -22) / 49);
        return false;
    }

    static {
        T = "Discard";
        U = -1;
    }
}
