/*
 * Decompiled with CFR 0.152.
 */
final class ua
extends vi {
    static String D;
    static long B;
    static w H;
    static String C;
    static int[] E;
    static String G;
    private Object F;

    static final String a(CharSequence charSequence, boolean bl) {
        String string = cf.a(0, ab.a(117, charSequence));
        if (!bl) {
            return null;
        }
        if (string == null) {
            string = "";
        }
        return string;
    }

    @Override
    final Object c(int n) {
        block0: {
            if (n == -1) break block0;
            E = null;
        }
        return this.F;
    }

    static final void h(byte by) {
        block1: {
            if (~gd.gd_e == ~(0 - sh.sh_i) || ~gd.gd_e == ~(-sh.sh_i + 250)) {
                // empty if block
            }
            ++gd.gd_e;
            if (by == -70) break block1;
            ji ji2 = null;
            ua.a(-119, (ji)null, false, ji2);
        }
    }

    static final void a(int n, ji ji2, boolean bl, ji ji3) {
        re.a(fc.fc_c, df.df_ab, H, rd.rd_a, sg.sg_e, bl, wa.wa_a, db.db_c, nf.nf_d, oh.oh_i, (byte)103, tm.tm_b);
        ef.O = bj.a(112, ji2, "lobby", "chatfilter");
        sg.sg_a[2] = mc.mc_d;
        sg.sg_a[0] = qj.qj_g;
        sg.sg_a[1] = al.al_a;
        jh.a((byte)116, tg.tg_a, ji3);
        int n2 = 74 / ((-31 - n) / 46);
    }

    static final void a(long l, int n) {
        if (n > -127) {
            H = null;
        }
        if (l <= 0L) {
            return;
        }
        if (0L != l % 10L) {
            qe.a(l, -111);
        } else {
            qe.a(-1L + l, -124);
            qe.a(1L, -109);
        }
    }

    static final void i(byte by) {
        ug ug2 = (ug)qi.Q.c((byte)-121);
        int n = -11 % ((by - 19) / 35);
        if (null == ug2) {
            si.a(66);
            return;
        }
        uf uf2 = de.V;
        uf2.i(7553);
        uf2.i(7553);
        uf2.i(7553);
        uf2.i(7553);
        ug2.b((byte)124);
    }

    @Override
    final boolean g(byte by) {
        if (by != -83) {
            C = null;
        }
        return false;
    }

    ua(Object object, int n) {
        super(n);
        this.F = object;
    }

    public static void e(int n) {
        if (n != 8) {
            C = null;
        }
        G = null;
        H = null;
        D = null;
        C = null;
        E = null;
    }

    static {
        E = new int[8];
        D = "WELL DONE!";
        G = "Login: ";
        C = "Type your password again to make sure it's correct";
    }
}
