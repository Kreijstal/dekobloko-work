/*
 * Decompiled with CFR 0.152.
 */
final class ul {
    static String ul_b = "Challenge Highscores";
    static int ul_d;
    static qm ul_e;
    static long ul_g;
    static ud ul_i;
    static String ul_a;
    static String ul_h;
    static int ul_f;
    static int[] ul_c;

    static final void a(byte by) {
        cl cl2;
        uf uf2;
        boolean bl2 = client.A;
        uf uf3 = uf2 = de.V;
        int n = uf3.d((byte)-110);
        cl cl3 = cl2 = (cl)oe.I.c((byte)-54);
        while (null != cl2 && n != cl2.cl_q) {
            cl3 = (cl)oe.I.d(true);
        }
        if (cl3 == null) {
            si.a(122);
            return;
        }
        int n2 = uf3.d((byte)-125);
        if (-1 != ~n2) {
            int n3;
            int n4;
            int n5;
            int n6 = cl3.z;
            t.t_cb[0] = oa.oa_f;
            int n7 = 1;
            while (~n2 < ~n7) {
                t.t_cb[n7] = uf2.c((byte)-38);
                ++n7;
            }
            ba.a(Integer.MAX_VALUE, n2, n6);
            for (n7 = 0; n7 < n2; ++n7) {
                pn.a(63, uf3);
                if (-1 != ~n7) {
                    ri.a(n7, dj.Y, -1, vm.vm_s, tj.Pb, oc.oc_c);
                    continue;
                }
                cl3.cl_p = oc.oc_c;
                cl3.cl_o = dj.Y;
                cl3.cl_w = tj.Pb;
                cl3.cl_t = vm.vm_s;
                ri.a(n7, dj.Y, -1, vm.vm_s, tj.Pb, oc.oc_c);
            }
            pd.a(n6, (byte)6);
            cl3.x = new String[2][n6];
            String[][] stringArray = cl3.x;
            cl3.cl_u = new int[2][n6 * 4];
            int[][] nArray = cl3.cl_u;
            int n8 = og.og_eb;
            int n9 = 0;
            int n10 = 0;
            while (n8 > n9) {
                n5 = ch.ch_a[n9];
                stringArray[0][n10] = t.t_cb[n5];
                nArray[0][n10 * 4] = ad.ad_i[n5];
                nArray[0][1 + n10 * 4] = oa.oa_e[n5];
                nArray[0][2 + 4 * n10] = ln.ln_a[n5];
                nArray[0][3 + n10 * 4] = mk.mk_b[n5];
                if (k.a(t.t_cb[n5], true) && -1 == ~(oa.oa_e[n5] + (ln.ln_a[n5] - -mk.mk_b[n5]))) {
                    stringArray[0][n10] = null;
                    --n10;
                }
                ++n9;
                ++n10;
            }
            n9 = n4 = 0;
            n10 = n3 = 0;
            while (n8 > n4) {
                n5 = ch.ch_a[n4 + n6];
                stringArray[1][n3] = t.t_cb[n5];
                nArray[1][n3 * 4] = ad.ad_i[n5];
                nArray[1][1 + 4 * n3] = oa.oa_e[n5];
                nArray[1][4 * n3 + 2] = ln.ln_a[n5];
                nArray[1][4 * n3 + 3] = mk.mk_b[n5];
                if (k.a(t.t_cb[n5], true) && -1 == ~(ln.ln_a[n5] + oa.oa_e[n5] + mk.mk_b[n5])) {
                    stringArray[1][n3] = null;
                    --n3;
                }
                ++n3;
                ++n4;
            }
        }
        if (by <= 107) {
            ul.a(-19, 9, -103);
        }
        cl3.A = true;
        cl3.b((byte)104);
    }

    public static void b(byte by) {
        ul_h = null;
        ul_b = null;
        ul_a = null;
        if (by != -75) {
            ul_d = -77;
        }
        ul_e = null;
        ul_c = null;
        ul_i = null;
    }

    static final int a(int n, int n2, int n3) {
        if (n3 != -28705) {
            ul.a(55, 34);
        }
        if (-3 < ~n2) {
            if (5 > n) {
                return 0;
            }
            return 1;
        }
        return 2;
    }

    static final void a(int n, int n2) {
        if (n2 != 4) {
            ul_e = null;
        }
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        uf2.a(true, 1);
        uf2.a(true, 1);
    }

    static {
        ul_e = new qm(6, 0, 4, 2);
        ul_g = 20000000L;
        ul_a = "Respect";
        ul_h = "Clan";
        ul_c = new int[5];
        ul_f = 3;
    }
}
