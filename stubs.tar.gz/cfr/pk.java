/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

final class pk
extends bh {
    int pk_s;
    int pk_n;
    static int pk_r = 0;
    static qn pk_v;
    int pk_u;
    pk pk_o;
    static ud pk_q;
    int pk_p;
    int pk_t;

    public static void c(int n) {
        int n2 = 86 % ((52 - n) / 35);
        pk_v = null;
        pk_q = null;
    }

    static final boolean d(int n) {
        lf.lf_g = true;
        if (n < 55) {
            pk.a(false, true);
        }
        lb.lb_d = 15000L + ik.a(4);
        return hc.hc_d == 11;
    }

    static final void a(boolean bl, boolean bl2) {
        if (bl2) {
            return;
        }
        jj.jj_f.a(-21, bl);
    }

    static final void me_a_applet(byte by, Applet applet) {
        try {
            URL uRL = new URL(applet.getCodeBase(), "quit.ws");
            if (by != -17) {
                pk.a(-74);
            }
            applet.getAppletContext().showDocument(gn.a(uRL, -1, applet), "_top");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    static final mi a(int n) {
        if (n != 15000) {
            return null;
        }
        return vh.vh_a;
    }

    pk(int n, int n2, int n3, int n4, int n5) {
        this.pk_u = n3;
        this.pk_n = n4;
        this.pk_s = n5;
        this.pk_p = n;
        this.pk_t = n2;
    }
}
