/*
 * Decompiled with CFR 0.152.
 */
final class pm {
    static boolean pm_b = false;
    static String pm_a = "You have declined the invitation.";
    static long pm_e;
    static int pm_g;
    static String pm_c;
    static int pm_f;
    static int pm_d;

    public static void a(int n) {
        int n2 = -26 / ((n - -34) / 48);
        pm_a = null;
        pm_c = null;
    }

    static final int a(int n, int n2, int n3) {
        boolean bl = client.A;
        int n4 = 0;
        if (n2 != -2141435999) {
            pm.a(7, 120, -115);
        }
        int n5 = rn.rn_d;
        while (~ef.M.length < ~n4) {
            int n6 = ug.ug_q[n4];
            if (-1 >= ~n6) {
                int n7;
                int n8 = qb.a(0, ef.M[n4], true);
                if (gi.a(17, n, n3, n8 + (ba.ba_d << 695051425), n5 += je.je_c, vb.V - -(le.le_t << 1525011617), (n7 = -(n8 >> -2141435999) + af.af_f) + -ba.ba_d)) {
                    return n6;
                }
                n5 += (le.le_t << -201922079) + (je.je_c + vb.V);
            } else {
                n5 += ma.I;
            }
            ++n4;
        }
        return -1;
    }

    static {
        pm_c = "Sound: ";
        pm_f = 0;
    }
}
