/*
 * Decompiled with CFR 0.152.
 */
final class da {
    static byte[] da_a;
    static i da_b;
    static cc da_c;
    static boolean[] da_d;
    static tf da_e;

    static final jc a(String string, int n) {
        String[] stringArray;
        block4: {
            boolean bl = client.A;
            int n2 = string.length();
            if (0 == n2) {
                return hm.hm_a;
            }
            if (~n2 < -256) {
                return ga.ga_e;
            }
            stringArray = ji.a('.', (byte)66, string);
            if (2 > stringArray.length) {
                return hm.hm_a;
            }
            String[] stringArray2 = stringArray;
            for (int i = 0; stringArray2.length > i; ++i) {
                String string2 = stringArray2[i];
                jc jc2 = ga.a(n ^ 0xFFFFEE3B, string2);
                if (jc2 == null) continue;
                return jc2;
            }
            if (n == -2734) break block4;
            da.a((byte)4);
        }
        return oe.a((byte)86, stringArray[stringArray.length + -1]);
    }

    public static void a(byte by) {
        da_c = null;
        da_e = null;
        da_b = null;
        da_a = null;
        if (by != -121) {
            da_d = null;
        }
        da_d = null;
    }

    static final void a(int n, boolean bl) {
        fl.a(130, 256, 16694016, kc.kc_s, 82 - -n, w.w_kb);
        int n2 = 145;
        fb.fb_c[0][0].c(82 + n, n2, 18, 18);
        n2 += ga.a(188, 0, n2, cc.cc_d, 16, 64, 0xFFFFFF, se.S, (byte)-124, 0, 110 + n) * 16 + 16;
        fb.fb_c[1][3].c(n + 82, n2, 18, 18);
        n2 += 16 - -(ga.a(188, 0, n2, dn.dn_q, 16, 64, 0xFFFFFF, se.S, (byte)-125, 0, 110 - -n) * 16);
        ri.a(n2, kk.kk_n, gi.gi_c, -115, 190 + n, nf.nf_e, 0);
        hk.g(309 + n, 117, 242, 263172);
        n2 = 116;
        hk.g(n + 310, 117, 242, 0x606060);
        fl.a(n2 - -14, 256, 16694016, ug.ug_n, 322 + n, w.w_kb);
        fl.a(13 + (n2 += 29), 256, 0xFFFFFF, vk.vk_b[0], n + 322, se.S);
        ph.yb[0].c(n + 480, n2 - -1);
        fl.a(13 + (n2 += 18), 256, 0xFFFFFF, vk.vk_b[1], 322 - -n, se.S);
        ph.yb[1].c(n + 480, n2 - -1);
        fl.a((n2 += 34) - -13, 256, 0xFFFFFF, vk.vk_b[2], n + 322, se.S);
        ph.yb[3].c(480 - -n, n2 + 1);
        fl.a((n2 += 18) - -13, 256, 0xFFFFFF, vk.vk_b[3], n + 322, se.S);
        ph.yb[4].c(n + 480, n2 - -1);
        ed.a(0xFFFFFF, 506 - -n, vk.vk_b[4], n2 + 13, (byte)75, se.S);
        ph.yb[2].c(516 + n, n2 - -1);
        fl.a((n2 += 34) + 13, 256, 0xFFFFFF, vk.vk_b[5], 322 + n, se.S);
        if (!bl) {
            return;
        }
        ph.yb[5].c(n + 480, n2 + 1);
        fl.a(14 + (n2 += 34), 256, 16694016, kc.kc_q, n + 322, w.w_kb);
        fl.a(13 + (n2 += 29), 256, 0xFFFFFF, vk.vk_b[6], 322 - -n, se.S);
        ph.yb[6].c(480 + n, 1 + n2);
    }

    static final void a(byte by, String string, String string2) {
        if (by != -109) {
            da.a((byte)-7);
        }
        db.a(-127, string, string2, false);
    }

    static final int a(int n, int n2, int n3, CharSequence charSequence, byte[] byArray, int n4) {
        boolean bl = client.A;
        int n5 = -n4 + n;
        int n6 = 0;
        if (n3 != -8218) {
            da.a(true, false);
        }
        while (n6 < n5) {
            char c = charSequence.charAt(n4 + n6);
            if (!('\u0000' < c && c < '\u0080' || c >= '\u00a0' && c <= '\u00ff')) {
                if (c == '\u20ac') {
                    byArray[n2 + n6] = (byte)-128;
                } else if (c != '\u201a') {
                    if (c == '\u0192') {
                        byArray[n2 + n6] = (byte)-125;
                    } else if ('\u201e' != c) {
                        if (c == '\u2026') {
                            byArray[n2 + n6] = (byte)-123;
                        } else if (c != '\u2020') {
                            if (c != '\u2021') {
                                if ('\u02c6' == c) {
                                    byArray[n2 + n6] = (byte)-120;
                                } else if ('\u2030' != c) {
                                    if (c != '\u0160') {
                                        if (c == '\u2039') {
                                            byArray[n6 + n2] = (byte)-117;
                                        } else if (c != '\u0152') {
                                            if ('\u017d' == c) {
                                                byArray[n2 + n6] = (byte)-114;
                                            } else if (c != '\u2018') {
                                                if (c != '\u2019') {
                                                    if (c == '\u201c') {
                                                        byArray[n6 + n2] = (byte)-109;
                                                    } else if (c == '\u201d') {
                                                        byArray[n6 + n2] = (byte)-108;
                                                    } else if (c != '\u2022') {
                                                        if (c == '\u2013') {
                                                            byArray[n2 + n6] = (byte)-106;
                                                        } else if (c == '\u2014') {
                                                            byArray[n6 + n2] = (byte)-105;
                                                        } else if (c == '\u02dc') {
                                                            byArray[n6 + n2] = (byte)-104;
                                                        } else if (c != '\u2122') {
                                                            if ('\u0161' != c) {
                                                                if (c == '\u203a') {
                                                                    byArray[n6 + n2] = (byte)-101;
                                                                } else if (c == '\u0153') {
                                                                    byArray[n6 + n2] = (byte)-100;
                                                                } else if (c != '\u017e') {
                                                                    byArray[n6 + n2] = '\u0178' != c ? (byte)63 : (byte)-97;
                                                                } else {
                                                                    byArray[n2 + n6] = (byte)-98;
                                                                }
                                                            } else {
                                                                byArray[n2 - -n6] = (byte)-102;
                                                            }
                                                        } else {
                                                            byArray[n2 - -n6] = (byte)-103;
                                                        }
                                                    } else {
                                                        byArray[n2 + n6] = (byte)-107;
                                                    }
                                                } else {
                                                    byArray[n6 + n2] = (byte)-110;
                                                }
                                            } else {
                                                byArray[n6 + n2] = (byte)-111;
                                            }
                                        } else {
                                            byArray[n6 + n2] = (byte)-116;
                                        }
                                    } else {
                                        byArray[n2 + n6] = (byte)-118;
                                    }
                                } else {
                                    byArray[n2 - -n6] = (byte)-119;
                                }
                            } else {
                                byArray[n6 + n2] = (byte)-121;
                            }
                        } else {
                            byArray[n2 - -n6] = (byte)-122;
                        }
                    } else {
                        byArray[n2 + n6] = (byte)-124;
                    }
                } else {
                    byArray[n2 - -n6] = (byte)-126;
                }
            } else {
                byArray[n6 + n2] = (byte)c;
            }
            ++n6;
        }
        return n5;
    }

    static final void a(boolean bl, boolean bl2) {
        block1: {
            he.a(bl2, -95);
            if (bl) {
                return;
            }
            if (null == sl.sl_g) break block1;
            qd.a(sl.sl_g, -2);
        }
    }

    static {
        da_b = new i();
    }
}
