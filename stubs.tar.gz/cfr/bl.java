/*
 * Decompiled with CFR 0.152.
 */
abstract class bl
extends kf {
    static int T;
    boolean S = false;
    private ka bl_ab;
    static String W;
    static fd U;
    static w Y;
    private int V = 0;
    static char[] Z;
    static String X;

    private final int a(int n) {
        if (n != -10604) {
            return -74;
        }
        return !this.S ? 0 : (this.bl_ab.g((byte)-83) == this ? 256 : 0);
    }

    final void a(int n, int n2, int n3) {
        if (n <= 92) {
            this.h((byte)-10);
        }
        this.b(n3, n2, cf.cf_f + -n2 >> -715540319, -n3 + vd.vd_n >> -532348575, -16555);
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        block5: {
            if (-1 != ~this.V) {
                if (256 <= this.V) {
                    if (~n3 != -1) {
                        return;
                    }
                    this.b(-128, n4 - -this.D, n - -this.ce_u);
                    super.a(n, -122, n3, n4);
                    return;
                }
            } else {
                return;
            }
            if (null == si.si_n || this.ce_t > si.si_n.I || this.y > si.si_n.H) {
                si.si_n = new ck(this.ce_t, this.y);
            }
            tb.a(true, si.si_n);
            hk.b();
            this.b(-128, 0, 0);
            super.a(-this.ce_u + -n, -116, n3, -n4 + -this.D);
            mk.a((byte)-5);
            si.si_n.c(this.ce_u + n, this.D + n4, this.V);
            if (n2 < -103) break block5;
            this.V = -41;
        }
    }

    bl(ka ka2, int n, int n2) {
        super(-n + cf.cf_f >> -954919615, vd.vd_n - n2 >> -1866710303, n, n2, null);
        this.bl_ab = ka2;
    }

    @Override
    final ce e(byte by) {
        ce ce2 = super.e(by);
        if (ce2 != null) {
            return ce2;
        }
        return this;
    }

    static final void a(int n, int n2, boolean bl2) {
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        boolean bl3 = client.A;
        fj.fj_e = true;
        bc.B = n2;
        if (-1 != ~bc.B) {
            if (-2 != ~bc.B) {
                if (-3 == ~bc.B) {
                    n8 = te.a(cm.a((byte)91, de.de_ab, new String[]{"<br><%0><br>"}), 86, om.om_a, vg.I, rk.R);
                    n7 = -1;
                    for (n6 = 0; n6 < n8; ++n6) {
                        if (!"<%0>".equals(vg.I[n6])) continue;
                        n7 = n6;
                        break;
                    }
                    if (~n7 == 0) {
                        throw new IllegalStateException();
                    }
                    tg.tg_g = new String[n7];
                    an.a(vg.I, 0, tg.tg_g, 0, n7);
                    dh.dh_b = new String[-1 + (n8 + -n7)];
                    an.a(vg.I, 1 + n7, dh.dh_b, 0, -n7 + n8 + -1);
                    n7 = -1;
                    n8 = te.a(cm.a((byte)86, ga.ga_d, new String[]{"<br><%0><br>"}), 112, om.om_a, vg.I, rk.R);
                    n6 = 0;
                    while (~n6 > ~n8) {
                        if ("<%0>".equals(vg.I[n6])) {
                            n7 = n6;
                            break;
                        }
                        ++n6;
                    }
                    if (-1 == n7) {
                        throw new IllegalStateException();
                    }
                    vb.U = new String[n7];
                    an.a(vg.I, 0, vb.U, 0, n7);
                    wb.Qb = new String[n8 - (n7 + 1)];
                    an.a(vg.I, n7 - -1, wb.Qb, 0, -1 + (-n7 + n8));
                    n6 = tg.tg_g.length < vb.U.length ? vb.U.length : tg.tg_g.length;
                    n5 = ~dh.dh_b.length <= ~wb.Qb.length ? dh.dh_b.length : wb.Qb.length;
                    n4 = n6 + (7 - -n5);
                    rk.P = new String[n4];
                    k.k_g = new int[n4];
                    n3 = 0;
                    while (~n4 < ~n3) {
                        k.k_g[n3] = -1;
                        ++n3;
                    }
                    qf.qf_i = new int[2];
                    rk.P[1] = i.i_g;
                    k.k_g[1] = 0;
                    rk.P[0] = tf.Z;
                    qf.qf_i[0] = 5;
                    rk.P[2] = wi.wi_a;
                    k.k_g[3] = 1;
                    rk.P[3] = sc.sc_p;
                    rk.P[4] = uj.uj_c;
                    qf.qf_i[1] = 2;
                    rk.P[5] = "";
                    n3 = 0;
                    while (~n3 > ~n6) {
                        rk.P[n3 + 6] = -n6 + (n3 - -vb.U.length) < 0 ? "" : vb.U[-n6 + (vb.U.length + n3)];
                        ++n3;
                    }
                    rk.P[n6 + 6] = null;
                    k.k_g[n6 + 6] = -2;
                    for (n3 = 0; n3 < n5; ++n3) {
                        rk.P[7 - (-n6 - n3)] = wb.Qb.length > n3 ? wb.Qb[n3] : "";
                    }
                    di.F = ik.a(4);
                } else if (-4 != ~bc.B) {
                    if (~bc.B != -5) {
                        if (bc.B != 5) {
                            throw new IllegalArgumentException();
                        }
                        n8 = te.a(gd.gd_i, 76, om.om_a, vg.I, rk.R);
                        n7 = 3 + n8;
                        rk.P = new String[n7];
                        k.k_g = new int[n7];
                        n6 = 0;
                        while (~n6 > ~n7) {
                            k.k_g[n6] = -1;
                            ++n6;
                        }
                        qf.qf_i = new int[2];
                        n6 = 0;
                        while (~n8 < ~n6) {
                            rk.P[n6] = vg.I[n6];
                            ++n6;
                        }
                        rk.P[-3 + n7] = "";
                        rk.P[n7 + -2] = fj.fj_c;
                        k.k_g[-2 + n7] = 0;
                        qf.qf_i[0] = 3;
                        rk.P[n7 + -1] = og.og_gb;
                        k.k_g[-1 + n7] = 1;
                        qf.qf_i[1] = 5;
                    } else {
                        n8 = te.a(dc.dc_g, 117, om.om_a, vg.I, rk.R);
                        n7 = 2 + n8;
                        k.k_g = new int[n7];
                        rk.P = new String[n7];
                        n6 = 0;
                        while (~n7 < ~n6) {
                            k.k_g[n6] = -1;
                            ++n6;
                        }
                        qf.qf_i = new int[1];
                        for (n6 = 0; n8 > n6; ++n6) {
                            rk.P[n6] = vg.I[n6];
                        }
                        rk.P[-2 + n7] = "";
                        rk.P[n7 + -1] = og.og_gb;
                        k.k_g[-1 + n7] = 0;
                        qf.qf_i[0] = 5;
                    }
                } else {
                    n8 = lf.lf_e.fd_a ? te.a(rb.rb_a, 99, om.om_a, vg.I, rk.R) : te.a(si.si_c, 81, om.om_a, vg.I, rk.R);
                    n7 = 2 - -n8;
                    rk.P = new String[n7];
                    k.k_g = new int[n7];
                    n6 = 0;
                    while (~n6 > ~n7) {
                        k.k_g[n6] = -1;
                        ++n6;
                    }
                    qf.qf_i = new int[1];
                    n6 = 0;
                    while (~n6 > ~n8) {
                        rk.P[n6] = vg.I[n6];
                        ++n6;
                    }
                    rk.P[n7 - 2] = "";
                    rk.P[n7 + -1] = og.og_gb;
                    k.k_g[-1 + n7] = 0;
                    qf.qf_i[0] = 5;
                }
            } else {
                n8 = te.a(df.X, 96, om.om_a, vg.I, rk.R);
                n7 = n8 + 2;
                k.k_g = new int[n7];
                rk.P = new String[n7];
                n6 = 0;
                while (~n7 < ~n6) {
                    k.k_g[n6] = -1;
                    ++n6;
                }
                qf.qf_i = new int[1];
                n6 = 0;
                while (~n6 > ~n8) {
                    rk.P[n6] = vg.I[n6];
                    ++n6;
                }
                rk.P[-2 + n7] = "";
                rk.P[-1 + n7] = og.og_gb;
                k.k_g[-1 + n7] = 0;
                qf.qf_i[0] = 5;
            }
        } else {
            n8 = te.a(df.X, 124, om.om_a, vg.I, rk.R);
            n7 = 3 + n8;
            rk.P = new String[n7];
            k.k_g = new int[n7];
            for (n6 = 0; n6 < n7; ++n6) {
                k.k_g[n6] = -1;
            }
            qf.qf_i = new int[2];
            n6 = 0;
            while (~n8 < ~n6) {
                rk.P[n6] = vg.I[n6];
                ++n6;
            }
            rk.P[n7 - 3] = "";
            rk.P[-2 + n7] = me.C;
            k.k_g[n7 + -2] = 0;
            qf.qf_i[0] = 4;
            rk.P[-1 + n7] = og.og_gb;
            k.k_g[-1 + n7] = 1;
            qf.qf_i[1] = 5;
        }
        if (n > -8) {
            U = null;
        }
        k.k_f.sk_l = qf.qf_i.length;
        n8 = 0;
        n7 = 0;
        while (~n7 > ~rk.P.length) {
            n6 = si.a(false, rk.P[n7], k.k_g[n7] >= 0);
            if (n6 > n8) {
                n8 = n6;
            }
            ++n7;
        }
        if (-3 == ~bc.B) {
            String[] stringArray = tg.tg_g;
            for (n6 = 0; stringArray.length > n6; ++n6) {
                String string = stringArray[n6];
                n4 = si.a(false, string, false);
                if (n4 <= n8) continue;
                n8 = n4;
            }
            String[] stringArray2 = dh.dh_b;
            for (n6 = 0; n6 < stringArray2.length; ++n6) {
                String string = stringArray2[n6];
                n4 = si.a(false, string, false);
                if (n8 >= n4) continue;
                n8 = n4;
            }
        }
        ig.ig_dc = (qk.qk_m + pa.Y << -1078448671) * k.k_f.sk_l;
        ri.ri_i = -(n8 >> -2049814175) + (n8 + qk.qk_d);
        ge.ge_e = qk.qk_d + -(n8 >> 504032897);
        n7 = 0;
        while (~rk.P.length < ~n7) {
            ig.ig_dc += -1 >= ~k.k_g[n7] ? cc.cc_a : ke.ke_d;
            ++n7;
        }
        fc.fc_a = ul.ul_d + -(ig.ig_dc >> 890590369);
        tj.tj_jc = new int[rk.P.length][];
        n6 = fc.fc_a;
        for (n7 = 0; rk.P.length > n7; ++n7) {
            n5 = k.k_g[n7];
            if (-1 < ~n5) {
                n6 += ke.ke_d;
                continue;
            }
            n4 = si.a(false, rk.P[n7], true);
            n3 = qk.qk_d - (n4 >> -1233259135);
            tj.tj_jc[n7] = new int[4];
            tj.tj_jc[n7][0] = n3 - mb.mb_c;
            tj.tj_jc[n7][1] = n6 += qk.qk_m;
            tj.tj_jc[n7][2] = n4 - -(mb.mb_c << 1785328417);
            n6 += (pa.Y << -668883583) + qk.qk_m + cc.cc_a;
            tj.tj_jc[n7][3] = cc.cc_a + (pa.Y << 1538379393);
        }
        if (-3 == ~bc.B) {
            k.k_f.a(-1, 0, -1, bl2);
        } else {
            k.k_f.a(0, 0, ub.a(bh.bh_g, (byte)-81, pm.pm_f), bl2);
        }
    }

    static final void b(int n, int n2) {
        fl.a(130, n2 ^ 0x304A, 16694016, mb.mb_e, 80 + n, w.w_kb);
        int n3 = 145;
        kd.kd_t.c(n + 82, n3, 18, 18);
        n3 += 16 + ga.a(188, 0, n3, nk.nk_c, 16, 64, 0xFFFFFF, se.S, (byte)-127, 0, n + 110) * 16;
        tg.a(true, 2).c(82 + n, n3, 18, 18);
        n3 += (~kd.kd_p == -1 ? 16 : 0) - -(ga.a(188, 0, n3, kb.kb_e, 16, 64, 0xFFFFFF, se.S, (byte)-127, 0, n + 110) * 16);
        vk.a(nf.nf_e, n + 190, 3, gi.gi_c, kk.kk_n, n3, -22981);
        hk.g(309 - -n, 117, 242, 263172);
        hk.g(310 - -n, 117, 242, 0x606060);
        fl.a(130, n2 ^ 0x304A, 16694016, hg.hg_d, 320 + n, w.w_kb);
        n3 = 145;
        tg.a(true, 0).c(320 - -n, n3, 18, 18);
        n3 += 16 * ga.a(212, 0, n3, dk.dk_f, 16, 64, 0xFFFFFF, se.S, (byte)-128, 0, 348 - -n) + 16;
        if (n2 != 12618) {
            bl.a(105, 85, false);
        }
        fl.a(n3 - -14, 256, 16694016, kc.kc_q, n + 320, w.w_kb);
        tg.a(true, 3).c(n + 320, n3 += 29, 18, 18);
        n3 += 16 - -(ga.a(212, 0, n3, ki.ki_u, 16, 64, 0xFFFFFF, se.S, (byte)-128, 0, 348 - -n) * 16);
    }

    boolean f(byte by) {
        this.V = this.a(-10604);
        if (by < 77) {
            this.S = false;
        }
        return 0 == this.V && !this.S;
    }

    boolean h(byte by) {
        int n = this.a(-10604);
        int n2 = n - this.V;
        if (by <= 15) {
            this.a(-126, -71, 58, -27);
        }
        if (0 < n2) {
            this.V += (-1 + n2 - -8) / 8;
        }
        if (-1 < ~n2) {
            this.V += (1 + (-16 + n2)) / 16;
        }
        return this.V == 0 && -1 == ~n && !this.S;
    }

    abstract void b(int var1, int var2, int var3);

    static final void g(byte by) {
        bf.x = bg.a(true);
        if (by > -12) {
            Z = null;
        }
        ah.ah_c = new ka();
        dd.a(true, true, (byte)66);
    }

    public static void i(int n) {
        Y = null;
        if (n != 2) {
            X = null;
        }
        U = null;
        W = null;
        X = null;
        Z = null;
    }

    static {
        W = "Chat view has been scrolled up. Scroll down to chat.";
        Z = new char[128];
        X = "Back";
    }
}
