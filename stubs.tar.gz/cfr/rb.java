/*
 * Decompiled with CFR 0.152.
 */
final class rb {
    static um rb_f = new um();
    static int rb_e;
    static String rb_l;
    static byte[] rb_k;
    static String rb_g;
    static int rb_b;
    static int rb_m;
    static String rb_i;
    static int[] rb_n;
    static i rb_c;
    static ck[][] rb_d;
    static int rb_h;
    static String rb_a;
    static ck[][] rb_j;

    static final String a(boolean bl, byte by, CharSequence charSequence) {
        boolean bl2 = client.A;
        if (null == charSequence) {
            return di.G;
        }
        int n = charSequence.length();
        if (-2 < ~n || -13 > ~n) {
            return di.G;
        }
        String string = kf.a(charSequence, (byte)2);
        if (string == null || 1 > string.length()) {
            return di.G;
        }
        if (ug.a(string.charAt(0), 32) || ug.a(string.charAt(-1 + string.length()), 32)) {
            return qf.qf_j;
        }
        if (by <= 12) {
            return null;
        }
        int n2 = 0;
        int n3 = 0;
        while (~charSequence.length() < ~n3) {
            char c = charSequence.charAt(n3);
            n2 = ug.a(c, 32) ? ++n2 : 0;
            if (2 <= n2 && !bl) {
                return un.un_b;
            }
            ++n3;
        }
        if (n2 <= 0) {
            return null;
        }
        return qf.qf_j;
    }

    static final void a(long l, String string, int n, int n2, int n3) {
        fa.fa_r = string;
        qa.y = n2;
        cd.cd_a = n3;
        if (n > -21) {
            rb_i = null;
        }
        li.li_e = l;
        ch.ch_c = true;
    }

    static final boolean a(int n, int n2, int[] nArray) {
        if (n > -6) {
            rb_b = -32;
        }
        return 0 != (nArray[n2 >> 1301827237] & 1 << (n2 & 0x1F));
    }

    static final void a(boolean bl2, byte by, String string, boolean bl3) {
        wj.q(-61);
        ah.ah_c.c(true);
        dm.dm_c = new he(hb.Ob, null, vb.Z, bl2, bl3);
        if (by > -13) {
            String string2 = null;
            rb.a(false, (byte)-65, string2, false);
        }
        de.W = new ph(ah.ah_c, dm.dm_c);
        ah.ah_c.a((byte)-109, (ce)de.W);
    }

    public static void a(int n) {
        rb_k = null;
        rb_l = null;
        rb_j = null;
        rb_a = null;
        rb_c = null;
        rb_d = null;
        if (n != 573767765) {
            rb_l = null;
        }
        rb_f = null;
        rb_n = null;
        rb_g = null;
        rb_i = null;
    }

    static final String a(int n2, int n3, String string) {
        if (!dc.a(string, (byte)-70)) {
            return ge.ge_d;
        }
        if (~jj.jj_b != -3) {
            return ah.ah_e;
        }
        if (k.a(string, true)) {
            return si.si_i;
        }
        if (qe.a(string, n3 ^ 3)) {
            return cm.a((byte)111, f.f_p, new String[]{string});
        }
        if (100 <= md.Z && 0 >= eh.eh_a) {
            return bh.bh_f;
        }
        if (200 <= md.Z) {
            return bh.bh_f;
        }
        if (ik.a(string, (byte)-118)) {
            return cm.a((byte)82, pe.pe_a, new String[]{string});
        }
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        ++uf2.wl_n;
        int n4 = uf2.wl_n;
        uf2.a(true, 0);
        uf2.a(n3, string);
        uf2.b(-n4 + uf2.wl_n, true);
        return null;
    }

    static final void a(hl hl2, int n2) {
        boolean bl2 = client.A;
        int n3 = 0;
        while (~n3 > -4) {
            ql.ql_d[n3] = 0;
            ++n3;
        }
        if (n2 != -3) {
            rb_c = null;
        }
        n3 = 0;
        while (~ic.ic_c < ~n3) {
            if (~pd.pd_g[n3].hl_m == ~hl2.hl_m) {
                int n4 = pd.pd_g[n3].b((byte)94);
                ql.ql_d[n4] = ql.ql_d[n4] + 1;
            }
            ++n3;
        }
        int n5 = hl2.b((byte)94);
        ql.ql_d[n5] = ql.ql_d[n5] + 1;
        n3 = 0;
        int n6 = 0;
        while (~ic.ic_c < ~n6) {
            int n7;
            if (~hl2.hl_m == ~pd.pd_g[n6].hl_m && ql.ql_d[n7 = pd.pd_g[n6].b((byte)94)] > kf.M) {
                int n8 = n7;
                ql.ql_d[n8] = ql.ql_d[n8] - 1;
            } else {
                pd.pd_g[n3++] = pd.pd_g[n6];
            }
            ++n6;
        }
        ic.ic_c = n3;
        pd.pd_g[ic.ic_c++] = hl2;
    }

    static {
        rb_i = "Open in popup window";
        rb_n = new int[]{287440998, 288563797, 0x11334444, 287467144, 289703987, 288594261, 288602999, 288612215, 573767765, 0x22443344, 0x22226655, 0x22449922, 0x2233CC33, 0x2222FF55};
        rb_h = 0;
        rb_g = "This password contains your Player Name, and would be easy to guess";
        rb_a = "Unfortunately your configuration doesn't support fullscreen mode.";
        rb_b = 0;
        rb_j = new ck[8][];
        rb_d = new ck[8][];
        rb_c = new i();
    }
}
