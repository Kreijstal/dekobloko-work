/*
 * Decompiled with CFR 0.152.
 */
final class cc {
    static String cc_g = "Score: ";
    static pi[][] cc_f = new pi[8][];
    static int[] cc_h;
    static String cc_d;
    static String cc_b;
    static int cc_a;
    private ck[] cc_c;
    static String cc_e;

    static final f a(int n, byte by) {
        f f2;
        block0: {
            f2 = new f();
            rc.rc_e.a(f2, 2777);
            gm.b(n, 65);
            if (by <= -81) break block0;
            cc_a = 118;
        }
        return f2;
    }

    public static void a(byte by) {
        cc_g = null;
        cc_d = null;
        cc_h = null;
        cc_e = null;
        cc_b = null;
        if (by != -94) {
            cc_g = null;
        }
        cc_f = null;
    }

    static final void a(int n) {
        block0: {
            kb.kb_i = new bk(ui.x, tg.tg_h, ib.ib_nb, ua.H, al.al_h, df.df_ab);
            if (n == 8) break block0;
            cc.a((byte)88);
        }
    }

    cc(ck[] ckArray) {
        this.cc_c = ckArray;
    }

    final void a(int n, int n2, int n3, int n4, int n5) {
        int n6 = -29 / ((n2 - -69) / 54);
        vk.a(n5, (byte)50, this.cc_c, n, n4, n3);
    }

    static {
        cc_d = "Colourful pieces are falling from the sky!";
        cc_b = "Staff impersonation";
        cc_e = "More suggestions";
    }
}
