/*
 * Decompiled with CFR 0.152.
 */
abstract class t
extends bl {
    private int t_db;
    private int t_gb;
    private int t_eb = 0;
    static String t_bb = "Matching Score: ";
    static String t_ib = "Animals";
    private int t_jb;
    static String[] t_cb = new String[255];
    private int t_hb = 0;
    private int t_fb;

    @Override
    boolean h(byte by) {
        if (-1 > ~this.t_hb) {
            int n = this.t_jb;
            int n2 = this.t_gb;
            if (this.t_hb <= ++this.t_eb) {
                this.t_hb = 0;
                this.j((byte)-52);
            } else {
                int n3 = (-this.t_eb + 2 * this.t_hb) * this.t_eb;
                int n4 = this.t_hb * this.t_hb;
                n = n3 * (this.t_jb + -this.t_db) / n4 + this.t_db;
                n2 = this.t_fb + n3 * (-this.t_fb + this.t_gb) / n4;
            }
            this.a(110, n, n2);
        }
        if (by < 15) {
            return true;
        }
        return super.h((byte)90);
    }

    final void b(int n, int n2, int n3, int n4) {
        if (n4 != 194) {
            this.b(35, 121, -128, 19);
        }
        if (n2 <= 0) {
            this.a(121, n, n3);
            return;
        }
        this.t_hb = n2;
        this.t_gb = n3;
        this.t_db = this.ce_t;
        this.t_fb = this.y;
        this.t_jb = n;
        this.t_eb = 0;
    }

    static final void k(byte by) {
        if (by != -73) {
            return;
        }
        de.W.c(new lg(), (byte)121);
    }

    void j(int n) {
        if (this.t_hb <= 0) {
            return;
        }
        this.a(112, this.t_jb, this.t_gb);
        this.t_hb = 0;
        this.j((byte)-32);
        int n2 = 40 % ((n - -15) / 49);
    }

    static final boolean i(byte by) {
        if (by != 124) {
            t_bb = null;
        }
        return -11 >= ~hc.hc_d && -14 >= ~ca.ca_vb;
    }

    t(ka ka2, int n, int n2) {
        super(ka2, n, n2);
    }

    @Override
    boolean f(byte by) {
        block0: {
            this.j(38);
            if (by >= 77) break block0;
            t_bb = null;
        }
        return super.f((byte)125);
    }

    void j(byte by) {
        int n = -128 % ((by - 30) / 39);
    }

    static final void a(int n, boolean bl2) {
        if (n < 104) {
            return;
        }
        uc.a(true, bl2, 54);
    }

    @Override
    void b(int n, int n2, int n3) {
        int n4;
        boolean bl2 = client.A;
        if (n > -127) {
            return;
        }
        hk.d(6 + n3, 35 + n2, -12 + this.ce_t, this.y - 40, 0x202020, 0);
        int n5 = 211;
        int n6 = 35;
        int n7 = 194;
        int n8 = 0;
        int n9 = n2;
        while (~n6 < ~n8) {
            if (hk.hk_h <= n9 && ~hk.hk_b < ~n9) {
                int n10;
                int n11;
                n4 = n5 - -((-n5 + n7) * n8 / n6);
                int n12 = 0;
                int n13 = this.ce_t;
                if (20 >= n8) {
                    while (~n12 >= -21) {
                        n11 = (20 + -n8) * (-n8 + 20) - -((-n12 + 20) * (20 + -n12));
                        if (462 >= n11) {
                            if (~n11 > -421) break;
                            n10 = (-n11 + 462) * n4 / 42;
                            n10 |= n10 << 1261671240 | n10 << 720680144;
                            hk.hk_l[hk.hk_j * n9 - -n3 - -n12] = n10;
                        }
                        ++n12;
                    }
                }
                if (-21 <= ~n8) {
                    int n14;
                    n11 = n13;
                    n13 -= 21;
                    n10 = 0;
                    while (20 >= n10 && -463 <= ~(n14 = (-n8 + 20) * (20 + -n8) + n10 * n10)) {
                        if (420 > n14) {
                            n11 = n13 - -1;
                        } else {
                            int n15 = (462 - n14) * n4 / 42;
                            n15 |= n15 << -1614545976 | n15 << -192934416;
                            hk.hk_l[n3 + n9 * hk.hk_j + n13] = n15;
                        }
                        ++n10;
                        ++n13;
                    }
                    n13 = n11;
                }
                n4 |= n4 << -1835908592 | n4 << -1970200856;
                hk.a(n12 + n3, n9, -n12 + n13, n4);
            }
            ++n8;
            ++n9;
        }
        n7 = 169;
        n6 = 22;
        n5 = 194;
        n8 = 0;
        n9 = n2 - -35;
        while (n8 < n6) {
            n4 = (-n5 + n7) * n8 / n6 + n5;
            n4 |= n4 << -1910141936 | n4 << -1313540568;
            hk.a(n3, n9, 6, n4);
            hk.a(n3 + this.ce_t + -6, n9, 6, n4);
            ++n8;
            ++n9;
        }
        jm.jm_q.c(-90 + (n3 - -this.ce_t), 10 + n2);
        ng.a(c.c_m, -10 + this.ce_t, n2 + 35, -1, 5 + n3);
        ng.a(g.O, this.ce_t, n2 + (this.y + -22), -1, n3);
        n6 = this.y + -79;
        n5 = 169;
        n7 = 127;
        n9 = 57 + n2;
        for (n8 = 0; n8 < n6; ++n8) {
            n4 = n5 - -(n8 * (n7 + -n5) / n6);
            n4 |= n4 << 23526640 | n4 << 495246472;
            hk.a(n3, n9, 6, n4);
            hk.a(-6 + (this.ce_t + n3), n9, 6, n4);
            ++n9;
        }
    }

    static final pi[] a(String string, ji ji2, boolean bl2, String string2) {
        if (bl2) {
            return null;
        }
        int n = ji2.b(-1, string2);
        int n2 = ji2.a(n, 13030, string);
        return on.a(n2, (byte)37, n, ji2);
    }

    public static void l(byte by) {
        t_bb = null;
        t_ib = null;
        if (by != 94) {
            String string = null;
            t.a(null, (ji)null, true, string);
        }
        t_cb = null;
    }

    static final hm k(int n) {
        if (n != -22) {
            return null;
        }
        try {
            return (hm)Class.forName("ag").newInstance();
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}
