/*
 * Decompiled with CFR 0.152.
 */
final class ve
extends w {
    int Ub;
    String Vb;
    w Tb;
    w Ec;
    static ck[][] ve_uc;
    static String Gc;
    boolean Cc;
    static int[] ve_ic;
    static int ve_hc;
    boolean Zb;
    int ve_mc;
    w Pb;
    long ve_tc;
    w ve_ec;
    int Nb;
    w yc;
    w ve_bc;
    boolean ve_wc;
    int Wb;
    w Sb;
    w Fc;
    static boolean Qb;
    static boolean Hc;
    int ve_rc;
    boolean ve_lc;
    w ve_jc;
    w ve_pc;
    boolean gc;
    boolean Ob;
    static w ve_vc;
    String[] xc;
    w Yb;
    int ve_oc;
    w Bc;
    w zc;
    w Ac;
    static String ve_cc;
    static boolean ve_ac;
    boolean Ic;
    w[] ve_fc;
    w Dc;
    int ve_qc;
    long Xb;
    static ck ve_dc;
    int Rb;
    byte[] ve_kc;
    w ve_sc;
    static int ve_nc;

    public static void h(byte by) {
        ve_uc = null;
        if (by != 116) {
            ve.g((byte)54);
        }
        ve_cc = null;
        Gc = null;
        ve_vc = null;
        ve_dc = null;
        ve_ic = null;
    }

    static final boolean g(byte by) {
        int n = -89 % ((76 - by) / 36);
        return vh.vh_h != null && vh.vh_h.f(261);
    }

    final boolean i(byte by) {
        if (by <= 98) {
            ve.g((byte)106);
        }
        return !this.d((byte)-68);
    }

    final int e(int n) {
        int n2 = 113 / ((n - 24) / 54);
        return (int)this.c((byte)57);
    }

    /*
     * Enabled aggressive block sorting
     */
    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, int[] nArray, int n8, int n9) {
        boolean bl = client.A;
        if (n7 != 9) {
            ve.h((byte)90);
        }
        --n6;
        while (n6 >= 0) {
            int[] nArray2 = nArray;
            int[] nArray3 = nArray;
            int n10 = n2++;
            int n11 = n5;
            int n12 = n;
            int n13 = n8;
            int n14 = 0x7F7F7F & nArray2[n10] >> -852264639;
            nArray3[n10] = n14 + lb.a(65280, n12 >> -1295343735) + (lb.a(n11 >> 1494704929, 0xFF0000) + lb.a(n13 >> 200866833, 255));
            n5 += n4;
            n8 += n9;
            n += n3;
            --n6;
        }
        return;
    }

    ve(int n) {
        super(0L, null);
        this.ve_kc = new byte[n];
    }

    static final String c(int n, int n2) {
        if (n2 != 26135) {
            return null;
        }
        return n + 1 + "/" + 4;
    }

    final boolean a(ve ve2, boolean bl) {
        boolean bl2;
        boolean bl3;
        if (bl) {
            return true;
        }
        boolean bl4 = this.Zb || ~this.ve_oc == -7;
        boolean bl5 = bl3 = ve2.Zb || ~ve2.ve_oc == -7;
        if (bl3 != bl4) {
            return bl4;
        }
        if (!bl4) {
            if (!ve2.gc == this.gc) {
                return this.gc;
            }
            if (this.gc && ~ve2.Wb != ~this.Wb) {
                return ~this.Wb > ~ve2.Wb;
            }
        }
        if (this.ve_lc == !ve2.ve_lc) {
            return !this.ve_lc;
        }
        if (!this.ve_lc) {
            return ve2.ve_tc > this.ve_tc;
        }
        boolean bl6 = this.ve_wc || ~this.ve_qc == -3;
        if (!bl6 == (bl2 = ve2.ve_wc || ve2.ve_qc == 2)) {
            return bl6;
        }
        return (ve2.ve_tc ^ 0xFFFFFFFFFFFFFFFFL) > (this.ve_tc ^ 0xFFFFFFFFFFFFFFFFL);
    }

    static {
        ve_hc = 10;
        ve_uc = new ck[8][];
        ve_cc = "You are on <%0>";
        ve_ic = new int[]{0, 0, 5, 9, 12, 14, 15, 15, 14, 12, 8, 4, 2, 1};
        ve_nc = 1;
    }
}
