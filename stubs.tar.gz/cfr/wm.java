/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Container;

abstract class wm
extends ba
implements qh {
    private rk wm_j;
    static int wm_l;
    static ck wm_n;
    static String wm_k;
    static ck wm_o;
    static String wm_g;
    static String wm_m;
    static String wm_i;
    static w wm_h;

    abstract tb b(String var1, byte var2);

    @Override
    final String e(byte by) {
        block0: {
            if (by > 2) break block0;
            wm_n = null;
        }
        return this.wm_a_string(this.wm_j.E, (byte)-11);
    }

    static final void d(int n) {
        block0: {
            oa.oa_f = de.V.c((byte)-38);
            h.h_c = kf.a(oa.oa_f, (byte)2);
            if (n == 140) break block0;
            wm.f((byte)98);
        }
    }

    @Override
    final tb b(int n) {
        block0: {
            if (n == -5520) break block0;
            this.wm_j = null;
        }
        return this.b(this.wm_j.E, (byte)-40);
    }

    abstract String wm_a_string(String var1, byte var2);

    @Override
    public final void a(int n, rk rk2) {
        if (n != 0xFF6666) {
            return;
        }
        this.c((byte)-51);
    }

    static final Container f(byte by) {
        block1: {
            if (hg.hg_c != null) {
                return hg.hg_c;
            }
            if (by > 123) break block1;
            wm.d(74);
        }
        return se.h(25144);
    }

    @Override
    public final void b(int n, rk rk2) {
        block0: {
            if (n == -2569) break block0;
            wm_n = null;
        }
    }

    @Override
    public final boolean a(byte by) {
        int n = 112 / ((by - 72) / 40);
        return null == this.wm_j.E || 0 == this.wm_j.E.length();
    }

    wm(rk rk2) {
        this.wm_j = rk2;
    }

    public static void c(int n) {
        wm_k = null;
        wm_h = null;
        wm_i = null;
        if (n != 18966) {
            wm.f((byte)42);
        }
        wm_n = null;
        wm_o = null;
        wm_m = null;
        wm_g = null;
    }

    static {
        wm_k = "Please wait...";
        wm_g = "Unfortunately there was a focus problem while setting fullscreen mode. You could try disabling any multiple monitor drivers or window enhancements, if you have any enabled, or try a different resolution.";
        wm_o = new ck(540, 140);
        wm_m = "Chain Bonus: ";
        wm_i = "<%0> would need a rating of <%1> to play with the current options.";
    }
}
