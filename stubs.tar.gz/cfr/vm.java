/*
 * Decompiled with CFR 0.152.
 */
final class vm
extends bh {
    static String vm_p;
    int vm_v;
    static String x;
    static int vm_s;
    int vm_n;
    int vm_t;
    static int vm_w;
    int vm_o;
    int y;
    static tb vm_u;
    static int vm_r;
    rf vm_q;

    static final boolean a(int[] nArray, long l, String string, int n, int n2) {
        if (!pc.a(n2, 2, l, string, nArray)) {
            return false;
        }
        if (n2 == 1) {
            n2 = 0;
        }
        ed.ed_c = string;
        pk.pk_r = n2;
        int n3 = -49 / ((-60 - n) / 43);
        cf.cf_c = kf.a(string, (byte)2);
        fm.fm_d = l;
        ig ig2 = wa.a(nArray, ad.ad_q, (byte)-127, fj.fj_d, rd.rd_e);
        be.a((byte)120, ig2);
        return true;
    }

    static final void a(cc cc2, int n, int n2, int n3) {
        block0: {
            if (n3 == -11) break block0;
            vm_s = -57;
        }
    }

    static final boolean a(int n, int n2, int n3, int n4) {
        int n5 = 104 % ((3 - n) / 61);
        if (kb.kb_i == null || 13 != wh.wh_c) {
            if (jg.jg_i) {
                if (!ql.a(2)) {
                    return false;
                }
                boolean bl = nm.a(n3, 1, n4);
                if (~wh.wh_c == -81 || ~wh.wh_c == -85) {
                    jg.jg_i = false;
                    bl = true;
                }
                if (13 == wh.wh_c) {
                    qk.a((byte)94);
                    jg.jg_i = false;
                    bl = true;
                }
                return bl;
            }
            if (!jh.jh_h && -10 != ~wh.wh_c && -11 != ~wh.wh_c && wh.wh_c != 11) {
                if (wh.wh_c == 80 && ql.a(2)) {
                    jg.jg_i = true;
                    return true;
                }
                return false;
            }
            return tl.b(n2, 102, n4);
        }
        kb.kb_i = null;
        return true;
    }

    public static void a(int n) {
        vm_u = null;
        vm_p = null;
        if (n < 120) {
            vm_r = -61;
        }
        x = null;
    }

    static final void a(int n, ig ig2) {
        ie.ie_c.a(ig2, -16834);
        int n2 = 14 / ((55 - n) / 49);
    }

    static final String c(int n) {
        block0: {
            if (n == -30185) break block0;
            vm_s = 3;
        }
        return hl.hl_a;
    }

    vm() {
    }

    static {
        x = "Name";
        vm_p = "Withdraw invitation to <%0> to join this game";
        vm_u = new tb();
    }
}
