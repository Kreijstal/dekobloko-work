/*
 * Decompiled with CFR 0.152.
 */
final class p {
    static String p_c = "Create unrated game";
    static w p_b;
    static String p_d;
    static long p_a;

    public static void a(int n) {
        if (n < 104) {
            p_b = null;
        }
        p_b = null;
        p_d = null;
        p_c = null;
    }

    static final void a(int n, byte by) {
        block2: {
            try {
                nc.a("resizing", by + -14511, se.h(by ^ 0xFFFF9DDA), new Object[]{new Integer(n)});
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (by == -30) break block2;
            p.a(72, (byte)-105);
        }
    }

    static {
        p_d = "Position";
    }
}
