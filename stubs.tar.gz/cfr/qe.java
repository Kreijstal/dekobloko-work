/*
 * Decompiled with CFR 0.152.
 */
final class qe {
    static String qe_b;
    private long[] qe_f;
    static String qe_h;
    private byte[] qe_d = new byte[64];
    static String qe_c;
    private byte[] qe_l;
    static int[] qe_k;
    private long[] qe_a;
    private int qe_o = 0;
    private long[] qe_g;
    private long[] qe_n;
    static String qe_j;
    private long[] qe_i;
    static String qe_e;
    private int qe_m = 0;

    final void b(byte by) {
        boolean bl = client.A;
        int n = 0;
        while (~n > -33) {
            this.qe_l[n] = 0;
            ++n;
        }
        this.qe_o = 0;
        this.qe_m = 0;
        this.qe_d[0] = 0;
        n = 0;
        if (by >= -32) {
            return;
        }
        while (-9 < ~n) {
            this.qe_g[n] = 0L;
            ++n;
        }
    }

    private final void b(int n) {
        boolean bl = client.A;
        int n2 = 0;
        int n3 = 0;
        while (~n2 > -9) {
            this.qe_f[n2] = pj.a(pj.a(jg.a(this.qe_d[n3 + 6], 255L) << -383590584, pj.a(jg.a((long)this.qe_d[n3 + 5] << -306192304, 0xFF0000L), pj.a(jg.a(0xFF000000L, (long)this.qe_d[n3 + 4] << 413393112), pj.a(jg.a((long)this.qe_d[3 + n3] << 459903008, 0xFF00000000L), pj.a(pj.a((long)this.qe_d[n3] << 1570355832, jg.a((long)this.qe_d[n3 + 1] << -455555024, 0xFF000000000000L)), jg.a(0xFF0000000000L, (long)this.qe_d[2 + n3] << -197783768)))))), jg.a(255L, (long)this.qe_d[7 + n3]));
            ++n2;
            n3 += 8;
        }
        n2 = 0;
        while (~n2 > -9) {
            this.qe_a[n2] = this.qe_g[n2];
            this.qe_n[n2] = pj.a(this.qe_f[n2], this.qe_a[n2]);
            ++n2;
        }
        n2 = 1;
        while (-11 <= ~n2) {
            int n4;
            int n5;
            for (n3 = 0; 8 > n3; ++n3) {
                this.qe_i[n3] = 0L;
                n5 = 0;
                n4 = 56;
                while (n5 < 8) {
                    this.qe_i[n3] = pj.a(this.qe_i[n3], uk.uk_s[n5][lb.a((int)(this.qe_a[lb.a(7, -n5 + n3)] >>> n4), 255)]);
                    ++n5;
                    n4 -= 8;
                }
            }
            n3 = 0;
            while (~n3 > -9) {
                this.qe_a[n3] = this.qe_i[n3];
                ++n3;
            }
            this.qe_a[0] = pj.a(this.qe_a[0], uk.x[n2]);
            n3 = 0;
            while (-9 < ~n3) {
                int n6;
                this.qe_i[n3] = this.qe_a[n3];
                n5 = n6 = 0;
                n4 = 56;
                while (8 > n6) {
                    this.qe_i[n3] = pj.a(this.qe_i[n3], uk.uk_s[n6][lb.a((int)(this.qe_n[lb.a(7, n3 + -n6)] >>> n4), 255)]);
                    ++n6;
                    n4 -= 8;
                }
                ++n3;
            }
            n3 = 0;
            while (-9 < ~n3) {
                this.qe_n[n3] = this.qe_i[n3];
                ++n3;
            }
            ++n2;
        }
        if (n > -24) {
            this.qe_l = null;
        }
        for (n2 = 0; n2 < 8; ++n2) {
            this.qe_g[n2] = pj.a(this.qe_g[n2], pj.a(this.qe_f[n2], this.qe_n[n2]));
        }
    }

    final void a(int n, byte[] byArray, long l) {
        int n2;
        boolean bl = client.A;
        int n3 = 0;
        int n4 = 7 & 8 - ((int)l & 7);
        if (n != 255) {
            qe.a((byte)13);
        }
        int n5 = 7 & this.qe_o;
        long l2 = l;
        int n6 = 0;
        for (int i = 31; 0 <= i; --i) {
            this.qe_l[i] = (byte)(n6 += (this.qe_l[i] & 0xFF) - -(0xFF & (int)l2));
            n6 >>>= 8;
            l2 >>>= 8;
        }
        while ((l ^ 0xFFFFFFFFFFFFFFFFL) < -9L) {
            n2 = 0xFF & byArray[n3] << n4 | (byArray[1 + n3] & 0xFF) >>> 8 + -n4;
            if (0 > n2 || -257 >= ~n2) {
                throw new RuntimeException("LOGIC ERROR");
            }
            this.qe_d[this.qe_m] = (byte)de.b(this.qe_d[this.qe_m], n2 >>> n5);
            this.qe_o += -n5 + 8;
            ++this.qe_m;
            if (-513 == ~this.qe_o) {
                this.b(-63);
                this.qe_o = 0;
                this.qe_m = 0;
            }
            this.qe_d[this.qe_m] = (byte)lb.a(255, n2 << 8 + -n5);
            l -= 8L;
            ++n3;
            this.qe_o += n5;
        }
        if (l <= 0L) {
            n2 = 0;
        } else {
            n2 = byArray[n3] << n4 & 0xFF;
            this.qe_d[this.qe_m] = (byte)de.b(this.qe_d[this.qe_m], n2 >>> n5);
        }
        if ((l + (long)n5 ^ 0xFFFFFFFFFFFFFFFFL) > -9L) {
            this.qe_o = (int)((long)this.qe_o + l);
        } else {
            this.qe_o += -n5 + 8;
            ++this.qe_m;
            l -= (long)(8 - n5);
            if (~this.qe_o == -513) {
                this.b(-26);
                this.qe_m = 0;
                this.qe_o = 0;
            }
            this.qe_d[this.qe_m] = (byte)lb.a(255, n2 << 8 + -n5);
            this.qe_o += (int)l;
        }
    }

    static final boolean a(String string, int n) {
        if (n != 3) {
            qe_k = null;
        }
        return null != ed.a(string, (byte)-108);
    }

    final void a(int n, int n2, byte[] byArray) {
        block4: {
            boolean bl = client.A;
            this.qe_d[this.qe_m] = (byte)de.b(this.qe_d[this.qe_m], 128 >>> lb.a(this.qe_o, 7));
            ++this.qe_m;
            if (~this.qe_m < -33) {
                while (~this.qe_m > -65) {
                    this.qe_d[this.qe_m++] = 0;
                }
                this.b(-115);
                this.qe_m = 0;
            }
            while (32 > this.qe_m) {
                this.qe_d[this.qe_m++] = 0;
            }
            an.a(this.qe_l, 0, this.qe_d, 32, 32);
            this.b(-76);
            int n3 = n2;
            for (int i = 0; i < 8; ++i) {
                long l = this.qe_g[i];
                byArray[n3] = (byte)(l >>> 1762041848);
                byArray[n3 - -1] = (byte)(l >>> 442716528);
                byArray[2 + n3] = (byte)(l >>> -499075224);
                byArray[3 + n3] = (byte)(l >>> 1507390240);
                byArray[n3 + 4] = (byte)(l >>> 1776836824);
                byArray[5 + n3] = (byte)(l >>> -396321520);
                byArray[6 + n3] = (byte)(l >>> 64767752);
                byArray[7 + n3] = (byte)l;
                n3 += 8;
            }
            if (n == 64767752) break block4;
            this.qe_m = -86;
        }
    }

    static final String a(byte by) {
        String string = "";
        if (by < 85) {
            return null;
        }
        if (dm.dm_c != null) {
            string = dm.dm_c.j(80);
        }
        if (-1 == ~string.length()) {
            string = db.b((byte)122);
        }
        if (string.length() == 0) {
            string = wh.wh_e;
        }
        return string;
    }

    static final ck[] a(boolean bl, int n, boolean bl2, int n2, int n3, int n4) {
        if (n4 != -26198) {
            qe_j = null;
        }
        int[] nArray = hk.hk_l;
        int n5 = hk.hk_j;
        int n6 = hk.hk_i;
        ck ck2 = new ck(16, n);
        ck2.a();
        hk.d(0, 0, 16, n, n2, n3);
        ck ck3 = null;
        if (bl2) {
            ck3 = ck2.c();
            ck3.a();
            hk.a(0, 0, 5, 0);
            hk.a(0, 1, 3, 0);
            hk.a(0, 2, 2, 0);
            hk.a(0, 3, 1, 0);
            hk.a(0, 4, 1, 0);
        }
        ck ck4 = null;
        if (bl) {
            ck4 = ck2.c();
            ck4.a();
            hk.a(11, 0, 5, 0);
            hk.a(13, 1, 3, 0);
            hk.a(14, 2, 2, 0);
            hk.a(15, 3, 1, 0);
            hk.a(15, 4, 1, 0);
        }
        hk.a(nArray, n5, n6);
        return new ck[]{null, null, null, ck3, ck2, ck4, null, null, null};
    }

    public static void a(int n) {
        block0: {
            qe_c = null;
            qe_h = null;
            qe_e = null;
            qe_k = null;
            qe_b = null;
            qe_j = null;
            if (n == -20007) break block0;
            qe_c = null;
        }
    }

    static final void a(long l, int n) {
        if (n >= -100) {
            return;
        }
        try {
            Thread.sleep(l);
        }
        catch (InterruptedException interruptedException) {}
    }

    qe() {
        this.qe_f = new long[8];
        this.qe_g = new long[8];
        this.qe_l = new byte[32];
        this.qe_i = new long[8];
        this.qe_n = new long[8];
        this.qe_a = new long[8];
    }

    static {
        qe_k = new int[8];
        qe_h = "Unable to add name - system busy";
        qe_j = "To activate a special item, pop a shape next to it.";
        qe_b = "Asking to join <%0>'s game...";
        qe_e = "Age:";
        qe_c = "Play rated game";
    }
}
