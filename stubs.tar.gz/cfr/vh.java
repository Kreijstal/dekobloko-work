/*
 * Decompiled with CFR 0.152.
 */
final class vh {
    static String vh_c = "Asking for or providing contact information";
    static hb vh_h;
    static int vh_e;
    static String[] vh_b;
    static int vh_d;
    static int vh_g;
    static String vh_f;
    static mi vh_a;

    static final boolean a(byte by) {
        boolean bl = client.A;
        if (by <= 50) {
            return false;
        }
        long l = ik.a(4);
        long l2 = -wg.wg_i + l;
        if (-30001L > (l2 ^ 0xFFFFFFFFFFFFFFFFL)) {
            af.af_d = 0;
            wg.wg_i = l;
            return true;
        }
        int n = 3000;
        if (-8 >= ~af.af_d) {
            n = 12000;
        } else if (-6 >= ~af.af_d) {
            n = 9000;
        } else if (-4 >= ~af.af_d) {
            n = 6000;
        }
        if ((long)n < l2) {
            wg.wg_i = l;
            ++af.af_d;
            return true;
        }
        return false;
    }

    static final a a(int n) {
        if (n != 1424) {
            return null;
        }
        if (null == sm.sm_c) {
            sm.sm_c = new a(bj.bj_f, 20, 0, 0, 0, 0xB0B0B0, -1, 0, 0, bj.bj_f.R, -1, Integer.MAX_VALUE, true);
        }
        return sm.sm_c;
    }

    public static void a(boolean bl) {
        block0: {
            vh_h = null;
            vh_b = null;
            vh_a = null;
            vh_f = null;
            vh_c = null;
            if (bl) break block0;
            vh_a = null;
        }
    }

    static final int a(int n, int n2, int n3, int n4) {
        block2: {
            if (~hk.hk_j <= ~(n3 + n4)) {
                return n4;
            }
            if (~(-n3 + n4 + n) <= -1) {
                return n + n4 + -n3;
            }
            if (n2 == -18265) break block2;
            vh.a(-78, -105, 117, -8);
        }
        return hk.hk_j - n3;
    }

    static {
        vh_e = 15;
        vh_g = 0;
        vh_b = new String[]{"By rating", "By win percentage"};
    }
}
