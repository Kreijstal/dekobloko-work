/*
 * Decompiled with CFR 0.152.
 */
final class id
extends ma {
    static String O = "<%0>: <%1>";
    static int[] M = new int[8192];
    static int P;
    static s N;

    @Override
    final void a(int n, int n2, int n3, ce ce2, int n4, int n5) {
        block0: {
            se se2;
            block1: {
                super.a(n, n2, n3, ce2, n4, n5);
                se2 = lg.Y;
                if (null == se2 || !this.a(n5, (byte)-58, n4, n, n3)) break block0;
                if (!(this.ce_v instanceof na)) break block1;
                ((na)this.ce_v).a(se2, this, (byte)-128);
                lg.Y = null;
                break block0;
            }
            if (!(se2.ce_v instanceof na)) break block0;
            ((na)se2.ce_v).a(se2, this, (byte)-128);
            lg.Y = null;
        }
    }

    private id(int n, int n2, int n3, int n4, gl gl2, kg kg2, ce ce2) {
        super(n, n2, n3, n4, gl2, kg2);
        this.L = ce2;
    }

    static final ck a(ji ji2, String string, String string2, int n) {
        if (n != 8192) {
            N = null;
        }
        int n2 = ji2.b(-1, string2);
        int n3 = ji2.a(n2, 13030, string);
        return af.a(n3, 50, ji2, n2);
    }

    public static void c(boolean bl) {
        M = null;
        N = null;
        if (!bl) {
            ck ck2 = null;
            id.a(99, 26, 67, 28, -65, -116, 74, ck2, 106);
        }
        O = null;
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, ck ck2, int n8) {
        qk.qk_k = n8;
        pm.pm_d = n6;
        g.Q = n3;
        db.db_a = n4;
        le.y = n5;
        ce.ce_r = n2;
        wg.wg_b = ck2;
        if (n7 != 8192) {
            id.c(false);
        }
        nk.nk_g = n;
    }

    static final w g(int n) {
        block0: {
            if (n == 8192) break block0;
            id.c(false);
        }
        return jg.b(false);
    }
}
