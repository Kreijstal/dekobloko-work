/*
 * Decompiled with CFR 0.152.
 */
final class ff
extends bh {
    int ff_t;
    int ff_n;
    int ff_r;
    static mm ff_o;
    int ff_p;
    int ff_s;
    int ff_q;

    public static void a(int n) {
        if (n > -5) {
            return;
        }
        ff_o = null;
    }

    static final void a(boolean bl, int n) {
        block1: {
            if (null != kb.kb_i && kb.kb_i.b(-1, bl)) {
                kb.kb_i = null;
            }
            if (n == 10891) break block1;
            ff_o = null;
        }
    }

    ff(int n, int n2, int n3, int n4, int n5, int n6) {
        this.ff_r = n2;
        this.ff_n = n4;
        this.ff_s = n5;
        this.ff_p = n3;
        this.ff_t = n6;
        this.ff_q = n;
    }
}
