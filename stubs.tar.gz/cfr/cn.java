/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;

final class cn
extends kf
implements fi,
vn {
    static int U;
    static String cn_ab;
    private og Y = new og("", null, 12);
    static String T;
    private ek S;
    static w X;
    static String V;
    private ek Z;
    df W;

    static final boolean f(byte by) {
        if (by < 69) {
            return false;
        }
        return ph.Ab;
    }

    @Override
    final boolean a(int n, int n2, ce ce2, char c) {
        if (super.a(-85, n2, ce2, c)) {
            return true;
        }
        if (98 == n2) {
            return this.a(ce2, (byte)-113);
        }
        if (n2 == 99) {
            return this.a(32, ce2);
        }
        int n3 = -60 / ((-22 - n) / 49);
        return false;
    }

    @Override
    public final void a(int n) {
        block0: {
            ((jm)this.Y.a(-105)).a(true);
            if (n == 25) break block0;
            ce ce2 = null;
            this.a(79, 36, ce2, '\uffbb');
        }
    }

    private final int a(int n, String string, ce ce2, String string2, boolean bl, int n2, int n3) {
        de de2 = new de(20, n2, 120 + n3, 25, ce2, bl, 120, 3, hh.hh_e, 0xFFFFFF, string2);
        this.b(de2, (byte)-55);
        pa pa2 = new pa(((jl)((Object)ce2)).a(-126), string, 126, n2 - -de2.y, n3 - -25, n);
        pa2.ce_v = this;
        this.b(pa2, (byte)-55);
        return pa2.y + de2.y;
    }

    @Override
    public final void a(String string, int n) {
        og og2 = this.Y;
        String string2 = string;
        if (n != -28464) {
            cn_ab = null;
        }
        og2.a(string2, (byte)114, false);
    }

    static final int b(boolean bl) {
        if (~ca.ca_vb > -3) {
            return 0;
        }
        if (~kd.kd_p != -1) {
            if (null != vj.vj_a) {
                if (!vj.vj_a.a((byte)121)) {
                    return 14;
                }
                if (!vj.vj_a.a("", 0)) {
                    return 29;
                }
                if (!vj.vj_a.a("", (byte)63)) {
                    return 29;
                }
            }
            if (!sk.sk_f.a((byte)121)) {
                return 43;
            }
            if (!sk.sk_f.a("commonui", (byte)-114)) {
                return 57;
            }
            if (!rc.rc_k.a((byte)121)) {
                return 71;
            }
            if (!rc.rc_k.a("commonui", (byte)-125)) {
                return 80;
            }
            if (!ph.Fb.a((byte)121)) {
                return 82;
            }
            if (!ph.Fb.a(!bl)) {
                return 86;
            }
        } else {
            if (!sk.sk_f.a((byte)121)) {
                return 20;
            }
            if (!sk.sk_f.a("commonui", (byte)-33)) {
                return 40;
            }
            if (!rc.rc_k.a((byte)121)) {
                return 50;
            }
            if (!rc.rc_k.a("commonui", (byte)57)) {
                return 60;
            }
            if (!ph.Fb.a((byte)121)) {
                return 70;
            }
            if (!ph.Fb.a(false)) {
                return 80;
            }
        }
        if (!bl) {
            return -41;
        }
        return 100;
    }

    private final int a(int n, int n2, int n3, String string, ce ce2, String string2) {
        int n4 = -109 % ((n3 - 16) / 54);
        return this.a(35, string, ce2, string2, false, n, n2);
    }

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        block2: {
            block1: {
                if (by != 67) {
                    ek ek3 = null;
                    this.a((byte)103, -75, ek3, 25, 38);
                }
                if (this.S == ek2) break block1;
                if (this.Z != ek2) break block2;
                this.i(-14356);
                break block2;
            }
            vb.g((byte)105);
        }
    }

    private final boolean cn_a_jl(jl jl2, byte by) {
        tb tb2;
        nb nb2 = jl2.a(-120);
        if (nb2 == null) {
            return true;
        }
        if (by > -28) {
            cn.j(8);
        }
        return (tb2 = nb2.a(20350)) == dc.dc_b;
    }

    static final void a(boolean bl, Canvas canvas) {
        block1: {
            if (hc.hc_d == 11) {
                bb.a((byte)-22);
            }
            rf.a(12, tf.tf_bb, cg.cg_d, he.he_hb);
            mf.a(1, 0, 0, canvas);
            if (bl) break block1;
            cn.b(true);
        }
    }

    public static void j(int n) {
        T = null;
        if (n != 3) {
            V = null;
        }
        cn_ab = null;
        X = null;
        V = null;
    }

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        if (n <= 38) {
            cn.f((byte)40);
        }
        super.a(ce2, 45, n2, n3);
        this.Z.I = this.g((byte)-29);
    }

    public cn() {
        super(0, 0, 496, 0, null);
        a a2 = new a(bj.bj_f, 0, 0, 0, 0, 0xFFFFFF, -1, 3, 0, hh.hh_e.R, -1, Integer.MAX_VALUE, true);
        ce ce2 = new ce(V, a2, null);
        this.Z = new ek(gm.J, null);
        this.S = new ek(fc.fc_g, null);
        this.Y.B = ea.C;
        this.Y.a(new jm(this.Y), -5362);
        this.Z.I = false;
        this.Z.ce_p = new fk();
        this.S.ce_p = new on();
        this.Y.ce_p = new di(0x989898);
        int n = 20;
        int n2 = 4;
        ce2.b(50, 270, 20, n, -16555);
        int n3 = 200;
        n += 50;
        this.b(ce2, (byte)-55);
        n += 5 + this.a(n, 170, -107, rg.rg_e, this.Y, ij.ij_b);
        this.Z.b(40, n3, -n3 + 496 >> 728917057, n, -16555);
        this.S.b(40, 60, 3 + n2, n + 15, -16555);
        this.S.ce_v = this;
        this.Z.ce_v = this;
        this.b(this.Z, (byte)-55);
        this.b(this.S, (byte)-55);
        this.W = new df(this);
        this.W.b(150, -60 + -this.Y.ce_t + this.ce_t + -this.Y.ce_u, 60 + (this.Y.ce_t + this.Y.ce_u), 20, -16555);
        this.b(this.W, (byte)-55);
        this.b(n2 + (n - -55), 496, 0, 0, -16555);
    }

    private final void i(int n) {
        block1: {
            if (!this.g((byte)-29)) {
                return;
            }
            gb.a(n + 14253, this.Y.E);
            if (n == -14356) break block1;
            U = -2;
        }
    }

    private final boolean g(byte by) {
        if (!this.cn_a_jl(this.Y, (byte)-116)) {
            return false;
        }
        return by == -29;
    }

    static {
        T = "YOU WIN!";
        V = "You need to choose a name before you can log in. This is the name that will be displayed to other players.";
        cn_ab = "Remove <%0> from friend list";
    }
}
