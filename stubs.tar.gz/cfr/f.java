/*
 * Decompiled with CFR 0.152.
 */
final class f
extends bh {
    static w f_n;
    static n f_r;
    int[] f_t;
    static String f_q;
    boolean f_u = false;
    static String f_w;
    static String x;
    static String f_v;
    static w f_o;
    static ke f_s;
    static String f_p;

    static final boolean a(wl wl2, int n) {
        if (n != 19) {
            return false;
        }
        int n2 = wl2.d((byte)-40);
        boolean bl = ~n2 == -2;
        return bl;
    }

    static final ke a(boolean bl2, boolean bl3, int n, boolean bl4, boolean bl5, int n2, boolean bl6, boolean bl7) {
        ke ke2;
        boolean bl8 = client.A;
        ke ke3 = ke2 = new ke(12);
        ke3.ke_p = bl7;
        ke3.ke_m = n;
        ke3.ke_g = bl2;
        if (!bl7) {
            ke3.a(new ec(1, gn.gn_d, a.a_t), n2 + -32232);
            ke3.a(new ec(2, b.Q, a.a_t), n2 ^ 0x7E19);
            ke3.a(new ec(3, oa.oa_c, a.a_t), 117);
        } else {
            ke3.a(new ec(13, mn.mn_a, a.a_t), n2 ^ 0x7E1C);
        }
        ke3.a(new ec(4, de.P, a.a_t), 117);
        if (bl4) {
            ke3.a(new ec(5, vb.T, a.a_t), 119);
        }
        if (n2 != 32357) {
            f.a(false, true, 98, true, false, 42, false, false);
        }
        ec ec2 = new ec(6, pm.pm_c, a.a_t);
        ec ec3 = new ec(7, fj.fj_f, a.a_t);
        ec3.ec_n = ~ec3.ec_n <= ~ec2.ec_n ? ec3.ec_n : ec2.ec_n;
        ec2.ec_n = ec3.ec_n;
        ke3.a(ec2, 125);
        ke3.a(ec3, 114);
        boolean bl9 = true;
        if (bl7 && eh.eh_a <= 0) {
            bl9 = false;
        }
        if (bl9) {
            ke3.a(new ec(8, re.re_w, a.a_t), 105);
        }
        int n3 = 116;
        if (!bl7) {
            ke3.a(new ec(19, ak.ak_e, a.a_t), 108);
            ke3.a(new ec(10, ul.ul_b, a.a_t), 126);
            ke3.a(new ec(9, u.u_g, a.a_t), 118);
            ke3.a(new ec(11, mf.P, a.a_t), 108);
            ke3.a(new ec(12, cf.cf_j, a.a_t), 112);
        } else {
            int n4 = 0;
            int n5 = jg.jg_k.length;
            if (fb.a(0, 0x9933FF, o.o_g)) {
                n4 += 2;
                n5 -= 2;
            }
            ke3.ke_l = ka.a((byte)114, n5, tf.tf_cb) + n4;
            if (!bl2) {
                ke3.a(new ec(14, la.la_g, a.a_t), 99);
            } else {
                int n6;
                int n7;
                n3 = 96;
                if (bl3) {
                    ke3.a(new ec(15), 124);
                    n3 = 86;
                    n7 = a.a_t.a(kf.R);
                    n6 = a.a_t.a(e.e_a);
                    if (n6 > n7) {
                        n7 = n6;
                    }
                    n6 = a.a_t.a(pg.pg_c);
                    if (~n7 > ~n6) {
                        n7 = n6;
                    }
                    ke2.ke_f[-1 + ke2.ke_b.sk_l].ec_n = n7 - -46;
                    ke3.a(new ec(16, ab.ab_a, a.a_t), 116);
                }
                if (bl6) {
                    ke3.a(new ec(17), 107);
                    n7 = a.a_t.a(ji.ji_c);
                    n6 = a.a_t.a(ik.ik_g);
                    if (n7 < n6) {
                        n7 = n6;
                    }
                    if (~(n6 = a.a_t.a(k.k_h)) < ~n7) {
                        n7 = n6;
                    }
                    if ((n6 = a.a_t.a(wj.Kb)) > n7) {
                        n7 = n6;
                    }
                    n6 = a.a_t.a(sc.sc_h);
                    if (n7 < n6) {
                        n7 = n6;
                    }
                    if (~(n6 = a.a_t.a(rc.rc_g)) < ~n7) {
                        n7 = n6;
                    }
                    n6 = a.a_t.a(ig.Xb);
                    if (~n7 > ~n6) {
                        n7 = n6;
                    }
                    n6 = a.a_t.a(di.E);
                    if (~n7 > ~n6) {
                        n7 = n6;
                    }
                    ke2.ke_f[-1 + ke2.ke_b.sk_l].ec_n = 46 + n7;
                }
                ke3.a(new ec(18, om.om_b, a.a_t), n2 + -32248);
            }
        }
        ke3.a(n3, 320, true, 53, 24);
        ke3.a(bl5 ? 1 : 0, false, -129);
        ke3.j((byte)-7);
        return ke3;
    }

    static final int a(lk lk2, lk lk3, int n, byte by) {
        int n2;
        int n3;
        if (by != -119) {
            f.a(false, true, -83, false, false, 55, true, true);
        }
        if (2 + (n3 = ge.a(lk2, by ^ 0xFFFFFFCA)) > (n2 = ge.a(lk3, 40))) {
            if (n != 3 || 1 + n3 > n2) {
                return n3;
            }
            return 3;
        }
        return 3;
    }

    static final cd a(int n, String string) {
        if (n != -11079) {
            f.a(false, false, 6, true, true, -105, true, true);
        }
        if (pa.V == ka.P) {
            return null;
        }
        if (ka.P != kl.z || !string.equals(pn.pn_fb)) {
            je.je_b = null;
            ka.P = pa.V;
            pn.pn_fb = string;
            return null;
        }
        ka.P = uc.uc_c;
        return je.je_b;
    }

    static final void d(int n) {
        block0: {
            on.b((byte)-100);
            uj.a(kf.O, vh.vh_e, ef.O[0].K, hn.hn_a, nk.nk_b, n ^ 0xFFFFFF92);
            if (n == 18) break block0;
            f.a(79, true);
        }
    }

    public static void c(int n2) {
        f_q = null;
        f_p = null;
        f_v = null;
        f_r = null;
        if (n2 != 30061) {
            f.a(120);
        }
        f_o = null;
        f_w = null;
        f_s = null;
        f_n = null;
        x = null;
    }

    static final void a(int n2, boolean bl2) {
        block2: {
            if (ea.d((byte)74)) {
                bl2 = false;
            }
            ch.a(bl2, 0);
            if (de.Z) {
                hk.d(je.je_f.ak_h.w_vb, je.je_f.ak_h.Ib, je.je_f.ak_h.w_mb, je.je_f.ak_h.N);
                je.je_f.ak_h.a(n2 ^ 0x4402E2A0, bl2);
            }
            ed.a((byte)127, bl2);
            if (n2 == 2) break block2;
            f.a(123, false);
        }
    }

    f() {
    }

    static final String a(int n2) {
        if (pa.V == sh.sh_d) {
            return te.te_q;
        }
        if (!jj.jj_f.a(85)) {
            return jj.jj_f.b((byte)62);
        }
        if (ka.P == pa.V) {
            return jj.jj_f.b((byte)123);
        }
        if (n2 != 116) {
            return null;
        }
        return hb.Ob;
    }

    static {
        f_r = new n();
        f_v = "The account name you use to access RuneScape and other Jagex.com games";
        x = "<%0> cannot join; the game has started.";
        f_p = "<%0> is already on your friend list.";
    }
}
