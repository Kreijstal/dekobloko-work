/*
 * Decompiled with CFR 0.152.
 */
final class ta {
    static qm ta_a;
    static boolean ta_f;
    private String ta_e;
    private boolean ta_j = false;
    private boolean ta_c = false;
    static hn ta_i;
    static String ta_g;
    static int ta_d;
    static dd ta_k;
    static int ta_b;
    static String ta_h;

    public static void a(boolean bl) {
        ta_a = null;
        if (bl) {
            return;
        }
        ta_h = null;
        ta_k = null;
        ta_g = null;
    }

    static final int a(CharSequence charSequence, int n) {
        boolean bl = client.A;
        int n2 = -43 / ((n - -74) / 38);
        int n3 = charSequence.length();
        int n4 = 0;
        int n5 = 0;
        while (~n5 > ~n3) {
            n4 = (n4 << -397216347) + (-n4 - -j.a(charSequence.charAt(n5), (byte)28));
            ++n5;
        }
        return n4;
    }

    static final boolean a(byte by) {
        if (by > -22) {
            ta.a(false);
        }
        return -21 < ~ca.ca_vb || !t.i((byte)124) || -1 > ~bb.bb_e && !bd.d((byte)31);
    }

    static final boolean a(ji ji2, ji ji3, int n, ji ji4) {
        block3: {
            if (!ji2.a((byte)121) || !ji2.a("commonui", (byte)-101)) {
                return false;
            }
            if (!ji3.a((byte)121) || !ji3.a("commonui", (byte)-117)) {
                return false;
            }
            if (!ji4.a((byte)121) || !ji4.a("button.gif", (byte)-34)) {
                return false;
            }
            if (n == -21) break block3;
            ta_h = null;
        }
        return true;
    }

    static final ck[] a(boolean bl2, int n, int n2, int n3, int n4) {
        block0: {
            if (!bl2) break block0;
            ta.a(false, 17, -88, -29, -62);
        }
        return ca.a(n3, 1, n4, 1, 1, false, n2, n, 3);
    }

    final void a(int n, boolean bl2) {
        block0: {
            this.ta_j = true;
            this.ta_c = bl2;
            if (n == -21) break block0;
            ta.a(false);
        }
    }

    final boolean b(int n) {
        if (n != -3348) {
            return false;
        }
        return this.ta_c;
    }

    final boolean a(int n) {
        if (n < 49) {
            return false;
        }
        return this.ta_j;
    }

    ta(String string) {
        this.ta_e = string;
    }

    final String b(byte by) {
        block0: {
            if (by >= 59) break block0;
            this.ta_j = true;
        }
        return this.ta_e;
    }

    static {
        ta_i = null;
        ta_g = "Fullscreen mode";
        ta_d = 0;
        ta_a = new qm(1, 2, 2, 0);
        ta_h = "Auto-respond to <%0>";
    }
}
