/*
 * Decompiled with CFR 0.152.
 */
final class la {
    private si la_e;
    private int la_c;
    static int la_a = 0;
    static boolean la_d;
    private uh la_b = new uh();
    static int[] la_h;
    private int la_f;
    static String la_g;

    private final void a(int n, long l) {
        vi vi2;
        if (n != 0) {
            ji ji2 = null;
            la.a(ji2, 118);
        }
        vi vi3 = vi2 = (vi)this.la_e.a(l, (byte)-37);
        this.a(-124, vi2);
    }

    final Object a(long l, byte by) {
        vi vi2 = (vi)this.la_e.a(l, (byte)-37);
        if (vi2 == null) {
            return null;
        }
        Object object = vi2.c(-1);
        if (by >= -9) {
            this.a(69L, (byte)-13);
        }
        if (null == object) {
            vi2.b((byte)119);
            vi2.e((byte)92);
            this.la_c += vi2.y;
            return null;
        }
        if (!vi2.g((byte)-83)) {
            this.la_b.a((byte)4, vi2);
            vi2.be_r = 0L;
        } else {
            ua ua2 = new ua(object, vi2.y);
            this.la_e.a(vi2.bh_i, false, ua2);
            this.la_b.a((byte)4, ua2);
            ua2.be_r = 0L;
            vi2.b((byte)106);
            vi2.e((byte)125);
        }
        return object;
    }

    final void a(Object object, long l, int n) {
        block0: {
            this.a(l, (byte)77, 1, object);
            if (n >= 3) break block0;
            this.a(94, -31L);
        }
    }

    private final void a(long l, byte by, int n, Object object) {
        vi vi2;
        boolean bl = client.A;
        if (n > this.la_f) {
            throw new IllegalStateException();
        }
        this.a(by + -77, l);
        this.la_c -= n;
        while (this.la_c < 0) {
            vi2 = (vi)this.la_b.a((byte)67);
            this.a(-122, vi2);
        }
        vi2 = new ua(object, n);
        this.la_e.a(l, false, vi2);
        this.la_b.a((byte)4, vi2);
        if (by != 77) {
            la.a((byte)-109);
        }
        vi2.be_r = 0L;
    }

    la(int n) {
        this(n, n);
    }

    static final void a(ji ji2, int n) {
        a.a_p = id.a(ji2, "display_name_changed", "basic", n ^ 0x5E75);
        k.k_b = new s(0L, id.N, o.o_h, fl.fl_e);
        ge.ge_f = new s(0L, id.N, mf.V, wk.wk_o);
        tb.tb_c = new w(0L, null);
        jc.jc_c = new w(0L, ua.H);
        jc.jc_c.X = 1;
        tc.Ub = new w(0L, fh.fh_g, cb.cb_h);
        cf.cf_d = new w(0L, dd.dd_k, qj.qj_e);
        jc.jc_d = new w(0L, df.df_ab);
        tb.tb_c.a(jc.jc_c, -16834);
        tb.tb_c.a(tc.Ub, -16834);
        tb.tb_c.a(cf.cf_d, -16834);
        tb.tb_c.a(k.k_b, n ^ 0xFFFFC04B);
        tb.tb_c.a(jc.jc_d, -16834);
        k.k_b.Rb.Rb.a(n ^ 0xFFFF81FA, ua.H);
        k.k_b.Rb.Rb.W = 1;
        if (n != 32373) {
            la.a((byte)92);
        }
        w w2 = k.k_b.Rb.Rb;
        w2.X = 1;
        ge.ge_f.Rb.Rb.a(n + -32488, ua.H);
        ge.ge_f.Rb.Rb.W = 1;
        w w3 = ge.ge_f.Rb.Rb;
        w3.X = 1;
    }

    public static void a(byte by) {
        block0: {
            la_g = null;
            la_h = null;
            if (by >= 36) break block0;
            ji ji2 = null;
            la.a(ji2, 120);
        }
    }

    private final void a(int n, vi vi2) {
        block1: {
            if (n > -111) {
                return;
            }
            if (null == vi2) break block1;
            vi2.b((byte)105);
            vi2.e((byte)76);
            this.la_c += vi2.y;
        }
    }

    private la(int n, int n2) {
        int n3;
        this.la_f = n;
        this.la_c = n;
        for (n3 = 1; n > n3 + n3 && n2 > n3; n3 += n3) {
        }
        this.la_e = new si(n3);
    }

    static {
        la_g = "End Game";
        la_h = new int[128];
    }
}
