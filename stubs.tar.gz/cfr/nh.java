/*
 * Decompiled with CFR 0.152.
 */
import java.io.EOFException;
import java.io.IOException;

final class nh {
    private long nh_b;
    private long nh_k;
    private long nh_n;
    private long nh_j;
    private long nh_e = -1L;
    private hf nh_h;
    private int nh_m;
    private byte[] nh_g;
    private long nh_o = -1L;
    private byte[] nh_d;
    private int nh_c = 0;
    static qm nh_i = new qm(0, 2, 2, 1);
    static boolean nh_a;
    static char[] nh_l;
    static String nh_f;

    public static void a(byte by) {
        nh_f = null;
        nh_l = null;
        if (by != -73) {
            return;
        }
        nh_i = null;
    }

    final void a(long l, byte by) throws IOException {
        block1: {
            if ((l ^ 0xFFFFFFFFFFFFFFFFL) > -1L) {
                throw new IOException();
            }
            this.nh_j = l;
            if (by == -109) break block1;
            nh.a((byte)91);
        }
    }

    private final void b(byte by) throws IOException {
        block9: {
            boolean bl = client.A;
            int n = 75 / ((by - -55) / 40);
            if (this.nh_e == -1L) break block9;
            if ((this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) != (this.nh_b ^ 0xFFFFFFFFFFFFFFFFL)) {
                this.nh_h.a(this.nh_e, 80);
                this.nh_b = this.nh_e;
            }
            this.nh_h.a(this.nh_d, 117, 0, this.nh_c);
            this.nh_b += (long)this.nh_c;
            if ((this.nh_k ^ 0xFFFFFFFFFFFFFFFFL) > (this.nh_b ^ 0xFFFFFFFFFFFFFFFFL)) {
                this.nh_k = this.nh_b;
            }
            long l = -1L;
            if ((this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) > (this.nh_o ^ 0xFFFFFFFFFFFFFFFFL) || (this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) <= (this.nh_o + (long)this.nh_m ^ 0xFFFFFFFFFFFFFFFFL)) {
                if ((this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) >= (this.nh_o ^ 0xFFFFFFFFFFFFFFFFL) && ((long)this.nh_c + this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) < (this.nh_o ^ 0xFFFFFFFFFFFFFFFFL)) {
                    l = this.nh_o;
                }
            } else {
                l = this.nh_e;
            }
            long l2 = -1L;
            if ((this.nh_o ^ 0xFFFFFFFFFFFFFFFFL) <= ((long)this.nh_c + this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) || (long)this.nh_m + this.nh_o < (long)this.nh_c + this.nh_e) {
                if ((long)this.nh_m + this.nh_o > this.nh_e && this.nh_o + (long)this.nh_m <= this.nh_e + (long)this.nh_c) {
                    l2 = this.nh_o + (long)this.nh_m;
                }
            } else {
                l2 = this.nh_e + (long)this.nh_c;
            }
            if (-1L < l && (l ^ 0xFFFFFFFFFFFFFFFFL) > (l2 ^ 0xFFFFFFFFFFFFFFFFL)) {
                int n2 = (int)(l2 - l);
                an.a(this.nh_d, (int)(-this.nh_e + l), this.nh_g, (int)(-this.nh_o + l), n2);
            }
            this.nh_e = -1L;
            this.nh_c = 0;
        }
    }

    final long b(int n) {
        int n2 = 93 / ((-25 - n) / 62);
        return this.nh_n;
    }

    private final void a(int n) throws IOException {
        boolean bl = client.A;
        this.nh_m = n;
        if (this.nh_b != this.nh_j) {
            this.nh_h.a(this.nh_j, 123);
            this.nh_b = this.nh_j;
        }
        this.nh_o = this.nh_j;
        while (~this.nh_m > ~this.nh_g.length) {
            int n2 = -this.nh_m + this.nh_g.length;
            if (-200000001 > ~n2) {
                n2 = 200000000;
            }
            int n3 = this.nh_h.a(this.nh_g, (byte)-103, this.nh_m, n2);
            if (-1 == n3) break;
            this.nh_m += n3;
            this.nh_b += (long)n3;
        }
    }

    final void a(int n, byte[] byArray, int n2, int n3) throws IOException {
        boolean bl = client.A;
        try {
            int n4;
            if (n2 != 741) {
                nh.a((byte)18, 18);
            }
            if (~byArray.length > ~(n - -n3)) {
                throw new ArrayIndexOutOfBoundsException(-byArray.length + (n + n3));
            }
            if ((this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) != 0L && this.nh_j >= this.nh_e && this.nh_j + (long)n3 <= (long)this.nh_c + this.nh_e) {
                an.a(this.nh_d, (int)(-this.nh_e + this.nh_j), byArray, n, n3);
                this.nh_j += (long)n3;
                return;
            }
            long l = this.nh_j;
            int n5 = n;
            int n6 = n3;
            if ((this.nh_j ^ 0xFFFFFFFFFFFFFFFFL) <= (this.nh_o ^ 0xFFFFFFFFFFFFFFFFL) && this.nh_j < (long)this.nh_m + this.nh_o) {
                n4 = (int)((long)this.nh_m + (-this.nh_j - -this.nh_o));
                if (n3 < n4) {
                    n4 = n3;
                }
                an.a(this.nh_g, (int)(this.nh_j - this.nh_o), byArray, n, n4);
                this.nh_j += (long)n4;
                n3 -= n4;
                n += n4;
            }
            if (n3 > this.nh_g.length) {
                this.nh_h.a(this.nh_j, 23);
                this.nh_b = this.nh_j;
                while (0 < n3 && ~(n4 = this.nh_h.a(byArray, (byte)-38, n, n3)) != 0) {
                    this.nh_b += (long)n4;
                    n3 -= n4;
                    n += n4;
                    this.nh_j += (long)n4;
                }
            } else if (~n3 < -1) {
                this.a(0);
                n4 = n3;
                if (~this.nh_m > ~n4) {
                    n4 = this.nh_m;
                }
                an.a(this.nh_g, 0, byArray, n, n4);
                n += n4;
                n3 -= n4;
                this.nh_j += (long)n4;
            }
            if (this.nh_e != -1L) {
                if (this.nh_j < this.nh_e && -1 > ~n3) {
                    n4 = n - -((int)(this.nh_e - this.nh_j));
                    if (n4 > n - -n3) {
                        n4 = n3 + n;
                    }
                    while (n4 > n) {
                        --n3;
                        byArray[n++] = 0;
                        ++this.nh_j;
                    }
                }
                long l2 = -1L;
                if ((l ^ 0xFFFFFFFFFFFFFFFFL) >= (this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) && this.nh_e < l - -((long)n6)) {
                    l2 = this.nh_e;
                } else if ((this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) >= (l ^ 0xFFFFFFFFFFFFFFFFL) && (l ^ 0xFFFFFFFFFFFFFFFFL) > ((long)this.nh_c + this.nh_e ^ 0xFFFFFFFFFFFFFFFFL)) {
                    l2 = l;
                }
                long l3 = -1L;
                if ((long)this.nh_c + this.nh_e <= l || ((long)n6 + l ^ 0xFFFFFFFFFFFFFFFFL) > ((long)this.nh_c + this.nh_e ^ 0xFFFFFFFFFFFFFFFFL)) {
                    if (this.nh_e < (long)n6 + l && ((long)this.nh_c + this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) <= (l + (long)n6 ^ 0xFFFFFFFFFFFFFFFFL)) {
                        l3 = (long)n6 + l;
                    }
                } else {
                    l3 = this.nh_e - -((long)this.nh_c);
                }
                if (l2 > -1L && (l3 ^ 0xFFFFFFFFFFFFFFFFL) < (l2 ^ 0xFFFFFFFFFFFFFFFFL)) {
                    int n7 = (int)(l3 - l2);
                    an.a(this.nh_d, (int)(-this.nh_e + l2), byArray, n5 + (int)(-l + l2), n7);
                    if ((l3 ^ 0xFFFFFFFFFFFFFFFFL) < (this.nh_j ^ 0xFFFFFFFFFFFFFFFFL)) {
                        n3 = (int)((long)n3 - (-this.nh_j + l3));
                        this.nh_j = l3;
                    }
                }
            }
        }
        catch (IOException iOException) {
            this.nh_b = -1L;
            throw iOException;
        }
        if (~n3 < -1) {
            throw new EOFException();
        }
    }

    final void c(byte by) throws IOException {
        block0: {
            this.b((byte)-99);
            this.nh_h.a(-82);
            if (by >= 113) break block0;
            nh_l = null;
        }
    }

    final void a(byte[] byArray, byte by, int n, int n2) throws IOException {
        boolean bl = client.A;
        try {
            if ((this.nh_n ^ 0xFFFFFFFFFFFFFFFFL) > (this.nh_j - -((long)n2) ^ 0xFFFFFFFFFFFFFFFFL)) {
                this.nh_n = (long)n2 + this.nh_j;
            }
            if (-1L != this.nh_e && ((this.nh_j ^ 0xFFFFFFFFFFFFFFFFL) > (this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) || (this.nh_j ^ 0xFFFFFFFFFFFFFFFFL) < (this.nh_e - -((long)this.nh_c) ^ 0xFFFFFFFFFFFFFFFFL))) {
                this.b((byte)-120);
            }
            if (0L != (this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) && this.nh_j + (long)n2 > this.nh_e - -((long)this.nh_d.length)) {
                int n3 = (int)((long)this.nh_d.length + (this.nh_e + -this.nh_j));
                an.a(byArray, n, this.nh_d, (int)(this.nh_j - this.nh_e), n3);
                n += n3;
                n2 -= n3;
                this.nh_j += (long)n3;
                this.nh_c = this.nh_d.length;
                this.b((byte)-15);
            }
            if (~this.nh_d.length > ~n2) {
                if ((this.nh_j ^ 0xFFFFFFFFFFFFFFFFL) != (this.nh_b ^ 0xFFFFFFFFFFFFFFFFL)) {
                    this.nh_h.a(this.nh_j, 47);
                    this.nh_b = this.nh_j;
                }
                this.nh_h.a(byArray, 83, n, n2);
                this.nh_b += (long)n2;
                if (this.nh_b > this.nh_k) {
                    this.nh_k = this.nh_b;
                }
                long l = -1L;
                if ((this.nh_o ^ 0xFFFFFFFFFFFFFFFFL) >= (this.nh_j ^ 0xFFFFFFFFFFFFFFFFL) && this.nh_j < this.nh_o + (long)this.nh_m) {
                    l = this.nh_j;
                } else if (this.nh_o >= this.nh_j && this.nh_o < (long)n2 + this.nh_j) {
                    l = this.nh_o;
                }
                long l2 = -1L;
                if (this.nh_o >= this.nh_j - -((long)n2) || (long)this.nh_m + this.nh_o < (long)n2 + this.nh_j) {
                    if ((long)this.nh_m + this.nh_o > this.nh_j && (this.nh_o - -((long)this.nh_m) ^ 0xFFFFFFFFFFFFFFFFL) >= ((long)n2 + this.nh_j ^ 0xFFFFFFFFFFFFFFFFL)) {
                        l2 = this.nh_o - -((long)this.nh_m);
                    }
                } else {
                    l2 = this.nh_j + (long)n2;
                }
                if ((l ^ 0xFFFFFFFFFFFFFFFFL) < 0L && l2 > l) {
                    int n4 = (int)(-l + l2);
                    an.a(byArray, (int)(l + ((long)n + -this.nh_j)), this.nh_g, (int)(-this.nh_o + l), n4);
                }
                this.nh_j += (long)n2;
                return;
            }
            if (by <= 91) {
                nh_f = null;
            }
            if (n2 > 0) {
                if ((this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) == 0L) {
                    this.nh_e = this.nh_j;
                }
                an.a(byArray, n, this.nh_d, (int)(this.nh_j - this.nh_e), n2);
                this.nh_j += (long)n2;
                if ((this.nh_j + -this.nh_e ^ 0xFFFFFFFFFFFFFFFFL) < ((long)this.nh_c ^ 0xFFFFFFFFFFFFFFFFL)) {
                    this.nh_c = (int)(-this.nh_e + this.nh_j);
                }
                return;
            }
        }
        catch (IOException iOException) {
            this.nh_b = -1L;
            throw iOException;
        }
    }

    static final void a(byte by, int n) {
        block3: {
            if (by != 12) {
                return;
            }
            qk.qk_i = 3 & n >> -171891708;
            wh.wh_d = (0xD & n) >> -1689619070;
            if (2 < qk.qk_i) {
                qk.qk_i = 2;
            }
            wl.wl_o = 3 & n;
            if (wh.wh_d > 2) {
                wh.wh_d = 2;
            }
            if (-3 <= ~wl.wl_o) break block3;
            wl.wl_o = 2;
        }
    }

    nh(hf hf2, int n, int n2) throws IOException {
        this.nh_h = hf2;
        this.nh_n = this.nh_k = hf2.a((byte)-50);
        this.nh_g = new byte[n];
        this.nh_j = 0L;
        this.nh_d = new byte[n2];
    }

    final void a(byte[] byArray, byte by) throws IOException {
        this.a(0, byArray, 741, byArray.length);
        int n = 38 / ((by - 70) / 44);
    }

    static {
        nh_f = "Show all lobby chat";
        nh_l = new char[]{(char)8364, (char)0, (char)8218, (char)402, (char)8222, (char)8230, (char)8224, (char)8225, (char)710, (char)8240, (char)352, (char)8249, (char)338, (char)0, (char)381, (char)0, (char)0, (char)8216, (char)8217, (char)8220, (char)8221, (char)8226, (char)8211, (char)8212, (char)732, (char)8482, (char)353, (char)8250, (char)339, (char)0, (char)382, (char)376};
    }
}
