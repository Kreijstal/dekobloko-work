/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

class a
implements gl,
nl {
    int a_i;
    int a_q;
    static int[] a_r;
    mm z;
    int a_m;
    int a_o;
    static String a_e;
    static lm a_t;
    static int[] a_u;
    private int a_a;
    int a_b;
    int a_c;
    int a_s;
    static int[] a_j;
    int a_f;
    private boolean a_w;
    int y;
    static int a_g;
    int a_v;
    private static long[] a_d;
    static int a_k;
    static String x;
    static ck[] a_n;
    static String a_l;
    static ck a_p;
    static int a_h;

    private final int c(ce ce2, byte by) {
        block0: {
            if (by < -124) break block0;
            ce ce3 = null;
            this.b(ce3, 125, -17, 115);
        }
        return ce2.y - (this.a_m - -this.y);
    }

    @Override
    public final int a(ce ce2, int n) {
        this.a(ce2, (byte)83);
        int n2 = -78 / ((-85 - n) / 36);
        return ce2.ce_n.b(-1) - -this.a_m - -this.y;
    }

    @Override
    public final cf a(ce ce2, byte by) {
        block3: {
            if (null == ce2.ce_n) {
                ce2.ce_n = new ea();
            }
            if (!this.a_w) {
                this.c(ce2, 18580);
            } else {
                ((ea)ce2.ce_n).a(this.b(ce2, (byte)121), this.a_o, this.z, this.a(false, ce2), this.c(ce2, (byte)-128), this.a_f, 86, this.a_b);
            }
            if (by >= 38) break block3;
            ce ce3 = null;
            this.a((byte)-75, ce3, 115);
        }
        return ce2.ce_n;
    }

    a(mm mm2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        this(mm2, n, n, n2, n2, n3, n4, n5, n6, n7, -1, Integer.MAX_VALUE, false);
    }

    private final int b(ce ce2, int n, int n2, int n3) {
        if (n2 < 72) {
            return -124;
        }
        return n + (this.a_s + (ce2.ce_u + n3)) + ce2.x;
    }

    @Override
    public final void a(ce ce2, int n, int n2, int n3, int n4) {
        block1: {
            if (ce2.a(true)) {
                cf cf2;
                cf cf3 = cf2 = this.a(ce2, (byte)53);
                int n5 = cf3.a(false, n);
                nf nf2 = cf2.cf_a[n5];
                int n6 = cf3.a((byte)-94, n);
                int n7 = this.b(ce2, n6, n2 + 110, n3);
                int n8 = this.a(n4, 0, ce2) + Math.max(0, nf2.nf_c);
                int n9 = this.a(n4, 0, ce2) + Math.min(this.c(ce2, (byte)-128), Math.min(nf2.nf_i, cf3.cf_a.length <= 1 + n5 ? nf2.nf_i : cf2.cf_a[n5 - -1].nf_c));
                gg.a(n4 + ce2.D, 20763, ce2.ce_u + (n3 + ce2.ce_t), ce2.ce_u + n3, ce2.D + n4 - -ce2.y);
                bf.x.a(n7, n8, n7, this.a_v, (byte)64, n9);
                mk.a((byte)-5);
            }
            if (n2 == 1) break block1;
            this.a_c = -31;
        }
    }

    @Override
    public void a(boolean bl, int n, int n2, byte by, ce ce2) {
        if (by >= -60) {
            ce ce3 = null;
            this.b(ce3, 118, -123, 71);
        }
        if (null == this.z) {
            return;
        }
        this.a(n2, ce2, (byte)-102, n);
    }

    @Override
    public final int b(ce ce2, int n) {
        block0: {
            this.a(ce2, (byte)60);
            if (n == 0) break block0;
            this.z = null;
        }
        return ce2.ce_n.a(false) + this.a_s + this.a_i;
    }

    static final void a(int n, boolean bl, boolean bl2) {
        wb wb2 = ma.a(n, bl, (byte)99);
        if (null != wb2) {
            w.H.a(false, 29072);
            pf pf2 = w.H;
            String string = fl.fl_e;
            pf2.pf_h.a(string, 5, 68);
            pf pf3 = w.H;
            int n2 = he.S;
            int n3 = nf.nf_h;
            pf3.pf_h.b(n3, n2, 63, 0, 0);
        }
        he.a(bl2, bl, n);
    }

    static final void a(String string, boolean bl, Applet applet) {
        rb.rb_l = string;
        try {
            String string2 = applet.getParameter("cookieprefix");
            String string3 = applet.getParameter("cookiehost");
            if (bl) {
                return;
            }
            String string4 = string2 + "settings=" + string + "; version=1; path=/; domain=" + string3;
            string4 = -1 != ~string.length() ? string4 + "; Expires=" + uf.a((byte)60, ik.a(4) + 94608000000L) + "; Max-Age=" + 94608000L : string4 + "; Expires=Thu, 01-Jan-1970 00:00:00 GMT; Max-Age=0";
            nc.a((byte)-51, applet, "document.cookie=\"" + string4 + "\"");
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        me.me_a_applet((byte)127, applet);
    }

    @Override
    public final int a(boolean bl, ce ce2) {
        block0: {
            if (!bl) break block0;
            this.a((byte)94);
        }
        return ce2.ce_t + -this.a_s + -this.a_i;
    }

    @Override
    public final int a(byte by, ce ce2, int n) {
        block0: {
            if (by > 6) break block0;
            ce ce3 = null;
            this.c(ce3, (byte)-126);
        }
        return this.b(ce2, 0, 97, n);
    }

    @Override
    public final void a(int n, int n2, int n3, int n4, int n5, ce ce2) {
        block5: {
            boolean bl = client.A;
            if (~n2 == ~n) {
                return;
            }
            if (ce2.a(true)) {
                int n6;
                int n7;
                cf cf2;
                cf cf3 = cf2 = this.a(ce2, (byte)100);
                if (~n <= ~n2) {
                    n7 = n;
                    n6 = n2;
                } else {
                    n7 = n2;
                    n6 = n;
                }
                int n8 = cf3.a(false, n6);
                int n9 = cf3.a(false, n7);
                gg.a(n3 - -ce2.D, 20763, ce2.ce_t + n4 - -ce2.ce_u, ce2.ce_u + n4, n3 + (ce2.D - -ce2.y));
                for (int j = n8; j <= n9; ++j) {
                    int n10;
                    nf nf2 = cf2.cf_a[j];
                    int n11 = n10 = j != n8 ? nf2.nf_a[0] : cf3.a((byte)-94, n6);
                    int n12 = ~j == ~n9 ? cf3.a((byte)-94, n7) : (nf2 == null ? 0 : nf2.nf_a[-1 + nf2.nf_a.length]);
                    bf.x.a((byte)-115, nf2.nf_c + ce2.F + (n3 - (-ce2.D - this.a_m)), this.a_c >>> 211015160, -n10 + n12, nf2.nf_i, this.a_c, this.b(ce2, n10, 96, n4));
                }
                mk.a((byte)-5);
            }
            if (n5 <= -89) break block5;
            this.a_i = -114;
        }
    }

    private final int a(ce ce2, int n, int n2, int n3) {
        block0: {
            if (n == 20881) break block0;
            this.a_v = 65;
        }
        return n2 + (this.a_m + (ce2.D + n3)) + ce2.F;
    }

    private final void c(ce ce2, int n) {
        block8: {
            int n2;
            int n3;
            block9: {
                block7: {
                    block6: {
                        int n4;
                        block5: {
                            int n5;
                            block4: {
                                block3: {
                                    block2: {
                                        boolean bl = client.A;
                                        if (null == ce2.ce_n) {
                                            ce2.ce_n = new ea();
                                        }
                                        n3 = this.a(false, ce2);
                                        n5 = this.c(ce2, (byte)-127);
                                        if (n != 18580) {
                                            a a2 = null;
                                            this.a(-13, a2);
                                        }
                                        if (-1 == ~(n4 = this.a_o)) break block2;
                                        if (~n4 == -3) break block3;
                                        if (-4 == ~n4 || -2 != ~n4) break block4;
                                        break block4;
                                    }
                                    n2 = this.z.R;
                                    break block5;
                                }
                                n2 = -this.z.K + n5;
                                break block5;
                            }
                            n2 = (-this.z.K + n5 + -this.z.R >> -1764590527) + this.z.R;
                        }
                        n4 = this.a_f;
                        if (-1 == ~n4 || n4 == 3) break block6;
                        if (~n4 == -2) break block7;
                        if (2 != n4) break block8;
                        break block9;
                    }
                    if (!(ce2.ce_n instanceof ea)) break block8;
                    ((ea)ce2.ce_n).a(0, this.z, this.b(ce2, (byte)127), n2, 25);
                    break block8;
                }
                if (!(ce2.ce_n instanceof ea)) break block8;
                ((ea)ce2.ce_n).a(n2, n3 >> 2108713153, this.b(ce2, (byte)116), (byte)8, this.z);
                break block8;
            }
            if (!(ce2.ce_n instanceof ea)) break block8;
            ((ea)ce2.ce_n).a(n ^ 0x4894, this.z, n3, n2, this.b(ce2, (byte)122));
        }
    }

    String b(ce ce2, byte by) {
        int n = -9 % ((by - 59) / 53);
        return ce2.E;
    }

    private final void a(int n, int n2, int n3, int n4, ce ce2, boolean bl, int n5, int n6) {
        block8: {
            int n7;
            int n8;
            block1: {
                int n9;
                block9: {
                    block7: {
                        block6: {
                            int n10;
                            block5: {
                                block4: {
                                    block3: {
                                        block2: {
                                            boolean bl2 = client.A;
                                            gg.a(ce2.D + n6, 20763, ce2.ce_t + (ce2.ce_u + n4), n4 - -ce2.ce_u, n6 + ce2.D - -ce2.y);
                                            if (!bl) {
                                                return;
                                            }
                                            n8 = this.a(false, ce2);
                                            n7 = this.c(ce2, (byte)-125);
                                            if (this.a_w) break block1;
                                            n10 = this.a_o;
                                            if (~n10 == -1) break block2;
                                            if (2 == n10) break block3;
                                            if (n10 == 3 || ~n10 != -2) break block4;
                                            break block4;
                                        }
                                        n9 = this.z.R;
                                        break block5;
                                    }
                                    n9 = -this.z.K + n7;
                                    break block5;
                                }
                                n9 = (-this.z.R + n7 - this.z.K >> 1767974529) + this.z.R;
                            }
                            n10 = this.a_f;
                            if (0 == n10 || -4 == ~n10) break block6;
                            if (-2 == ~n10) break block7;
                            if (~n10 != -3) break block8;
                            break block9;
                        }
                        this.z.a(this.b(ce2, (byte)-50), this.b(ce2, n, 81, n4), n9 + this.a(ce2, 20881, n5, n6), n2, n3);
                        break block8;
                    }
                    this.z.b(this.b(ce2, (byte)-67), this.b(ce2, n, 122, n4) - -(n8 >> 505266145), n9 + this.a(ce2, 20881, n5, n6), n2, n3);
                    break block8;
                }
                this.z.c(this.b(ce2, (byte)123), n8 + this.b(ce2, n, 78, n4), this.a(ce2, 20881, n5, n6) - -n9, n2, n3);
                break block8;
            }
            this.z.a(this.b(ce2, (byte)-36), this.b(ce2, n, 74, n4), this.a(ce2, 20881, n5, n6), n8, n7, n2, n3, this.a_f, this.a_o, this.a_b);
        }
        mk.a((byte)-5);
    }

    static final String a(Applet applet, byte by) {
        boolean bl = client.A;
        try {
            if (by <= 110) {
                Applet applet2 = null;
                a.a(null, false, applet2);
            }
            String string = applet.getParameter("cookieprefix");
            String string2 = string + "settings";
            String string3 = (String)nc.a(true, "getcookies", applet);
            String[] stringArray = ji.a(';', (byte)66, string3);
            int n = 0;
            while (~stringArray.length < ~n) {
                int n2 = stringArray[n].indexOf(61);
                if (~n2 <= -1 && stringArray[n].substring(0, n2).trim().equals(string2)) {
                    return stringArray[n].substring(n2 - -1).trim();
                }
                ++n;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (null != rb.rb_l) {
            return rb.rb_l;
        }
        return applet.getParameter("settings");
    }

    public static void a(int n) {
        if (n != -1) {
            return;
        }
        a_e = null;
        a_l = null;
        x = null;
        a_n = null;
        a_d = null;
        a_u = null;
        a_r = null;
        a_j = null;
        a_t = null;
        a_p = null;
    }

    @Override
    public final int a(byte by) {
        if (by > -4) {
            return -27;
        }
        return this.z.K + this.z.R;
    }

    private final void a(int n, ce ce2, byte by, int n2) {
        if (by >= -1) {
            ce ce3 = null;
            this.c(ce3, 109);
        }
        this.a(0, this.a_q, this.a_a, n2, ce2, true, 0, n);
    }

    @Override
    public final int a(int n, int n2, ce ce2, int n3, int n4, int n5) {
        if (n2 != -257) {
            return -101;
        }
        this.a(ce2, (byte)46);
        return ce2.ce_n.a(n5 + -this.a((byte)81, ce2, n), n4 - this.a(n3, 0, ce2), n2 ^ 0x7DAC);
    }

    static final pi b(int n) {
        pi pi2 = new pi(ed.ed_f, i.i_d, sg.sg_d[0], fh.fh_a[0], tm.tm_a[0], hc.hc_c[0], tc.Nb[n], mb.mb_d);
        oa.a(127);
        return pi2;
    }

    protected a() {
    }

    static final void a(int n, int n2, ud ud2, int n3, int n4) {
        int n5 = (int)(0.5 + (double)(n4 * ud2.ud_p) * Math.pow(2.0, 8.333333333333334E-4 * (double)n) / (double)en.en_o);
        dg.dg_c.a(ud2, n5, pb.pb_d * n2, n3 << 1104899142);
    }

    a(mm mm2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, boolean bl) {
        this.a_m = n3;
        this.a_a = n6;
        this.a_b = n9;
        this.a_i = n2;
        this.a_q = n5;
        this.a_f = n7;
        this.y = n4;
        this.a_v = n10;
        this.a_s = n;
        this.z = mm2;
        this.a_o = n8;
        this.a_c = n11;
        this.a_w = bl;
    }

    final void a(int n, a a2) {
        a2.a_i = this.a_i;
        a2.a_a = this.a_a;
        a2.a_m = this.a_m;
        a2.a_q = this.a_q;
        a2.a_c = this.a_c;
        if (n != -12253) {
            this.a_s = -80;
        }
        a2.a_s = this.a_s;
        a2.a_b = this.a_b;
        a2.a_o = this.a_o;
        a2.y = this.y;
        a2.a_f = this.a_f;
        a2.z = this.z;
        a2.a_w = this.a_w;
        a2.a_v = this.a_v;
    }

    @Override
    public final int a(int n, int n2, ce ce2) {
        block0: {
            if (n2 == 0) break block0;
            ce ce3 = null;
            this.c(ce3, (byte)33);
        }
        return this.a(ce2, 20881, 0, n);
    }

    static {
        int n;
        a_e = "<%0><br>IS OUT!";
        a_r = new int[1024];
        a_g = 128;
        a_j = new int[256];
        int n2 = 0;
        while (~n2 > -257) {
            int n3 = n2;
            for (n = 0; n < 8; ++n) {
                if (-2 != ~(1 & n3)) {
                    n3 >>>= 1;
                    continue;
                }
                n3 = 0xEDB88320 ^ n3 >>> 73361217;
            }
            a.a_j[n2] = n3;
            ++n2;
        }
        a_d = new long[256];
        x = "Theme";
        a_l = "Invite";
        for (n = 0; 256 > n; ++n) {
            long l = n;
            for (int j = 0; j < 8; ++j) {
                if (-2L == (l & 1L ^ 0xFFFFFFFFFFFFFFFFL)) {
                    l = l >>> 1676111105 ^ 0xC96C5795D7870F42L;
                    continue;
                }
                l >>>= 1;
            }
            a.a_d[n] = l;
        }
    }
}
