/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Frame;
import java.io.IOException;
import java.net.Socket;

final class oj {
    static String oj_a = "Remove <%0> from ignore list";
    static Frame oj_c;
    static String oj_b;

    /*
     * Enabled aggressive block sorting
     */
    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, byte by, int n8, int n9, int n10, int n11, int[] nArray, int n12, int n13, int n14, int n15) {
        int n16;
        int n17;
        int n18;
        int n19;
        int n20;
        int n21;
        int n22;
        int n23;
        int n24;
        int n25;
        int n26;
        int n27;
        int n28;
        int n29;
        int n30;
        int n31;
        int n32;
        int n33;
        int n34;
        int n35;
        int n36;
        int n37;
        block42: {
            boolean bl;
            block40: {
                block41: {
                    int n38;
                    block37: {
                        block38: {
                            block39: {
                                boolean bl2 = client.A;
                                if (n13 < 0) {
                                    return;
                                }
                                if (n11 >= qg.qg_e) {
                                    return;
                                }
                                if (0 > n10 && ~n5 > -1 && ~n6 > -1) {
                                    return;
                                }
                                if (~qg.qg_a >= ~n10 && qg.qg_a <= n5 && ~qg.qg_a >= ~n6) {
                                    return;
                                }
                                if (by >= -32) {
                                    oj.a(false, 33);
                                }
                                n38 = n13 + -n11;
                                if (~n11 == ~n4) break block37;
                                n36 = n37 = n10 << -730941840;
                                n34 = n35 = n15 << 1289314096;
                                n32 = n33 = n14 << 1566545744;
                                n30 = n31 = n3 << 1351173328;
                                n29 = (n6 - n10 << -203723312) / n38;
                                n28 = -n11 + n4;
                                n27 = (n5 + -n10 << 730891408) / n28;
                                if (~n29 >= ~n27) {
                                    n26 = n27;
                                    n27 = n29;
                                    n29 = n26;
                                    n25 = (-n3 + n9 << -673284208) / n38;
                                    n24 = (-n15 + n2 << 1073040304) / n28;
                                    n23 = (n12 - n15 << -173449456) / n38;
                                    bl = true;
                                    n22 = (n7 + -n3 << 383628816) / n28;
                                    n21 = (n - n14 << -1494216976) / n38;
                                    n20 = (-n14 + n8 << 1793998992) / n28;
                                } else {
                                    bl = false;
                                    n25 = (-n3 + n7 << -1396000880) / n28;
                                    n24 = (n12 - n15 << -527501296) / n38;
                                    n20 = (-n14 + n << 88354320) / n38;
                                    n22 = (-n3 + n9 << 1843172400) / n38;
                                    n23 = (-n15 + n2 << 1221710416) / n28;
                                    n21 = (n8 + -n14 << 445940656) / n28;
                                }
                                if (~n11 <= -1) break block38;
                                if (n4 >= 0) break block39;
                                n11 = n4 - n11;
                                n31 += n22 * n11;
                                n36 += n27 * n11;
                                n34 += n23 * n11;
                                n35 += n24 * n11;
                                n32 += n11 * n21;
                                n33 += n11 * n20;
                                n30 += n25 * n11;
                                n37 += n11 * n29;
                                n11 = n4;
                                break block40;
                            }
                            n11 = -n11;
                            n30 += n11 * n25;
                            n31 += n22 * n11;
                            n33 += n20 * n11;
                            n37 += n29 * n11;
                            n36 += n11 * n27;
                            n35 += n11 * n24;
                            n34 += n11 * n23;
                            n32 += n21 * n11;
                            n11 = 0;
                        }
                        n26 = qg.qg_d[n11];
                        break block41;
                    }
                    if (n11 == n13) {
                        n23 = 0;
                        n24 = 0;
                        n34 = n15;
                        n35 = n2;
                        n21 = 0;
                        n31 = n7;
                        n33 = n8;
                        n37 = n5 << 2085950640;
                        n32 = n14;
                        n30 = n3;
                        n36 = n10 << 227461968;
                        n20 = 0;
                        n29 = 0;
                        n25 = 0;
                        n22 = 0;
                        n27 = 0;
                    } else {
                        n28 = -n4 + n13;
                        if (n5 > n10) {
                            n20 = (n + -n8 << 103509712) / n28;
                            n30 = n3 << 1824834864;
                            n37 = n5 << 1447744176;
                            n33 = n8 << -2087622768;
                            n23 = (-n15 + n12 << 169002384) / n38;
                            n25 = (n9 + -n3 << 1818588624) / n38;
                            n36 = n10 << -2136218224;
                            n22 = (n9 - n7 << 2004310480) / n28;
                            n21 = (n + -n14 << 164776688) / n38;
                            n27 = (-n10 + n6 << 57541136) / n38;
                            n31 = n7 << 1927871056;
                            n29 = (n6 + -n5 << -640950384) / n28;
                            n32 = n14 << 769210544;
                            n35 = n2 << -966869008;
                            n24 = (-n2 + n12 << 908598512) / n28;
                            n34 = n15 << -592129456;
                        } else {
                            n22 = (n9 + -n3 << -1680556016) / n38;
                            n25 = (n9 + -n7 << -41763632) / n28;
                            n23 = (-n2 + n12 << 1969128912) / n28;
                            n32 = n8 << 694023920;
                            n34 = n2 << -1110131216;
                            n33 = n14 << 811891056;
                            n20 = (n + -n14 << -870526320) / n38;
                            n29 = (-n10 + n6 << 1917023856) / n38;
                            n21 = (n - n8 << 602685712) / n28;
                            n31 = n3 << 1164548048;
                            n24 = (n12 + -n15 << 1308800688) / n38;
                            n35 = n15 << 1888427600;
                            n36 = n5 << -1712434352;
                            n30 = n7 << 2013083280;
                            n27 = (n6 + -n5 << 1684500688) / n28;
                            n37 = n10 << -1403567344;
                        }
                    }
                    if (~n11 > -1) {
                        n11 = Math.min(-n11, n4 + -n11);
                        n31 += n11 * n22;
                        n35 += n11 * n24;
                        n37 += n11 * n29;
                        n36 += n11 * n27;
                        n32 += n21 * n11;
                        n33 += n20 * n11;
                        n34 += n11 * n23;
                        n30 += n11 * n25;
                        n11 = 0;
                    }
                    bl = false;
                    break block42;
                }
                while (n4 > n11) {
                    n19 = n36 >> 1660328304;
                    if (~qg.qg_a < ~n19) {
                        n18 = -(n36 >> 314386992) + (n37 >> -1916013776);
                        if (-1 == ~n18) {
                            if (n19 >= 0 && ~n19 > ~qg.qg_a) {
                                ve.a(n30, n19 + n26, 0, 0, n32, n18, 9, nArray, n34, 0);
                            }
                        } else {
                            n17 = (n33 + -n32) / n18;
                            n16 = (-n30 + n31) / n18;
                            int n39 = (-n34 + n35) / n18;
                            if (n19 - -n18 >= qg.qg_a) {
                                n18 = -1 + (qg.qg_a - n19);
                            }
                            if (~n19 > -1) {
                                ve.a(n30 + -(n19 * n16), n26, n16, n17, n32 + -(n19 * n17), n18 - -n19, 9, nArray, n34 + -(n19 * n39), n39);
                            } else {
                                ve.a(n30, n19 - -n26, n16, n17, n32, n18, 9, nArray, n34, n39);
                            }
                        }
                    }
                    if (~(++n11) <= ~qg.qg_e) {
                        return;
                    }
                    n37 += n29;
                    n32 += n21;
                    n35 += n24;
                    n31 += n22;
                    n33 += n20;
                    n26 += hk.hk_j;
                    n36 += n27;
                    n30 += n25;
                    n34 += n23;
                }
            }
            n26 = -n4 + n13;
            if (n26 != 0) {
                n19 = n6 << -572941456;
                n18 = n << -204350576;
                n17 = n9 << -1376142832;
                n16 = n12 << 275676016;
                if (bl) {
                    n31 = n7 << 683536;
                    n33 = n8 << 900853968;
                    n35 = n2 << 1844960624;
                    n37 = n5 << 1120306672;
                } else {
                    n32 = n8 << 1813150832;
                    n30 = n7 << -1157667376;
                    n34 = n2 << 1306533680;
                    n36 = n5 << 1674738864;
                }
                n23 = (-n34 + n16) / n26;
                n21 = (n18 + -n32) / n26;
                n25 = (-n30 + n17) / n26;
                n29 = (-n37 + n19) / n26;
                n20 = (-n33 + n18) / n26;
                n24 = (-n35 + n16) / n26;
                n27 = (n19 + -n36) / n26;
                n22 = (n17 + -n31) / n26;
            } else {
                n21 = 0;
                n27 = 0;
                n24 = 0;
                n29 = 0;
                n23 = 0;
                n20 = 0;
                n25 = 0;
                n22 = 0;
            }
        }
        if (n11 < 0) {
            n11 = -n11;
            n30 += n11 * n25;
            n32 += n11 * n21;
            n37 += n11 * n29;
            n36 += n11 * n27;
            n35 += n24 * n11;
            n34 += n23 * n11;
            n31 += n11 * n22;
            n33 += n20 * n11;
            n11 = 0;
        }
        n28 = qg.qg_d[n11];
        while (~n11 > ~n13) {
            n26 = n36 >> -1578848208;
            if (~qg.qg_a < ~n26) {
                n19 = (n37 >> 502258192) - (n36 >> 1575409104);
                if (-1 != ~n19) {
                    n18 = (-n32 + n33) / n19;
                    n17 = (n31 + -n30) / n19;
                    n16 = (-n34 + n35) / n19;
                    if (qg.qg_a <= n19 + n26) {
                        n19 = -n26 + qg.qg_a - 1;
                    }
                    if (-1 < ~n26) {
                        ve.a(n30 + -(n17 * n26), n28, n17, n18, -(n26 * n18) + n32, n19 + n26, 9, nArray, n34 - n16 * n26, n16);
                    } else {
                        ve.a(n30, n28 + n26, n17, n18, n32, n19, 9, nArray, n34, n16);
                    }
                } else if (-1 >= ~n26 && ~qg.qg_a < ~n26) {
                    ve.a(n30, n26 + n28, 0, 0, n32, n19, 9, nArray, n34, 0);
                }
            }
            if (++n11 >= qg.qg_e) {
                return;
            }
            n34 += n23;
            n28 += hk.hk_j;
            n31 += n22;
            n37 += n29;
            n30 += n25;
            n33 += n20;
            n35 += n24;
            n36 += n27;
            n32 += n21;
        }
        return;
    }

    static final int b(int n) {
        if (4 <= ta.ta_k.dd_j) {
            if (~ta.ta_k.dd_o == 0) {
                return 3;
            }
            if (ta.ta_k.dd_o != -2) {
                return 1;
            }
            return 4;
        }
        try {
            if (n == hd.hd_n) {
                d.d_f = bl.U.a(124, pe.pe_b, cb.cb_c);
                ++hd.hd_n;
            }
            if (hd.hd_n == 1) {
                if (2 == d.d_f.mh_c) {
                    return al.a(0, -1);
                }
                if (-2 == ~d.d_f.mh_c) {
                    ++hd.hd_n;
                }
            }
            if (~hd.hd_n == -3) {
                rk.L = new qk((Socket)d.d_f.mh_b, bl.U);
                wl wl2 = new wl(13);
                gi.a(hh.hh_f, fh.fh_f, 17, wl2, cn.U);
                wl2.a(true, 15);
                wl2.a(vm.vm_w, false);
                rk.L.a(0, 13, n + 1, wl2.wl_r);
                ++hd.hd_n;
                me.E = 30000L + ik.a(n ^ 4);
            }
            if (-4 == ~hd.hd_n) {
                if (-1 <= ~rk.L.b(0)) {
                    if (me.E < ik.a(n ^ 4)) {
                        return al.a(0, -2);
                    }
                } else {
                    int n2 = rk.L.c((byte)8);
                    if (-1 != ~n2) {
                        return al.a(0, n2);
                    }
                    ++hd.hd_n;
                }
            }
            if (-5 == ~hd.hd_n) {
                ta.ta_k.a(rk.L, (byte)-128, ta.ta_f);
                rk.L = null;
                d.d_f = null;
                hd.hd_n = 0;
                return 0;
            }
            return -1;
        }
        catch (IOException iOException) {
            return al.a(0, -3);
        }
    }

    public static void a(int n) {
        block0: {
            oj_b = null;
            oj_c = null;
            oj_a = null;
            if (n == 3805) break block0;
            oj_b = null;
        }
    }

    static final ke a(boolean bl2, int n) {
        ec ec2;
        ke ke2;
        ke ke3 = ke2 = new ke(3);
        if (!ph.n(-30146)) {
            ec ec3;
            ke2.a(new ec(23, vh.vh_b[0], a.a_t), 117);
            ke2.a(new ec(23, vh.vh_b[1], a.a_t), n + -299);
            ke2.ke_f[1].ec_n = 200;
            ec2 = ec3 = ke2.ke_f[0];
            ec3.ec_n = 200;
            ke2.ke_f[0].ec_l = 320 + (-ke2.ke_f[0].ec_n + -10);
            ke2.ke_f[1].ec_l = 330;
            ke2.ke_f[1].ec_m = 372;
            ec ec4 = ke2.ke_f[0];
            ec4.ec_m = 372;
        } else {
            ec2 = new ec(20, qn.qn_rb, a.a_t);
            ec2.ec_l = 320 - ec2.ec_n / 2;
            ec2.ec_m = 372;
            ke3.a(ec2, 112);
        }
        ec2 = new ec(13, pc.pc_f, a.a_t);
        ec2.ec_l = -(ec2.ec_n / 2) + 320;
        ec2.ec_m = n;
        ke3.a(ec2, 102);
        ke3.ke_w = 70;
        ke3.y = 500;
        ke3.z = 76;
        ke3.ke_q = 272;
        ke3.a(cj.cj_c, bl2, -129);
        return ke3;
    }

    static {
        oj_b = "To <%0>: ";
    }
}
