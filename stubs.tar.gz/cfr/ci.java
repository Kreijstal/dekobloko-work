/*
 * Decompiled with CFR 0.152.
 */
final class ci {
    static String ci_g;
    static String ci_f;
    static String ci_e;
    static vj ci_a;
    static String ci_b;
    static boolean ci_c;
    static vj ci_h;
    static String ci_d;

    public static void a(int n) {
        if (n != -27513) {
            return;
        }
        ci_d = null;
        ci_f = null;
        ci_g = null;
        ci_b = null;
        ci_e = null;
        ci_h = null;
        ci_a = null;
    }

    static final pi[] b(int n) {
        boolean bl = client.A;
        pi[] piArray = new pi[ec.ec_g];
        if (n > -110) {
            return null;
        }
        int n2 = 0;
        while (~n2 > ~ec.ec_g) {
            piArray[n2] = new pi(ed.ed_f, i.i_d, sg.sg_d[n2], fh.fh_a[n2], tm.tm_a[n2], hc.hc_c[n2], tc.Nb[n2], mb.mb_d);
            ++n2;
        }
        oa.a(126);
        return piArray;
    }

    static final void a(byte by) {
        boolean bl = client.A;
        int[] nArray = nm.Nb;
        int[] nArray2 = nm.Nb;
        int n = -61 % ((60 - by) / 38);
        int n2 = 0;
        int n3 = nArray.length;
        while (n2 < n3) {
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
        }
    }

    static final void a(cc cc2, int n, int n2, byte by, int n3, cc cc3) {
        if (by >= -62) {
            ci_d = null;
        }
        nf.nf_g = cc2;
        da.da_c = cc3;
        mb.mb_c = n;
        qk.qk_m = n3;
        pa.Y = n2;
    }

    static final boolean a(char c, byte by) {
        if (by < 66) {
            ci.a((byte)-16);
        }
        if (Character.isISOControl(c)) {
            return false;
        }
        if (j.a(-8241, c)) {
            return true;
        }
        return '-' == c || '\u00a0' == c || ' ' == c || c == '_';
    }

    static {
        ci_f = "<%0> has not yet unlocked this option for use.";
        ci_g = "Hide private chat and appear offline to friends";
        ci_e = "Please select an option in the '<%0>' row.";
        ci_a = new vj();
        ci_b = "Try changing the '<%0>' setting.";
        ci_d = "Click or press F10 to open Quick Chat";
    }
}
