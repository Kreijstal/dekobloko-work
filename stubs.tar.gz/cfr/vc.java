/*
 * Decompiled with CFR 0.152.
 */
import java.awt.DisplayMode;
import java.awt.Frame;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

final class vc {
    private GraphicsDevice vc_a;
    private DisplayMode vc_b;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void a(Frame frame, int n) {
        int n2 = -31 % ((1 - n) / 51);
        this.vc_a.setFullScreenWindow(frame);
    }

    public final int[] listmodes() {
        DisplayMode[] displayModeArray;
        DisplayMode[] displayModeArray2 = displayModeArray = this.vc_a.getDisplayModes();
        int[] nArray = new int[displayModeArray.length << -328200030];
        for (int i = 0; i < displayModeArray.length; ++i) {
            nArray[i << -1813773502] = displayModeArray[i].getWidth();
            nArray[(i << 373556130) + 1] = displayModeArray[i].getHeight();
            nArray[2 + (i << 840954370)] = displayModeArray[i].getBitDepth();
            nArray[3 + (i << 975549314)] = displayModeArray[i].getRefreshRate();
        }
        return nArray;
    }

    public final void enter(Frame frame, int n, int n2, int n3, int n4) {
        this.vc_b = this.vc_a.getDisplayMode();
        if (this.vc_b == null) {
            throw new NullPointerException();
        }
        frame.setUndecorated(true);
        frame.enableInputMethods(false);
        this.a(frame, 127);
        if (-1 == ~n4) {
            int n5 = this.vc_b.getRefreshRate();
            DisplayMode[] displayModeArray = this.vc_a.getDisplayModes();
            boolean bl = false;
            for (int i = 0; i < displayModeArray.length; ++i) {
                if (~displayModeArray[i].getWidth() != ~n || displayModeArray[i].getHeight() != n2 || ~n3 != ~displayModeArray[i].getBitDepth()) continue;
                int n6 = displayModeArray[i].getRefreshRate();
                if (bl && ~Math.abs(n6 + -n5) <= ~Math.abs(-n5 + n4)) continue;
                bl = true;
                n4 = n6;
            }
            if (!bl) {
                n4 = n5;
            }
        }
        this.vc_a.setDisplayMode(new DisplayMode(n, n2, n3, n4));
    }

    public final void exit() {
        if (this.vc_b != null) {
            this.vc_a.setDisplayMode(this.vc_b);
            if (!this.vc_a.getDisplayMode().equals(this.vc_b)) {
                throw new RuntimeException("");
            }
            this.vc_b = null;
        }
        this.a(null, 121);
    }

    public vc() throws Exception {
        GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        this.vc_a = graphicsEnvironment.getDefaultScreenDevice();
        if (!this.vc_a.isFullScreenSupported()) {
            GraphicsDevice[] graphicsDeviceArray;
            GraphicsDevice[] graphicsDeviceArray2 = graphicsDeviceArray = graphicsEnvironment.getScreenDevices();
            int n = 0;
            while (~graphicsDeviceArray2.length < ~n) {
                GraphicsDevice graphicsDevice = graphicsDeviceArray2[n];
                if (null != graphicsDevice && graphicsDevice.isFullScreenSupported()) {
                    this.vc_a = graphicsDevice;
                    return;
                }
                ++n;
            }
            throw new Exception();
        }
    }
}
