/*
 * Decompiled with CFR 0.152.
 */
final class de
extends ma {
    static int M;
    static ph W;
    private mm T;
    private int O;
    static qm U;
    static String de_ab;
    private boolean S;
    static String P;
    private int X;
    private int Q;
    static int R;
    static uf V;
    static boolean Z;
    private String Y;

    de(int n, int n2, int n3, int n4, ce ce2, boolean bl, int n5, int n6, mm mm2, int n7, String string) {
        super(n, n2, n3, n4, null, null);
        this.S = bl;
        this.X = n7;
        this.L = ce2;
        this.O = n6;
        this.T = mm2;
        this.Y = string;
        this.Q = n5;
        int n8 = -this.O + this.Q;
        int n9 = this.T.b(string, n8, this.T.R) - -(this.O * 2);
        if (~n9 >= ~n4) {
            n9 = n4;
        } else {
            this.b(n9, n3, n, n2, -16555);
        }
        int n10 = this.S ? 0 : this.Q - -(this.O * 2);
        this.L.b(-(this.O * 2) + n4, n3 - this.Q + -(3 * this.O), n10, this.O + (n9 - n4 >> 1459606401), -16555);
    }

    public static void g(int n) {
        W = null;
        V = null;
        P = null;
        U = null;
        if (n >= -117) {
            P = null;
        }
        de_ab = null;
    }

    static int b(int n, int n2) {
        return n | n2;
    }

    static final void a(boolean bl, int n, String string, int n2, boolean bl2) {
        int n3;
        int n4;
        int n5;
        String string2;
        boolean bl3 = client.A;
        ph.Ab = true;
        kk.kk_k = n2;
        String string3 = string;
        String string4 = string2 = bl2 ? qn.qn_rb : me.C;
        if (-1 == ~kk.kk_k) {
            n5 = te.a(string3, 116, 480, pj.N, wf.wf_q);
            n4 = n5 + 3;
            ug.ug_q = new int[n4];
            ef.M = new String[n4];
            n3 = 0;
            while (~n3 > ~n4) {
                ug.ug_q[n3] = -1;
                ++n3;
            }
            ef.T = new int[2];
            n3 = 0;
            while (~n3 > ~n5) {
                ef.M[n3] = pj.N[n3];
                ++n3;
            }
            ef.M[-3 + n4] = "";
            ef.M[n4 - 2] = string2;
            ug.ug_q[n4 + -2] = 0;
            ef.T[0] = 1;
            ef.M[-1 + n4] = og.og_gb;
            ug.ug_q[-1 + n4] = 1;
            ef.T[1] = 2;
        } else {
            if (~kk.kk_k != -2) {
                throw new IllegalArgumentException();
            }
            n5 = te.a(string3, 104, 480, pj.N, wf.wf_q);
            n4 = 2 - -n5;
            ug.ug_q = new int[n4];
            ef.M = new String[n4];
            n3 = 0;
            while (~n3 > ~n4) {
                ug.ug_q[n3] = -1;
                ++n3;
            }
            ef.T = new int[1];
            n3 = 0;
            while (~n3 > ~n5) {
                ef.M[n3] = pj.N[n3];
                ++n3;
            }
            ef.M[n4 + -2] = "";
            ef.M[-1 + n4] = og.og_gb;
            ug.ug_q[-1 + n4] = 0;
            ef.T[0] = 2;
        }
        wj.Jb.sk_l = ef.T.length;
        n5 = 0;
        n4 = 0;
        if (n != -5540) {
            return;
        }
        while (~n4 > ~ef.M.length) {
            n3 = qb.a(0, ef.M[n4], 0 <= ug.ug_q[n4]);
            if (~ug.ug_q[n4] != 0) {
                n3 += ba.ba_d * 2;
            }
            if (n3 > n5) {
                n5 = n3;
            }
            ++n4;
        }
        ac.A = (je.je_c + le.le_t << 1002777217) * wj.Jb.sk_l;
        fb.fb_f = -(n5 >> -1152159039) + (af.af_f + n5);
        ad.ad_a = af.af_f - (n5 >> 1945551777);
        for (n4 = 0; n4 < ef.M.length; ++n4) {
            ac.A += ug.ug_q[n4] >= 0 ? vb.V : ma.I;
        }
        rn.rn_d = kk.kk_e + -(ac.A >> 1639359713);
        wj.Jb.a(0, 0, pm.a(pm.pm_f, -2141435999, bh.bh_g), bl);
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        int n5 = n + this.ce_u;
        int n6 = this.D - -n4;
        if (n2 > -103) {
            return;
        }
        super.a(n, -109, n3, n4);
        if (n3 != 0) {
            return;
        }
        int n7 = this.S ? this.ce_t + (-this.Q + -(2 * this.O)) : 0;
        this.T.a(this.Y, n7 + n5 + this.O, n6 - -this.O, -this.O + this.Q, this.y + -(2 * this.O), this.X, -1, this.S ? 0 : 2, 1, this.T.R);
    }

    static final ck[] c(boolean bl) {
        ck[] ckArray;
        block2: {
            boolean bl2 = client.A;
            ckArray = new ck[ec.ec_g];
            for (int j = 0; j < ec.ec_g; ++j) {
                int n = hc.hc_c[j] * tm.tm_a[j];
                byte[] byArray = tc.Nb[j];
                int[] nArray = new int[n];
                int n2 = 0;
                while (~n2 > ~n) {
                    nArray[n2] = mb.mb_d[lb.a(byArray[n2], 255)];
                    ++n2;
                }
                ckArray[j] = new ck(ed.ed_f, i.i_d, sg.sg_d[j], fh.fh_a[j], tm.tm_a[j], hc.hc_c[j], nArray);
            }
            oa.a(126);
            if (!bl) break block2;
            W = null;
        }
        return ckArray;
    }

    @Override
    final String c(byte by) {
        boolean bl = this.L.ce_q;
        this.L.ce_q = this.ce_q;
        String string = this.L.c(by);
        this.L.ce_q = bl;
        return string;
    }

    static {
        de_ab = "If you do nothing the game will revert to normal view in <%0> second.";
        P = "Instructions";
        Z = false;
        U = new qm(12, 0, 1, 0);
    }
}
