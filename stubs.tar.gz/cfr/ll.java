/*
 * Decompiled with CFR 0.152.
 */
final class ll {
    static um ll_a = new um();

    static final void a(boolean bl2, int n, int n2) {
        block7: {
            int n3;
            if (n != 0) {
                return;
            }
            if (null == vh.vh_h || (n3 = vh.vh_h.a((byte)-63, bl2)) == 0) break block7;
            if (~n3 == -3 && null != vh.vh_h.Y && !vh.vh_h.Y.equals("")) {
                String string = vh.vh_h.Y.charAt(0) == '[' ? vh.vh_h.Y : kf.a(vh.vh_h.Y, (byte)2);
                String string2 = null;
                if (-1 == ~of.of_d) {
                    string2 = rb.a(n2, n + 0, string);
                }
                if (of.of_d == 1) {
                    string2 = md.a(n2, string, false);
                }
                if (-3 == ~of.of_d) {
                    string2 = dd.b(string, 127, n2);
                }
                if (~of.of_d == -4) {
                    string2 = sg.a(string, string, n2, (byte)125);
                }
                if (string2 != null) {
                    ca.a(string, null, string2, (byte)-37, 2, 0);
                }
            }
            vh.vh_h = null;
            of.of_d = -1;
        }
    }

    static final boolean a(int n, byte by) {
        if (-1 < ~n) {
            return 0 == (1 + n) % 4;
        }
        if (n < 1582) {
            return ~(n % 4) == -1;
        }
        if (~(n % 4) != -1) {
            return false;
        }
        if (~(n % 100) != -1) {
            return true;
        }
        if (0 != n % 400) {
            return false;
        }
        if (by > -12) {
            ll_a = null;
        }
        return true;
    }

    static final ig a(w w2, w w3, ac ac2, w w4, int n) {
        int n2;
        boolean bl2 = client.A;
        if (ac2 == null) {
            return null;
        }
        int n3 = ac2.C != null ? ac2.C.length : 0;
        int n4 = null == ac2.E ? 0 : ac2.E.length;
        int n5 = n3 + n4;
        String[] stringArray = new String[n5];
        if (n != 0) {
            return null;
        }
        char[] cArray = new char[n5];
        int[] nArray = new int[n5];
        ig[] igArray = new ig[n5];
        if (null != ac2.C) {
            n2 = 0;
            while (~ac2.C.length < ~n2) {
                ac ac3 = oi.oi_a.a(-126, ac2.C[n2]);
                stringArray[n2] = ac3.H;
                cArray[n2] = ac2.G[n2];
                igArray[n2] = ll.a(w2, w3, ac3, w4, 0);
                ++n2;
            }
        }
        if (ac2.E != null) {
            n2 = n3;
            int n6 = 49;
            for (int i = 0; ac2.E.length > i; ++i) {
                int n7 = ac2.E[i];
                if (-1 != n7) {
                    me me2 = wj.Qb.a(126, n7);
                    stringArray[i + n2] = me2.f((byte)-81);
                    cArray[n2 + i] = ac2.y[i];
                    if (cArray[n2 - -i] <= '\u0000') {
                        int n8 = n6;
                        n6 = (char)(n6 + 1);
                        cArray[i + n2] = (char)n8;
                    }
                    nArray[n2 - -i] = ac2.E[i];
                    continue;
                }
                stringArray[i + n2] = gk.Gb;
                cArray[n2 + i] = ac2.y[i];
                nArray[n2 + i] = ac2.E[i];
            }
        }
        return new ig(0L, w2, w4, w3, igArray, nArray, stringArray, cArray);
    }

    public static void a(int n) {
        block0: {
            ll_a = null;
            if (n >= 29) break block0;
            ll_a = null;
        }
    }

    static final void a(int n, boolean bl2) {
        if (n != -1) {
            return;
        }
        f.a(2, bl2);
        fc.a(n + 6, bl2);
    }
}
