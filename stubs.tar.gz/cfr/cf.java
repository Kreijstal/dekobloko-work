/*
 * Decompiled with CFR 0.152.
 */
abstract class cf {
    static int cf_f = 640;
    static w cf_d;
    static String cf_c;
    nf[] cf_a;
    static String cf_b;
    static w cf_h;
    static String cf_e;
    static String cf_j;
    static boolean cf_i;
    static String cf_g;

    static final String a(int n, long l) {
        boolean bl = client.A;
        if (l <= (long)n) {
            return null;
        }
        if (6582952005840035281L <= l) {
            return null;
        }
        if (0L == l % 37L) {
            return null;
        }
        int n2 = 0;
        long l2 = l;
        while (0L != l2) {
            l2 /= 37L;
            ++n2;
        }
        StringBuilder stringBuilder = new StringBuilder(n2);
        while (-1L != (l ^ 0xFFFFFFFFFFFFFFFFL)) {
            long l3 = l;
            int n3 = db.db_g[(int)(l3 + -(37L * (l /= 37L)))];
            if (n3 == 95) {
                int n4 = -1 + stringBuilder.length();
                stringBuilder.setCharAt(n4, Character.toUpperCase(stringBuilder.charAt(n4)));
                n3 = 160;
            }
            stringBuilder.append((char)n3);
        }
        stringBuilder.reverse();
        stringBuilder.setCharAt(0, Character.toUpperCase(stringBuilder.charAt(0)));
        return stringBuilder.toString();
    }

    static final byte[] a(boolean bl, int n, Object object) {
        if (object == null) {
            return null;
        }
        if (object instanceof byte[]) {
            byte[] byArray = (byte[])object;
            if (bl) {
                return jd.a(0, byArray);
            }
            return byArray;
        }
        if (object instanceof mk) {
            mk mk2 = (mk)object;
            return mk2.a(256);
        }
        if (n <= 18) {
            cf.a(52, 9L);
        }
        throw new IllegalArgumentException();
    }

    final int a(boolean bl) {
        boolean bl2 = client.A;
        int n = -1;
        if (bl) {
            return 85;
        }
        if (this.cf_a != null) {
            nf[] nfArray = this.cf_a;
            for (int i = 0; nfArray.length > i; ++i) {
                int n2;
                nf nf2 = nfArray[i];
                if (null == nf2 || ~n <= ~(n2 = nf2.b(-6375))) continue;
                n = n2;
            }
        }
        return n;
    }

    final int b(int n) {
        if (n != -1) {
            return -39;
        }
        return this.cf_a != null && ~this.cf_a.length < -1 ? this.cf_a[this.cf_a.length + -1].nf_i - this.cf_a[0].nf_c : 0;
    }

    public static void a(byte by) {
        if (by != 126) {
            cf_g = null;
        }
        cf_c = null;
        cf_d = null;
        cf_h = null;
        cf_g = null;
        cf_e = null;
        cf_j = null;
        cf_b = null;
    }

    cf() {
    }

    static final String a(int n) {
        if (ca.ca_vb < 2) {
            return ef.U;
        }
        if (null != vj.vj_a) {
            if (!vj.vj_a.a((byte)121)) {
                return fe.fe_a;
            }
            return eb.eb_n;
        }
        if (!sk.sk_f.a((byte)121)) {
            return ng.ng_l;
        }
        if (!sk.sk_f.a("commonui", (byte)118)) {
            return bn.bn_d + " - " + sk.sk_f.a(-128, "commonui") + "%";
        }
        if (!rc.rc_k.a((byte)121)) {
            return ne.ne_d;
        }
        if (n != -11777) {
            cf.a(-68);
        }
        if (!rc.rc_k.a("commonui", (byte)124)) {
            return un.un_a + " - " + rc.rc_k.a(-125, "commonui") + "%";
        }
        if (!ph.Fb.a((byte)121)) {
            return bk.Ob;
        }
        if (!ph.Fb.a(false)) {
            return bg.bg_c + " - " + ph.Fb.b((byte)-61) + "%";
        }
        return wm.wm_k;
    }

    final int a(byte by, int n) {
        boolean bl = client.A;
        nf[] nfArray = this.cf_a;
        nf[] nfArray2 = this.cf_a;
        if (by != -94) {
            cf.a(102);
        }
        for (int j = 0; j < nfArray.length; ++j) {
            nf nf2 = nfArray[j];
            if (n < nf2.nf_a.length) {
                return nf2.nf_a[n];
            }
            n -= nf2.nf_a.length - 1;
        }
        return 0;
    }

    final int a(int n, int n2, int n3) {
        boolean bl = client.A;
        if (n3 != -31917) {
            cf.a(-31, -100L);
        }
        if (null == this.cf_a || ~this.cf_a.length == -1 || n2 < this.cf_a[0].nf_c) {
            return -1;
        }
        if (~n2 < ~this.cf_a[this.cf_a.length - 1].nf_i) {
            return -1;
        }
        if (1 == this.cf_a.length) {
            return this.cf_a[0].a(n, 109);
        }
        int n4 = 0;
        int n5 = 0;
        while (~this.cf_a.length < ~n5) {
            nf nf2 = this.cf_a[n5];
            if (~nf2.nf_c >= ~n2 && n2 <= nf2.nf_i) {
                int n6 = nf2.a(n, 109);
                if (-1 == n6) {
                    return -1;
                }
                return n4 + n6;
            }
            n4 += -1 + nf2.nf_a.length;
            ++n5;
        }
        return -1;
    }

    final int a(boolean bl, int n) {
        boolean bl2 = client.A;
        if (bl) {
            return -107;
        }
        for (int j = 0; j < this.cf_a.length; ++j) {
            nf nf2 = this.cf_a[j];
            if (~nf2.nf_a.length < ~n) {
                return j;
            }
            n -= -1 + nf2.nf_a.length;
        }
        return this.cf_a.length;
    }

    final int a(byte by, int n, String string, int n2) {
        boolean bl = client.A;
        int n3 = 0;
        if (by != 64) {
            return -43;
        }
        boolean bl2 = false;
        int n4 = string.length();
        for (int j = 0; n4 > j; ++j) {
            char c2 = string.charAt(j);
            if (c2 == '<') {
                bl2 = true;
                continue;
            }
            if (c2 == '>') {
                bl2 = false;
                continue;
            }
            if (bl2 || c2 != ' ') continue;
            ++n3;
        }
        if (n3 <= 0) {
            return 0;
        }
        return (n2 - n << -139770712) / n3;
    }

    /*
     * Enabled aggressive block sorting
     */
    static final void a(int n, byte by, int[] nArray, int n2, int n3) {
        boolean bl = client.A;
        if (by != 57) {
            cf.a(-62, (byte)71, null, 113, -87);
        }
        --n3;
        while (n3 >= 0) {
            int[] nArray2 = nArray;
            int[] nArray3 = nArray;
            int n4 = n++;
            int n5 = n2;
            nArray2[n4] = n5 - -(lb.a(0xFEFEFE, nArray2[n4]) >> -59233087);
            --n3;
        }
        return;
    }

    static {
        cf_e = "FIGHT!";
        cf_j = "Quit";
        cf_b = "Game options changed (<%0>)";
        cf_g = "Honour";
    }
}
