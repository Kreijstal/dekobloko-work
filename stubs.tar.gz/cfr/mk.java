/*
 * Decompiled with CFR 0.152.
 */
abstract class mk {
    static int mk_e;
    static int[] mk_b;
    static nh mk_d;
    static int[] mk_c;
    static String mk_a;

    public static void a(boolean bl) {
        block0: {
            mk_c = null;
            mk_d = null;
            mk_a = null;
            mk_b = null;
            if (!bl) break block0;
            mk_a = null;
        }
    }

    abstract byte[] a(int var1);

    static final void a(int n, int n2, byte by, cc cc2, int n3, cc cc3) {
        if (by >= 0) {
            mk.a((byte)1);
        }
        le.le_t = n;
        je.je_c = n2;
        ql.ql_b = cc3;
        ba.ba_d = n3;
        gf.gf_b = cc2;
    }

    mk() {
    }

    static final void a(byte by) {
        wc wc2;
        if (by != -5) {
            cc cc2 = null;
            mk.a(-94, -9, (byte)-115, null, -10, cc2);
        }
        if ((wc2 = (wc)ci.ci_a.d(by ^ 0x71)) == null) {
            throw new IllegalStateException();
        }
        hk.a(wc2.wc_t, wc2.wc_w, wc2.wc_s);
        hk.b(wc2.wc_p, wc2.wc_v, wc2.wc_o, wc2.wc_u);
        wc2.wc_t = null;
        sn.sn_e.a(wc2, by ^ 0xFFFFF522);
    }

    abstract void a(byte[] var1, boolean var2);

    static {
        mk_a = "Match by...";
        mk_c = new int[256];
    }
}
