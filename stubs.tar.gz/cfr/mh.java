/*
 * Decompiled with CFR 0.152.
 */
public class mh {
    int mh_a;
    mh mh_f;
    public int mh_g;
    public volatile int mh_c = 0;
    int mh_d;
    Object mh_e;
    public volatile Object mh_b;

    mh() {
    }
}
