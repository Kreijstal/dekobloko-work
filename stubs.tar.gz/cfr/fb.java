/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;

final class fb {
    static Color fb_g;
    static String fb_a;
    static String fb_d;
    static w fb_b;
    static int fb_f;
    static ck[][] fb_c;
    static int fb_e;

    public static void a(byte by) {
        fb_a = null;
        fb_b = null;
        fb_g = null;
        if (by <= 66) {
            fb.a(-7, 19, null);
        }
        fb_d = null;
        fb_c = null;
    }

    static final boolean a(int n, int n2, int[] nArray) {
        if (n2 != 0x9933FF) {
            fb.a(1, 103, null);
        }
        return (nArray[n >> -1825332859] & 1 << (0x1F & n)) == 0;
    }

    static {
        fb_d = "Hide players in <%0>'s game";
        fb_a = "Type your age in years";
        fb_g = new Color(0x9933FF);
        fb_c = new ck[8][8];
    }
}
