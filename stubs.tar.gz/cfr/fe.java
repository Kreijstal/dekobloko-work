/*
 * Decompiled with CFR 0.152.
 */
final class fe {
    static String fe_a;
    static int fe_b;
    private static final String z;

    public static void a(byte by) {
        fe_a = null;
        int n = -37 / ((-34 - by) / 50);
    }

    static {
        z = "fe.A(";
    }
}
