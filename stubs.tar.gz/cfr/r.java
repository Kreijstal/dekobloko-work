/*
 * Decompiled with CFR 0.152.
 */
final class r
extends ce {
    private int N;
    boolean L;
    private ck O;
    private int J;
    private int M;
    private ck[] P;
    private int S;
    private ck K;
    private int H;
    private ck G;
    private int R;
    int Q;

    r(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        this(n, n2, n3, n4, n5, n6, n7, (n6 & 0xFEFEFE) >> -1519559391, (n7 & 0xFEFEFE) >> -1248347583);
    }

    static final void a(boolean bl, int n) {
        block1: {
            if (vh.vh_h != null) {
                vh.vh_h.a(1141039778, bl);
            }
            if (n == 4028) break block1;
            r.a(false, 20);
        }
    }

    @Override
    final void b(int n, int n2, int n3, int n4, int n5) {
        super.b(n, n2, n3, n4, n5);
        this.b(true);
    }

    private final void b(boolean bl) {
        if (!bl) {
            this.e((byte)116);
        }
        this.P = new ck[]{this.b(-81, this.M, this.H), this.b(-107, this.S, this.N)};
        this.O = this.e((byte)-125);
        this.K = this.O.e();
        this.G = new ck(this.y >> 1564443297, this.y);
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        block2: {
            if (-1 != ~n3) {
                return;
            }
            int n5 = this.ce_u + n;
            if (n2 > -103) {
                this.a(-17, 35, 5);
            }
            int n6 = n4 - -this.D;
            this.a(-2044, n6, n5, this.P[0]);
            if (65536 <= this.Q) break block2;
            gg.a(n6, 20763, n5 - -this.ce_t, n5 + (this.Q * this.ce_t >> -172186704), this.y + n6);
            this.a(-2044, n6, n5, this.P[1]);
            mk.a((byte)-5);
        }
    }

    private final ck e(byte by) {
        ck ck2;
        block3: {
            boolean bl = client.A;
            int n = this.y >> -760619487;
            ck2 = new ck(n, this.y);
            tb.a(true, ck2);
            for (int i = 0; i < this.y; ++i) {
                for (int j = 0; n > j; ++j) {
                    double d = (double)j * (double)j / (double)(i * (-i + this.y));
                    int n2 = 1;
                    if (d < 1.0) {
                        n2 = 1.0 <= (d = Math.sqrt(-d + 1.0)) ? 255 : (int)(255.0 * d);
                    }
                    hk.a(j, i, n2 << 23521128 | n2 | n2 << -98736656);
                }
            }
            mk.a((byte)-5);
            if (by <= -73) break block3;
            this.M = -48;
        }
        return ck2;
    }

    private final ck b(int n, int n2, int n3) {
        boolean bl = client.A;
        if (n >= -78) {
            this.K = null;
        }
        ck ck2 = new ck(2 * this.J, this.y);
        tb.a(true, ck2);
        int n4 = this.y >> 1326292865;
        int n5 = 0;
        while (~n5 > ~this.y) {
            int n6 = (-1 + this.J * 2) * (n5 >> 221156193) % (this.J * 2);
            int n7 = n3 & 0xFF00FF;
            int n8 = 0xFF00 & n3;
            int n9 = -n4 + n5;
            int n10 = 128 + (int)(128.0 * (Math.sqrt(n4 * n4 - n9 * n9) / (double)n4));
            int n11 = ~n10 <= -257 ? n7 | n8 : (n7 * n10 & 0xFF00FF00 | 0xFF0000 & n8 * n10) >>> -464832536;
            hk.a(n6, n5, this.J, n11);
            n8 = n2 & 0xFF00;
            hk.a(-(this.J * 2) + n6, n5, this.J, n11);
            n7 = 0xFF00FF & n2;
            n11 = ~n10 <= -257 ? n7 | n8 : (0xFF0000 & n8 * n10 | 0xFF00FF00 & n7 * n10) >>> -721839096;
            hk.a(n6 - -this.J, n5, this.J, n11);
            hk.a(-this.J + n6, n5, this.J, n11);
            ++n5;
        }
        mk.a((byte)-5);
        return ck2;
    }

    final void a(int n, int n2, int n3) {
        if (n2 != 4088) {
            this.e((byte)42);
        }
        this.N = 0x7F7F7F & n3 >> -111273055;
        this.H = n3;
        this.M = n;
        this.S = (n & 0xFEFEFE) >> -329332639;
        this.b(true);
    }

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        block2: {
            if (n <= 38) {
                this.Q = -76;
            }
            if (!this.L) break block2;
            ++this.R;
            if (~(2 * this.J) > ~this.R) {
                this.R -= 2 * this.J;
            }
        }
    }

    private final void a(int n, int n2, int n3, ck ck2) {
        block4: {
            int n4;
            boolean bl = client.A;
            int n5 = n3 + this.ce_t;
            if (n != -2044) {
                r.a(true, 38);
            }
            gg.a(n2, 20763, n5 + -this.O.I, this.O.I + n3, this.y + n2);
            int n6 = n3 + -this.R;
            while (~n5 < ~n6) {
                ck2.c(n6, n2);
                n6 += ck2.I;
            }
            mk.a((byte)-5);
            if (~(n3 + this.O.I) <= ~hk.hk_c) {
                tb.a(true, this.G);
                ck2.c(-this.R, 0);
                ck2.c(-this.R + this.J * 2, 0);
                this.K.f(0, 0);
                mk.a((byte)-5);
                this.G.c(n3, n2);
            }
            if (~(-this.O.I + n5) < ~hk.hk_g) break block4;
            tb.a(true, this.G);
            for (n4 = -this.O.I + (this.ce_t - -this.R); this.J * 2 < n4; n4 -= 2 * this.J) {
            }
            ck2.c(-n4, 0);
            ck2.c(2 * this.J - n4, 0);
            this.O.f(0, 0);
            mk.a((byte)-5);
            this.G.c(n5 - this.O.I, n2);
        }
    }

    private r(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9) {
        this.H = n6;
        this.S = n9;
        this.J = n5;
        this.M = n7;
        this.N = n8;
        this.b(n4, n3, n, n2, -16555);
    }
}
