/*
 * Decompiled with CFR 0.152.
 */
final class o {
    static fd o_f;
    static String o_h;
    static int o_b;
    static w o_a;
    static int[] o_e;
    static int[] o_g;
    static int o_d;
    static String o_c;

    public static void a(boolean bl) {
        if (bl) {
            o_d = 7;
        }
        o_h = null;
        o_g = null;
        o_e = null;
        o_c = null;
        o_a = null;
        o_f = null;
    }

    static final int a(int n, int n2, int n3, int n4) {
        if (hk.hk_i >= n + (n4 + n3)) {
            return n4 + n;
        }
        if (-n3 + n4 >= n2) {
            return n4 - n3;
        }
        return hk.hk_i - n3;
    }

    static {
        o_b = 50;
        o_h = "Add friend";
        o_g = b.h(-123);
        o_c = "Did you know?";
    }
}
