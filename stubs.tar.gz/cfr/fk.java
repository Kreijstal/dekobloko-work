/*
 * Decompiled with CFR 0.152.
 */
final class fk
extends a {
    static int H;
    private int F;
    static pi[][] G;
    static int[] I;
    private int D;
    private int B;
    private ck[] C;

    public static void c(int n) {
        if (n != 8) {
            I = null;
        }
        G = null;
        I = null;
    }

    public fk() {
        this(2188450, 2591221, 9543);
    }

    @Override
    public final void a(boolean bl, int n, int n2, byte by, ce ce2) {
        boolean bl2;
        if (by >= -60) {
            fk.c(-101);
        }
        boolean bl3 = bl2 = ce2.ce_q || ce2.a(true);
        if (ce2 instanceof ek) {
            bl &= ((ek)ce2).I;
        }
        int n3 = bl ? (!bl2 ? this.D : this.B) : this.F;
        int n4 = !bl ? 0x6C6C6C : 0xFFFFFF;
        rm.a(n2 - (-ce2.D + -(ce2.y - this.C[0].C >> 2089386273)), this.C, ce2.ce_u + n, ce2.ce_t, n3, -121);
        this.z.a(ce2.E, ce2.ce_u + n, -2 + (ce2.D + n2), ce2.ce_t, ce2.y, n4, -1, 1, 1, this.z.R);
    }

    private fk(int n, int n2, int n3) {
        this.D = n;
        this.z = ec.ec_p;
        this.C = rm.rm_a;
        this.F = n3;
        this.B = n2;
    }

    static {
        G = new pi[8][];
        I = new int[2];
    }
}
