/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

class bh {
    static String bh_h = "This is <%0>'s RuneScape clan if they have one.";
    static String bh_c;
    static ck[][] bh_d;
    static String bh_j;
    static String bh_f;
    bh bh_a;
    bh bh_b;
    static int bh_m;
    static String[] bh_e;
    static int bh_g;
    long bh_i;
    static um bh_l;
    static int bh_k;

    final boolean a(byte by) {
        if (by <= 34) {
            bh_l = null;
        }
        return this.bh_a != null;
    }

    static final void a(int n, int n2) {
        fa fa2;
        boolean bl = client.A;
        if (n2 > -116) {
            return;
        }
        bh bh2 = fa2 = (fa)sa.C.c((byte)-114);
        while (null != fa2) {
            w.a(124, n, fa2);
            bh2 = (fa)sa.C.d(true);
        }
        bh2 = c.c_r.c((byte)99);
        while (null != bh2) {
            ad.a(-1, n);
            bh2 = c.c_r.d(true);
        }
    }

    final void b(byte by) {
        if (this.bh_a == null) {
            return;
        }
        this.bh_a.bh_b = this.bh_b;
        this.bh_b.bh_a = this.bh_a;
        if (by < 100) {
            bh_k = -105;
        }
        this.bh_a = null;
        this.bh_b = null;
    }

    static final void a(int n, Applet applet) {
        try {
            if (n > -98) {
                Applet applet2 = null;
                bh.a(-55, applet2);
            }
            URL uRL = new URL(applet.getCodeBase(), "tosupport.ws");
            applet.getAppletContext().showDocument(gn.a(uRL, -1, applet), "_top");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static void b(int n) {
        bh_d = null;
        bh_c = null;
        bh_h = null;
        if (n != 25189) {
            bh.b(-88);
        }
        bh_l = null;
        bh_e = null;
        bh_j = null;
        bh_f = null;
    }

    static final int a(int n, boolean bl, CharSequence charSequence) {
        block0: {
            if (!bl) break block0;
            bh_h = null;
        }
        return s.a(true, 4, n, charSequence);
    }

    static final String a(int n, String string, String string2, String string3) {
        boolean bl = client.A;
        if (n != 0) {
            bh_k = -96;
        }
        int n2 = string.indexOf(string3);
        while (0 != ~n2) {
            string = string.substring(0, n2) + string2 + string.substring(string3.length() + n2);
            n2 = string.indexOf(string3, string2.length() + n2);
        }
        return string;
    }

    static {
        bh_j = "RuneScape clan";
        bh_d = new ck[8][];
        bh_f = "Your friend list is full. Max of 100 for free users, and 200 for members.";
        bh_e = new String[]{null, "To store your progress, you must log in or create a free account.#Alternatively, click <%0> to discard it and continue.", "To store your score, you must log in or create a free account.#Alternatively, click <%0> to discard it and continue.", "To store your score and progress, you must log in or create a free account.#Alternatively, click <%0> to discard them and continue.", "To store your achievements, you must log in or create a free account.#Alternatively, click <%0> to discard them and continue.", "To store your achievements and progress, you must log in or create a free account.#Alternatively, click <%0> to discard them and continue.", "To store your achievements and score, you must log in or create a free account.#Alternatively, click <%0> to discard them and continue.", "To store your achievements, score and progress, you must log in or create a free account.#Alternatively, click <%0> to discard them and continue."};
        bh_g = 0;
        bh_c = "You can ask to join this game";
        bh_k = -1;
        bh_l = new um();
    }
}
