/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Frame;
import java.io.IOException;

final class wj
extends gk
implements vn {
    static ia Ob;
    static w Mb;
    static sm Qb;
    private boolean Pb;
    private tf Nb;
    static String Kb;
    private boolean Rb;
    static sk Jb;
    static int Lb;

    @Override
    final boolean h(byte by) {
        block1: {
            cd cd2;
            if (by <= 15) {
                this.Nb = null;
            }
            if (!this.S || this.Pb || (cd2 = je.a(13)) == null) break block1;
            this.a(false, cd2, false);
        }
        return super.h((byte)117);
    }

    static final void q(int n) {
        mg.Nb = false;
        int n2 = -22 % ((-14 - n) / 35);
        vb.Z = false;
        hm.a(-1, (byte)-122);
        ka.P = uc.uc_c;
        sh.sh_d = uc.uc_c;
    }

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        block1: {
            if (this.Rb) {
                dd.a(false, true, (byte)66);
                return;
            }
            in.c((byte)-51);
            this.n(-128);
            if (by == 67) break block1;
            Jb = null;
        }
    }

    static final void a(int n, int n2, boolean bl2, int n3, boolean bl3, String string) {
        block0: {
            de.a(bl3, -5540, string, n, bl2);
            fe.fe_b = n3;
            boolean bl4 = im.im_f = !bl2;
            if (n2 < -70) break block0;
            ck ck2 = null;
            wj.a(ck2, 81);
        }
    }

    static final void a(boolean bl2, Frame frame, fd fd2) {
        boolean bl3 = client.A;
        if (!bl2) {
            wj.q(92);
        }
        while (true) {
            mh mh2 = fd2.a(75254128, frame);
            while (-1 == ~mh2.mh_c) {
                ua.a(10L, -128);
            }
            if (~mh2.mh_c == -2) break;
            ua.a(100L, -128);
        }
        frame.setVisible(false);
        frame.dispose();
    }

    static final void c(int n, int n2) {
        block5: {
            if (qc.qc_s == null || n2 >= 0 && ph.xb != wf.wf_u) {
                we.we_b.wl_n = 0;
                return;
            }
            if (~we.we_b.wl_n == -1 && ik.a(4) > 10000L + el.J) {
                we.we_b.f(n2, -4);
            }
            if (n != 4792) {
                Kb = null;
            }
            if (-1 <= ~we.we_b.wl_n) break block5;
            try {
                qc.qc_s.a(0, we.we_b.wl_n, 1, we.we_b.wl_r);
                el.J = ik.a(n ^ 0x12BC);
            }
            catch (IOException iOException) {
                si.a(100);
            }
            we.we_b.wl_n = 0;
        }
    }

    wj(ka ka2, tf tf2) {
        super(ka2, ec.ec_p, cm.cm_i, false, false);
        this.Nb = tf2;
    }

    private final void a(boolean bl2, cd cd2, boolean bl3) {
        block17: {
            String string;
            boolean bl4 = client.A;
            this.Pb = true;
            if (!cd2.cd_n) {
                if (null == cd2.cd_d) {
                    string = cd2.cd_f;
                    if (cd2.cd_h == 248) {
                        if (!bl2) {
                            k.a((byte)-36);
                        }
                        this.Rb = true;
                        string = ab.ab_d;
                    }
                } else {
                    string = of.of_g;
                    if (this.Nb != null) {
                        this.Nb.a(25);
                    }
                }
            } else {
                string = wf.wf_k;
            }
            dj dj2 = new dj(this, ec.ec_p, string);
            if (cd2.cd_n) {
                if (cd2.cd_e) {
                    this.c(new md(this), (byte)79);
                    return;
                }
                dj2.a(119, fa.fa_o, this);
            } else {
                if (this.Rb) {
                    dj2.a(115, fa.fa_o, this);
                } else if (-6 != ~cd2.cd_h) {
                    dj2.a(bl.X, -1, 14);
                } else {
                    dj2.a(pb.pb_e, 11, 14);
                    dj2.a(ig.Tb, 17, 14);
                }
                if (-4 != ~cd2.cd_h) {
                    if (-7 == ~cd2.cd_h) {
                        dj2.a(vb.Y, 9, 14);
                    }
                } else {
                    dj2.a(ce.z, 7, 14);
                }
            }
            this.c(dj2, (byte)68);
            if (!bl3) break block17;
            Lb = 4;
        }
    }

    final void b(boolean bl2) {
        this.a(bl2, un.a(248, ab.ab_d, -12), false);
    }

    public static void s(int n) {
        Ob = null;
        Qb = null;
        Mb = null;
        Kb = null;
        if (n != 0) {
            fd fd2 = null;
            wj.a(true, (Frame)null, fd2);
        }
        Jb = null;
    }

    static final boolean r(int n) {
        if (n <= 17) {
            return true;
        }
        return li.li_b != null && li.li_b.b(0);
    }

    static final hl a(byte by, int n, int n2, int n3) {
        int n4;
        int n5;
        boolean bl2 = client.A;
        hl hl2 = null;
        dn.dn_l.Ob.M.c(115);
        int n6 = 0;
        int n7 = 0;
        for (n5 = ic.ic_c - 1; n5 >= 0; --n5) {
            hl hl3 = pd.pd_g[n5];
            boolean bl3 = false;
            if (!wc.wc_n && ~n6 > ~kf.M) {
                int n8 = rf.a(0, hl3.hl_m);
                if (hl3.b((byte)94) >= n8 && (hl3.hl_j || !ik.a(hl3.hl_o, (byte)-118))) {
                    bl3 = true;
                }
            }
            if (!bl3) {
                hl3.hl_f = null;
                continue;
            }
            if (hl3.hl_f == null || rg.rg_c) {
                if (null == hl3.hl_f) {
                    ++bg.bg_b;
                }
                String string = mb.a(106, hl3);
                String string2 = string + mm.c(hl3.hl_h);
                int n9 = tc.a(by ^ 0x122B, hl3);
                hl3.hl_f = new w(0L, fj.fj_g, string2);
                n7 += n;
                hl3.hl_f.J = ff.ff_o;
                hl3.hl_f.w_fb = n9 - ((0xFEFEFE & n9) >> 1796712545) - -((fj.fj_g.w_fb & 0xFEFEFE) >> -1751457759);
                hl3.hl_f.G = n9;
                hl3.hl_f.Bb = ((0xFEFEFF & fj.fj_g.Bb) >> 369179521) + -((0xFEFEFF & n9) >> -1720740735) + n9;
            }
            ++n6;
        }
        n5 = 0;
        if (by != 55) {
            return null;
        }
        for (n4 = 0; n4 < ic.ic_c; ++n4) {
            hl hl4 = pd.pd_g[n4];
            if (null == hl4.hl_f) continue;
            dn.dn_l.Ob.a(hl4.hl_f, -16834);
            hl4.hl_f.a(hl4.hl_f.a(true), 0, n5, n, n3);
            n5 += n;
            if (~hl4.hl_f.w_ob == -1) continue;
            hl2 = hl4;
        }
        n4 = -n5 + n7 + (dn.dn_l.Ob.F + dn.dn_l.Ob.N);
        dn.dn_l.Ob.N -= n4;
        dn.dn_l.Ob.Ib += n4;
        if (rg.rg_c) {
            dn.dn_l.Ob.N = n5;
        }
        if (rg.rg_c) {
            rg.rg_c = false;
            sc.sc_m = true;
            dn.dn_l.Ob.Ib = dn.dn_l.Rb.N + -dn.dn_l.Ob.N;
            dn.dn_l.Ob.Mb = 0;
        }
        dn.dn_l.Ob.F = n5 - dn.dn_l.Ob.N;
        if (jg.jg_i && tf.tf_gb != null) {
            sc.sc_m = true;
        }
        int n10 = -dn.dn_l.Ob.F - (dn.dn_l.Ob.N - dn.dn_l.Rb.N);
        if (sc.sc_m) {
            dn.dn_l.Ob.Mb = -dn.dn_l.Ob.Ib + n10;
        }
        dn.dn_l.a(2 * n * n2, true, true, n);
        sc.sc_m = n10 == dn.dn_l.Ob.Ib - -dn.dn_l.Ob.Mb;
        return hl2;
    }

    static final void a(ck ck2, int n) {
        block0: {
            pe.pe_d = ck2;
            if (n == 369179521) break block0;
            Lb = -2;
        }
    }

    static {
        Kb = "Accept unrated rematch";
        Jb = new sk(1);
    }
}
