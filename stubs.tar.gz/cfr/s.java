/*
 * Decompiled with CFR 0.152.
 */
final class s
extends w {
    w Ob;
    static ck[] Qb = new ck[8];
    static int Pb;
    w Nb;
    nm Rb;
    w Sb = new w(0L, null);

    final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        this.Ib = n4;
        this.w_mb = n7;
        this.w_vb = n;
        this.N = n3;
        if (n2 != 1) {
            this.Nb = null;
        }
        this.a(n5, n8, n6, 16);
    }

    static final int a(boolean bl, int n, int n2, CharSequence charSequence) {
        boolean bl2 = client.A;
        if (2 > n2 || -37 > ~n2) {
            throw new IllegalArgumentException("" + n2);
        }
        boolean bl3 = false;
        boolean bl4 = false;
        int n3 = 0;
        if (n != 4) {
            s.b(true);
        }
        int n4 = charSequence.length();
        int n5 = 0;
        while (~n4 < ~n5) {
            block17: {
                int n6;
                int n7;
                block15: {
                    block16: {
                        n7 = charSequence.charAt(n5);
                        if (n5 != 0) break block15;
                        if (45 != n7) break block16;
                        bl3 = true;
                        break block17;
                    }
                    if (n7 == 43 && bl) break block17;
                }
                if (n7 < 48 || 57 < n7) {
                    if (n7 >= 65 && n7 <= 90) {
                        n7 -= 55;
                    } else {
                        if (97 > n7 || n7 > 122) {
                            throw new NumberFormatException();
                        }
                        n7 -= 87;
                    }
                } else {
                    n7 -= 48;
                }
                if (n7 >= n2) {
                    throw new NumberFormatException();
                }
                if (bl3) {
                    n7 = -n7;
                }
                if (n3 != (n6 = n2 * n3 - -n7) / n2) {
                    throw new NumberFormatException();
                }
                n3 = n6;
                bl4 = true;
            }
            ++n5;
        }
        if (!bl4) {
            throw new NumberFormatException();
        }
        return n3;
    }

    static final void a(int n, int n2, byte by, int n3, int n4) {
        a.a_k = n3;
        nd.nd_b = n;
        if (by != -91) {
            s.b((byte)18, 119);
        }
        ke.ke_d = n4;
        cc.cc_a = n2;
    }

    static final void h(byte by) {
        block2: {
            sn.a(false);
            if (null != jh.jh_b) {
                tj.a(false, jh.jh_b);
            }
            wf.d(90);
            rf.a((byte)0);
            fc.a((byte)67);
            if (di.a(false)) {
                we.we_b.f(1, -4);
                wj.c(4792, 0);
            }
            si.a(80);
            if (by > 69) break block2;
            ji ji2 = null;
            s.a(-57, -79, null, null, null, -19, false, null, null, null, null, null, null, null, null, null, ji2);
        }
    }

    public static void i(byte by) {
        int n = 8 % ((by - -32) / 55);
        Qb = null;
    }

    s(long l, w w2, w w3, jd jd2, w w4, String string, String string2) {
        super(l, w2);
        this.Rb = new nm(0L, this.Sb, w3, jd2);
        this.Ob = new w(0L, w4);
        this.Nb = new w(0L, w4);
        this.Ob.Y = string;
        this.Nb.Y = string2;
        this.a(this.Rb, -16834);
        this.a(this.Ob, -16834);
        this.a(this.Nb, -16834);
    }

    final void a(int n, int n2, int n3, int n4) {
        int n5 = (this.w_mb - -n3) / 2;
        int n6 = this.N - n2;
        this.Rb.a(6, 0, n, 0, -n3 + n6, this.w_mb, n3);
        this.Ob.Ib = n6;
        if (n4 != 16) {
            Qb = null;
        }
        this.Ob.N = n2;
        this.Ob.w_mb = n5 - n3;
        this.Ob.w_vb = 0;
        this.Nb.w_mb = this.w_mb - n5;
        this.Nb.w_vb = n5;
        this.Nb.Ib = n6;
        this.Nb.N = n2;
    }

    static final void g(byte by) {
        if (ah.ah_c != null) {
            ah.ah_c.f((byte)-66);
        }
        if (null != pk.pk_v) {
            pk.pk_v.m((byte)114);
        }
        sh.a(0);
        int n = 62 % ((-55 - by) / 60);
    }

    static final int b(byte by, int n) {
        int n2 = 0;
        if (n < 0 || ~n <= -65537) {
            n >>>= 16;
            n2 += 16;
        }
        if (256 <= n) {
            n2 += 8;
            n >>>= 8;
        }
        if (-17 >= ~n) {
            n >>>= 4;
            n2 += 4;
        }
        if (4 <= n) {
            n2 += 2;
            n >>>= 2;
        }
        if (n >= 1) {
            n >>>= 1;
            ++n2;
        }
        int n3 = -60 % ((by - 69) / 45);
        return n2 - -n;
    }

    s(long l, s s2, String string, String string2) {
        this(l, (w)s2, s2.Rb.Rb, s2.Rb.Sb, s2.Ob, string, string2);
    }

    static final void b(boolean bl2) {
        int n;
        boolean bl3 = client.A;
        gh.gh_e = null;
        ge.ge_c = false;
        he.he_db = false;
        gn.gn_b = false;
        si.si_e = new vj();
        if (!bl2) {
            CharSequence charSequence = null;
            s.a(true, -23, -56, charSequence);
        }
        jm.jm_r = new vj();
        int[] nArray = o.o_g;
        int[] nArray2 = o.o_g;
        int n2 = 0;
        while (~n2 > -9) {
            nArray[n2] = 0;
            ++n2;
        }
        int[] nArray3 = j.j_d;
        nArray2 = j.j_d;
        n2 = n = 0;
        while (n < 8) {
            nArray3[n] = 0;
            ++n;
        }
        id.P = 0;
    }

    static final void a(int n, int n2, ck[][] ckArray, byte[] byArray, ck[][] ckArray2, int n3, boolean bl2, String[][] stringArray, int[] nArray, byte[] byArray2, ji ji2, int[] nArray2, ji ji3, pi[] piArray, String[] stringArray2, String[][] stringArray3, ji ji4) {
        block0: {
            sg.a(stringArray3, bl2, byArray2, ji4, nArray2, (byte)-57, stringArray, stringArray2, 1, byArray, piArray, nArray, n2, ji3, null, ji2, ckArray2, ckArray, n3);
            if (n >= 66) break block0;
            Pb = 77;
        }
    }
}
