/*
 * Decompiled with CFR 0.152.
 */
final class gm
extends di {
    static String J = "OK";
    static int H;
    static boolean I;

    static final void a(int n, int n2) {
        ql.ql_d = new int[3];
        kf.M = n2;
        pd.pd_g = new hl[n2 * 15];
        if (n != -3504) {
            J = null;
        }
        ic.ic_c = 0;
    }

    private gm(mm mm2, int n) {
        super(mm2, n);
    }

    gm(int n) {
        this(hh.hh_e, n);
    }

    public static void d(int n) {
        int n2 = 85 / ((-16 - n) / 51);
        J = null;
    }

    @Override
    final String b(ce ce2, byte by) {
        int n = 61 / ((by - 59) / 53);
        return vb.a('*', ce2.E.length(), -12681);
    }

    static final void b(int n, int n2) {
        if (n2 <= 35) {
            J = null;
        }
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        uf2.a(true, 1);
        uf2.a(true, 2);
    }
}
