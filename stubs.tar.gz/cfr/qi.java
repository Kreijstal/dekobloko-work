/*
 * Decompiled with CFR 0.152.
 */
class qi
extends ek {
    private pk P = null;
    static String L;
    private String[] K;
    private vj O;
    static vj Q;
    static vj S;
    static String N;
    static String T;
    static ck R;
    static boolean M;

    @Override
    String c(byte by) {
        if (null == this.P) {
            return null;
        }
        if (null == this.K) {
            return null;
        }
        if (~this.K.length >= ~this.P.pk_p) {
            return null;
        }
        if (by != 113) {
            return null;
        }
        return this.K[this.P.pk_p];
    }

    final void c(int n, int n2, int n3, int n4) {
        int n5 = -125 % ((-61 - n) / 43);
        this.b(((nl)((Object)this.ce_p)).a((ce)this, -125), n4, n2, n3, -16555);
    }

    static final void a(boolean bl2, byte by) {
        block5: {
            if (lk.F) {
                h.h_d = uh.a(j.j_d, bl2, !gk.Ib ? 1 : 2, -104);
                return;
            }
            if (mg.Zb) {
                cl.B = qj.a(-21, bl2);
                return;
            }
            if (fm.fm_e) {
                am.am_a = ib.a((byte)-108, bl2);
                return;
            }
            if (he.he_db) {
                jm.a(0, bl2);
                he.he_db = false;
                return;
            }
            if (ob.ob_k) {
                tj.a(bl2, 111);
                gi.gi_b = true;
                ob.ob_k = false;
                return;
            }
            kf.G.c(-1, bl2);
            if (by < -99) break block5;
            qi.h(-32);
        }
    }

    @Override
    void a(ce ce2, int n, int n2, int n3) {
        block1: {
            super.a(ce2, 48, n2, n3);
            this.P = null;
            if (this.ce_q) {
                int n4 = -this.ce_u + (bh.bh_g + -n3);
                int n5 = pm.pm_f - (n2 - -this.D);
                this.P = this.a(1, n5, n4);
            }
            if (n >= 38) break block1;
            this.K = null;
        }
    }

    final void a(String string, int n, int n2) {
        boolean bl2 = client.A;
        if (n2 != 1) {
            return;
        }
        if (null == this.K || ~n <= ~this.K.length) {
            String[] stringArray;
            String[] stringArray2 = stringArray = new String[n + 1];
            if (null != this.K) {
                int n3 = 0;
                while (~this.K.length < ~n3) {
                    stringArray[n3] = this.K[n3];
                    ++n3;
                }
            }
            this.K = stringArray;
        }
        this.K[n] = string;
    }

    @Override
    void a(int n, int n2, int n3, int n4) {
        block3: {
            super.a(n, -128, n3, n4);
            if (n2 >= -103) {
                this.a(112);
            }
            if (n3 != 0) {
                return;
            }
            nl nl2 = (nl)((Object)this.ce_p);
            pk pk2 = this.P;
            if (null == pk2) break block3;
            int n5 = nl2.a((byte)24, this, n);
            int n6 = nl2.a(n4, 0, this);
            do {
                kd.a(2 + pk2.pk_n, pk2.pk_t + (n5 - 2), (byte)-128, -2 + (pk2.pk_u + n6), pk2.pk_s - -2);
            } while ((pk2 = pk2.pk_o) != null);
        }
    }

    static final w e(byte by) {
        int n = 48 / ((64 - by) / 52);
        return qa.d(5);
    }

    static final void a(float f, int n, String string) {
        cg.cg_d = f;
        he.he_hb = string;
        int n2 = 79 / ((-18 - n) / 58);
    }

    private final pk a(int n, int n2, int n3) {
        boolean bl2 = client.A;
        pk pk2 = (pk)this.O.c((byte)49);
        if (n != 1) {
            ce ce2 = null;
            this.a(ce2, 8, -16, -10);
        }
        while (null != pk2) {
            pk pk3 = pk2;
            while (null != pk3) {
                if (n3 >= pk3.pk_t && ~pk3.pk_u >= ~n2 && n3 < pk3.pk_n + pk3.pk_t && ~(pk3.pk_u - -pk3.pk_s) <= ~n2) {
                    return pk2;
                }
                pk3 = pk3.pk_o;
            }
            pk2 = (pk)this.O.d(true);
        }
        return null;
    }

    public static void f(byte by) {
        R = null;
        S = null;
        L = null;
        int n = -63 % ((-30 - by) / 38);
        T = null;
        N = null;
        Q = null;
    }

    @Override
    boolean a(boolean bl2, ce ce2) {
        if (bl2) {
            N = null;
        }
        return false;
    }

    static final void h(int n) {
        hm.a(n, (byte)-104);
    }

    @Override
    final void b(int n, int n2, int n3, int n4) {
        block0: {
            super.b(n, n2, n3, n4);
            int n5 = -this.ce_u + n;
            int n6 = n2 + -this.D;
            pk pk2 = this.a(1, n6, n5);
            if (pk2 == null || null == this.ce_v) break block0;
            ((rl)((Object)this.ce_v)).a(this, n3, -118, pk2.pk_p);
        }
    }

    @Override
    final void b(int n, int n2, int n3, int n4, int n5) {
        super.b(n, n2, n3, n4, n5);
        this.a(2874);
    }

    final void a(int n) {
        int n2;
        boolean bl2 = client.A;
        this.O = new vj();
        int n3 = 0;
        if (n != 2874) {
            S = null;
        }
        nl nl2 = (nl)((Object)this.ce_p);
        cf cf2 = nl2.a((ce)this, (byte)117);
        while (0 != ~(n2 = this.E.indexOf("<hotspot=", n3))) {
            int n4 = this.E.indexOf(">", n2);
            String string = this.E.substring(9 + n2, n4);
            n4 = Integer.parseInt(string);
            n3 = this.E.indexOf("</hotspot>", n2);
            int n5 = cf2.a(false, n2);
            int n6 = cf2.a(false, n3);
            pk pk2 = null;
            for (int i = n5; i <= n6; ++i) {
                int n7;
                nf nf2 = cf2.cf_a[i];
                int n8 = n7 = i == n5 ? cf2.a((byte)-94, n2) : nf2.nf_a[0];
                int n9 = n6 == i ? cf2.a((byte)-94, n3) : (null == nf2 ? 0 : nf2.nf_a[nf2.nf_a.length + -1]);
                pk pk3 = new pk(n4, n7, nf2.nf_c, n9 - n7, Math.max(nl2.a((byte)-120), -nf2.nf_c + nf2.nf_i));
                if (pk2 != null) {
                    pk2.pk_o = pk3;
                }
                this.O.a(pk3, 2777);
                pk2 = pk3;
            }
        }
    }

    qi(String string, gl gl2) {
        super(string, null);
        this.ce_p = gl2;
    }

    static {
        N = "to over <%0> great games";
        L = "Fast Drop Bonus: ";
        T = "Checking";
        Q = new vj();
        R = new ck(270, 70);
    }
}
