/*
 * Decompiled with CFR 0.152.
 */
final class ga
implements lh {
    static String ga_d = "If you do nothing the game will revert to normal view in <%0> seconds.";
    static jc ga_e;
    static String ga_a;
    static String ga_c;
    static String ga_b;

    static final int a(int n, int n2, int n3, String string, int n4, int n5, int n6, mm mm2, byte by, int n7, int n8) {
        block2: {
            int n9 = 2;
            if (mm2 == se.S) {
                n9 = 1;
            }
            mm2.a(string, n8 - n9, -n9 + n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, -n9 + n8, n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8 + -n9, n3 - -n9, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8, -n9 + n3, n, n5, 65793, -1, n7, n2, n4);
            if (by > -123) {
                ga.a(false, -18, 81);
            }
            mm2.a(string, n8, n3 - -n9, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8 - -n9, n3 + -n9, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8 - -n9, n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n9 + n8, n3 + n9, n, n5, 65793, -1, n7, n2, n4);
            if (mm2 != w.w_kb) break block2;
            mm2.a(string, 1 + n8, -n9 + n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8 + -1, -n9 + n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8 + n9, -1 + n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, -n9 + n8, n3 + -1, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n9 + n8, 1 + n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8 - n9, n3 - -1, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, n8 + 1, n9 + n3, n, n5, 65793, -1, n7, n2, n4);
            mm2.a(string, -1 + n8, n3 - -n9, n, n5, 65793, -1, n7, n2, n4);
        }
        return mm2.a(string, n8, n3, n, n5, n6, -1, n7, n2, n4);
    }

    public static void a(byte by) {
        ga_b = null;
        ga_d = null;
        ga_c = null;
        if (by != -52) {
            ga_d = null;
        }
        ga_e = null;
        ga_a = null;
    }

    static final void b(byte by) {
        block0: {
            aa.aa_f = new vj();
            if (by == -112) break block0;
            ga_e = null;
        }
    }

    static final void a(boolean bl, int n, int n2) {
        if (bl) {
            ga_a = null;
        }
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        uf2.a(true, 3);
        uf2.a(true, 10);
        uf2.d(-1, n);
    }

    static final jc a(int n, String string) {
        boolean bl = client.A;
        int n2 = string.length();
        if (~n2 == -1) {
            return hm.hm_a;
        }
        if (n2 > 63) {
            return ga_e;
        }
        int n3 = 0;
        if (n != 7017) {
            ga_d = null;
        }
        while (~n3 > ~n2) {
            char c = string.charAt(n3);
            if ('-' == c) {
                if (-1 == ~n3 || n3 == -1 + n2) {
                    return be.x;
                }
            } else if (0 == ~v.v_c.indexOf(c)) {
                return be.x;
            }
            ++n3;
        }
        return null;
    }

    static {
        ga_a = "Rating";
        ga_e = new jc();
        ga_c = "Confirm Password: ";
        ga_b = "Loading backgrounds";
    }
}
