/*
 * Decompiled with CFR 0.152.
 */
final class ic {
    static int ic_c;
    static String ic_d;
    static int ic_a;
    static String ic_b;
    private static final String z;

    public static void a(int n) {
        block0: {
            ic_b = null;
            ic_d = null;
            if (n == -18551) break block0;
            ic_b = null;
        }
    }

    static {
        z = "ic.A(";
        ic_d = "CRC mismatch - unable to get a valid download. Please check any firewall/antivirus/filtering software.";
        ic_b = "Just play";
    }
}
