/*
 * Decompiled with CFR 0.152.
 */
final class kd
extends wm {
    static int kd_p;
    static int[][] kd_s;
    static int kd_u;
    static String kd_r;
    static String kd_q;
    static ck kd_t;

    @Override
    final String wm_a_string(String string, byte by) {
        if (this.b(string, (byte)-40) == vm.vm_u) {
            return um.um_b;
        }
        if (by == -11) {
            return null;
        }
        kd_u = 2;
        return null;
    }

    @Override
    final tb b(String string, byte by) {
        int n;
        if (!be.a((byte)98, string)) {
            return vm.vm_u;
        }
        if (by != -40) {
            kd_t = null;
        }
        if ((n = cb.a((byte)-106, string)) <= 0 || ~n < -131) {
            return vm.vm_u;
        }
        return dc.dc_b;
    }

    static final void a(int n, int n2, byte by, int n3, int n4) {
        int n5;
        int n6;
        int n7;
        boolean bl = client.A;
        int n8 = n2 + n;
        int n9 = n4 + n3;
        int n10 = n2 <= hk.hk_c ? hk.hk_c : n2;
        int n11 = -83 / ((by - 29) / 53);
        int n12 = ~hk.hk_h > ~n3 ? n3 : hk.hk_h;
        int n13 = hk.hk_g > n8 ? n8 : hk.hk_g;
        int n14 = n7 = ~n9 <= ~hk.hk_b ? hk.hk_b : n9;
        if (~n2 <= ~hk.hk_c && ~hk.hk_g < ~n2) {
            n6 = n2 + n12 * hk.hk_j;
            n5 = -n12 + n7 + 1 >> -97095103;
            while (~(--n5) <= -1) {
                hk.hk_l[n6] = 0xFFFFFF;
                n6 += hk.hk_j * 2;
            }
        }
        if (n3 >= hk.hk_h && ~hk.hk_b < ~n9) {
            n6 = hk.hk_j * n3 + n10;
            n5 = -n10 + n13 + 1 >> -1989691583;
            while (-1 >= ~(--n5)) {
                hk.hk_l[n6] = 0xFFFFFF;
                n6 += 2;
            }
        }
        if (n8 >= hk.hk_c && ~n8 > ~hk.hk_g) {
            n6 = (n12 - -(n8 - n2 & 1)) * hk.hk_j - -n8;
            n5 = -n12 + 1 + n7 >> -2048490399;
            while (~(--n5) <= -1) {
                hk.hk_l[n6] = 0xFFFFFF;
                n6 += 2 * hk.hk_j;
            }
        }
        if (hk.hk_h <= n3 && hk.hk_b > n9) {
            n6 = (-n3 + n9 & 1) + n9 * hk.hk_j - -n10;
            n5 = 1 - -n13 - n10 >> -418335423;
            while (0 <= --n5) {
                hk.hk_l[n6] = 0xFFFFFF;
                n6 += 2;
            }
        }
    }

    kd(rk rk2) {
        super(rk2);
    }

    public static void e(int n) {
        kd_t = null;
        kd_q = null;
        kd_s = null;
        kd_r = null;
        int n2 = -6 / ((80 - n) / 42);
    }

    static {
        kd_s = new int[2][8];
        kd_r = "Find opponent";
        kd_q = "Loading music";
        new vj();
    }
}
