/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class jb
extends RuntimeException {
    Throwable jb_e;
    static vg[] jb_g;
    static tb jb_j;
    static int jb_d;
    static w jb_f;
    String jb_i;
    static String jb_h;
    static boolean jb_a;
    static byte[] jb_b;
    static int jb_c;

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, String string, int n8) {
        k.k_a.Y = string;
        bf.bf_v.Y = 2 == pk.pk_r ? of.of_b : km.B;
        int n9 = 495;
        int n10 = -66 % ((14 - n3) / 34);
        int n11 = 5;
        hm.hm_b.a(n9 + -10, 0, n11, n7, 5);
        wj.Mb.a(hm.hm_b.w_mb - jb.jb_f.w_mb, 0, 0, n7, 0);
        jb_f.a(jb.jb_f.w_mb, 0, 0, n7, wj.Mb.w_mb);
        ve.ve_vc.a(ve.ve_vc.a(true), 0, n11 += n7 + n8, n6, 5);
        int n12 = bf.bf_v.a(true);
        bf.bf_v.a(n12, 0, n11, n6, -5 + (n9 - n12));
        k.k_a.a(n9, 0, 0, n, 0);
        int n13 = 5 + (n6 + n11);
        ib.ib_mb.a(n9, 0, n, n13, 0);
        ib.ib_mb.w_lb = ea.a(0x202020, -20982, 3, ib.ib_mb.N, 0x808080, 0xB0B0B0);
        tf.tf_gb.a(n9, 0, -((n13 += n) / 2) + n2, n13, -(n9 / 2) + n5);
    }

    static final void jb_a_string(String string, byte by) {
        block0: {
            if (by == 45) break block0;
            jb.a((byte)96);
        }
    }

    static final void a(byte by, String string) {
        ve.Qb = true;
        f.f_n.Y = string;
        int n2 = le.le_m.eh_g;
        int n3 = 66 / ((by - 29) / 46);
        int n4 = le.le_m.eh_i;
        int n5 = f.f_n.J.b(string, 272, f.f_n.Db);
        int n6 = 7 + n4 / 2 + (-110 - n5 / 2);
        tc.Ob.a(320, 0, n6, -(n6 * 2) + -120 + n4, (n2 + -320) / 2);
        tc.Ob.w_lb = ea.a(0x202020, -20982, 3, tc.Ob.N, 0x808080, 0xB0B0B0);
        f.f_n.a(tc.Ob.w_mb - 24 + -24, 0, 16, tc.Ob.N - 20 - 24, 24);
        ce.A.a(80, 0, -44 + tc.Ob.N, 24, 120);
    }

    static final char a(byte by, byte by2) {
        int n2;
        int n3 = by & 0xFF;
        if (0 == n3) {
            throw new IllegalArgumentException("" + Integer.toString(n3, 16));
        }
        if (~n3 <= -129 && 160 > n3) {
            n2 = nh.nh_l[n3 - 128];
            if (n2 == 0) {
                n2 = 63;
            }
            n3 = n2;
        }
        n2 = -109 / ((by2 - 41) / 35);
        return (char)n3;
    }

    static final ij a(Applet applet, int n2) {
        boolean bl = client.A;
        String string = wd.a(applet, (byte)-1, "jagex-last-login-method");
        if (null == string) {
            return hn.hn_c;
        }
        ij[] ijArray = oc.a((byte)27);
        if (n2 != -10314) {
            jb_d = -54;
        }
        int n3 = 0;
        while (~n3 > ~ijArray.length) {
            ij ij2 = ijArray[n3];
            if (ij2.a(string, -39)) {
                return ij2;
            }
            ++n3;
        }
        return hn.hn_c;
    }

    public static void a(byte by) {
        jb_h = null;
        jb_g = null;
        jb_j = null;
        if (by != -9) {
            jb_a = false;
        }
        jb_f = null;
        jb_b = null;
    }

    static final void a(w w2, w w3, w w4, int n2, w w5) {
        boolean bl = client.A;
        if (null != kf.Q) {
            return;
        }
        jg.jg_i = false;
        String string = !wc.wc_n ? (!wl.wl_p ? df.S : ln.ln_e) : vg.vg_s;
        cl.a(null, 0, ij.ij_c, string, -24503);
        wj.Mb.w_rb = ((fj.fj_g.w_rb & 0xFEFEFE) >> 1584730369) + -(0x7F7F7F & ij.ij_c >> 22503841) + ij.ij_c;
        wj.Mb.w_fb = ij.ij_c + (-(0x7F7F7F & ij.ij_c >> -1451362751) + ((0xFEFEFF & fj.fj_g.w_fb) >> 1099046881));
        kf.Q = wj.Mb;
        wj.Mb.Bb = ij.ij_c - (((ij.ij_c & 0xFEFEFF) >> 729335969) - (0x7F7F7F & fj.fj_g.Bb >> -1665413055));
        jf.jf_e = jb_f;
        tf.tf_gb = new w(0L, w5);
        k.k_a = new w(0L, w2);
        ib.ib_mb = new w(0L, null);
        hm.hm_b = new w(0L, w4);
        wj.Mb = new w(0L, w3);
        wj.Mb.J = ff.ff_o;
        hm.hm_b.a(wj.Mb, -16834);
        jb_f = new w(0L, jf.jf_e);
        hm.hm_b.a(jb_f, -16834);
        ve.ve_vc = new w(0L, fj.fj_g, pg.pg_g);
        bf.bf_v = new w(0L, fj.fj_g);
        tf.tf_gb.a(k.k_a, -16834);
        if (n2 >= -32) {
            jb_j = null;
        }
        tf.tf_gb.a(ib.ib_mb, -16834);
        ib.ib_mb.a(hm.hm_b, -16834);
        ib.ib_mb.a(ve.ve_vc, -16834);
        ib.ib_mb.a(bf.bf_v, -16834);
    }

    jb(Throwable throwable, String string) {
        this.jb_e = throwable;
        this.jb_i = string;
    }

    static {
        jb_d = 500;
        jb_j = new tb();
        jb_h = "Previous";
        jb_b = new byte[520];
    }
}
