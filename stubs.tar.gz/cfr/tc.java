/*
 * Decompiled with CFR 0.152.
 */
final class tc
extends w {
    static byte[][] Nb;
    private w Vb;
    static w Ub;
    private w[] Rb;
    static ck Tb;
    static String Qb;
    int Pb;
    private w[] Sb;
    static w Ob;

    final void b(boolean bl) {
        block2: {
            boolean bl2 = client.A;
            int n = 0;
            while (~this.Rb.length < ~n) {
                if (~n != ~this.Pb && 0 != this.Rb[n].w_ob) {
                    this.Rb[this.Pb].w_ab = false;
                    this.Sb[this.Pb].w_vb += 10000;
                    this.Pb = n;
                    this.Rb[n].w_ab = true;
                    this.Sb[n].w_vb -= 10000;
                }
                ++n;
            }
            if (!bl) break block2;
            this.a(-26, true, -12);
        }
    }

    public static void h(byte by) {
        if (by <= 83) {
            return;
        }
        Nb = null;
        Ob = null;
        Tb = null;
        Qb = null;
        Ub = null;
    }

    tc(long l, w w2, String[] stringArray, w w3, w[] wArray, int n) {
        super(l, null);
        int n2;
        int n3;
        this.Rb = new w[stringArray.length];
        this.Vb = new w(0L, w3);
        this.Sb = wArray;
        for (n3 = 0; stringArray.length > n3; ++n3) {
            w w4 = new w(0L, w2);
            w4.Y = stringArray[n3];
            this.Rb[n3] = w4;
            this.a(w4, -16834);
        }
        this.a(this.Vb, -16834);
        n3 = n2 = 0;
        while (~n2 > ~wArray.length) {
            this.Vb.a(wArray[n2], -16834);
            ++n2;
        }
        this.Pb = n;
        this.Rb[n].w_ab = true;
    }

    private final void a(int n, boolean bl, int n2) {
        int n3;
        int n4;
        boolean bl2 = client.A;
        if (!bl) {
            this.a(-2, -35, 12, -28, 52, 1, -110);
        }
        for (n4 = 0; n4 < this.Rb.length; ++n4) {
            int n5 = n4 * this.w_mb / this.Rb.length;
            int n6 = this.w_mb * (n4 - -1) / this.Rb.length;
            this.Rb[n4].w_vb = n5;
            this.Rb[n4].Ib = 0;
            this.Rb[n4].w_mb = n6 + -n5;
            this.Rb[n4].N = n2;
        }
        this.Vb.a(this.w_mb, 0, n2, -n2 + this.N, 0);
        n4 = n3 = 0;
        while (n3 < this.Sb.length) {
            this.Sb[n3].a(this.Vb.w_mb + -(2 * n), 0, n, -(2 * n) + this.Vb.N, n);
            if (~n3 != ~this.Pb) {
                this.Sb[n3].w_vb += 10000;
            }
            ++n3;
        }
    }

    static final w g(byte by) {
        if (by != 98) {
            return null;
        }
        return dm.a((byte)108);
    }

    final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        if (n7 >= -44) {
            this.a(4, true, -41);
        }
        this.N = n;
        this.w_mb = n3;
        this.w_vb = n6;
        this.Ib = n2;
        this.a(n4, true, n5);
    }

    static final int a(int n, hl hl2) {
        int n2;
        block0: {
            boolean bl = client.A;
            n2 = ij.ij_c;
            n2 = -3 != ~hl2.hl_m ? (4 == hl2.hl_m ? ul.ul_c[hl2.hl_m] : (hl2.hl_r == uc.uc_g ? tl.tl_q[hl2.hl_m] : ul.ul_c[hl2.hl_m])) : (hl2.hl_j ? ij.ij_c : (hl2.hl_i != 0 || -1 != ~hl2.hl_n ? ul.ul_c[hl2.hl_m] : tl.tl_q[hl2.hl_m]));
            if (n == 4636) break block0;
            tc.g((byte)85);
        }
        return n2;
    }
}
