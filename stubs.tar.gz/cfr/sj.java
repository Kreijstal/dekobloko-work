/*
 * Decompiled with CFR 0.152.
 */
interface sj
extends vn {
    public void a(int var1, int var2, int var3, int var4, ek var5, int var6);

    public void a(int var1, int var2, ek var3, int var4, int var5, int var6, int var7);
}
