/*
 * Decompiled with CFR 0.152.
 */
import java.math.BigInteger;

final class re
extends wm {
    static String re_w;
    static String re_s;
    static String[] re_q;
    static String re_u;
    static int re_v;
    static String re_t;
    private rk re_p;
    static ck re_r;
    static w x;

    @Override
    final String wm_a_string(String string, byte by) {
        nb nb2;
        if (by != -11) {
            String string2 = null;
            this.b(string2, (byte)-68);
        }
        if (this.re_p instanceof jl && (nb2 = ((jl)((Object)this.re_p)).a(by + -78)) != null) {
            if (nb2.a(20350) == dc.dc_b && !string.equals(this.re_p.E)) {
                return ak.ak_f;
            }
            return nb2.b((byte)103);
        }
        if (!string.equals(this.re_p.E)) {
            return ak.ak_f;
        }
        return null;
    }

    static final void a(int n, int n2, int n3, int n4, ck ck2, int n5, int n6, int n7) {
        boolean bl = client.A;
        if (hk.hk_c > n3) {
            n6 -= -n3 + hk.hk_c;
            n3 = hk.hk_c;
        }
        if (hk.hk_g < n3 + n6) {
            n6 = -n3 + hk.hk_g;
        }
        if (~n5 > ~hk.hk_h) {
            n7 -= -n5 + hk.hk_h;
            n5 = hk.hk_h;
        }
        if (hk.hk_b < n7 + n5) {
            n7 = hk.hk_b + -n5;
        }
        if (~n6 < -1) {
            if (0 >= n7) {
                return;
            }
            ck ck3 = ck2.c();
            int[] nArray = hk.hk_l;
            int n8 = hk.hk_j;
            int n9 = hk.hk_i;
            int[] nArray2 = new int[4];
            hk.b(nArray2);
            ck2.a();
            hk.f(nArray2[0], nArray2[1], nArray2[n4], nArray2[3]);
            int n10 = n5 * ck2.I + n3;
            int n11 = ck2.I + -n6;
            int[] nArray3 = ck3.D;
            int n12 = n5;
            while (~(n7 - -n5) < ~n12) {
                for (int i = n3; i < n6 + n3; ++i) {
                    int n13 = nArray3[n10];
                    if (0 != n13 && (0 < i && nArray3[-1 + n10] == 0 || n12 > 0 && -1 == ~nArray3[n10 + -ck2.I] || ~i > ~(ck2.I + -1) && -1 == ~nArray3[1 + n10] || -1 + ck2.H > n12 && nArray3[ck2.I + n10] == 0)) {
                        hk.e(i, n12, n, n2);
                    }
                    ++n10;
                }
                n10 += n11;
                ++n12;
            }
            ck3.c(-ck2.F, -ck2.z);
            hk.a(nArray, n8, n9);
            hk.a(nArray2);
            return;
        }
    }

    public static void g(byte by) {
        re_w = null;
        x = null;
        if (by >= 0) {
            re_t = null;
        }
        re_q = null;
        re_t = null;
        re_s = null;
        re_r = null;
        re_u = null;
    }

    static final void a(BigInteger bigInteger, BigInteger bigInteger2, wl wl2, wl wl3, int n) {
        ri.a(n, (byte)115, wl3.wl_n, bigInteger, bigInteger2, wl2, wl3.wl_r);
    }

    static final boolean a(int n, char c, CharSequence charSequence) {
        if (!oe.a(c, -6237)) {
            return false;
        }
        if (null == charSequence) {
            return false;
        }
        int n2 = charSequence.length();
        if (12 <= n2) {
            return false;
        }
        if (ug.a(c, 32) && 0 == n2) {
            return false;
        }
        int n3 = 110 % ((n - 23) / 47);
        return true;
    }

    @Override
    final tb b(String string, byte by) {
        nb nb2;
        if (this.re_p instanceof jl && (nb2 = ((jl)((Object)this.re_p)).a(-87)) != null && nb2.a(20350) != dc.dc_b) {
            return vm.vm_u;
        }
        if (by != -40) {
            x = null;
        }
        return !string.equals(this.re_p.E) ? vm.vm_u : dc.dc_b;
    }

    re(rk rk2, rk rk3) {
        super(rk2);
        this.re_p = rk3;
    }

    static final void a(w w2, w w3, w w4, w w5, w w6, boolean bl, w w7, w w8, mm mm2, w w9, byte by, jd jd2) {
        block6: {
            ck ck2;
            boolean bl2 = client.A;
            tl.tl_q[1] = 0x60FF60;
            tl.tl_q[0] = 16764000;
            tl.tl_q[3] = 0xFF60FF;
            tl.tl_q[4] = 0xFF00FF;
            tl.tl_q[2] = 0x9090FF;
            fj.fj_g = w3;
            ii.ii_q = bl;
            ff.ff_o = mm2;
            ul.ul_c[0] = 16764000;
            tl.tl_q[4] = 0xFF00FF;
            ul.ul_c[3] = 0xFF60FF;
            ul.ul_c[2] = 0xFF6060;
            ul.ul_c[1] = 0x60FF60;
            ij.ij_c = 0x808080;
            ck ck3 = ck2 = new ck(4, 4);
            int[] nArray = ck3.D;
            int[] nArray2 = ck3.D;
            int[] nArray3 = ck2.D;
            ck2.D[15] = 0x707070;
            nArray3[8] = 0x707070;
            nArray2[5] = 0x707070;
            nArray[2] = 0x707070;
            ck[] ckArray = new ck[9];
            ckArray[4] = ck2;
            ea.D = new w(0L, w7);
            x = new w(0L, w8);
            ea.D.a(x, -16834);
            w w10 = new w(0L, null);
            w10.M = new vj();
            dn.dn_l = new nm(0L, w10, w6, jd2);
            x.a(dn.dn_l, -16834);
            sk.sk_c = new w(0L, w2);
            x.a(sk.sk_c, -16834);
            wj.Mb = new w(0L, w4);
            wj.Mb.J = ff.ff_o;
            sk.sk_c.a(wj.Mb, -16834);
            sk.sk_c.d(-25);
            jb.jb_f = new w(0L, null);
            jb.jb_f.w_lb = ckArray;
            sk.sk_c.a(jb.jb_f, -16834);
            dh.dh_c = new w[5];
            ui.E = new w[5];
            si.si_b = new w[5];
            le.D = new w[5];
            int n = 0;
            while (~n > -6) {
                block5: {
                    String string;
                    block3: {
                        block4: {
                            block2: {
                                if (~n != -1) break block2;
                                string = !ii.ii_q ? qm.qm_b : uc.uc_b;
                                break block3;
                            }
                            if (1 == n && ii.ii_q) break block4;
                            if (2 != n) break block5;
                            string = sk.sk_m;
                            break block3;
                        }
                        string = eg.eg_b;
                    }
                    dh.dh_c[n] = new w(0L, w5);
                    ui.E[n] = new w(0L, fj.fj_g, string);
                    si.si_b[n] = new w(0L, null);
                    si.si_b[n].W = 1;
                    le.D[n] = new w(0L, fj.fj_g);
                    le.D[n].W = 1;
                    dh.dh_c[n].a(ui.E[n], -16834);
                    dh.dh_c[n].a(si.si_b[n], by + -16937);
                    dh.dh_c[n].a(le.D[n], -16834);
                    dh.dh_c[n].d(-64);
                    ea.D.a(dh.dh_c[n], by ^ 0xFFFFBE59);
                    ++dh.dh_f;
                }
                ++n;
            }
            if (by != 103) {
                re.g((byte)-47);
            }
            qb.qb_p = new w(0L, w9);
            qb.qb_p.Y = hf.hf_h;
            ea.D.a(qb.qb_p, -16834);
            if (si.c(-12851) && !wc.wc_n) break block6;
            bc.E = new mf(0, 0, 0, 0);
        }
    }

    static {
        re_s = "Theme:";
        re_u = "Error connecting to server. Please try using a different server.";
        re_w = "Fullscreen";
        re_t = "Quick Chat lobby";
        re_q = new String[]{"Connection lost - attempting to reconnect", "Connection lost - attempting to reconnect.", "Connection lost - attempting to reconnect..", "Connection lost - attempting to reconnect..."};
    }
}
