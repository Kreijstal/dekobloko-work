/*
 * Decompiled with CFR 0.152.
 */
final class mi
extends ol {
    private vj mi_t = new vj();
    private vj mi_u = new vj();
    private int mi_r = -1;
    private int mi_s = 0;

    private final void e() {
        if (this.mi_s > 0) {
            rh rh2 = (rh)this.mi_u.c((byte)-59);
            while (rh2 != null) {
                rh2.rh_o -= this.mi_s;
                rh rh3 = (rh)this.mi_u.d(true);
            }
            this.mi_r -= this.mi_s;
            this.mi_s = 0;
            return;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    final synchronized void b(int[] nArray, int n, int n2) {
        do {
            rh rh2;
            if (this.mi_r < 0) {
                this.c(nArray, n, n2);
                return;
            }
            if (this.mi_s + n2 < this.mi_r) {
                this.mi_s += n2;
                this.c(nArray, n, n2);
                return;
            }
            int n3 = this.mi_r - this.mi_s;
            this.c(nArray, n, n3);
            n += n3;
            n2 -= n3;
            this.mi_s += n3;
            this.e();
            rh rh3 = rh2 = (rh)this.mi_u.c((byte)-109);
            synchronized (rh3) {
                int n4 = rh2.a(this);
                if (n4 < 0) {
                    rh2.rh_o = 0;
                    this.b(rh2);
                } else {
                    rh2.rh_o = n4;
                    this.a(rh2.bh_b, rh2);
                }
            }
        } while (n2 != 0);
    }

    private final void c(int n) {
        ol ol2 = (ol)this.mi_t.c((byte)-69);
        while (ol2 != null) {
            ol2.a(n);
            ol ol3 = (ol)this.mi_t.d(true);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    final synchronized void a(int n) {
        do {
            rh rh2;
            if (this.mi_r < 0) {
                this.c(n);
                return;
            }
            if (this.mi_s + n < this.mi_r) {
                this.mi_s += n;
                this.c(n);
                return;
            }
            int n2 = this.mi_r - this.mi_s;
            this.c(n2);
            n -= n2;
            this.mi_s += n2;
            this.e();
            rh rh3 = rh2 = (rh)this.mi_u.c((byte)-54);
            synchronized (rh3) {
                int n3 = rh2.a(this);
                if (n3 < 0) {
                    rh2.rh_o = 0;
                    this.b(rh2);
                } else {
                    rh2.rh_o = n3;
                    this.a(rh2.bh_b, rh2);
                }
            }
        } while (n != 0);
    }

    final synchronized void b(ol ol2) {
        ol2.b((byte)108);
    }

    @Override
    final ol c() {
        return (ol)this.mi_t.d(true);
    }

    final void a(ud ud2, int n, int n2, int n3) {
        this.a(ei.a(ud2, n, n2, n3));
    }

    final synchronized void a(ol ol2) {
        this.mi_t.b(ol2, 7143);
    }

    private final void b(rh rh2) {
        rh2.b((byte)114);
        rh2.a();
        rh2.rh_n = null;
        bh bh2 = this.mi_u.vj_c.bh_b;
        this.mi_r = bh2 == this.mi_u.vj_c ? -1 : ((rh)bh2).rh_o;
    }

    final synchronized void c(rh rh2) {
        if (rh2.rh_n == null) {
            return;
        }
        if (rh2.rh_n != this) {
            throw new RuntimeException();
        }
        this.e();
        this.b(rh2);
    }

    @Override
    final int a() {
        return 0;
    }

    final synchronized void a(rh rh2) {
        if (rh2.rh_n != null) {
            throw new RuntimeException();
        }
        this.e();
        rh2.rh_n = this;
        rh2.b();
        this.a(this.mi_u.vj_c.bh_b, rh2);
    }

    private final void a(bh bh2, rh rh2) {
        while (bh2 != this.mi_u.vj_c && ((rh)bh2).rh_o <= rh2.rh_o) {
            bh2 = bh2.bh_b;
        }
        fm.a((byte)10, rh2, bh2);
        this.mi_r = ((rh)this.mi_u.vj_c.bh_b).rh_o;
    }

    @Override
    final ol d() {
        return (ol)this.mi_t.c((byte)126);
    }

    private final void c(int[] nArray, int n, int n2) {
        ol ol2 = (ol)this.mi_t.c((byte)-106);
        while (ol2 != null) {
            ol2.a(nArray, n, n2);
            ol ol3 = (ol)this.mi_t.d(true);
        }
    }
}
