/*
 * Decompiled with CFR 0.152.
 */
final class ec {
    static String ec_c = "(1 player wants to join)";
    String ec_o;
    static String ec_j = "Only show private chat from my friends and opponents";
    static int[] ec_f = new int[8192];
    int ec_l;
    int ec_r;
    int ec_n;
    static String[] ec_e = new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    static nm ec_k;
    static int ec_g;
    int ec_m;
    static String ec_b;
    static mm ec_p;
    static String ec_a;
    int ec_d;
    static String ec_q;
    static w ec_i;
    static int ec_h;

    public static void a(byte by) {
        ec_k = null;
        ec_p = null;
        ec_i = null;
        if (by < 78) {
            return;
        }
        ec_c = null;
        ec_f = null;
        ec_j = null;
        ec_a = null;
        ec_q = null;
        ec_b = null;
        ec_e = null;
    }

    static final void a(int n) {
        block1: {
            boolean bl = client.A;
            uf uf2 = we.we_b;
            while (sc.c((byte)-104)) {
                uf2.f(8, -4);
                int n2 = ++uf2.wl_n;
                ba.a(-32141, uf2);
                we.we_b.b(uf2.wl_n - n2, true);
            }
            if (n <= -91) break block1;
            ec.a(-123);
        }
    }

    ec(int n, String string, mm mm2) {
        this.ec_d = n;
        this.ec_o = string;
        this.ec_n = mm2.a(this.ec_o) + 46;
        this.ec_r = 30;
    }

    ec(int n) {
        this.ec_r = 30;
        this.ec_d = n;
    }

    static {
        ec_a = "Spectate <%0>'s game";
        ec_b = "You cannot join this game - it is in progress";
        ec_q = "Go Back";
    }
}
