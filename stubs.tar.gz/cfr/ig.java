/*
 * Decompiled with CFR 0.152.
 */
final class ig
extends w {
    private int ig_fc;
    private int Vb;
    static ud ig_ac;
    private int ig_bc;
    private int ig_ec;
    private int[] Nb;
    private qd[] gc;
    private int Ob;
    private int Qb;
    private char[] Wb;
    static String Sb;
    static String Xb;
    private int Zb;
    private ig[] Pb;
    static int Yb;
    private int Rb = -1;
    static int ig_dc;
    static nh[] ig_cc;
    private ig Ub;
    static String Tb;

    private final void a(int n, int n2, int n3, int n4) {
        boolean bl = client.A;
        int n5 = 2 % ((n3 - 61) / 40);
        if (n2 == this.Rb) {
            this.e(0);
            this.b((byte)67, 0);
        } else if (this.Pb[n2] == null) {
            if (this.Nb[n2] == -1) {
                cc.a(8);
                pf.a(false);
            } else {
                int n6 = this.Nb[n2] | 0x8000;
                int n7 = pk.pk_r;
                if (n7 == 0 && null != cd.cd_m) {
                    n7 = 1;
                }
                if (-3 == ~rf.a(0, n7)) {
                    eg.a(n7, n, 1, (byte)123);
                }
                ce.a(n4, (byte)-85, pk.pk_r, ed.ed_c, n6, null);
                rb.a(fm.fm_d, ed.ed_c, -94, pk.pk_r, n6);
                pf.a(false);
                h.a((byte)11);
            }
        } else {
            this.e(0);
            this.b((byte)67, 0);
            this.Rb = n2;
            this.Ub = this.Pb[this.Rb];
            vm.a(107, this.Ub);
            this.Ub.b((byte)67, 12);
        }
    }

    final boolean b(int n, int n2, int n3) {
        boolean bl;
        boolean bl2 = client.A;
        boolean bl3 = bl = wh.wh_c == 85;
        if (null == this.Ub) {
            if (this.Ub == null && this == mg.mg_bc && bl) {
                pf.a(false);
                return true;
            }
        } else {
            if (bl && this.Ub.Rb == -1) {
                this.e(n2 + -15028);
                this.b((byte)67, 0);
                return true;
            }
            return this.Ub.b(n, n2 ^ 0, n3);
        }
        if (n2 != 15028) {
            return true;
        }
        char c = el.G;
        if (c > '\u0000') {
            if (~aa.aa_b == ~c) {
                c = '?';
            }
            int n4 = 0;
            while (~this.Wb.length < ~n4) {
                if (~this.Wb[n4] == ~c) {
                    this.a(n, n4, 107, n3);
                    return true;
                }
                ++n4;
            }
        }
        return false;
    }

    final int g(int n) {
        if (n > -87) {
            ig_cc = null;
        }
        return this.ig_bc - -(null != this.Ub ? this.Ub.g(-119) : 0);
    }

    private final void b(byte by, int n) {
        boolean bl = client.A;
        this.ig_ec = n;
        if (by != 67) {
            this.Wb = null;
        }
        for (int i = 0; this.Ob > i; ++i) {
            int n2 = this.ig_ec * this.ig_ec;
            int n3 = i * this.Vb;
            this.gc[i].Ib = (n3 * (-n2 + 144) + (this.Zb - this.w_pb) * n2) / 144;
        }
    }

    final void a(int n, int n2, int n3) {
        block3: {
            ig ig2;
            boolean bl = client.A;
            if (n3 > -97) {
                Tb = null;
            }
            for (int i = 0; i < this.gc.length; ++i) {
                qd qd2 = this.gc[i];
                if (~qd2.w_ob != -2) continue;
                this.a(n2, i, -90, n);
                qd2.w_ab = ~i == ~this.Rb;
            }
            if (this.Rb != -1 && null != (ig2 = this.Pb[this.Rb])) {
                ig2.a(n, n2, -99);
            }
            if (-1 <= ~this.ig_ec) break block3;
            this.b((byte)67, this.ig_ec - 1);
        }
    }

    final void a(int n, int n2, int n3, int n4, byte by, int n5) {
        block4: {
            int n6;
            int n7;
            boolean bl = client.A;
            this.ig_bc = this.ig_fc + n * 2;
            this.a(this.ig_bc, 0, -this.Qb + n3, this.Qb, n2);
            if (by != -18) {
                this.Qb = 30;
            }
            if (~n5 != ~this.Zb) {
                this.Zb = n5;
                this.b((byte)67, this.ig_ec);
            }
            for (n7 = 0; this.Ob > n7; ++n7) {
                this.gc[n7].a(this.Vb, n, 0, this.gc[n7].Ib, this.ig_bc, n4, 500);
            }
            if (0 == ~this.Rb || null == this.Pb[this.Rb]) break block4;
            n7 = this.Pb[this.Rb].Ob;
            for (n6 = (n7 + this.Rb) * this.Vb + this.Ib; n3 < n6; n6 -= this.Vb) {
            }
            this.Pb[this.Rb].a(n, this.ig_bc + n2, n6, n4, (byte)-18, this.gc[this.Rb].w_pb);
        }
    }

    final boolean f(int n) {
        boolean bl = client.A;
        if (n != -1) {
            return false;
        }
        boolean bl2 = false;
        qd[] qdArray = this.gc;
        int n2 = 0;
        while (~qdArray.length < ~n2) {
            qd qd2 = qdArray[n2];
            bl2 |= 0 != qd2.w_ob;
            ++n2;
        }
        if (!bl2 && -1 != this.Rb && this.Pb[this.Rb] != null) {
            bl2 = this.Pb[this.Rb].f(-1);
        }
        return bl2;
    }

    final void e(int n) {
        boolean bl = client.A;
        qd[] qdArray = this.gc;
        qd[] qdArray2 = this.gc;
        int n2 = n;
        while (~n2 > ~qdArray.length) {
            qd qd2 = qdArray[n2];
            qd2.w_ab = false;
            qd2.w_ob = 0;
            ++n2;
        }
        if (null != this.Ub) {
            this.Ub.e(0);
            this.Ub.b((byte)104);
        }
        this.Rb = -1;
        this.Ub = null;
        this.b((byte)67, 12);
    }

    static final boolean a(int n, int n2, int n3, byte by) {
        if (by != 69) {
            return true;
        }
        if (w.H != null && w.H.c(by + -72)) {
            tf.i((byte)-125);
            return true;
        }
        if (pd.pd_f != null && pd.pd_f.b(false)) {
            pd.pd_f = null;
            tf.i((byte)-97);
            return true;
        }
        if (ve.g((byte)119)) {
            return true;
        }
        return rm.a(n2, n, (byte)10, n3);
    }

    public static void g(byte by) {
        Xb = null;
        if (by < 18) {
            return;
        }
        ig_cc = null;
        ig_ac = null;
        Sb = null;
        Tb = null;
    }

    ig(long l, w w2, w w3, w w4, ig[] igArray, int[] nArray, String[] stringArray, char[] cArray) {
        super(l, w2);
        mm mm2;
        this.Wb = cArray;
        this.Nb = nArray;
        this.Pb = igArray;
        this.Ob = this.Nb.length;
        mm mm3 = mm2 = w4.J;
        this.Vb = mm3.K + 2 + mm3.R;
        this.ig_fc = 0;
        this.gc = new qd[this.Ob];
        this.Qb = this.Vb * this.Ob;
        String string = "<col=999999>";
        String string2 = "</col>";
        for (int i = 0; this.Ob > i; ++i) {
            if ('\u0000' < this.Wb[i]) {
                stringArray[i] = string + pf.a(this.Wb[i], (byte)-9).toUpperCase() + ": " + string2 + stringArray[i];
            }
            ck ck2 = null;
            if (this.Pb[i] != null || this.Nb[i] == -1) {
                ck2 = qb.qb_q;
            }
            this.gc[i] = new qd(0L, w3, null, w4, ck2, stringArray[i]);
            this.a(this.gc[i], -16834);
            int n = mm2.a(stringArray[i]);
            if (~n >= ~this.ig_fc) continue;
            this.ig_fc = n;
        }
        this.ig_fc += qb.qb_q.K - -10;
        this.b((byte)67, 12);
    }

    static final boolean b(boolean bl) {
        if (!bl) {
            ig_ac = null;
        }
        return uc.uc_g == cd.cd_m.Xb;
    }

    static {
        Sb = "This game option has not yet been unlocked for use.";
        Yb = 0;
        Xb = "Set up new game";
        Tb = "Quit to website";
    }
}
