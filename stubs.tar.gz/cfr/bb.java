/*
 * Decompiled with CFR 0.152.
 */
final class bb {
    static int bb_d = -1;
    static ck[][] bb_a = new ck[8][];
    static int bb_e;
    static ck bb_c;
    static ck[] bb_b;
    static int bb_f;

    static final void a(boolean bl) {
        boolean bl2 = client.A;
        ck ck2 = new ck(540, 140);
        tb.a(bl, ck2);
        qg.b();
        hk.b();
        gd.gd_e = 0;
        vk.a(0);
        ck ck3 = ck2.c();
        for (int i = 0; 15 > i; ++i) {
            ck3.d(-2, -2, 0xFFFFFF);
            hk.b(4, 4, 0, 0, 540, 140);
        }
        qi.R.a();
        ck2.d(0, 0);
        mk.a((byte)-5);
    }

    static final void b(boolean bl) {
        if (!bl) {
            bb.a((byte)-17);
        }
        tf.i((byte)-121);
        db.a(bl);
        pd.pd_f = null;
        pf.a(false);
    }

    public static void a(int n) {
        bb_c = null;
        bb_a = null;
        int n2 = -3 / ((n - 37) / 58);
        bb_b = null;
    }

    static final void a(boolean bl2, ji ji2, pi[] piArray, int[] nArray, ji ji3) {
        int n2;
        boolean bl3 = client.A;
        lc[] lcArray = t.a("crowns", ji2, false, "lobby");
        n.n_c = lcArray.length;
        if (piArray != null) {
            lc[] lcArray2 = new lc[piArray.length + n.n_c];
            for (n2 = 0; n.n_c > n2; ++n2) {
                lcArray2[n2] = lcArray[n2];
            }
            for (n2 = 0; piArray.length > n2; ++n2) {
                lcArray2[n2 + n.n_c] = piArray[n2];
            }
            lcArray = lcArray2;
        }
        int[] nArray2 = new int[lcArray.length];
        for (n2 = 0; n2 < n.n_c; ++n2) {
            nArray2[n2] = 10;
        }
        if (null != piArray) {
            if (nArray == null) {
                for (n2 = 0; n2 < piArray.length; ++n2) {
                    nArray2[n2 + n.n_c] = piArray[n2].lc_g;
                }
            } else {
                for (n2 = 0; piArray.length > n2; ++n2) {
                    nArray2[n2 + n.n_c] = nArray[n2];
                }
            }
        }
        hn.hn_a = 2;
        kf.O = 15;
        wg.wg_e = 11;
        nk.nk_b = 4;
        j.j_c = 2;
        lm lm2 = cd.a("largefont", ji3, ji2, (byte)91, "lobby");
        tg.tg_a = cd.a("generalfont", ji3, ji2, (byte)121, "lobby");
        nf.nf_d = cd.a("chatfont", ji3, ji2, (byte)102, "lobby");
        lm2.a(lcArray, nArray2);
        tg.tg_a.a(lcArray, nArray2);
        nf.nf_d.a(lcArray, nArray2);
        w w2 = new w(0L, null);
        w2.Db = kf.O;
        w2.G = 0xFFFFFF;
        w2.J = lm2;
        w w3 = w2;
        w2.W = 1;
        w3.X = 1;
        w w4 = new w(0L, null);
        w4.Db = kf.O;
        w4.G = 0xFFFFFF;
        w4.J = tg.tg_a;
        w w5 = w4;
        w4.W = 1;
        w5.X = 1;
        ml.ml_a = new w(0L, w2);
        ml.ml_a.w_lb = cg.a((byte)116, bj.a(112, ji2, "lobby", "heading"));
        wa.wa_a = new w(0L, null);
        wa.wa_a.w_lb = qe.a(false, 120, false, 0x808080, 0x404040, -26198);
        db.db_c = new w(0L, null);
        db.db_c.w_lb = ea.a(1, -20982, 3, 114, 0x606060, 0x606060);
        ah.ah_h = new w(0L, null);
        ah.ah_h.w_lb = cg.a((byte)126, bj.a(112, ji2, "lobby", "popup"));
        ck[] ckArray = cg.a((byte)118, bj.a(112, ji2, "lobby", "popup_mouseover"));
        ck[] ckArray2 = bj.a(112, ji2, "lobby", "button");
        ck[] ckArray3 = cg.a((byte)119, bj.a(112, ji2, "lobby", "tab_active"));
        tg.tg_h = new w(0L, w2);
        tg.tg_h.w_lb = ckArray3;
        ib.ib_nb = new w(0L, null);
        ib.ib_nb.I = id.a(ji2, "closebutton", "lobby", 8192);
        ib.ib_nb.R = id.a(ji2, "closebutton_mouseover", "lobby", 8192);
        i.i_e = new w(0L, w2);
        i.i_e.w_lb = qe.a(true, 40, true, 0x3A3A3A, 0x1F1F1F, -26198);
        fh.fh_g = new w(0L, w4);
        fh.fh_g.w_ub = 2;
        fh.fh_g.w_lb = qe.a(false, 30, true, 0x3A3A3A, 0x1F1F1F, -26198);
        bl.Y = new w(0L, w4);
        bl.Y.w_ub = 2;
        bl.Y.w_lb = qe.a(false, 30, false, 0x3A3A3A, 0x1F1F1F, -26198);
        dd.dd_k = new w(0L, w4);
        dd.dd_k.w_ub = 2;
        dd.dd_k.w_lb = qe.a(true, 30, false, 0x3A3A3A, 0x1F1F1F, -26198);
        ua.H = new w(0L, null);
        ua.H.J = tg.tg_a;
        ua.H.Db = kf.O;
        ua.H.W = 1;
        ua.H.G = 0xCCCCCC;
        df.df_ab = new w(0L, ua.H);
        df.df_ab.P = 0x808080;
        df.df_ab.w_rb = 0xFFFFFF;
        df.df_ab.Bb = 0xFFFFFF;
        df.df_ab.G = 0xFFCC66;
        df.df_ab.w_fb = 0xFFFFFF;
        w w6 = new w(0L, df.df_ab);
        w6.Db = kf.O;
        w6.G = 0xFFFFFF;
        w6.J = lm2;
        fc.fc_c = new w(0L, ua.H);
        fc.fc_c.w_lb = qe.a(bl2, 16, false, 0x222222, 0x222222, -26198);
        fc.fc_c.w_ub = 2;
        sg.sg_e = new w(0L, ua.H);
        sg.sg_e.w_lb = qe.a(false, 16, false, 0x171717, 0x171717, -26198);
        sg.sg_e.w_ub = 2;
        fc.fc_f = new w(0L, fc.fc_c);
        fc.fc_f.a(-118, df.df_ab);
        gg.G = new w(0L, sg.sg_e);
        gg.G.a(-125, df.df_ab);
        ck[] ckArray4 = bj.a(112, ji2, "lobby", "button_mouseover");
        ik.ik_e = new gb(ah.ah_h, ckArray, ua.H, df.df_ab, 3, 2, j.j_c, 3, kf.O);
        vd.vd_s = new w(0L, df.df_ab);
        vd.vd_s.S = ckArray4;
        vd.vd_s.w_db = 1;
        vd.vd_s.Z = 1;
        vd.vd_s.w_lb = ckArray2;
        vd.vd_s.w_nb = 1;
        vd.vd_s.w_ib = 1;
        vd.vd_s.w_eb = bj.a(112, ji2, "lobby", "button_mouseheld");
        vd.vd_s.Q = bj.a(112, ji2, "lobby", "button_active");
        vd.vd_s.Ab = bj.a(112, ji2, "lobby", "button_disabled");
        vd.vd_s.X = 1;
        ec.ec_i = new w(0L, df.df_ab);
        ec.ec_i.X = 1;
        ec.ec_i.w_lb = cg.a((byte)125, bj.a(112, ji2, "lobby", "tab_inactive"));
        ec.ec_i.S = cg.a((byte)126, bj.a(112, ji2, "lobby", "tab_mouseover"));
        ec.ec_i.Q = ckArray3;
        fb.fb_b = new w(0L, null);
        fb.fb_b.w_lb = ea.a(-1, -20982, 3, 206, 1127256, 1856141);
        bf.bf_t = new w(0L, null);
        bf.bf_t.w_lb = ea.a(-1, -20982, 3, 290, 0x5C5C5C, 0xB0B0B0);
        d.d_g = new w(0L, w6);
        d.d_g.w_ib = 1;
        d.d_g.w_nb = 1;
        d.d_g.X = 1;
        d.d_g.Z = 1;
        d.d_g.w_db = 1;
        kn.kn_p = new w(0L, d.d_g);
        ma.J = new w(0L, df.df_ab);
        ma.J.X = 1;
        ma.J.w_ib = 1;
        ma.J.Z = 1;
        ma.J.w_db = 1;
        ma.J.w_nb = 1;
        lj.lj_c = new w(0L, ma.J);
        gk.Hb = new w(0L, ma.J);
        hd.hd_q = new w(0L, d.d_g);
        oh.oh_i = new w(0L, ma.J);
        rd.rd_a = new w(0L, ma.J);
        l.l_a = new w(0L, ma.J);
        ma.J.w_lb = cg.a((byte)116, bj.a(112, ji2, "lobby", "smallbutton"));
        ma.J.S = cg.a((byte)113, bj.a(112, ji2, "lobby", "smallbutton_mouseover"));
        ma.J.Q = cg.a((byte)127, bj.a(112, ji2, "lobby", "smallbutton_active"));
        ma.J.w_eb = ma.J.Q;
        ma.J.Ab = cg.a((byte)115, bj.a(112, ji2, "lobby", "smallbutton_disabled"));
        kn.kn_p.w_lb = cg.a((byte)123, bj.a(112, ji2, "lobby", "mediumbutton"));
        kn.kn_p.S = cg.a((byte)117, bj.a(112, ji2, "lobby", "mediumbutton_mouseover"));
        kn.kn_p.w_eb = cg.a((byte)114, bj.a(112, ji2, "lobby", "mediumbutton_mouseheld"));
        d.d_g.w_lb = cg.a((byte)120, bj.a(112, ji2, "lobby", "bigbutton"));
        d.d_g.S = cg.a((byte)114, bj.a(112, ji2, "lobby", "bigbutton_mouseover"));
        d.d_g.w_eb = cg.a((byte)123, bj.a(112, ji2, "lobby", "bigbutton_mouseheld"));
        d.d_g.Ab = cg.a((byte)121, bj.a(112, ji2, "lobby", "bigbutton_disabled"));
        lj.lj_c.w_lb = cg.a((byte)125, bj.a(112, ji2, "lobby", "greenbutton"));
        lj.lj_c.S = cg.a((byte)114, bj.a(112, ji2, "lobby", "greenbutton_mouseover"));
        lj.lj_c.w_eb = cg.a((byte)123, bj.a(112, ji2, "lobby", "greenbutton_mouseheld"));
        gk.Hb.w_lb = cg.a((byte)113, bj.a(112, ji2, "lobby", "redbutton"));
        gk.Hb.S = cg.a((byte)113, bj.a(112, ji2, "lobby", "redbutton_mouseover"));
        gk.Hb.w_eb = cg.a((byte)123, bj.a(112, ji2, "lobby", "redbutton_mouseheld"));
        hd.hd_q.w_lb = cg.a((byte)119, bj.a(112, ji2, "lobby", "backbutton"));
        hd.hd_q.S = cg.a((byte)117, bj.a(112, ji2, "lobby", "backbutton_mouseover"));
        hd.hd_q.w_eb = cg.a((byte)120, bj.a(112, ji2, "lobby", "backbutton_mouseheld"));
        hd.hd_q.Ab = cg.a((byte)120, bj.a(112, ji2, "lobby", "backbutton_disabled"));
        l.l_a.w_lb = cg.a((byte)122, bj.a(112, ji2, "lobby", "gameoptionbutton"));
        l.l_a.S = cg.a((byte)123, bj.a(112, ji2, "lobby", "gameoptionbutton_mouseover"));
        l.l_a.Q = cg.a((byte)117, bj.a(112, ji2, "lobby", "gameoptionbutton_active"));
        l.l_a.w_eb = l.l_a.Q;
        l.l_a.Ab = cg.a((byte)114, bj.a(112, ji2, "lobby", "gameoptionbutton_disabled"));
        oh.oh_i.w_lb = cg.a((byte)124, bj.a(112, ji2, "lobby", "chatbutton"));
        oh.oh_i.S = cg.a((byte)114, bj.a(112, ji2, "lobby", "chatbutton_mouseover"));
        oh.oh_i.Q = cg.a((byte)125, bj.a(112, ji2, "lobby", "chatbutton_active"));
        oh.oh_i.w_eb = oh.oh_i.Q;
        rd.rd_a.w_lb = cg.a((byte)124, bj.a(112, ji2, "lobby", "chatfilterbutton"));
        rd.rd_a.S = cg.a((byte)125, bj.a(112, ji2, "lobby", "chatfilterbutton_mouseover"));
        rd.rd_a.Q = cg.a((byte)126, bj.a(112, ji2, "lobby", "chatfilterbutton_active"));
        rd.rd_a.w_eb = rd.rd_a.Q;
        ck[] ckArray5 = bj.a(112, ji2, "lobby", "checkbox");
        al.al_h = new ha(0L, ckArray5[1], ckArray5[0], 1, df.df_ab, null);
        cf.cf_h = new w(0L, null);
        cf.cf_h.w_lb = vj.a(id.a(ji2, "slideregion", "lobby", 8192), 32169);
        cf.cf_h.S = vj.a(id.a(ji2, "slideregion_mouseover", "lobby", 8192), 32169);
        cf.cf_h.w_eb = vj.a(id.a(ji2, "slideregion_mouseheld", "lobby", 8192), 32169);
        cf.cf_h.Ab = vj.a(id.a(ji2, "slideregion_disabled", "lobby", 8192), 32169);
        ng.ng_i = new w(0L, null);
        ng.ng_i.w_lb = cg.a((byte)122, bj.a(112, ji2, "lobby", "dragbar"));
        ng.ng_i.S = cg.a((byte)118, bj.a(112, ji2, "lobby", "dragbar_mouseover"));
        ng.ng_i.w_eb = cg.a((byte)118, bj.a(112, ji2, "lobby", "dragbar_mouseheld"));
        ng.ng_i.Ab = cg.a((byte)124, bj.a(112, ji2, "lobby", "dragbar_disabled"));
        pe.pe_e = new w(0L, null);
        pe.pe_e.I = id.a(ji2, "upbutton", "lobby", 8192);
        pe.pe_e.R = id.a(ji2, "upbutton_mouseover", "lobby", 8192);
        pe.pe_e.w_bb = id.a(ji2, "upbutton_mouseheld", "lobby", 8192);
        pe.pe_e.w_tb = id.a(ji2, "upbutton_disabled", "lobby", 8192);
        cn.X = new w(0L, null);
        cn.X.I = id.a(ji2, "downbutton", "lobby", 8192);
        cn.X.R = id.a(ji2, "downbutton_mouseover", "lobby", 8192);
        cn.X.w_bb = id.a(ji2, "downbutton_mouseheld", "lobby", 8192);
        cn.X.w_tb = id.a(ji2, "downbutton_disabled", "lobby", 8192);
        tm.tm_b = new jd(0L, pe.pe_e, cn.X, cf.cf_h, ng.ng_i);
        id.N = new s(0L, null, gf.gf_g, tm.tm_b, ma.J, null, null);
    }

    static final ck[] a(int n2, String string, ji ji2, String string2) {
        ck[] ckArray;
        ck[] ckArray2 = ckArray = bj.a(n2 ^ 0x46E0, ji2, string, string2);
        ckArray[1].K = ckArray[1].I;
        ckArray[3].C = ckArray[3].H;
        ckArray[7].K = ckArray[7].I;
        if (n2 != 18064) {
            return null;
        }
        ckArray[5].C = ckArray[5].H;
        return ckArray2;
    }

    static final void a(byte by) {
        block0: {
            if (by == -22) break block0;
            bb.a(-30);
        }
    }

    static {
        bb_f = 0;
    }
}
