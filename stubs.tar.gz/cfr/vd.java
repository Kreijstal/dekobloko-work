/*
 * Decompiled with CFR 0.152.
 */
final class vd
extends bh {
    static int vd_n = 480;
    static w vd_s;
    static String vd_o;
    static String vd_r;
    static String vd_q;
    int vd_p;

    static final int a(int n) {
        if (n != 480) {
            return 53;
        }
        return ri.ri_i + -ge.ge_e;
    }

    public static void c(byte by) {
        int n = 9 % ((by - 10) / 59);
        vd_q = null;
        vd_r = null;
        vd_s = null;
        vd_o = null;
    }

    vd(int n) {
        this.vd_p = n;
    }

    static {
        vd_o = "Unpacking graphics";
        vd_r = "Lost";
    }
}
