/*
 * Decompiled with CFR 0.152.
 */
final class pj
extends sf {
    int K;
    static String G;
    static String F;
    static String[] N;
    static String L;
    static ck I;
    wl J;
    byte M;

    @Override
    final int a(boolean bl) {
        if (bl) {
            return -110;
        }
        if (this.J == null) {
            return 0;
        }
        return 100 * this.J.wl_n / (-this.M + this.J.wl_r.length);
    }

    static long a(long l, long l2) {
        return l ^ l2;
    }

    public static void h(byte by) {
        block0: {
            N = null;
            G = null;
            L = null;
            I = null;
            F = null;
            if (by >= 78) break block0;
            pj.d(-100);
        }
    }

    @Override
    final byte[] g(byte by) {
        block1: {
            if (this.z || this.J.wl_r.length - this.M > this.J.wl_n) {
                throw new RuntimeException();
            }
            if (by > 65) break block1;
            pj.d(9);
        }
        return this.J.wl_r;
    }

    static final int d(int n) {
        int n2 = -62 % ((n - 81) / 40);
        return ac.A;
    }

    static final void a(ve ve2, byte by) {
        ve ve3;
        boolean bl = client.A;
        ve2.b((byte)108);
        if (by != -50) {
            return;
        }
        ve ve4 = ve3 = (ve)h.h_b.c((byte)-99);
        while (ve3 != null && ve3.a(ve2, false)) {
            ve4 = (ve)h.h_b.d(true);
        }
        if (ve4 == null) {
            h.h_b.a(ve2, 2777);
        } else {
            fm.a((byte)114, ve2, ve4);
        }
    }

    static final void a(int n, int n2, int n3) {
        block0: {
            ul.ul_d = n3;
            qk.qk_d = n2;
            if (n == 31004) break block0;
            pj.d(-44);
        }
    }

    pj() {
    }

    static {
        F = "This game option is only available to members.";
        G = "Add <%0> to ignore list";
        N = new String[16];
        L = "Enter name of player to add to list";
    }
}
