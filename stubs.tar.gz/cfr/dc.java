/*
 * Decompiled with CFR 0.152.
 */
final class dc {
    static tb dc_b;
    static boolean dc_d;
    static String dc_g;
    static String dc_c;
    static String dc_k;
    int dc_j;
    int dc_f;
    int dc_h;
    int dc_a;
    static ak dc_e;
    static String dc_i;

    static final boolean a(int n, int n2, int n3) {
        boolean bl;
        if (n3 != 6774) {
            dc_c = null;
        }
        boolean bl2 = bl = g.N != null;
        if (-10 == ~wh.wh_c && pc.a(uh.uh_d, n3 + -6772, ng.ng_a, he.Y, wf.wf_o)) {
            if (2 != uh.uh_d && bl) {
                return false;
            }
            return vm.a(wf.wf_o, ng.ng_a, he.Y, -12, uh.uh_d);
        }
        if (-11 == ~wh.wh_c) {
            if (bl) {
                return false;
            }
            aj.a(-1045);
            return true;
        }
        if (11 == wh.wh_c) {
            if (!ch.ch_c) {
                return false;
            }
            if (~qa.y == -3 && !sg.a(fa.fa_r, n3 ^ 0x1A0F, li.li_e)) {
                return false;
            }
            if (-3 != ~qa.y && bl) {
                return false;
            }
            if (vh.a((byte)70)) {
                ce.a(n2, (byte)-85, qa.y, fa.fa_r, cd.cd_a, null);
            }
            return true;
        }
        return false;
    }

    static final void a(boolean bl2, int n) {
        if (ph.n(-30146) && (tf.a((byte)38, j.j_d) || gh.gh_e != null || -1 > ~id.P)) {
            ba.ba_c = true;
            pd.pd_d = rc.a(true, id.P > 0, null != gh.gh_e, (byte)-61, bl2);
            return;
        }
        ba.ba_c = false;
        ob.ob_k = false;
        if (tf.a((byte)64, j.j_d)) {
            lk.F = true;
        }
        if (ge.ge_c) {
            ge.ge_c = false;
            fm.fm_e = true;
        }
        if (gn.gn_b) {
            mg.Zb = true;
            gn.gn_b = false;
        }
        if (n <= 75) {
            dc_i = null;
        }
        qi.a(bl2, (byte)-108);
    }

    static final boolean a(CharSequence charSequence, byte by) {
        boolean bl2 = client.A;
        if (!cb.a(true, charSequence, 4564)) {
            return false;
        }
        for (int i = 0; charSequence.length() > i; ++i) {
            if (oe.a(charSequence.charAt(i), -6237)) continue;
            return false;
        }
        if (by != -70) {
            dc_i = null;
        }
        return true;
    }

    static final void a(int n2) {
        block10: {
            boolean bl2 = client.A;
            if (!nm.Qb) {
                if (null == dm.dm_b) {
                    dm.dm_b = cc.a(4, (byte)-115);
                }
                if (dm.dm_b.f_u) {
                    int n3;
                    int n4;
                    int[] nArray = o.o_g;
                    int[] nArray2 = o.o_g;
                    int[] nArray3 = dm.dm_b.f_t;
                    for (n4 = 0; n4 < 8; ++n4) {
                        nArray[n4] = de.b(nArray[n4], nArray3[n4]);
                    }
                    int[] nArray4 = j.j_d;
                    nArray2 = j.j_d;
                    int[] nArray5 = dm.dm_b.f_t;
                    n4 = n3 = 0;
                    while (~n3 > -9) {
                        nArray4[n3] = lb.a(nArray4[n3], ~nArray5[n3]);
                        ++n3;
                    }
                    nm.Qb = true;
                    dm.dm_b = null;
                }
            }
            if (!qj.qj_k) {
                if (null == mf.N) {
                    mf.N = ub.a(1, 5, 0, 107);
                }
                if (mf.N.sb_s) {
                    int n5 = mf.N.sb_q[0];
                    mf.N = null;
                    qj.qj_k = true;
                    if (id.P < n5) {
                        id.P = n5;
                    }
                }
            }
            if (n2 > -59) {
                dc.a(true, 110);
            }
            if (!nm.Qb || !qj.qj_k) break block10;
            fh.b((byte)-125);
        }
    }

    public static void a(boolean bl2) {
        if (!bl2) {
            return;
        }
        dc_i = null;
        dc_c = null;
        dc_e = null;
        dc_b = null;
        dc_k = null;
        dc_g = null;
    }

    dc() {
    }

    static {
        dc_g = "Unfortunately there was a focus problem while setting fullscreen mode. You could try disabling any multiple monitor drivers or window enhancements, if you have any enabled.";
        dc_c = "Shortcut Reference";
        dc_d = false;
        dc_k = "You cannot chat to <%0> because <%0> is offline in your friend list.";
        dc_b = new tb();
        dc_i = "You have withdrawn your request to join.";
    }
}
