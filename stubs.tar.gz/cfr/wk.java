/*
 * Decompiled with CFR 0.152.
 */
class wk
extends fm {
    static String wk_k;
    static String wk_n;
    static String wk_j;
    static String wk_g;
    static ji wk_q;
    private String wk_h;
    static boolean wk_i;
    private long wk_m;
    static String wk_p;
    static ck wk_l;
    static String wk_o;

    static final void a(byte by, tj tj2) {
        tj tj3;
        boolean bl = client.A;
        tj2.b((byte)111);
        tj tj4 = tj3 = (tj)i.i_b.c((byte)-61);
        while (tj3 != null && tj3.a(-985, tj2)) {
            tj4 = (tj)i.i_b.d(true);
        }
        if (by <= 3) {
            wk.c(31);
        }
        if (null == tj4) {
            i.i_b.a(tj2, 2777);
        } else {
            fm.a((byte)114, tj2, tj4);
        }
    }

    static final int b(int n) {
        block0: {
            if (n == 3) break block0;
            wk_k = null;
        }
        return -ad.ad_a + fb.fb_f;
    }

    @Override
    gh a(int n) {
        block0: {
            if (n == 18) break block0;
            ff ff2 = null;
            wk.a(124, -86, ff2);
        }
        return ui.ui_t;
    }

    static final void a(int n, int n2, ff ff2) {
        if (n != 3) {
            wk_i = false;
        }
        cd.cd_c.a(ff2, 2777);
        mc.a(true, ff2, n2);
    }

    static final void a(int n, int n2, int n3) {
        block4: {
            block3: {
                block2: {
                    block1: {
                        block0: {
                            boolean bl2 = client.A;
                            int n4 = -84 / ((n - 5) / 54);
                            int n5 = n2;
                            if (0 == n5) break block0;
                            if (n5 == 1) break block1;
                            if (n5 == 2) break block2;
                            if (3 == n5) break block3;
                            break block4;
                        }
                        da.a(n3, true);
                        break block4;
                    }
                    h.a(n3, false);
                    break block4;
                }
                bl.b(n3, 12618);
                break block4;
            }
            uf.g(n3, -2093);
        }
    }

    @Override
    final void a(wl wl2, byte by) {
        wl2.a(this.wk_m, (byte)0);
        if (by < 34) {
            return;
        }
        wl2.a(this.wk_h, true);
    }

    public static void c(int n) {
        wk_o = null;
        wk_g = null;
        if (n != 7751) {
            ff ff2 = null;
            wk.a(12, -125, ff2);
        }
        wk_q = null;
        wk_p = null;
        wk_j = null;
        wk_k = null;
        wk_l = null;
        wk_n = null;
    }

    wk(long l, String string) {
        this.wk_m = l;
        this.wk_h = string;
    }

    static {
        wk_g = "<%0> has entered a game.";
        wk_n = "Send private message";
        wk_o = "Remove name";
        wk_k = "Offensive account name";
        wk_j = "Searching for an opponent";
        wk_p = "Message lobby";
    }
}
