/*
 * Decompiled with CFR 0.152.
 */
final class le
extends of {
    private kh le_w;
    static int y;
    private byte[] F;
    static String le_r;
    private ng G;
    private im le_v;
    static w[] D;
    private int le_q;
    private kh H;
    private ad I;
    private sf le_p;
    private byte[] z;
    static tb le_o;
    private dd le_l;
    private int le_n;
    private int x;
    static int le_t;
    private vj J;
    private boolean le_u;
    private vj le_k;
    private int le_j;
    static eh le_m;
    static int le_s;
    private boolean B;
    static ji E;
    private long A;
    private boolean C;

    @Override
    final ad a(boolean bl) {
        boolean bl2 = client.A;
        if (null != this.I) {
            return this.I;
        }
        if (this.le_p == null) {
            if (this.le_l.a(bl)) {
                return null;
            }
            this.le_p = this.le_l.a(true, (byte)0, true, 255, this.x);
        }
        if (this.le_p.z) {
            return null;
        }
        if (!bl) {
            return null;
        }
        byte[] byArray = this.le_p.g((byte)70);
        if (!(this.le_p instanceof el)) {
            if (byArray == null) {
                throw new RuntimeException();
            }
            this.I = new ad(byArray, this.le_q, this.z);
            if (this.H != null) {
                this.le_v.a(this.x, this.H, byArray, (byte)67);
            }
        } else {
            if (byArray == null) {
                throw new RuntimeException();
            }
            this.I = new ad(byArray, this.le_q, this.z);
            if (~this.le_n != ~this.I.ad_m) {
                throw new RuntimeException();
            }
        }
        if (null != this.le_w) {
            this.F = new byte[this.I.ad_n];
        }
        this.le_p = null;
        return this.I;
    }

    public static void b(boolean bl) {
        le_m = null;
        D = null;
        E = null;
        le_r = null;
        if (!bl) {
            return;
        }
        le_o = null;
    }

    final void b(int n) {
        block8: {
            boolean bl = client.A;
            if (this.J == null) {
                return;
            }
            if (null == this.a(true)) {
                return;
            }
            bh bh2 = this.le_k.c((byte)-113);
            while (null != bh2) {
                int n2 = (int)bh2.bh_i;
                if (n2 < 0 || this.I.ad_n <= n2 || -1 == ~this.I.B[n2]) {
                    bh2.b((byte)105);
                } else {
                    if (0 == this.F[n2]) {
                        this.a(1, n2, (byte)-20);
                    }
                    if (-1 == this.F[n2]) {
                        this.a(2, n2, (byte)-20);
                    }
                    if (this.F[n2] == 1) {
                        bh2.b((byte)117);
                    }
                }
                bh2 = this.le_k.d(true);
            }
            if (n == 16322) break block8;
            this.b(-71);
        }
    }

    @Override
    final int a(int n, int n2) {
        sf sf2;
        int n3 = 103 % ((n2 - 5) / 58);
        sf sf3 = sf2 = (sf)this.G.a(n, 77);
        if (null != sf2) {
            return sf2.a(false);
        }
        return 0;
    }

    final void b(byte by) {
        block2: {
            if (null == this.le_w) {
                return;
            }
            if (by != 0) {
                this.I = null;
            }
            this.B = true;
            if (this.J != null) break block2;
            this.J = new vj();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final sf a(int n, int n2, byte by) {
        sf sf2;
        boolean bl = client.A;
        sf sf3 = sf2 = (sf)this.G.a(n2, 95);
        if (null != sf2 && ~n == -1 && !sf2.D && sf2.z) {
            sf2.b((byte)114);
            sf3 = null;
        }
        if (null == sf3) {
            if (-1 != ~n) {
                if (1 != n) {
                    if (n != 2) throw new RuntimeException();
                    if (null == this.le_w) {
                        throw new RuntimeException();
                    }
                    if (0 != ~this.F[n2]) {
                        throw new RuntimeException();
                    }
                    if (this.le_l.b(0)) {
                        return null;
                    }
                    sf3 = this.le_l.a(false, (byte)2, true, this.x, n2);
                } else {
                    if (null == this.le_w) {
                        throw new RuntimeException();
                    }
                    sf3 = this.le_v.a(n2, this.le_w, (byte)61);
                }
            } else if (null == this.le_w || 0 == ~this.F[n2]) {
                if (this.le_l.a(true)) {
                    return null;
                }
                sf3 = this.le_l.a(true, (byte)2, true, this.x, n2);
            } else {
                sf3 = this.le_v.a(n2, this.le_w, -98);
            }
            this.G.a(n2, -1, sf3);
        }
        if (sf3.z) {
            return null;
        }
        byte[] byArray = sf3.g((byte)79);
        if (by != -20) {
            this.le_q = 57;
        }
        if (sf3 instanceof el) {
            try {
                int n3;
                if (null == byArray || -3 <= ~byArray.length) {
                    throw new RuntimeException();
                }
                ab.ab_c.reset();
                ab.ab_c.update(byArray, 0, -2 + byArray.length);
                int n4 = (int)ab.ab_c.getValue();
                if (~this.I.ad_c[n2] != ~n4) {
                    throw new RuntimeException();
                }
                if (this.I.ad_l != null && null != this.I.ad_l[n2]) {
                    byte[] byArray2 = this.I.ad_l[n2];
                    byte[] byArray3 = um.a(0, byArray, 0, byArray.length - 2);
                    for (int i = 0; 64 > i; ++i) {
                        if (~byArray3[i] == ~byArray2[i]) continue;
                        throw new RuntimeException();
                    }
                }
                if ((this.I.y[n2] & 0xFFFF) != (n3 = ((byArray[byArray.length + -2] & 0xFF) << 1262224936) - -(byArray[byArray.length + -1] & 0xFF))) {
                    throw new RuntimeException();
                }
                if (this.F[n2] != 1) {
                    if (0 == this.F[n2]) {
                        // empty if block
                    }
                    this.F[n2] = 1;
                }
                if (sf3.D) return sf3;
                sf3.b((byte)115);
                return sf3;
            }
            catch (Exception exception) {
                this.F[n2] = (byte)-1;
                sf3.b((byte)119);
                if (!sf3.D) {
                    return null;
                }
                if (this.le_l.a(true)) return null;
                sf3 = this.le_l.a(true, (byte)2, true, this.x, n2);
                this.G.a(n2, by ^ 0x13, sf3);
                return null;
            }
        }
        if (null == byArray || -3 <= ~byArray.length) {
            throw new RuntimeException();
        }
        ab.ab_c.reset();
        ab.ab_c.update(byArray, 0, -2 + byArray.length);
        int n5 = (int)ab.ab_c.getValue();
        if (~this.I.ad_c[n2] != ~n5) {
            throw new RuntimeException();
        }
        if (this.I.ad_l != null && null != this.I.ad_l[n2]) {
            int n6;
            byte[] byArray4 = this.I.ad_l[n2];
            byte[] byArray5 = um.a(0, byArray, 0, -2 + byArray.length);
            int n7 = n6 = 0;
            while (n6 < 64) {
                if (~byArray4[n6] != ~byArray5[n6]) {
                    throw new RuntimeException();
                }
                ++n6;
            }
        }
        this.le_l.dd_j = 0;
        this.le_l.dd_o = 0;
        byArray[-2 + byArray.length] = (byte)(this.I.y[n2] >>> 967493416);
        byArray[-1 + byArray.length] = (byte)this.I.y[n2];
        if (null != this.le_w) {
            this.le_v.a(n2, this.le_w, byArray, (byte)-68);
            if (~this.F[n2] != -2) {
                this.F[n2] = 1;
            }
        }
        if (sf3.D) return sf3;
        sf3.b((byte)117);
        return sf3;
    }

    static final int b(int n, int n2) {
        block0: {
            if (n == 32085) break block0;
            le.b(false);
        }
        return 500 * ((-1 + n2) * n2);
    }

    static final void a(byte by, int n) {
        dk.dk_i = n * 100 / 150;
        dk.dk_c = (n << -367606192) / 150;
        dk.dk_g = n * 400 / 150;
        int n2 = 101 % ((8 - by) / 52);
    }

    final void c(boolean bl) {
        block32: {
            sf sf2;
            boolean bl2 = client.A;
            if (!bl) {
                this.c(false);
            }
            if (null != this.J) {
                int n;
                bh bh2;
                boolean bl3;
                if (null == this.a(bl)) {
                    return;
                }
                if (this.le_u) {
                    bl3 = true;
                    bh2 = this.J.c((byte)54);
                    while (null != bh2) {
                        n = (int)bh2.bh_i;
                        if (-1 == ~this.F[n]) {
                            this.a(1, n, (byte)-20);
                        }
                        if (this.F[n] == 0) {
                            bl3 = false;
                        } else {
                            bh2.b((byte)121);
                        }
                        bh2 = this.J.d(true);
                    }
                    while (this.le_j < this.I.B.length) {
                        if (0 == this.I.B[this.le_j]) {
                            ++this.le_j;
                            continue;
                        }
                        if (this.le_v.im_b >= 250) {
                            bl3 = false;
                            break;
                        }
                        if (~this.F[this.le_j] == -1) {
                            this.a(1, this.le_j, (byte)-20);
                        }
                        if (0 == this.F[this.le_j]) {
                            bh2 = new bh();
                            bh2.bh_i = this.le_j;
                            this.J.a(bh2, 2777);
                            bl3 = false;
                        }
                        ++this.le_j;
                    }
                    if (bl3) {
                        this.le_j = 0;
                        this.le_u = false;
                    }
                } else if (!this.B) {
                    this.J = null;
                } else {
                    bl3 = true;
                    bh2 = this.J.c((byte)77);
                    while (null != bh2) {
                        n = (int)bh2.bh_i;
                        if (1 != this.F[n]) {
                            this.a(2, n, (byte)-20);
                        }
                        if (-2 == ~this.F[n]) {
                            bh2.b((byte)102);
                        } else {
                            bl3 = false;
                        }
                        bh2 = this.J.d(true);
                    }
                    while (~this.le_j > ~this.I.B.length) {
                        if (this.I.B[this.le_j] == 0) {
                            ++this.le_j;
                            continue;
                        }
                        if (this.le_l.b(0)) {
                            bl3 = false;
                            break;
                        }
                        if (this.F[this.le_j] != 1) {
                            this.a(2, this.le_j, (byte)-20);
                        }
                        if (1 != this.F[this.le_j]) {
                            bh2 = new bh();
                            bh2.bh_i = this.le_j;
                            this.J.a(bh2, 2777);
                            bl3 = false;
                        }
                        ++this.le_j;
                    }
                    if (bl3) {
                        this.le_j = 0;
                        this.B = false;
                    }
                }
            }
            if (!this.C || (ik.a(4) ^ 0xFFFFFFFFFFFFFFFFL) > (this.A ^ 0xFFFFFFFFFFFFFFFFL)) break block32;
            sf sf3 = sf2 = (sf)this.G.a((byte)126);
            while (null != sf2) {
                if (!sf2.z) {
                    if (!sf2.A) {
                        sf2.A = true;
                    } else {
                        if (!sf2.D) {
                            throw new RuntimeException();
                        }
                        sf2.b((byte)101);
                    }
                }
                sf3 = (sf)this.G.b((byte)107);
            }
            this.A = ik.a(4) + 1000L;
        }
    }

    @Override
    final byte[] a(int n, byte by) {
        sf sf2 = this.a(0, n, (byte)-20);
        if (null == sf2) {
            return null;
        }
        byte[] byArray = sf2.g((byte)126);
        sf2.b((byte)107);
        if (by != 91) {
            return null;
        }
        return byArray;
    }

    le(int n, kh kh2, kh kh3, dd dd2, im im2, int n2, byte[] byArray, int n3, boolean bl) {
        block2: {
            this.G = new ng(16);
            this.le_j = 0;
            this.le_k = new vj();
            this.A = 0L;
            this.le_w = kh2;
            this.x = n;
            if (null == this.le_w) {
                this.le_u = false;
            } else {
                this.le_u = true;
                this.J = new vj();
            }
            this.le_q = n2;
            this.le_l = dd2;
            this.C = bl;
            this.z = byArray;
            this.H = kh3;
            this.le_n = n3;
            this.le_v = im2;
            if (null == this.H) break block2;
            this.le_p = this.le_v.a(this.x, this.H, -36);
        }
    }

    static {
        le_r = "No highscores";
        le_o = new tb();
    }
}
