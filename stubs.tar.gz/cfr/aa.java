/*
 * Decompiled with CFR 0.152.
 */
final class aa {
    static vj aa_f;
    static String aa_a;
    static pi[] aa_c;
    static char aa_b;
    static String aa_d;
    static ck aa_e;

    public static void a(boolean bl) {
        aa_f = null;
        aa_a = null;
        if (!bl) {
            aa.a(73);
        }
        aa_c = null;
        aa_d = null;
        aa_e = null;
    }

    static final String a(int n) {
        if (pa.V == sh.sh_d) {
            return qb.qb_t;
        }
        if (n >= -25) {
            aa_c = null;
        }
        if (ka.P == pa.V) {
            return pn.pn_fb;
        }
        if (!jj.jj_f.a(92)) {
            return pn.pn_fb;
        }
        return hb.Ob;
    }

    static {
        aa_a = "Type your email address again to make sure it's correct";
        aa_f = new vj();
        aa_b = (char)47;
        aa_d = "You have 1 unread message!";
    }
}
