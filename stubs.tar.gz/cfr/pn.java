/*
 * Decompiled with CFR 0.152.
 */
final class pn
extends vb {
    static String pn_fb;
    private rk pn_gb = new og("", null, 2);
    static String[] pn_bb;
    static int pn_ab;
    private rk pn_hb = new og("", null, 2);
    private boolean pn_cb;
    static boolean pn_db;
    static int[] pn_eb;
    private rk pn_ib = new og("", null, 4);

    static final void a(int n, long l, String string) {
        ed.ed_c = string;
        pk.pk_r = 2;
        cf.cf_c = kf.a(string, (byte)2);
        int n2 = -54 / ((-27 - n) / 54);
        fm.fm_d = l;
        v.b(0);
    }

    @Override
    final void a(int n2, int n3, int n4, int n5) {
        if (n3 > -103) {
            return;
        }
        super.a(n2, -120, n4, n5);
        if (~n4 != -1) {
            return;
        }
        this.a(n2 += this.ce_u, n.n_d, n5 += this.D, this.pn_gb, 0);
        this.a(n2, ql.ql_a, n5, this.pn_hb, 0);
        this.a(n2, pf.pf_c, n5, this.pn_ib, 0);
    }

    static final void a(int n2, int n3, boolean bl, int n4, String string, int n5, int n6, int n7) {
        block7: {
            if (n5 < 126) {
                pn.a(false, true, false);
            }
            if (0 != sk.sk_c.w_ob && !wc.wc_n) {
                if (!wl.wl_p) {
                    jg.jg_i = true;
                } else {
                    aj.a(-1045);
                }
            }
            if (!jg.jg_i) break block7;
            jb.a(20, n4, 113, n3, n7, n6, n6, string, n2);
            tf.tf_gb.a(false, bl);
            if (bl) {
                if (~ve.ve_vc.w_ob != -1) {
                    jg.jg_i = false;
                }
                if (bf.bf_v.w_ob != 0) {
                    qk.a((byte)94);
                    jg.jg_i = false;
                }
            }
        }
    }

    private pn(gl gl2, boolean bl) {
        super(0, 0, 0, 0, null);
        this.pn_hb.ce_p = this.pn_ib.ce_p = gl2;
        this.pn_gb.ce_p = this.pn_ib.ce_p;
        this.pn_cb = bl;
        if (!this.pn_cb) {
            this.b(this.pn_gb, (byte)-55);
            this.b(this.pn_hb, (byte)-55);
        } else {
            this.b(this.pn_hb, (byte)-55);
            this.b(this.pn_gb, (byte)-55);
        }
        this.b(this.pn_ib, (byte)-55);
    }

    @Override
    final int b(boolean bl) {
        try {
            if (bl) {
                return 6;
            }
            return -1 + Integer.parseInt(this.pn_hb.E);
        }
        catch (NumberFormatException numberFormatException) {
            return -1;
        }
    }

    static final void a(int n2, wl wl2) {
        dj.Y = wl2.e(3) << -610206843;
        int n3 = wl2.d((byte)-39);
        tj.Pb = n3 << 1424118994 & 0x1C0000;
        dj.Y += n3 >> 1911408259;
        tj.Pb += wl2.e(3) << 697928706;
        n3 = wl2.d((byte)-59);
        oc.oc_c = (n3 & n2) << -2074046513;
        tj.Pb += n3 >> 1459247494;
        oc.oc_c += wl2.d((byte)-105) << 2087446055;
        n3 = wl2.d((byte)-81);
        vm.vm_s = (1 & n3) << -1105099568;
        oc.oc_c += n3 >> -344219967;
        vm.vm_s += wl2.e(n2 + -60);
    }

    pn(gl gl2, boolean bl, int n2, int n3, int n4, int n5) {
        this(gl2, bl);
        this.b(n5, n4, n2, n3, -16555);
    }

    @Override
    final String c(byte by) {
        String string = this.pn_hb.c(by);
        if (null != string) {
            return string;
        }
        if (!this.ce_q) {
            return null;
        }
        return null == this.B ? this.E : this.B;
    }

    @Override
    final int i(int n2) {
        if (n2 != -22079) {
            this.pn_ib = null;
        }
        try {
            return Integer.parseInt(this.pn_gb.E);
        }
        catch (NumberFormatException numberFormatException) {
            return -1;
        }
    }

    @Override
    final void a(byte by, qf qf2) {
        super.a((byte)88, qf2);
        if (by < 74) {
            wb wb2 = null;
            pn.a((wb)null, wb2, true);
        }
        this.pn_gb.ce_v = qf2;
        this.pn_hb.ce_v = qf2;
        this.pn_ib.ce_v = qf2;
    }

    static final boolean a(wb wb2, wb wb3, boolean bl) {
        boolean bl2 = client.A;
        if (bl) {
            wb wb4 = null;
            pn.a((wb)null, wb4, true);
        }
        int n2 = -wb2.Xb + wb3.Xb;
        if (f.f_w == wb3.Vb) {
            n2 -= 200;
        } else if (wb3.Vb == null) {
            n2 += 200;
        }
        if (f.f_w != wb2.Vb) {
            if (wb2.Vb == null) {
                n2 -= 200;
            }
        } else {
            n2 += 200;
        }
        return -1 > ~n2;
    }

    public static void l(int n2) {
        block0: {
            pn_bb = null;
            pn_eb = null;
            pn_fb = null;
            if (n2 == 33) break block0;
            pn_ab = 39;
        }
    }

    private final void a(int n2, String string, int n3, ce ce2, int n4) {
        if (n4 != 0) {
            this.pn_ib = null;
        }
        bj.bj_f.b(string, (ce2.ce_t >> 1492292289) + ce2.ce_u + n2, n3 + (ce2.D - 5), 0xFFFFFF, -1);
    }

    @Override
    final void b(int n2, int n3, int n4, int n5, int n6) {
        super.b(n2, n3, n4, n5, -16555);
        int n7 = n3 - 130 >> 401361505;
        if (this.pn_cb) {
            this.pn_hb.b(n2, 25, n7, 0, -16555);
            this.pn_gb.b(n2, 25, 45 + n7, 0, -16555);
        } else {
            this.pn_gb.b(n2, 25, n7, 0, -16555);
            this.pn_hb.b(n2, 25, 45 + n7, 0, n6 + 0);
        }
        this.pn_ib.b(n2, 40, n7 - -90, 0, n6);
    }

    @Override
    final int f(byte by) {
        if (by != 48) {
            pn_db = false;
        }
        try {
            return Integer.parseInt(this.pn_ib.E);
        }
        catch (NumberFormatException numberFormatException) {
            return -1;
        }
    }

    @Override
    final boolean k(int n2) {
        if (this.pn_gb.E == null || 0 == this.pn_gb.E.length()) {
            return true;
        }
        if (n2 <= 64) {
            return true;
        }
        if (null == this.pn_hb.E || 0 == this.pn_hb.E.length()) {
            return true;
        }
        return this.pn_ib.E == null || this.pn_ib.E.length() == 0;
    }

    static final we a(String string, int n2, int n3) {
        sc sc2 = new sc();
        sc2.we_d = string;
        if (n3 != 23155) {
            pn.l(-1);
        }
        sc2.we_f = n2;
        return sc2;
    }

    static final void a(boolean bl2, boolean bl3, boolean bl4) {
        boolean bl5 = client.A;
        cd.a(true);
        gh.gh_e = null;
        kf.I = new qc(false, 0, false, 0, 0, 3, 0, null, 0, false, bl3, bl2);
        if (!bl3) {
            kf.I.qc_p.a(new in(sk.sk_i, 10, false), 2777);
        } else {
            kf.I.qc_p.a(new in(ka.M, 10, false), 2777);
        }
        am.am_c = bl4;
        gk.Ib = false;
        int[] nArray = j.j_d;
        int[] nArray2 = j.j_d;
        int n2 = 0;
        while (~n2 > -9) {
            nArray[n2] = 0;
            ++n2;
        }
        nn.a(kf.I.b(bl4), sb.sb_u[0][0], true);
    }

    static {
        pn_ab = 0;
        pn_eb = new int[]{40, 33, 27, 22, 18, 15, 12, 10, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    }
}
