/*
 * Decompiled with CFR 0.152.
 */
final class qn
extends t {
    private boolean qn_qb;
    private r qn_ob;
    private String qn_kb;
    private String qn_mb;
    static int qn_lb;
    static String qn_pb;
    private boolean qn_nb;
    static String qn_rb;

    static final vj a(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        vj vj2 = new vj();
        uk uk2 = new uk();
        uk2.uk_n = 10000;
        uk2.A = n6;
        uk2.uk_q = new pi[n * n6];
        uk2.uk_r = n3;
        uk2.uk_w = n5;
        uk2.uk_u = n2;
        uk2.uk_t = n;
        uk2.uk_v = n7;
        vj2.a(uk2, 2777);
        int n9 = -11 / ((n8 - 10) / 35);
        uk2.b(11976, n4);
        return vj2;
    }

    qn(ka ka2, String string) {
        super(ka2, 300, 120);
        this.qn_kb = string;
        if (this.qn_kb != null) {
            int n = ec.ec_p.b(this.qn_kb, 260, ec.ec_p.R);
            this.a(112, 300, n + 150);
        }
        this.qn_ob = new r(13, 50, 274, 30, 15, 2113632, 0x404040);
        this.qn_nb = false;
        this.qn_ob.L = true;
        this.qn_qb = false;
        this.b(this.qn_ob, (byte)-55);
    }

    public static void n(byte by) {
        qn_pb = null;
        if (by <= 60) {
            ck ck2 = null;
            qn.a(null, ck2, (byte)-20);
        }
        qn_rb = null;
    }

    static final void c(int n, int n2) {
        ug ug2;
        boolean bl2 = client.A;
        if (n != -20494) {
            qn_pb = null;
        }
        ug ug3 = ug2 = (ug)qi.Q.c((byte)125);
        while (ug2 != null) {
            in.a(ug2, (byte)-70, n2);
            ug3 = (ug)qi.Q.d(true);
        }
    }

    final void m(byte by) {
        block0: {
            this.qn_ob.L = false;
            this.qn_nb = true;
            if (by >= 75) break block0;
            this.m((byte)-99);
        }
    }

    static final void a(ck ck2, ck ck3, byte by) {
        boolean bl2 = client.A;
        float f = 1.0f;
        int n = ck3.I;
        int n2 = ck3.H;
        int[] nArray = ck3.D;
        int[] nArray2 = ck2.D;
        int n3 = 0;
        if (by > -73) {
            ck ck4 = null;
            qn.a(null, ck4, (byte)15);
        }
        int n4 = 0;
        while (~n2 < ~n4) {
            int n5 = 0;
            while (~n < ~n5) {
                int n6;
                int n7 = 0xFF & nArray[n3];
                int n8 = n5 + n4 - -(n7 / 5) - -uf.A & 0x7F;
                float f2 = (float)n7 / 255.0f;
                float f3 = (float)n8 / 128.0f;
                nArray2[n3] = n6 = nm.a(f3, f2, false, f);
                ++n3;
                ++n5;
            }
            ++n4;
        }
    }

    static final void a(int n, fd fd2, int n2, wl wl2) {
        boolean bl2 = client.A;
        kl kl2 = new kl();
        kl2.kl_o = wl2.d((byte)-116);
        kl2.C = wl2.i(7553);
        kl2.kl_q = new int[kl2.kl_o];
        kl2.A = new int[kl2.kl_o];
        kl2.kl_s = new byte[kl2.kl_o][][];
        kl2.y = new mh[kl2.kl_o];
        kl2.kl_u = new int[kl2.kl_o];
        kl2.kl_t = new mh[kl2.kl_o];
        for (int i = 0; i < kl2.kl_o; ++i) {
            try {
                int n3;
                String string;
                String string2;
                int n4 = wl2.d((byte)-21);
                if (0 != n4 && ~n4 != -2 && -3 != ~n4) {
                    int n5;
                    int n6;
                    if (~n4 != -4 && 4 != n4) continue;
                    string2 = wl2.c((byte)-38);
                    string = wl2.c((byte)-38);
                    n3 = wl2.d((byte)-72);
                    String[] stringArray = new String[n3];
                    int n7 = 0;
                    while (~n7 > ~n3) {
                        stringArray[n7] = wl2.c((byte)-38);
                        ++n7;
                    }
                    byte[][] byArrayArray = new byte[n3][];
                    if (-4 == ~n4) {
                        int n8 = 0;
                        while (~n3 < ~n8) {
                            n6 = wl2.i(7553);
                            byArrayArray[n8] = new byte[n6];
                            wl2.a(byArrayArray[n8], 0, (byte)127, n6);
                            ++n8;
                        }
                    }
                    kl2.kl_u[i] = n4;
                    Class[] classArray = new Class[n3];
                    n6 = n5 = 0;
                    while (n3 > n5) {
                        classArray[n5] = cg.a(stringArray[n5], (byte)-122);
                        ++n5;
                    }
                    kl2.kl_t[i] = fd2.a(-10962, string, cg.a(string2, (byte)-108), classArray);
                    kl2.kl_s[i] = byArrayArray;
                    continue;
                }
                string2 = wl2.c((byte)-38);
                string = wl2.c((byte)-38);
                n3 = 0;
                if (1 == n4) {
                    n3 = wl2.i(7553);
                }
                kl2.kl_u[i] = n4;
                kl2.kl_q[i] = n3;
                kl2.y[i] = fd2.a(false, string, cg.a(string2, (byte)9));
                continue;
            }
            catch (ClassNotFoundException classNotFoundException) {
                kl2.A[i] = -1;
                continue;
            }
            catch (SecurityException securityException) {
                kl2.A[i] = -2;
                continue;
            }
            catch (NullPointerException nullPointerException) {
                kl2.A[i] = -3;
                continue;
            }
            catch (Exception exception) {
                kl2.A[i] = -4;
                continue;
            }
            catch (Throwable throwable) {
                kl2.A[i] = -5;
            }
        }
        if (n2 != 0x404040) {
            qn_pb = null;
        }
        aa.aa_f.a(kl2, 2777);
    }

    final void a(boolean bl2, float f, int n, String string) {
        if (!bl2 == this.qn_qb) {
            this.qn_qb = bl2;
            if (!this.qn_qb) {
                this.qn_ob.a(0x404040, 4088, 2113632);
                if (this.qn_nb) {
                    this.qn_ob.L = false;
                }
            } else {
                this.qn_ob.a(0x404040, 4088, 8405024);
                this.qn_ob.L = true;
            }
        }
        if (n != 0x404040) {
            qn.l(68);
        }
        this.qn_ob.Q = (int)(f / 100.0f * 65536.0f);
        this.qn_mb = string;
    }

    @Override
    final void b(int n, int n2, int n3) {
        block1: {
            super.b(-128, n2, n3);
            ec.ec_p.b(this.qn_mb, (this.ce_t >> -544182591) + n3, 103 + n2, 0xFFFFFF, -1);
            if (n >= -127) {
                return;
            }
            if (null == this.qn_kb) break block1;
            hk.a(n3 - -20, n2 - -113, 260, 0x808080);
            ec.ec_p.a(this.qn_kb, n3 - -20, 128 + n2, 260, 100, 0xFFFFFF, -1, 1, 0, ec.ec_p.R);
        }
    }

    static final void l(int n) {
        block1: {
            if (jh.jh_h) {
                pf.a(false);
            }
            if (n == 13) break block1;
            qn_rb = null;
        }
    }

    static {
        qn_pb = "This game has started.";
        qn_rb = "Log in / Create account";
    }
}
