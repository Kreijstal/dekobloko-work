/*
 * Decompiled with CFR 0.152.
 */
class di
extends a {
    static String A;
    static String D;
    private static int[] B;
    static String E;
    static String C;
    static String G;
    static long F;

    public static void c(int n) {
        A = null;
        G = null;
        D = null;
        E = null;
        if (n <= 44) {
            C = null;
        }
        B = null;
        C = null;
    }

    @Override
    public final void a(boolean bl, int n, int n2, byte by, ce ce2) {
        if (bl) {
            ke.a(ce2.ce_u + n, n2 + ce2.D, ce2.ce_t, ce2.y, (byte)112);
        }
        if (by > -60) {
            return;
        }
        super.a(bl, n, n2, (byte)-120, ce2);
    }

    static final boolean a(boolean bl) {
        if (bl) {
            di.a(false);
        }
        return null != qc.qc_s && ph.xb.b(22277);
    }

    di(mm mm2, int n) {
        super(mm2, 4, 2, 2, 2, n, -1, 0, 1, mm2.R, -1, Integer.MAX_VALUE, false);
    }

    di(int n) {
        this(hh.hh_e, n);
    }

    static {
        D = "Solid shapes are sent to the next player!";
        A = "Invalid Login or Password<br><br>For accounts created after the 24th of November 2010, please use your email address to log in.<br><br>Otherwise please log in with your username.";
        C = "Accept invitation to <%0>'s game";
        E = "Set up new unrated game";
        B = new int[98304];
        for (int i = 92682; i >= 46341; --i) {
            int n;
            long l = -1 + (i << -1906740639);
            long l2 = 1 + (i << -1894538015);
            int n2 = (int)(-32768L + (l2 * l2 >> -1783657518));
            int n3 = (int)((l * l >> 217359698) - 32768L);
            if (~B.length >= ~n2) {
                n2 = B.length - 1;
            }
            int n4 = n = ~n3 > -1 ? 0 : n3;
            while (~n2 <= ~n) {
                di.B[n] = i;
                ++n;
            }
        }
        G = "Names should contain a maximum of 12 characters";
    }
}
