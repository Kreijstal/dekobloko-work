/*
 * Decompiled with CFR 0.152.
 */
import java.util.zip.Inflater;

final class lf {
    static ck[] lf_h;
    private Inflater lf_a;
    static String lf_d;
    static int lf_c;
    static boolean lf_g;
    static ck lf_i;
    static fd lf_f;
    static fd lf_e;
    static String lf_b;

    final void a(byte by, wl wl2, byte[] byArray) {
        if (~wl2.wl_r[wl2.wl_n] != -32 || -117 != wl2.wl_r[1 + wl2.wl_n]) {
            throw new RuntimeException("");
        }
        if (this.lf_a == null) {
            this.lf_a = new Inflater(true);
        }
        if (by < 105) {
            lf.a(-120);
        }
        try {
            this.lf_a.setInput(wl2.wl_r, 10 + wl2.wl_n, -10 + -wl2.wl_n + -8 + wl2.wl_r.length);
            this.lf_a.inflate(byArray);
        }
        catch (Exception exception) {
            this.lf_a.reset();
            throw new RuntimeException("");
        }
        this.lf_a.reset();
    }

    private lf(int n, int n2, int n3) {
    }

    public static void a(int n) {
        lf_h = null;
        lf_e = null;
        if (n != -13495) {
            return;
        }
        lf_f = null;
        lf_i = null;
        lf_b = null;
        lf_d = null;
    }

    public lf() {
        this(-1, 1000000, 1000000);
    }

    static {
        lf_d = "Create a free account to start using this feature";
        lf_b = "This password contains repeated characters, and would be easy to guess";
    }
}
