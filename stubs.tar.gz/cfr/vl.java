/*
 * Decompiled with CFR 0.152.
 */
final class vl {
    int[] vl_v = new int[6];
    int vl_m;
    int[][] vl_c;
    byte I;
    int C;
    static int[] G;
    int vl_l;
    byte[] vl_w;
    int vl_r = 0;
    int vl_b;
    int vl_e;
    int vl_o;
    byte[] vl_d;
    int vl_p;
    int F;
    int E = 0;
    int vl_f;
    int z;
    byte[] vl_a;
    byte[][] x = new byte[6][258];
    int[][] D;
    byte[] vl_j;
    byte[] vl_g = new byte[18002];
    int vl_n;
    byte[] vl_h;
    static int vl_k;
    int[] vl_s;
    int vl_i;
    int[] vl_t;
    static byte[] A;
    boolean[] y;
    int[] B;
    int H;
    int[][] vl_u;
    boolean[] vl_q;

    static final int a(int n, int n2, int n3) {
        int n4;
        block0: {
            n4 = n3 >>> 1762660287;
            if (n == 23841) break block0;
            vl_k = -119;
        }
        return (n3 + n4) / n2 + -n4;
    }

    public static void a(boolean bl) {
        block0: {
            A = null;
            G = null;
            if (bl) break block0;
            G = null;
        }
    }

    vl() {
        this.vl_c = new int[6][258];
        this.vl_h = new byte[4096];
        this.vl_s = new int[257];
        this.vl_d = new byte[256];
        this.vl_t = new int[16];
        this.B = new int[256];
        this.y = new boolean[16];
        this.D = new int[6][258];
        this.vl_u = new int[6][258];
        this.vl_q = new boolean[256];
        this.vl_a = new byte[18002];
    }

    static {
        A = new byte[]{(byte)2, (byte)5, (byte)5, (byte)5, (byte)3};
    }
}
