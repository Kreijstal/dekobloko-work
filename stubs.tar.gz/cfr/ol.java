/*
 * Decompiled with CFR 0.152.
 */
abstract class ol
extends bh {
    ti ol_q;
    ol ol_o;
    int ol_n;
    volatile boolean ol_p = true;

    int b() {
        return 255;
    }

    final void a(int[] nArray, int n, int n2) {
        if (this.ol_p) {
            this.b(nArray, n, n2);
        } else {
            this.a(n2);
        }
    }

    abstract ol d();

    abstract int a();

    abstract void b(int[] var1, int var2, int var3);

    abstract ol c();

    ol() {
    }

    abstract void a(int var1);
}
