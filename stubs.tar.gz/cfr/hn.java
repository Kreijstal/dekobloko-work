/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.lang.reflect.Method;
import java.net.URL;

public abstract class hn
extends Applet
implements Runnable,
FocusListener,
WindowListener {
    boolean hn_f = false;
    static ij hn_c = new ij("");
    static nk hn_h;
    static int hn_a;
    static lm hn_g;
    public static boolean hn_j;
    public static boolean hn_b;
    public static int hn_k;
    public static boolean hn_e;
    public static int hn_i;
    public static int hn_l;
    public static boolean hn_d;

    @Override
    public final void windowOpened(WindowEvent windowEvent) {
    }

    @Override
    public final void focusGained(FocusEvent focusEvent) {
        ge.ge_i = true;
        cd.cd_g = true;
    }

    @Override
    public final void windowActivated(WindowEvent windowEvent) {
    }

    abstract void c(int var1);

    static final pi a(String string, ji ji2, String string2, byte by) {
        if (by <= 26) {
            hn_c = null;
        }
        int n = ji2.b(-1, string2);
        int n2 = ji2.a(n, 13030, string);
        return ma.a(ji2, n, n2, 21828);
    }

    @Override
    public final String getParameter(String string) {
        if (null != hg.hg_c) {
            return null;
        }
        if (null != kb.kb_h && this != kb.kb_h) {
            return kb.kb_h.getParameter(string);
        }
        return super.getParameter(string);
    }

    @Override
    public final AppletContext getAppletContext() {
        if (hg.hg_c != null) {
            return null;
        }
        if (kb.kb_h != null && kb.kb_h != this) {
            return kb.kb_h.getAppletContext();
        }
        return super.getAppletContext();
    }

    final void a(String string, int n, int n2, boolean bl, int n3, int n4, int n5) {
        boolean bl2 = client.A;
        try {
            if (ta.ta_i != null) {
                if (++be.be_q >= 3) {
                    this.a(true, "alreadyloaded");
                    return;
                }
                this.getAppletContext().showDocument(this.getDocumentBase(), "_self");
                return;
            }
            pn.pn_ab = 0;
            oe.H = de.M = n4;
            qd.Rb = 0;
            lf.lf_c = ob.ob_g = n3;
            ta.ta_i = this;
            wb.Rb = n5;
            th.th_b = se.h(25144);
            o.o_f = lf.lf_e = new fd(n, string, n2, bl);
            mh mh2 = lf.lf_e.a((byte)-126, 1, this);
            while (0 == mh2.mh_c) {
                ua.a(10L, -128);
            }
        }
        catch (Throwable throwable) {
            qb.a(throwable, 16408, null);
            this.a(true, "crash");
        }
    }

    final boolean a(byte by) {
        return true;
    }

    public static final void provideLoaderApplet(Applet applet) {
        kb.kb_h = applet;
    }

    @Override
    public final void windowClosed(WindowEvent windowEvent) {
    }

    @Override
    public final void destroy() {
        if (ta.ta_i == this) {
            if (eg.eg_d) {
                return;
            }
            l.l_h = ik.a(4);
            ua.a(5000L, -128);
            o.o_f = null;
            this.a(false, -124);
            return;
        }
    }

    private final void a(boolean bl) {
        long l2 = ik.a(4);
        long l3 = sf.y[ec.ec_h];
        sf.y[ec.ec_h] = l2;
        if ((l3 ^ 0xFFFFFFFFFFFFFFFFL) != -1L && l3 < l2) {
            int n = (int)(-l3 + l2);
            jf.jf_c = (32000 - -(n >> -555538303)) / n;
        }
        if (bl) {
            return;
        }
        ec.ec_h = ec.ec_h - -1 & 0x1F;
        if (-51 > ~jb.jb_d++) {
            cd.cd_g = true;
            jb.jb_d -= 50;
            jh.jh_b.setSize(de.M, ob.ob_g);
            jh.jh_b.setVisible(true);
            if (null == hg.hg_c || oj.oj_c != null) {
                jh.jh_b.setLocation(qd.Rb, pn.pn_ab);
            } else {
                Insets insets = hg.hg_c.getInsets();
                jh.jh_b.setLocation(qd.Rb + insets.left, pn.pn_ab + insets.top);
            }
        }
        this.d(320);
    }

    final synchronized void b(byte by) {
        boolean bl = client.A;
        if (null != jh.jh_b) {
            jh.jh_b.removeFocusListener(this);
            jh.jh_b.getParent().setBackground(Color.black);
            jh.jh_b.getParent().remove(jh.jh_b);
        }
        int n = 123 / ((by - 18) / 39);
        Container container = null != oj.oj_c ? oj.oj_c : (hg.hg_c == null ? (kb.kb_h != null ? kb.kb_h : ta.ta_i) : hg.hg_c);
        container.setLayout(null);
        jh.jh_b = new dk(this);
        container.add(jh.jh_b);
        jh.jh_b.setSize(de.M, ob.ob_g);
        jh.jh_b.setVisible(true);
        if (hg.hg_c == container) {
            Insets insets = hg.hg_c.getInsets();
            jh.jh_b.setLocation(insets.left - -qd.Rb, pn.pn_ab + insets.top);
        } else {
            jh.jh_b.setLocation(qd.Rb, pn.pn_ab);
        }
        jh.jh_b.addFocusListener(this);
        jh.jh_b.requestFocus();
        ge.ge_i = true;
        qc.N = true;
        cd.cd_g = true;
        jg.jg_e = false;
        gn.gn_f = ik.a(4);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void a(boolean bl, int n) {
        hn hn2 = this;
        synchronized (hn2) {
            if (eg.eg_d) {
                return;
            }
            eg.eg_d = true;
        }
        if (null != kb.kb_h) {
            kb.kb_h.destroy();
        }
        try {
            this.e(0);
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (jh.jh_b != null) {
            try {
                jh.jh_b.removeFocusListener(this);
                jh.jh_b.getParent().remove(jh.jh_b);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if (null != lf.lf_e) {
            try {
                lf.lf_e.a(0);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        this.a(124);
        if (null != hg.hg_c) {
            try {
                System.exit(0);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        System.out.println("Shutdown complete - clean:" + bl);
        int n2 = -105 / ((n - 7) / 62);
    }

    @Override
    public final void windowDeactivated(WindowEvent windowEvent) {
    }

    abstract void a(int var1);

    @Override
    public final void start() {
        if (this == ta.ta_i) {
            if (eg.eg_d) {
                return;
            }
            l.l_h = 0L;
            return;
        }
    }

    @Override
    public final void windowIconified(WindowEvent windowEvent) {
    }

    final void a(boolean bl, String string) {
        if (this.hn_f) {
            return;
        }
        this.hn_f = true;
        System.out.println("error_game_" + string);
        try {
            nc.a(bl, "loggedout", se.h(25144));
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            this.getAppletContext().showDocument(new URL(this.getCodeBase(), "error_game_" + string + ".ws"), "_top");
        }
        catch (Exception exception) {}
    }

    @Override
    public final void windowClosing(WindowEvent windowEvent) {
        this.destroy();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void f(int n) {
        long l2 = ik.a(4);
        long l3 = jd.Ub[le.le_s];
        jd.Ub[le.le_s] = l2;
        le.le_s = 0x1F & 1 + le.le_s;
        if (-1L == (l3 ^ 0xFFFFFFFFFFFFFFFFL) || (l3 ^ 0xFFFFFFFFFFFFFFFFL) > (l2 ^ 0xFFFFFFFFFFFFFFFFL)) {
            // empty if block
        }
        int n2 = -68 / ((-31 - n) / 40);
        hn hn2 = this;
        synchronized (hn2) {
            qc.N = ge.ge_i;
        }
        this.c(11978);
    }

    @Override
    public final void run() {
        block16: {
            boolean bl = client.A;
            try {
                Method method;
                int n;
                Object object;
                Object object2;
                if (null != fd.fd_k && (-1 != ((String)(object2 = fd.fd_k.toLowerCase())).indexOf("sun") || ((String)object2).indexOf("apple") != -1)) {
                    object = fd.fd_c;
                    if (((String)object).equals("1.1") || ((String)object).startsWith("1.1.") || ((String)object).equals("1.2") || ((String)object).startsWith("1.2.") || ((String)object).equals("1.3") || ((String)object).startsWith("1.3.") || ((String)object).equals("1.4") || ((String)object).startsWith("1.4.") || ((String)object).equals("1.5") || ((String)object).startsWith("1.5.") || ((String)object).equals("1.6.0")) {
                        this.a(true, "wrongjava");
                        break block16;
                    }
                    if (((String)object).startsWith("1.6.0_")) {
                        for (n = 6; ((String)object).length() > n && fl.a(((String)object).charAt(n), (byte)23); ++n) {
                        }
                        String string = ((String)object).substring(6, n);
                        if (be.a((byte)98, string) && -11 < ~cb.a((byte)51, string)) {
                            this.a(true, "wrongjava");
                            break block16;
                        }
                    }
                }
                if (null != fd.fd_c && fd.fd_c.startsWith("1.")) {
                    int n2 = 2;
                    int n3 = 0;
                    while (~n2 > ~fd.fd_c.length() && (n = fd.fd_c.charAt(n2)) >= 48 && n <= 57) {
                        ++n2;
                        n3 = n3 * 10 - (-n + 48);
                    }
                    if (-6 >= ~n3) {
                        oh.oh_b = true;
                    }
                }
                object2 = ta.ta_i;
                if (null != kb.kb_h) {
                    object2 = kb.kb_h;
                }
                if ((object = (method = fd.fd_f)) != null) {
                    try {
                        method.invoke(object2, Boolean.TRUE);
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
                si.b(1);
                this.b((byte)125);
                le.le_m = el.a(ob.ob_g, (byte)120, de.M, jh.jh_b);
                this.b(false);
                cm.cm_f = eg.a((byte)63);
                while ((l.l_h ^ 0xFFFFFFFFFFFFFFFFL) == -1L || (ik.a(4) ^ 0xFFFFFFFFFFFFFFFFL) > (l.l_h ^ 0xFFFFFFFFFFFFFFFFL)) {
                    vm.vm_r = cm.cm_f.a(ul.ul_g, 4);
                    int n4 = 0;
                    while (~n4 > ~vm.vm_r) {
                        this.f(121);
                        ++n4;
                    }
                    this.a(false);
                    db.a(-61, jh.jh_b, lf.lf_e);
                }
            }
            catch (Throwable throwable) {
                qb.a(throwable, 16408, null);
                this.a(true, "crash");
            }
        }
        this.a(true, -128);
    }

    @Override
    public abstract void init();

    @Override
    public final void focusLost(FocusEvent focusEvent) {
        ge.ge_i = false;
    }

    public static void b(int n) {
        hn_h = null;
        hn_c = null;
        if (n != 6) {
            return;
        }
        hn_g = null;
    }

    @Override
    public final URL getCodeBase() {
        if (null != hg.hg_c) {
            return null;
        }
        if (null != kb.kb_h && kb.kb_h != this) {
            return kb.kb_h.getCodeBase();
        }
        return super.getCodeBase();
    }

    @Override
    public final synchronized void paint(Graphics graphics) {
        if (ta.ta_i == this) {
            Rectangle rectangle;
            if (eg.eg_d) {
                return;
            }
            cd.cd_g = true;
            if (oh.oh_b && -gn.gn_f + ik.a(4) > 1000L && (null == (rectangle = graphics.getClipBounds()) || ~oe.H >= ~rectangle.width && rectangle.height >= lf.lf_c)) {
                jg.jg_e = true;
            }
            return;
        }
    }

    abstract void e(int var1);

    @Override
    public final void stop() {
        if (ta.ta_i == this) {
            if (eg.eg_d) {
                return;
            }
            l.l_h = ik.a(4) - -4000L;
            return;
        }
    }

    @Override
    public final URL getDocumentBase() {
        if (hg.hg_c != null) {
            return null;
        }
        if (null != kb.kb_h && kb.kb_h != this) {
            return kb.kb_h.getDocumentBase();
        }
        return super.getDocumentBase();
    }

    abstract void d(int var1);

    protected hn() {
    }

    @Override
    public final void update(Graphics graphics) {
        this.paint(graphics);
    }

    @Override
    public final void windowDeiconified(WindowEvent windowEvent) {
    }

    abstract void b(boolean var1);
}
