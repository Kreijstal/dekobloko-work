/*
 * Decompiled with CFR 0.152.
 */
final class b
extends ek {
    private int O;
    private mb N;
    static int[] M = new int[8192];
    static String Q = "Master Challenge";
    int K;
    int L;
    static int[] P;

    public static void a(int n) {
        block0: {
            Q = null;
            P = null;
            M = null;
            if (n <= -53) break block0;
            String string = null;
            b.a(-83, string);
        }
    }

    final int b(int n, int n2) {
        block1: {
            if (n2 < 0 || ~this.N.a(126) >= ~n2) {
                return -1;
            }
            if (n == -1) break block1;
            P = null;
        }
        return this.N.b(n2, 0);
    }

    static final int[] h(int n) {
        int n2 = 110 / ((-90 - n) / 32);
        return new int[8];
    }

    static final String a(int n, String string) {
        int n2 = ul.a(d.d_b, te.te_p, -28705);
        if (~n2 == -2) {
            string = "<img=0>" + string;
        }
        if (n2 == 2) {
            string = "<img=1>" + string;
        }
        if (n < 78) {
            return null;
        }
        return string;
    }

    @Override
    final boolean a(int n, int n2, ce ce2, int n3, int n4, int n5, byte by) {
        boolean bl = client.A;
        if (super.a(n, n2, ce2, n3, n4, n5, by)) {
            int n6 = this.ce_t + -(this.L * 2);
            int n7 = -n5 + n2 + -this.L;
            if (n6 < n7) {
                n7 = n6;
            }
            if (n7 < 0) {
                n7 = 0;
            }
            n7 = n7 * this.O / n6;
            if (-2 == ~n3) {
                this.N.a(n7, false);
                return true;
            }
            if (2 == n3) {
                int n8 = Integer.MAX_VALUE;
                int n9 = -1;
                int n10 = 0;
                while (~n10 > ~this.N.a(114)) {
                    int n11 = this.N.b(n10, 0) + -n7;
                    if ((n11 *= n11) < n8) {
                        n8 = n11;
                        n9 = n10;
                    }
                    ++n10;
                }
                if (-1 >= ~n9) {
                    this.N.c(-91, n9);
                }
            }
            return true;
        }
        return false;
    }

    final int i(int n) {
        block0: {
            if (n == -15317) break block0;
            String string = null;
            b.a(-69, string);
        }
        return this.O;
    }

    final int b(boolean bl) {
        if (!bl) {
            return -57;
        }
        return this.N.a(-77);
    }

    private b() throws Throwable {
        throw new Error();
    }
}
