/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.PixelGrabber;

class ck
extends gg {
    int[] D;

    private final void e(int n, int n2, int n3, int n4, int n5) {
        block19: {
            block18: {
                int n6;
                int n7;
                int n8;
                int n9;
                int n10;
                int n11;
                int n12;
                int n13;
                int n14;
                int n15;
                block17: {
                    int n16 = n3 * this.I + n2;
                    n4 &= 0xFFF;
                    n5 &= 0xFFF;
                    if (n3 >= 0) {
                        if (n2 >= 0) {
                            n15 = this.D[n16];
                            n14 = n15 != 0 ? (4096 - n4) * (4096 - n5) : 0;
                        } else {
                            n14 = 0;
                            n15 = 0;
                        }
                        if (n2 < this.I - 1) {
                            n13 = this.D[n16 + 1];
                            n12 = n13 != 0 ? n4 * (4096 - n5) : 0;
                        } else {
                            n12 = 0;
                            n13 = 0;
                        }
                    } else {
                        n12 = 0;
                        n14 = 0;
                        n13 = 0;
                        n15 = 0;
                    }
                    if (n3 < this.H - 1) {
                        if (n2 >= 0) {
                            n11 = this.D[n16 + this.I];
                            n10 = n11 != 0 ? (4096 - n4) * n5 : 0;
                        } else {
                            n10 = 0;
                            n11 = 0;
                        }
                        if (n2 < this.I - 1) {
                            n9 = this.D[n16 + this.I + 1];
                            n8 = n9 != 0 ? n4 * n5 : 0;
                        } else {
                            n8 = 0;
                            n9 = 0;
                        }
                    } else {
                        n8 = 0;
                        n10 = 0;
                        n9 = 0;
                        n11 = 0;
                    }
                    n7 = (n14 >>= 16) + (n12 >>= 16) + (n10 >>= 16) + (n8 >>= 16);
                    if (n7 < 256) break block17;
                    int n17 = (n15 & 0xFF00FF) * n14 + (n13 & 0xFF00FF) * n12;
                    int n18 = (n15 & 0xFF00) * n14 + (n13 & 0xFF00) * n12;
                    int n19 = ((n17 += (n11 & 0xFF00FF) * n10 + (n9 & 0xFF00FF) * n8) >>> 8 & 0xFF00FF) + ((n18 += (n11 & 0xFF00) * n10 + (n9 & 0xFF00) * n8) >>> 8 & 0xFF00);
                    if (n19 == 0) {
                        n19 = 1;
                    }
                    hk.hk_l[n] = n19;
                    break block18;
                }
                if (n7 < 128) break block19;
                int n20 = (n15 & 0xFF00FF) * n14 + (n13 & 0xFF00FF) * n12;
                int n21 = (n15 & 0xFF00) * n14 + (n13 & 0xFF00) * n12;
                if ((n6 = (((n20 += (n11 & 0xFF00FF) * n10 + (n9 & 0xFF00FF) * n8) >>> 16) / n7 << 16) + ((n21 += (n11 & 0xFF00) * n10 + (n9 & 0xFF00) * n8) / n7 & 0xFF00) + (n20 & 0xFFFF) / n7) == 0) {
                    n6 = 1;
                }
                hk.hk_l[n] = n6;
            }
            return;
        }
    }

    final void d(int n, int n2, int n3, int n4) {
        int n5 = this.K << 3;
        int n6 = this.C << 3;
        n = (n << 4) + (n5 & 0xF);
        n2 = (n2 << 4) + (n6 & 0xF);
        this.a(n5, n6, n, n2, n3, n4);
    }

    final void f() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        block0: for (n5 = this.H - 1; n5 >= 0; --n5) {
            n4 = n5 * this.I;
            for (n3 = 0; n3 < this.I; ++n3) {
                if (this.D[n4 + n3] != 0) break block0;
            }
        }
        block2: for (n4 = 0; n4 < n5; ++n4) {
            n3 = n4 * this.I;
            for (n2 = 0; n2 < this.I; ++n2) {
                if (this.D[n3 + n2] != 0) break block2;
            }
        }
        block4: for (n3 = this.I - 1; n3 >= 0; --n3) {
            for (n2 = n4; n2 <= n5; ++n2) {
                if (this.D[n2 * this.I + n3] != 0) break block4;
            }
        }
        block6: for (n2 = 0; n2 < n3; ++n2) {
            for (n = n4; n <= n5; ++n) {
                if (this.D[n * this.I + n2] != 0) break block6;
            }
        }
        if (n2 == 0 && n3 == this.I - 1 && n4 == 0 && n5 == this.H - 1) {
            return;
        }
        n = n3 + 1 - n2;
        int n6 = n5 + 1 - n4;
        int[] nArray = new int[n * n6];
        for (int i = 0; i < n6; ++i) {
            for (int j = 0; j < n; ++j) {
                nArray[i * n + j] = this.D[(i + n4) * this.I + (j + n2)];
            }
        }
        this.D = nArray;
        this.I = n;
        this.H = n6;
        this.F += n2;
        this.z += n4;
    }

    void e(int n, int n2) {
        int n3;
        int n4 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n5 = 0;
        int n6 = this.H;
        int n7 = this.I;
        int n8 = hk.hk_j - n7;
        int n9 = 0;
        if (n2 < hk.hk_h) {
            n3 = hk.hk_h - n2;
            n6 -= n3;
            n2 = hk.hk_h;
            n5 += n3 * n7;
            n4 += n3 * hk.hk_j;
        }
        if (n2 + n6 > hk.hk_b) {
            n6 -= n2 + n6 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n3 = hk.hk_c - n;
            n7 -= n3;
            n = hk.hk_c;
            n5 += n3;
            n4 += n3;
            n9 += n3;
            n8 += n3;
        }
        if (n + n7 > hk.hk_g) {
            n3 = n + n7 - hk.hk_g;
            n7 -= n3;
            n9 += n3;
            n8 += n3;
        }
        if (n7 > 0) {
            if (n6 <= 0) {
                return;
            }
            ck.a(hk.hk_l, this.D, n5, n4, n7, n6, n8, n9);
            return;
        }
    }

    private static final void b(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = -(n4 >> 2);
        n4 = -(n4 & 3);
        for (int i = -n5; i < 0; ++i) {
            int n9;
            for (n9 = n8; n9 < 0; ++n9) {
                if ((n = nArray2[n2++]) != 0) {
                    nArray[n3++] = n;
                } else {
                    ++n3;
                }
                n = nArray2[n2++];
                if (n != 0) {
                    nArray[n3++] = n;
                } else {
                    ++n3;
                }
                n = nArray2[n2++];
                if (n != 0) {
                    nArray[n3++] = n;
                } else {
                    ++n3;
                }
                n = nArray2[n2++];
                if (n != 0) {
                    nArray[n3++] = n;
                    continue;
                }
                ++n3;
            }
            for (n9 = n4; n9 < 0; ++n9) {
                if ((n = nArray2[n2++]) != 0) {
                    nArray[n3++] = n;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    private static final void a(int n, int n2, int n3, int[] nArray, int[] nArray2, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11) {
        for (n7 = -n9; n7 < 0; ++n7) {
            for (n5 = -n8; n5 < 0; ++n5) {
                if ((n = nArray2[n4++]) != 0) {
                    n2 = nArray[n6];
                    n3 = n + n2;
                    n = (n & 0xFF00FF) + (n2 & 0xFF00FF);
                    n2 = (n & 0x1000100) + (n3 - n & 0x10000);
                    nArray[n6++] = n3 - n2 | n2 - (n2 >>> 8);
                    continue;
                }
                ++n6;
            }
            n6 += n10;
            n4 += n11;
        }
    }

    final void c(int n, int n2, int n3, int n4, int n5) {
        if (n3 > 0) {
            int n6;
            int n7;
            if (n4 <= 0) {
                return;
            }
            if (n3 == this.I && n4 == this.H) {
                this.d(n, n2, n5);
                return;
            }
            int n8 = this.I;
            int n9 = this.H;
            int n10 = 0;
            int n11 = 0;
            int n12 = this.K;
            int n13 = this.C;
            int n14 = (n12 << 16) / n3;
            int n15 = (n13 << 16) / n4;
            if (this.F > 0) {
                n7 = ((this.F << 16) + n14 - 1) / n14;
                n += n7;
                n10 += n7 * n14 - (this.F << 16);
            }
            if (this.z > 0) {
                n7 = ((this.z << 16) + n15 - 1) / n15;
                n2 += n7;
                n11 += n7 * n15 - (this.z << 16);
            }
            if (n8 < n12) {
                n3 = ((n8 << 16) - n10 + n14 - 1) / n14;
            }
            if (n9 < n13) {
                n4 = ((n9 << 16) - n11 + n15 - 1) / n15;
            }
            n7 = n + n2 * hk.hk_j;
            int n16 = hk.hk_j - n3;
            if (n2 + n4 > hk.hk_b) {
                n4 -= n2 + n4 - hk.hk_b;
            }
            if (n2 < hk.hk_h) {
                n6 = hk.hk_h - n2;
                n4 -= n6;
                n7 += n6 * hk.hk_j;
                n11 += n15 * n6;
            }
            if (n + n3 > hk.hk_g) {
                n6 = n + n3 - hk.hk_g;
                n3 -= n6;
                n16 += n6;
            }
            if (n < hk.hk_c) {
                n6 = hk.hk_c - n;
                n3 -= n6;
                n7 += n6;
                n10 += n14 * n6;
                n16 += n6;
            }
            ck.c(hk.hk_l, this.D, 0, n10, n11, n7, n16, n3, n4, n14, n15, n8, n5);
            return;
        }
    }

    final void a() {
        hk.a(this.D, this.I, this.H);
    }

    private static final void c(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11) {
        int n12 = n2;
        for (int i = -n7; i < 0; ++i) {
            int n13 = (n3 >> 16) * n10;
            for (int j = -n6; j < 0; ++j) {
                n = nArray2[(n2 >> 16) + n13];
                if (n != 0) {
                    nArray[n4++] = n11;
                } else {
                    ++n4;
                }
                n2 += n8;
            }
            n3 += n9;
            n2 = n12;
            n4 += n5;
        }
    }

    final ck e() {
        ck ck2 = new ck(this.I, this.H);
        ck2.K = this.K;
        ck2.C = this.C;
        ck2.F = this.K - this.I - this.F;
        ck2.z = this.z;
        for (int i = 0; i < this.H; ++i) {
            for (int j = 0; j < this.I; ++j) {
                ck2.D[i * this.I + j] = this.D[i * this.I + this.I - 1 - j];
            }
        }
        return ck2;
    }

    private static final void a(int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = 0;
        while (n8 < n7) {
            int n9 = 0;
            while (n9 < n6) {
                int n10 = hk.hk_l[n2] & 0xFF00FF;
                int n11 = hk.hk_l[n2] & 0xFF00;
                int n12 = 0;
                int n13 = 0;
                int n14 = nArray[n];
                if (n14 == 0) {
                    n12 += n10;
                    n13 += n11;
                } else {
                    n12 += n14 & 0xFF00FF;
                    n13 += n14 & 0xFF00;
                }
                n14 = nArray[n + 1];
                if (n14 == 0) {
                    n12 += n10;
                    n13 += n11;
                } else {
                    n12 += n14 & 0xFF00FF;
                    n13 += n14 & 0xFF00;
                }
                n14 = nArray[n + n5];
                if (n14 == 0) {
                    n12 += n10;
                    n13 += n11;
                } else {
                    n12 += n14 & 0xFF00FF;
                    n13 += n14 & 0xFF00;
                }
                n14 = nArray[n + n5 + 1];
                if (n14 == 0) {
                    n12 += n10;
                    n13 += n11;
                } else {
                    n12 += n14 & 0xFF00FF;
                    n13 += n14 & 0xFF00;
                }
                hk.hk_l[n2++] = (n12 & 0x3FC03FC | n13 & 0x3FC00) >> 2;
                ++n9;
                n += 2;
            }
            ++n8;
            n += n3;
            n2 += n4;
        }
    }

    void c(int n, int n2) {
        int n3;
        int n4 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n5 = 0;
        int n6 = this.H;
        int n7 = this.I;
        int n8 = hk.hk_j - n7;
        int n9 = 0;
        if (n2 < hk.hk_h) {
            n3 = hk.hk_h - n2;
            n6 -= n3;
            n2 = hk.hk_h;
            n5 += n3 * n7;
            n4 += n3 * hk.hk_j;
        }
        if (n2 + n6 > hk.hk_b) {
            n6 -= n2 + n6 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n3 = hk.hk_c - n;
            n7 -= n3;
            n = hk.hk_c;
            n5 += n3;
            n4 += n3;
            n9 += n3;
            n8 += n3;
        }
        if (n + n7 > hk.hk_g) {
            n3 = n + n7 - hk.hk_g;
            n7 -= n3;
            n9 += n3;
            n8 += n3;
        }
        if (n7 > 0) {
            if (n6 <= 0) {
                return;
            }
            ck.b(hk.hk_l, this.D, 0, n5, n4, n7, n6, n8, n9);
            return;
        }
    }

    final void b(int n, int n2, int n3, int n4) {
        if (n3 > this.K || n4 > this.C) {
            throw new IllegalArgumentException();
        }
        int n5 = n + this.F * n3 / this.K;
        int n6 = n + ((this.F + this.I) * n3 + this.K - 1) / this.K;
        int n7 = n2 + this.z * n4 / this.C;
        int n8 = n2 + ((this.z + this.H) * n4 + this.C - 1) / this.C;
        if (n5 < hk.hk_c) {
            n5 = hk.hk_c;
        }
        if (n6 > hk.hk_g) {
            n6 = hk.hk_g;
        }
        if (n7 < hk.hk_h) {
            n7 = hk.hk_h;
        }
        if (n8 > hk.hk_b) {
            n8 = hk.hk_b;
        }
        if (n5 < n6) {
            if (n7 >= n8) {
                return;
            }
            int n9 = n7 * hk.hk_j + n5;
            int n10 = hk.hk_j - (n6 - n5);
            for (int i = n7; i < n8; ++i) {
                for (int j = n5; j < n6; ++j) {
                    int n11;
                    int n12 = j - n << 4;
                    int n13 = (n12 + 16) * this.K / n3 - (this.F << 4);
                    int n14 = n12 * this.K / n3 - (this.F << 4);
                    int n15 = i - n2 << 4;
                    int n16 = (n15 + 16) * this.C / n4 - (this.z << 4);
                    int n17 = n15 * this.C / n4 - (this.z << 4);
                    int n18 = (n13 - n14) * (n16 - n17);
                    if (n18 == 0) continue;
                    if (n14 < 0) {
                        n14 = 0;
                    }
                    if (n13 > this.I << 4) {
                        n13 = this.I << 4;
                    }
                    if (n17 < 0) {
                        n17 = 0;
                    }
                    if (n16 > this.H << 4) {
                        n16 = this.H << 4;
                    }
                    int n19 = 16 - (n14 & 0xF);
                    int n20 = (--n13 & 0xF) + 1;
                    int n21 = 16 - (n17 & 0xF);
                    int n22 = (--n16 & 0xF) + 1;
                    n14 >>= 4;
                    n13 >>= 4;
                    n17 >>= 4;
                    n16 >>= 4;
                    int n23 = 0;
                    int n24 = 0;
                    int n25 = 0;
                    int n26 = 0;
                    int n27 = hk.hk_l[n9];
                    for (n11 = n17; n11 <= n16; ++n11) {
                        int n28 = 16;
                        if (n11 == n17) {
                            n28 = n21;
                        }
                        if (n11 == n16) {
                            n28 = n22;
                        }
                        for (int k = n14; k <= n13; ++k) {
                            int n29 = this.D[n11 * this.I + k];
                            if (n29 == 0) {
                                n29 = n27;
                            }
                            int n30 = n28;
                            n30 = k == n14 ? (n30 *= n19) : (k == n13 ? (n30 *= n20) : (n30 <<= 4));
                            n26 += n30;
                            n23 += (n29 >> 16 & 0xFF) * n30;
                            n24 += (n29 >> 8 & 0xFF) * n30;
                            n25 += (n29 & 0xFF) * n30;
                        }
                    }
                    if (n26 < n18) {
                        n11 = n18 - n26;
                        n23 += (n27 >> 16 & 0xFF) * n11;
                        n24 += (n27 >> 8 & 0xFF) * n11;
                        n25 += (n27 & 0xFF) * n11;
                    }
                    if ((n11 = (n23 / n18 << 16) + (n24 / n18 << 8) + n25 / n18) == 0) {
                        n11 = 1;
                    }
                    hk.hk_l[n9] = n11;
                    ++n9;
                }
                n9 += n10;
            }
            return;
        }
    }

    void f(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            if (n3 == 256) {
                ck.a(0, 0, 0, hk.hk_l, this.D, n6, 0, n5, 0, n8, n7, n9, n10);
            } else {
                ck.a(0, 0, 0, hk.hk_l, this.D, n6, 0, n5, 0, n8, n7, n9, n10, n3);
            }
            return;
        }
    }

    private static final void a(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = -(n4 >> 2);
        n4 = -(n4 & 3);
        for (int i = -n5; i < 0; ++i) {
            int n9;
            for (n9 = n8; n9 < 0; ++n9) {
                if (nArray2[n2++] != 0) {
                    nArray[n3++] = n;
                } else {
                    ++n3;
                }
                if (nArray2[n2++] != 0) {
                    nArray[n3++] = n;
                } else {
                    ++n3;
                }
                if (nArray2[n2++] != 0) {
                    nArray[n3++] = n;
                } else {
                    ++n3;
                }
                if (nArray2[n2++] != 0) {
                    nArray[n3++] = n;
                    continue;
                }
                ++n3;
            }
            for (n9 = n4; n9 < 0; ++n9) {
                if (nArray2[n2++] != 0) {
                    nArray[n3++] = n;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    final void f(int n, int n2) {
        int n3;
        int n4 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n5 = 0;
        int n6 = this.H;
        int n7 = this.I;
        int n8 = hk.hk_j - n7;
        int n9 = 0;
        if (n2 < hk.hk_h) {
            n3 = hk.hk_h - n2;
            n6 -= n3;
            n2 = hk.hk_h;
            n5 += n3 * n7;
            n4 += n3 * hk.hk_j;
        }
        if (n2 + n6 > hk.hk_b) {
            n6 -= n2 + n6 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n3 = hk.hk_c - n;
            n7 -= n3;
            n = hk.hk_c;
            n5 += n3;
            n4 += n3;
            n9 += n3;
            n8 += n3;
        }
        if (n + n7 > hk.hk_g) {
            n3 = n + n7 - hk.hk_g;
            n7 -= n3;
            n9 += n3;
            n8 += n3;
        }
        if (n7 > 0) {
            if (n6 <= 0) {
                return;
            }
            ck.a(0, hk.hk_l, this.D, 0, n5, n4, n7, n6, n8, n9);
            return;
        }
    }

    private static final void a(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
        int n11 = n2;
        for (int i = -n7; i < 0; ++i) {
            int n12 = (n3 >> 16) * n10;
            for (int j = -n6; j < 0; ++j) {
                n = nArray2[(n2 >> 16) + n12];
                if (n != 0) {
                    nArray[n4++] = n;
                } else {
                    ++n4;
                }
                n2 += n8;
            }
            n3 += n9;
            n2 = n11;
            n4 += n5;
        }
    }

    void d(int n, int n2) {
        int n3 = (n += this.F >> 1) < hk.hk_c ? hk.hk_c - n << 1 : 0;
        int n4 = n + (this.I >> 1) > hk.hk_g ? hk.hk_g - n << 1 : this.I;
        int n5 = n2 < hk.hk_h ? hk.hk_h - (n2 += this.z >> 1) << 1 : 0;
        int n6 = n2 + (this.H >> 1) > hk.hk_b ? hk.hk_b - n2 << 1 : this.H;
        ck.a(this.D, n5 * this.I + n3, (n2 + (n5 >> 1)) * hk.hk_j + (n + (n3 >> 1)), (this.I << 1) - (n4 - n3) + (this.I & 1), hk.hk_j - (n4 - n3 >> 1), this.I, n4 - n3 >> 1, n6 - n5 >> 1);
    }

    final ck c() {
        ck ck2 = new ck(this.I, this.H);
        ck2.K = this.K;
        ck2.C = this.C;
        ck2.F = this.F;
        ck2.z = this.z;
        int n = this.D.length;
        System.arraycopy(this.D, 0, ck2.D, 0, n);
        return ck2;
    }

    private static final void c(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        for (int i = -n5; i < 0; ++i) {
            for (int j = -n4; j < 0; ++j) {
                if ((n = nArray2[n2++]) != 0) {
                    int n9 = (n & 0xFF00FF) * n8 & 0xFF00FF00;
                    int n10 = (n & 0xFF00) * n8 & 0xFF0000;
                    nArray[n3++] = (n9 | n10) >>> 8;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    final void b() {
        if (this.I == this.K && this.H == this.C) {
            return;
        }
        int[] nArray = new int[this.K * this.C];
        for (int i = 0; i < this.H; ++i) {
            for (int j = 0; j < this.I; ++j) {
                nArray[(i + this.z) * this.K + (j + this.F)] = this.D[i * this.I + j];
            }
        }
        this.D = nArray;
        this.I = this.K;
        this.H = this.C;
        this.F = 0;
        this.z = 0;
    }

    private static final void b(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11) {
        int n12 = 256 - n11;
        int n13 = n2;
        for (int i = -n7; i < 0; ++i) {
            int n14 = (n3 >> 16) * n10;
            for (int j = -n6; j < 0; ++j) {
                n = nArray2[(n2 >> 16) + n14];
                if (n != 0) {
                    int n15 = nArray[n4];
                    nArray[n4++] = ((n & 0xFF00FF) * n11 + (n15 & 0xFF00FF) * n12 & 0xFF00FF00) + ((n & 0xFF00) * n11 + (n15 & 0xFF00) * n12 & 0xFF0000) >> 8;
                } else {
                    ++n4;
                }
                n2 += n8;
            }
            n3 += n9;
            n2 = n13;
            n4 += n5;
        }
    }

    void e(int n, int n2, int n3) {
        int n4;
        if (n3 == 256) {
            this.c(n, n2);
            return;
        }
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ck.c(hk.hk_l, this.D, 0, n6, n5, n8, n7, n9, n10, n3);
            return;
        }
    }

    private static final void b(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
        int n11 = n10 & 0xFF00FF;
        int n12 = n10 >> 8 & 0xFF;
        for (n5 = -n7; n5 < 0; ++n5) {
            for (n4 = -n6; n4 < 0; ++n4) {
                if ((n = nArray2[n2++]) != 0) {
                    if (n >> 8 == (n & 0xFFFF)) {
                        nArray[n3++] = ((n &= 0xFF) * n11 >> 8 & 0xFF00FE) + (n * n12 & 0xFF00) + 1;
                        continue;
                    }
                    nArray[n3++] = n;
                    continue;
                }
                ++n3;
            }
            n3 += n8;
            n2 += n9;
        }
    }

    final void d(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ck.a(hk.hk_l, this.D, n3, n6, n5, n8, n7, n9, n10);
            return;
        }
    }

    final void d() {
        int n;
        int[] nArray = new int[this.I * this.H];
        int n2 = 0;
        for (n = 0; n < this.I; ++n) {
            for (int i = this.H - 1; i >= 0; --i) {
                nArray[n2++] = this.D[n + i * this.I];
            }
        }
        this.D = nArray;
        n = this.z;
        this.z = this.F;
        this.F = this.C - this.H - n;
        n = this.H;
        this.H = this.I;
        this.I = n;
        n = this.C;
        this.C = this.K;
        this.K = n;
    }

    void b(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ck.b(hk.hk_l, this.D, 0, n6, n5, 0, 0, n8, n7, n9, n10, n3);
            return;
        }
    }

    final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        block71: {
            block72: {
                int n7;
                int n8;
                int n9;
                int n10;
                int n11;
                int n12;
                int n13;
                int n14;
                int n15;
                block69: {
                    block70: {
                        int n16;
                        int n17;
                        if (n6 == 0) {
                            return;
                        }
                        double d = (double)(n5 & 0xFFFF) * 9.587379924285257E-5;
                        int n18 = (int)Math.floor(Math.sin(d) * (double)n6 + 0.5);
                        int n19 = (int)Math.floor(Math.cos(d) * (double)n6 + 0.5);
                        int n20 = -(n -= this.F << 4) * n19 + -(n2 -= this.z << 4) * n18;
                        int n21 = -(-n) * n18 + -n2 * n19;
                        int n22 = ((this.I << 4) - n) * n19 + -n2 * n18;
                        int n23 = -((this.I << 4) - n) * n18 + -n2 * n19;
                        int n24 = -n * n19 + ((this.H << 4) - n2) * n18;
                        int n25 = -(-n) * n18 + ((this.H << 4) - n2) * n19;
                        int n26 = ((this.I << 4) - n) * n19 + ((this.H << 4) - n2) * n18;
                        int n27 = -((this.I << 4) - n) * n18 + ((this.H << 4) - n2) * n19;
                        if (n20 < n22) {
                            n17 = n20;
                            n15 = n22;
                        } else {
                            n17 = n22;
                            n15 = n20;
                        }
                        if (n24 < n17) {
                            n17 = n24;
                        }
                        if (n26 < n17) {
                            n17 = n26;
                        }
                        if (n24 > n15) {
                            n15 = n24;
                        }
                        if (n26 > n15) {
                            n15 = n26;
                        }
                        if (n21 < n23) {
                            n16 = n21;
                            n14 = n23;
                        } else {
                            n16 = n23;
                            n14 = n21;
                        }
                        if (n25 < n16) {
                            n16 = n25;
                        }
                        if (n27 < n16) {
                            n16 = n27;
                        }
                        if (n25 > n14) {
                            n14 = n25;
                        }
                        if (n27 > n14) {
                            n14 = n27;
                        }
                        n17 >>= 12;
                        n15 = n15 + 4095 >> 12;
                        n16 >>= 12;
                        n14 = n14 + 4095 >> 12;
                        n17 += n3;
                        n15 += n3;
                        n16 += n4;
                        n14 += n4;
                        n15 = n15 + 15 >> 4;
                        n16 >>= 4;
                        n14 = n14 + 15 >> 4;
                        if ((n17 >>= 4) < hk.hk_c) {
                            n17 = hk.hk_c;
                        }
                        if (n15 > hk.hk_g) {
                            n15 = hk.hk_g;
                        }
                        if (n16 < hk.hk_h) {
                            n16 = hk.hk_h;
                        }
                        if (n14 > hk.hk_b) {
                            n14 = hk.hk_b;
                        }
                        if ((n15 = n17 - n15) >= 0) {
                            return;
                        }
                        if ((n14 = n16 - n14) >= 0) {
                            return;
                        }
                        n13 = n16 * hk.hk_j + n17;
                        n12 = hk.hk_j + n15;
                        double d2 = 1.6777216E7 / (double)n6;
                        n11 = (int)Math.floor(Math.sin(d) * d2 + 0.5);
                        n10 = (int)Math.floor(Math.cos(d) * d2 + 0.5);
                        n9 = (n17 << 4) + 8 - n3;
                        int n28 = (n16 << 4) + 8 - n4;
                        n8 = (n << 8) - 2048 - (n28 * n11 >> 4);
                        n7 = (n2 << 8) - 2048 + (n28 * n10 >> 4);
                        if (n10 >= 0) break block69;
                        if (n11 >= 0) break block70;
                        int n29 = n14;
                        while (n29 < 0) {
                            int n30 = n8 + (n9 * n10 >> 4);
                            int n31 = n7 + (n9 * n11 >> 4);
                            int n32 = n15;
                            boolean bl = false;
                            int n33 = n30 - (this.I << 12);
                            if (n33 < 0) {
                                bl = true;
                            } else if (n10 == 0) {
                                n13 -= n32;
                            } else {
                                n33 = (n10 - n33) / n10;
                                n32 += n33;
                                n30 += n10 * n33;
                                n31 += n11 * n33;
                                n13 += n33;
                                bl = true;
                            }
                            if (bl) {
                                bl = false;
                                n33 = n31 - (this.H << 12);
                                if (n33 < 0) {
                                    bl = true;
                                } else if (n11 == 0) {
                                    n13 -= n32;
                                } else {
                                    n33 = (n11 - n33) / n11;
                                    n32 += n33;
                                    n30 += n10 * n33;
                                    n31 += n11 * n33;
                                    n13 += n33;
                                    bl = true;
                                }
                                if (bl) {
                                    while (n32 < 0 && n30 >= -4096 && n31 >= -4096) {
                                        int n34 = n30 >> 12;
                                        int n35 = n31 >> 12;
                                        this.e(n13, n34, n35, n30, n31);
                                        ++n32;
                                        n30 += n10;
                                        n31 += n11;
                                        ++n13;
                                    }
                                    n13 -= n32;
                                }
                            }
                            ++n29;
                            n8 -= n11;
                            n7 += n10;
                            n13 += n12;
                        }
                        break block71;
                    }
                    int n36 = n14;
                    while (n36 < 0) {
                        int n37 = n8 + (n9 * n10 >> 4);
                        int n38 = n7 + (n9 * n11 >> 4);
                        int n39 = n15;
                        boolean bl = false;
                        int n40 = n37 - (this.I << 12);
                        if (n40 < 0) {
                            bl = true;
                        } else if (n10 == 0) {
                            n13 -= n39;
                        } else {
                            n40 = (n10 - n40) / n10;
                            n39 += n40;
                            n37 += n10 * n40;
                            n38 += n11 * n40;
                            n13 += n40;
                            bl = true;
                        }
                        if (bl) {
                            bl = false;
                            n40 = n38 + 4096;
                            if (n40 >= 0) {
                                bl = true;
                            } else if (n11 == 0) {
                                n13 -= n39;
                            } else {
                                n40 = (n11 - 1 - n40) / n11;
                                n39 += n40;
                                n37 += n10 * n40;
                                n38 += n11 * n40;
                                n13 += n40;
                                bl = true;
                            }
                            if (bl) {
                                int n41;
                                while (n39 < 0 && n37 >= -4096 && (n41 = n38 >> 12) < this.H) {
                                    int n42 = n37 >> 12;
                                    this.e(n13, n42, n41, n37, n38);
                                    ++n39;
                                    n37 += n10;
                                    n38 += n11;
                                    ++n13;
                                }
                                n13 -= n39;
                            }
                        }
                        ++n36;
                        n8 -= n11;
                        n7 += n10;
                        n13 += n12;
                    }
                    break block72;
                }
                if (n11 < 0) {
                    int n43 = n14;
                    while (n43 < 0) {
                        int n44 = n8 + (n9 * n10 >> 4);
                        int n45 = n7 + (n9 * n11 >> 4);
                        int n46 = n15;
                        boolean bl = false;
                        int n47 = n44 + 4096;
                        if (n47 >= 0) {
                            bl = true;
                        } else if (n10 == 0) {
                            n13 -= n46;
                        } else {
                            n47 = (n10 - 1 - n47) / n10;
                            n46 += n47;
                            n44 += n10 * n47;
                            n45 += n11 * n47;
                            n13 += n47;
                            bl = true;
                        }
                        if (bl) {
                            bl = false;
                            n47 = n45 - (this.H << 12);
                            if (n47 < 0) {
                                bl = true;
                            } else if (n11 == 0) {
                                n13 -= n46;
                            } else {
                                n47 = (n11 - n47) / n11;
                                n46 += n47;
                                n44 += n10 * n47;
                                n45 += n11 * n47;
                                n13 += n47;
                                bl = true;
                            }
                            if (bl) {
                                int n48;
                                while (n46 < 0 && n45 >= -4096 && (n48 = n44 >> 12) < this.I) {
                                    int n49 = n45 >> 12;
                                    this.e(n13, n48, n49, n44, n45);
                                    ++n46;
                                    n44 += n10;
                                    n45 += n11;
                                    ++n13;
                                }
                                n13 -= n46;
                            }
                        }
                        ++n43;
                        n8 -= n11;
                        n7 += n10;
                        n13 += n12;
                    }
                } else {
                    int n50 = n14;
                    while (n50 < 0) {
                        int n51 = n8 + (n9 * n10 >> 4);
                        int n52 = n7 + (n9 * n11 >> 4);
                        int n53 = n15;
                        boolean bl = false;
                        int n54 = n51 + 4096;
                        if (n54 >= 0) {
                            bl = true;
                        } else if (n10 == 0) {
                            n13 -= n53;
                        } else {
                            n54 = (n10 - 1 - n54) / n10;
                            n53 += n54;
                            n51 += n10 * n54;
                            n52 += n11 * n54;
                            n13 += n54;
                            bl = true;
                        }
                        if (bl) {
                            bl = false;
                            n54 = n52 + 4096;
                            if (n54 >= 0) {
                                bl = true;
                            } else if (n11 == 0) {
                                n13 -= n53;
                            } else {
                                n54 = (n11 - 1 - n54) / n11;
                                n53 += n54;
                                n51 += n10 * n54;
                                n52 += n11 * n54;
                                n13 += n54;
                                bl = true;
                            }
                            if (bl) {
                                int n55;
                                int n56;
                                while (n53 < 0 && (n56 = n51 >> 12) < this.I && (n55 = n52 >> 12) < this.H) {
                                    this.e(n13, n56, n55, n51, n52);
                                    ++n53;
                                    n51 += n10;
                                    n52 += n11;
                                    ++n13;
                                }
                                n13 -= n53;
                            }
                        }
                        ++n50;
                        n8 -= n11;
                        n7 += n10;
                        n13 += n12;
                    }
                }
            }
            return;
        }
    }

    private static final void b(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        int n9 = n8 >> 16 & 0xFF;
        int n10 = n8 >> 8 & 0xFF;
        int n11 = n8 & 0xFF;
        int n12 = -(n4 >> 2);
        n4 = -(n4 & 3);
        int n13 = n12 + n12 + n12 + n12 + n4;
        for (int i = -n5; i < 0; ++i) {
            for (int j = n13; j < 0; ++j) {
                if ((n = nArray2[n2++]) != 0) {
                    int n14 = n >> 16 & 0xFF;
                    int n15 = n >> 8 & 0xFF;
                    int n16 = n & 0xFF;
                    if (n14 == n15 && n15 == n16) {
                        if (n14 <= 128) {
                            nArray[n3++] = (n14 * n9 >> 7 << 16) + (n15 * n10 >> 7 << 8) + (n16 * n11 >> 7);
                            continue;
                        }
                        nArray[n3++] = (n9 * (256 - n14) + 255 * (n14 - 128) >> 7 << 16) + (n10 * (256 - n15) + 255 * (n15 - 128) >> 7 << 8) + (n11 * (256 - n16) + 255 * (n16 - 128) >> 7);
                        continue;
                    }
                    nArray[n3++] = n;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    private static final void a(int n, int n2, int n3, int[] nArray, int[] nArray2, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12) {
        for (n7 = -n9; n7 < 0; ++n7) {
            for (n5 = -n8; n5 < 0; ++n5) {
                if ((n = nArray2[n4++]) != 0) {
                    n2 = (n & 0xFF00FF) * n12;
                    n = (n2 & 0xFF00FF00) + (n * n12 - n2 & 0xFF0000) >>> 8;
                    n2 = nArray[n6];
                    n3 = n + n2;
                    n = (n & 0xFF00FF) + (n2 & 0xFF00FF);
                    n2 = (n & 0x1000100) + (n3 - n & 0x10000);
                    nArray[n6++] = n3 - n2 | n2 - (n2 >>> 8);
                    continue;
                }
                ++n6;
            }
            n6 += n10;
            n4 += n11;
        }
    }

    private static final void a(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6) {
        for (int i = -n4; i < 0; ++i) {
            int n7 = n2 + n3 - 3;
            while (n2 < n7) {
                nArray[n2++] = nArray2[n++];
                nArray[n2++] = nArray2[n++];
                nArray[n2++] = nArray2[n++];
                nArray[n2++] = nArray2[n++];
            }
            n7 += 3;
            while (n2 < n7) {
                nArray[n2++] = nArray2[n++];
            }
            n2 += n5;
            n += n6;
        }
    }

    private static final void a(int n, int[] nArray, int[] nArray2, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        for (int i = -n6; i < 0; ++i) {
            for (int j = -n5; j < 0; ++j) {
                if ((n2 = nArray2[n3++]) != 0) {
                    n = nArray[n4];
                    if (n != 0) {
                        int n9 = ((n2 & 0xFF0000) >>> 16) * ((n & 0xFF0000) >>> 16) >>> 8;
                        int n10 = (n2 & 0xFF00) * (n & 0xFF00) >>> 24;
                        int n11 = (n2 & 0xFF) * (n & 0xFF) >>> 8;
                        nArray[n4++] = (n9 << 16) + (n10 << 8) + n11;
                        continue;
                    }
                    ++n4;
                    continue;
                }
                ++n4;
            }
            n4 += n7;
            n3 += n8;
        }
    }

    void a(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ck.b(hk.hk_l, this.D, 0, n6, n5, n8, n7, n9, n10, n3);
            return;
        }
    }

    final void a(int n, int n2, int n3, int n4) {
        if (n3 > this.K || n4 > this.C) {
            throw new IllegalArgumentException();
        }
        int n5 = n + this.F * n3 / this.K;
        int n6 = n + ((this.F + this.I) * n3 + this.K - 1) / this.K;
        int n7 = n2 + this.z * n4 / this.C;
        int n8 = n2 + ((this.z + this.H) * n4 + this.C - 1) / this.C;
        if (n5 < hk.hk_c) {
            n5 = hk.hk_c;
        }
        if (n6 > hk.hk_g) {
            n6 = hk.hk_g;
        }
        if (n7 < hk.hk_h) {
            n7 = hk.hk_h;
        }
        if (n8 > hk.hk_b) {
            n8 = hk.hk_b;
        }
        if (n5 < n6) {
            if (n7 >= n8) {
                return;
            }
            int n9 = n7 * hk.hk_j + n5;
            int n10 = hk.hk_j - (n6 - n5);
            for (int i = n7; i < n8; ++i) {
                for (int j = n5; j < n6; ++j) {
                    int n11;
                    int n12 = j - n << 4;
                    int n13 = (n12 + 16) * this.K / n3 - (this.F << 4);
                    int n14 = n12 * this.K / n3 - (this.F << 4);
                    int n15 = i - n2 << 4;
                    int n16 = (n15 + 16) * this.C / n4 - (this.z << 4);
                    int n17 = n15 * this.C / n4 - (this.z << 4);
                    int n18 = (n13 - n14) * (n16 - n17) >> 1;
                    if (n18 == 0) continue;
                    if (n14 < 0) {
                        n14 = 0;
                    }
                    if (n13 > this.I << 4) {
                        n13 = this.I << 4;
                    }
                    if (n17 < 0) {
                        n17 = 0;
                    }
                    if (n16 > this.H << 4) {
                        n16 = this.H << 4;
                    }
                    int n19 = 16 - (n14 & 0xF);
                    int n20 = (--n13 & 0xF) + 1;
                    int n21 = 16 - (n17 & 0xF);
                    int n22 = (--n16 & 0xF) + 1;
                    n14 >>= 4;
                    n13 >>= 4;
                    n17 >>= 4;
                    n16 >>= 4;
                    int n23 = 0;
                    int n24 = 0;
                    int n25 = 0;
                    int n26 = 0;
                    for (n11 = n17; n11 <= n16; ++n11) {
                        int n27 = 16;
                        if (n11 == n17) {
                            n27 = n21;
                        }
                        if (n11 == n16) {
                            n27 = n22;
                        }
                        for (int k = n14; k <= n13; ++k) {
                            int n28 = this.D[n11 * this.I + k];
                            if (n28 == 0) continue;
                            int n29 = n27;
                            n29 = k == n14 ? (n29 *= n19) : (k == n13 ? (n29 *= n20) : (n29 <<= 4));
                            n26 += n29;
                            n23 += (n28 >> 16 & 0xFF) * n29;
                            n24 += (n28 >> 8 & 0xFF) * n29;
                            n25 += (n28 & 0xFF) * n29;
                        }
                    }
                    if (n26 >= n18) {
                        n11 = (n23 / n26 << 16) + (n24 / n26 << 8) + n25 / n26;
                        if (n11 == 0) {
                            n11 = 1;
                        }
                        hk.hk_l[n9] = n11;
                    }
                    ++n9;
                }
                n9 += n10;
            }
            return;
        }
    }

    void b(int n, int n2, int n3, int n4, int n5) {
        if (n3 > 0) {
            int n6;
            int n7;
            if (n4 <= 0) {
                return;
            }
            int n8 = this.I;
            int n9 = this.H;
            int n10 = 0;
            int n11 = 0;
            int n12 = this.K;
            int n13 = this.C;
            int n14 = (n12 << 16) / n3;
            int n15 = (n13 << 16) / n4;
            if (this.F > 0) {
                n7 = ((this.F << 16) + n14 - 1) / n14;
                n += n7;
                n10 += n7 * n14 - (this.F << 16);
            }
            if (this.z > 0) {
                n7 = ((this.z << 16) + n15 - 1) / n15;
                n2 += n7;
                n11 += n7 * n15 - (this.z << 16);
            }
            if (n8 < n12) {
                n3 = ((n8 << 16) - n10 + n14 - 1) / n14;
            }
            if (n9 < n13) {
                n4 = ((n9 << 16) - n11 + n15 - 1) / n15;
            }
            n7 = n + n2 * hk.hk_j;
            int n16 = hk.hk_j - n3;
            if (n2 + n4 > hk.hk_b) {
                n4 -= n2 + n4 - hk.hk_b;
            }
            if (n2 < hk.hk_h) {
                n6 = hk.hk_h - n2;
                n4 -= n6;
                n7 += n6 * hk.hk_j;
                n11 += n15 * n6;
            }
            if (n + n3 > hk.hk_g) {
                n6 = n + n3 - hk.hk_g;
                n3 -= n6;
                n16 += n6;
            }
            if (n < hk.hk_c) {
                n6 = hk.hk_c - n;
                n3 -= n6;
                n7 += n6;
                n10 += n14 * n6;
                n16 += n6;
            }
            ck.b(hk.hk_l, this.D, 0, n10, n11, n7, n16, n3, n4, n14, n15, n8, n5);
            return;
        }
    }

    private static final void a(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11) {
        int n12 = n2;
        for (int i = -n7; i < 0; ++i) {
            int n13 = (n3 >> 16) * n10;
            for (int j = -n6; j < 0; ++j) {
                n = nArray2[(n2 >> 16) + n13];
                if (n != 0) {
                    int n14 = (n & 0xFF00FF) * n11 & 0xFF00FF00;
                    int n15 = (n & 0xFF00) * n11 & 0xFF0000;
                    nArray[n4++] = (n14 | n15) >>> 8;
                } else {
                    ++n4;
                }
                n2 += n8;
            }
            n3 += n9;
            n2 = n12;
            n4 += n5;
        }
    }

    ck(int n, int n2, int n3, int n4, int n5, int n6, int[] nArray) {
        this.K = n;
        this.C = n2;
        this.F = n3;
        this.z = n4;
        this.I = n5;
        this.H = n6;
        this.D = nArray;
    }

    private static final void a(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        int n9 = 256 - n8;
        for (int i = -n5; i < 0; ++i) {
            for (int j = -n4; j < 0; ++j) {
                if ((n = nArray2[n2++]) != 0) {
                    int n10 = nArray[n3];
                    nArray[n3++] = ((n & 0xFF00FF) * n8 + (n10 & 0xFF00FF) * n9 & 0xFF00FF00) + ((n & 0xFF00) * n8 + (n10 & 0xFF00) * n9 & 0xFF0000) >> 8;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    ck(int n, int n2) {
        this.D = new int[n * n2];
        this.I = this.K = n;
        this.H = this.C = n2;
        this.z = 0;
        this.F = 0;
    }

    void c(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ck.a(hk.hk_l, this.D, 0, n6, n5, n8, n7, n9, n10, n3);
            return;
        }
    }

    ck(byte[] byArray, Component component) {
        try {
            Image image = Toolkit.getDefaultToolkit().createImage(byArray);
            MediaTracker mediaTracker = new MediaTracker(component);
            mediaTracker.addImage(image, 0);
            mediaTracker.waitForAll();
            this.I = image.getWidth(component);
            this.H = image.getHeight(component);
            this.K = this.I;
            this.C = this.H;
            this.F = 0;
            this.z = 0;
            this.D = new int[this.I * this.H];
            PixelGrabber pixelGrabber = new PixelGrabber(image, 0, 0, this.I, this.H, this.D, 0, this.I);
            pixelGrabber.grabPixels();
        }
        catch (InterruptedException interruptedException) {
            // empty catch block
        }
    }

    void d(int n, int n2, int n3, int n4, int n5) {
        if (n3 > 0) {
            int n6;
            int n7;
            if (n4 <= 0) {
                return;
            }
            if (n5 == 256) {
                this.c(n, n2, n3, n4);
                return;
            }
            int n8 = this.I;
            int n9 = this.H;
            int n10 = 0;
            int n11 = 0;
            int n12 = this.K;
            int n13 = this.C;
            int n14 = (n12 << 16) / n3;
            int n15 = (n13 << 16) / n4;
            if (this.F > 0) {
                n7 = ((this.F << 16) + n14 - 1) / n14;
                n += n7;
                n10 += n7 * n14 - (this.F << 16);
            }
            if (this.z > 0) {
                n7 = ((this.z << 16) + n15 - 1) / n15;
                n2 += n7;
                n11 += n7 * n15 - (this.z << 16);
            }
            if (n8 < n12) {
                n3 = ((n8 << 16) - n10 + n14 - 1) / n14;
            }
            if (n9 < n13) {
                n4 = ((n9 << 16) - n11 + n15 - 1) / n15;
            }
            n7 = n + n2 * hk.hk_j;
            int n16 = hk.hk_j - n3;
            if (n2 + n4 > hk.hk_b) {
                n4 -= n2 + n4 - hk.hk_b;
            }
            if (n2 < hk.hk_h) {
                n6 = hk.hk_h - n2;
                n4 -= n6;
                n7 += n6 * hk.hk_j;
                n11 += n15 * n6;
            }
            if (n + n3 > hk.hk_g) {
                n6 = n + n3 - hk.hk_g;
                n3 -= n6;
                n16 += n6;
            }
            if (n < hk.hk_c) {
                n6 = hk.hk_c - n;
                n3 -= n6;
                n7 += n6;
                n10 += n14 * n6;
                n16 += n6;
            }
            ck.a(hk.hk_l, this.D, 0, n10, n11, n7, n16, n3, n4, n14, n15, n8, n5);
            return;
        }
    }

    void c(int n, int n2, int n3, int n4) {
        if (n3 > 0) {
            int n5;
            int n6;
            if (n4 <= 0) {
                return;
            }
            int n7 = this.I;
            int n8 = this.H;
            int n9 = 0;
            int n10 = 0;
            int n11 = this.K;
            int n12 = this.C;
            int n13 = (n11 << 16) / n3;
            int n14 = (n12 << 16) / n4;
            if (this.F > 0) {
                n6 = ((this.F << 16) + n13 - 1) / n13;
                n += n6;
                n9 += n6 * n13 - (this.F << 16);
            }
            if (this.z > 0) {
                n6 = ((this.z << 16) + n14 - 1) / n14;
                n2 += n6;
                n10 += n6 * n14 - (this.z << 16);
            }
            if (n7 < n11) {
                n3 = ((n7 << 16) - n9 + n13 - 1) / n13;
            }
            if (n8 < n12) {
                n4 = ((n8 << 16) - n10 + n14 - 1) / n14;
            }
            n6 = n + n2 * hk.hk_j;
            int n15 = hk.hk_j - n3;
            if (n2 + n4 > hk.hk_b) {
                n4 -= n2 + n4 - hk.hk_b;
            }
            if (n2 < hk.hk_h) {
                n5 = hk.hk_h - n2;
                n4 -= n5;
                n6 += n5 * hk.hk_j;
                n10 += n14 * n5;
            }
            if (n + n3 > hk.hk_g) {
                n5 = n + n3 - hk.hk_g;
                n3 -= n5;
                n15 += n5;
            }
            if (n < hk.hk_c) {
                n5 = hk.hk_c - n;
                n3 -= n5;
                n6 += n5;
                n9 += n13 * n5;
                n15 += n5;
            }
            ck.a(hk.hk_l, this.D, 0, n9, n10, n6, n15, n3, n4, n13, n14, n7);
            return;
        }
    }
}
