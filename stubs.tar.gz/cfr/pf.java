/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class pf {
    private String pf_m;
    gb pf_h = new gb(ik.ik_e);
    private int[] pf_j;
    static volatile int pf_g = 0;
    w pf_l;
    private int pf_a;
    String pf_b;
    static String[] pf_k;
    private long pf_e;
    static String pf_c;
    static int[] pf_i;
    static byte[] pf_d;
    int pf_f;

    final void a(int n) {
        block1: {
            if (this.pf_b != null && this.pf_e != uc.uc_g) {
                String string;
                String string2 = string = this.d(-116);
                this.pf_h.a(cm.a((byte)104, li.li_f, new String[]{string}), 17, n ^ 0x59);
            }
            if (n == 17) break block1;
            pf_k = null;
        }
    }

    final boolean c(int n) {
        if (n != -3) {
            String string = null;
            pf.a(null, null, 28L, (byte)102, string);
        }
        return null != this.pf_h && this.pf_h.f(30);
    }

    private final boolean a(int n, int n2, int n3) {
        if (n != ~n2) {
            return false;
        }
        pd.pd_f = new mg(this.pf_l.E, this.pf_l.w_pb, this.pf_l.w_mb, this.pf_l.N, n3, ui.x, tg.tg_h, ib.ib_nb, ua.H, al.al_h, df.df_ab, this.pf_b, this.pf_e);
        return true;
    }

    final void a(byte by, boolean bl) {
        if (by < 25) {
            this.a((byte)114, true);
        }
        this.pf_h.a(1141039778, bl);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final boolean a(int n, boolean bl, int n2) {
        boolean bl2 = client.A;
        if (!bl) {
            return true;
        }
        if (0 == n2) {
            bn.a(this.pf_e, n, (byte)-84);
            return true;
        }
        if (1 != n2) {
            if (~n2 == -3) {
                cg.a(this.pf_f, (byte)-9, n);
                return true;
            } else if (-4 == ~n2) {
                md.a(9, n, this.pf_f);
                return true;
            } else if (n2 != 10) {
                if (n2 != 15) {
                    if (n2 != 16) return false;
                    vg.a(-20974, n, 0);
                    return true;
                } else {
                    vg.a(-20974, n, this.pf_f);
                }
                return true;
            } else {
                ga.a(false, this.pf_f, n);
            }
            return true;
        } else {
            mn.a(bl, this.pf_e, n);
        }
        return true;
    }

    final void a(boolean bl, int n) {
        block5: {
            String string;
            block6: {
                boolean bl2 = client.A;
                if (n != 29072) {
                    pf.a(false);
                }
                if (null == this.pf_b || this.pf_e == uc.uc_g || cd.cd_m == null || !ig.b(true)) break block5;
                tj tj2 = ma.a(-105, this.pf_e);
                tj tj3 = bj.a(this.pf_e, (byte)58);
                string = this.d(-124);
                if (tj3 != null) break block6;
                if (null == tj2 || !cd.cd_m.ve_wc || ~cd.cd_m.ve_rc <= ~cd.cd_m.ve_mc) break block5;
                if (tj2.tj_bc) {
                    this.pf_h.a(cm.a((byte)93, vm.vm_p, new String[]{string}), 1, 64);
                } else if (!bl || !tj2.tj_fc) {
                    this.pf_h.a(cm.a((byte)92, lj.lj_b, new String[]{string}), 0, -30);
                } else {
                    this.pf_h.a(cm.a((byte)101, jh.jh_g, new String[]{string}), 0, -124);
                    this.pf_h.a(cm.a((byte)108, df.T, new String[]{string}), 1, n ^ 0xFFFF8E46);
                }
                break block5;
            }
            if (cd.cd_m.ve_lc && 0 > cd.cd_m.Nb) break block5;
            this.pf_h.a(cm.a((byte)106, un.un_c, new String[]{string}), 1, -20);
        }
    }

    final void b(int n) {
        block7: {
            ve ve2;
            boolean bl = client.A;
            if (cd.cd_m == null && null != (ve2 = ob.a(this.pf_f, 8))) {
                String string = ve2.Vb;
                if (!ve2.Zb) {
                    if (ve2.gc) {
                        this.pf_h.a(cm.a((byte)119, fl.fl_c, new String[]{string}), 2, -98);
                    } else if (!ve2.Ob && ve2.ve_wc && (!ve2.ve_lc || ve2.gc)) {
                        this.pf_h.a(cm.a((byte)114, u.u_d, new String[]{string}), 2, -93);
                    }
                    if (ve2.Ob) {
                        this.pf_h.a(cm.a((byte)120, fj.fj_j, new String[]{string}), 3, -110);
                    }
                } else {
                    this.pf_h.a(cm.a((byte)124, di.C, new String[]{string}), 2, 73);
                    this.pf_h.a(cm.a((byte)89, hl.hl_b, new String[]{string}), 3, 126);
                }
            }
            if (n <= -71) break block7;
            this.pf_f = -11;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final boolean a(int n, int n2, byte by) {
        boolean bl = client.A;
        if (by != -92) {
            this.pf_h = null;
        }
        if (-9 == ~n) {
            u.a((byte)115, this.pf_b, this.pf_e);
            return true;
        }
        if (n == 18) {
            pn.a(38, this.pf_e, this.pf_b);
            return true;
        } else if (n != 11) {
            if (-13 == ~n) {
                eg.a(this.pf_a, n2, 1, (byte)91);
                return true;
            } else if (~n != -14) {
                if (14 != n) {
                    if (~n != -21) {
                        if (-20 != ~n) return false;
                        vm.a(this.pf_j, this.pf_e, this.pf_b, by + -28, this.pf_a);
                        return true;
                    } else {
                        aj.a(-1045);
                    }
                    return true;
                } else {
                    ke.o(0);
                }
                return true;
            } else {
                eg.a(this.pf_a, n2, 2, (byte)91);
            }
            return true;
        } else {
            eg.a(this.pf_a, n2, 0, (byte)73);
        }
        return true;
    }

    static final void a(Applet applet, String string, long l, byte by, String string2) {
        try {
            String string3 = applet.getParameter("cookiehost");
            String string4 = string + "=" + string2 + "; version=1; path=/; domain=" + string3;
            if (by <= 87) {
                return;
            }
            string4 = -1L < (l ^ 0xFFFFFFFFFFFFFFFFL) ? string4 + "; Discard;" : string4 + "; Expires=" + uf.a((byte)60, l * 1000L + ik.a(4)) + "; Max-Age=" + l;
            nc.a((byte)-51, applet, "document.cookie=\"" + string4 + "\"");
        }
        catch (Throwable throwable) {}
    }

    private final String d(int n) {
        String string;
        block0: {
            string = this.pf_m != null ? this.pf_m : this.pf_b;
            if (n <= -65) break block0;
            pf_i = null;
        }
        return string;
    }

    static final String a(char c, byte by) {
        block0: {
            if (by == -9) break block0;
            pf_k = null;
        }
        return String.valueOf(c);
    }

    public static void a(byte by) {
        pf_k = null;
        pf_d = null;
        pf_c = null;
        int n = 3 / ((-2 - by) / 52);
        pf_i = null;
    }

    final boolean a(boolean bl, int n, int n2, int n3, int n4) {
        int n5 = this.pf_h.b(-56, bl);
        if (n5 == -2) {
            return false;
        }
        this.a(n, true, n5);
        this.b(n4, n5, n3);
        this.a(n5, n4, (byte)-92);
        this.a(n3 ^ 0xFFFFFFEE, n5, n2);
        return true;
    }

    final void a(byte by, hl hl2) {
        block7: {
            if (hl2.hl_j) {
                return;
            }
            this.pf_a = hl2.hl_m;
            if (hl2.hl_m == 0) {
                if (qk.qk_i == 0) {
                    this.pf_h.a(vg.vg_p, 12, 95);
                }
                this.pf_h.a(gf.gf_h, 13, -65);
            }
            if (1 == hl2.hl_m) {
                if (wh.wh_d == 0) {
                    this.pf_h.a(ai.L, 12, by + 126);
                }
                this.pf_h.a(dk.dk_d, 13, by + 153);
            }
            if (2 == hl2.hl_m) {
                if (-1 == ~wl.wl_o) {
                    this.pf_h.a(ec.ec_j, 12, by ^ 0xFFFFFFF6);
                }
                this.pf_h.a(ci.ci_g, 13, -77);
            }
            if (by == -51) break block7;
            pf_c = null;
        }
    }

    final void a(int n, byte by, int[] nArray) {
        block8: {
            String string;
            if (by != -43) {
                this.a(85, (byte)40, null);
            }
            if (this.pf_b == null || uc.uc_g == this.pf_e && ~n != -3 || jj.jj_b != 2) break block8;
            String string2 = string = this.d(-66);
            wb wb2 = ed.a(this.pf_b, (byte)-125);
            boolean bl = ik.a(this.pf_b, (byte)-118);
            if (null == wb2 && !bl) {
                this.pf_h.a(cm.a((byte)93, pl.pl_e, new String[]{string}), 4, by + -60);
                this.pf_h.a(cm.a((byte)122, pj.G, new String[]{string}), 6, by ^ 0xC);
                if (null != nArray && ~n != -3 && !wc.wc_n) {
                    this.pf_j = nArray;
                    this.pf_h.a(cm.a((byte)94, ta.ta_h, new String[]{string}), 19, by + -85);
                }
            }
            if (null != wb2) {
                if (!wi.a(-119, this.pf_b) && !wc.wc_n) {
                    if (!wl.wl_p) {
                        this.pf_h.a(cm.a((byte)125, ai.M, new String[]{string}), 8, 89);
                    }
                    this.pf_h.a(cm.a((byte)124, wa.wa_e, new String[]{string}), 18, 80);
                    if (null != nArray) {
                        this.pf_j = nArray;
                        this.pf_h.a(cm.a((byte)99, ta.ta_h, new String[]{string}), 19, by + 140);
                    }
                }
                this.pf_h.a(cm.a((byte)118, cn.cn_ab, new String[]{string}), 5, by ^ 0x66);
            }
            if (bl) {
                this.pf_h.a(cm.a((byte)116, oj.oj_a, new String[]{string}), 7, -12);
            }
        }
    }

    static final void a(boolean bl) {
        jh.jh_h = bl;
        if (null != mg.mg_bc) {
            mg.mg_bc.e(0);
        }
        if (pk.pk_r != 0) {
            qk.a((byte)94);
        }
        l.l_f = 0;
    }

    private final boolean b(int n, int n2, int n3) {
        if (n3 != 0) {
            return false;
        }
        String string = null;
        if (4 == n2) {
            string = rb.a(n, 0, this.pf_b);
        } else if (~n2 != -6) {
            if (~n2 == -7) {
                string = dd.b(this.pf_b, 127, n);
            } else {
                if (7 != n2) {
                    return false;
                }
                string = sg.a(this.pf_b, this.pf_m, n, (byte)126);
            }
        } else {
            string = md.a(n, this.pf_b, false);
        }
        if (null != string) {
            ca.a(this.pf_b, null, string, (byte)-79, 2, 0);
        }
        return true;
    }

    pf(w w2, long l2, String string, String string2, int n, int n2, int[] nArray) {
        this.pf_f = n;
        this.pf_l = w2;
        this.pf_m = string2;
        this.pf_a = n2;
        w2.w_ab = true;
        this.pf_b = string;
        this.pf_j = nArray;
        this.pf_e = l2;
    }

    static {
        pf_i = new int[128];
        pf_c = "Year";
        pf_d = new byte[]{0, 0, (byte)2, 1, 1};
    }
}
