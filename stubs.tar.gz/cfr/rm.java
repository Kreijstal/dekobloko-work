/*
 * Decompiled with CFR 0.152.
 */
final class rm {
    static long rm_c;
    static ui rm_b;
    static ck[] rm_a;

    static final boolean a(int n, int n2, byte by, int n3) {
        int n4 = -27 % ((-37 - by) / 37);
        if (wc.wc_n) {
            return bc.E.a(wh.wh_c, el.G, (byte)126);
        }
        if (jh.jh_h) {
            return tl.b(n, 102, n3);
        }
        if (dc.a(n3, n, 6774)) {
            return true;
        }
        if (wl.wl_p) {
            return false;
        }
        return nm.a(n2, 1, n3);
    }

    static final void a(byte by, String string) {
        block0: {
            vh.vh_f = string;
            if (by == 73) break block0;
            rm_a = null;
        }
    }

    static final void a(int n, ck[] ckArray, int n2, int n3, int n4, int n5) {
        boolean bl = client.A;
        if (null != ckArray) {
            if (-1 <= ~n3) {
                return;
            }
            int n6 = ckArray[0].K;
            int n7 = ckArray[2].K;
            int n8 = ckArray[1].K;
            ckArray[0].a(n2, n, n4);
            ckArray[2].a(-n7 + n2 - -n3, n, n4);
            hk.b(kh.kh_e);
            hk.f(n6 + n2, n, -n7 + (n3 + n2), ckArray[1].C + n);
            int n9 = n2 + n6;
            int n10 = n3 + n2 - n7;
            if (n5 >= -98) {
                rm_a = null;
            }
            n2 = n9;
            while (~n2 > ~n10) {
                ckArray[1].a(n2, n, n4);
                n2 += n8;
            }
            hk.a(kh.kh_e);
            return;
        }
    }

    public static void a(int n) {
        if (n != 2) {
            rm_c = 40L;
        }
        rm_a = null;
        rm_b = null;
    }
}
