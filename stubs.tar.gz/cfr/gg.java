/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

abstract class gg
extends be {
    int K;
    static Random A = new Random();
    int H;
    int z;
    static int B;
    static w y;
    int I;
    int F;
    int C;
    static String E;
    static w G;

    static final lm a(pi[] piArray, int n, byte[] byArray) {
        int[] nArray;
        boolean bl = client.A;
        if (~piArray.length != -257) {
            throw new IllegalArgumentException();
        }
        if (n <= 48) {
            gg.c(-68);
        }
        int[] nArray2 = nArray = new int[256];
        int[] nArray3 = new int[256];
        int[] nArray4 = new int[256];
        int[] nArray5 = new int[256];
        byte[][] byArrayArray = new byte[256][];
        for (int i = 0; 256 > i; ++i) {
            nArray[i] = piArray[i].lc_d;
            nArray3[i] = piArray[i].lc_c;
            nArray4[i] = piArray[i].lc_b;
            nArray5[i] = piArray[i].lc_i;
            byArrayArray[i] = piArray[i].pi_k;
        }
        return new lm(byArray, nArray, nArray3, nArray4, nArray5, byArrayArray);
    }

    static final int b(int n, int n2) {
        if (n2 != 27935) {
            return 72;
        }
        return 5 * ((n - -1) * n);
    }

    static final void a(int n, int n2, int n3, int n4, int n5) {
        uh.a(-9074);
        if (n2 != 20763) {
            gg.b(119, 2);
        }
        hk.f(n4, n, n3, n5);
    }

    public static void c(int n) {
        block0: {
            E = null;
            A = null;
            G = null;
            y = null;
            if (n == 0) break block0;
            gg.c(-109);
        }
    }

    gg() {
    }

    static {
        E = "Disruptive behaviour";
    }
}
