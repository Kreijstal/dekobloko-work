/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

final class me
extends be {
    int[] F;
    static long E;
    static String C;
    static String B;
    static pi J;
    private String[] H;
    private int[][] D;
    static String G;
    private int[] A;
    static int y;
    static jk z;
    static int[] I;

    final void me_a_wl(byte by, wl wl2) {
        block1: {
            int n;
            boolean bl = client.A;
            while (~(n = wl2.d((byte)-88)) != -1) {
                this.a(n, by ^ 0xA26, wl2);
            }
            if (by == 80) break block1;
            wl wl3 = null;
            this.me_a_wl((byte)71, wl3);
        }
    }

    final String f(byte by) {
        StringBuilder stringBuilder;
        boolean bl = client.A;
        StringBuilder stringBuilder2 = stringBuilder = new StringBuilder(80);
        if (by > -57) {
            wl wl2 = null;
            this.me_a_wl((byte)104, wl2);
        }
        if (null == this.H) {
            return "";
        }
        stringBuilder.append(this.H[0]);
        for (int i = 1; this.H.length > i; ++i) {
            stringBuilder2.append("...");
            stringBuilder.append(this.H[i]);
        }
        return stringBuilder2.toString();
    }

    final void d(int n) {
        boolean bl = client.A;
        if (n != 19423) {
            me.c(-120);
        }
        if (this.F != null) {
            int n2 = 0;
            while (~n2 > ~this.F.length) {
                this.F[n2] = de.b(this.F[n2], 32768);
                ++n2;
            }
        }
    }

    public static void c(int n) {
        block0: {
            z = null;
            G = null;
            B = null;
            C = null;
            J = null;
            I = null;
            if (n == 0) break block0;
            y = 75;
        }
    }

    private final void a(int n, int n2, wl wl2) {
        block8: {
            block5: {
                block6: {
                    block7: {
                        boolean bl = client.A;
                        if (n2 != 2678) {
                            return;
                        }
                        if (~n == -2) break block5;
                        if (n == 2) break block6;
                        if (n == 3) break block7;
                        if (n != 4) break block8;
                        break block8;
                    }
                    int n3 = wl2.d((byte)-89);
                    this.D = new int[n3][];
                    this.A = new int[n3];
                    int n4 = 0;
                    while (~n3 < ~n4) {
                        int n5 = wl2.e(3);
                        qm qm2 = je.a(-121, n5);
                        if (null != qm2) {
                            this.A[n4] = n5;
                            this.D[n4] = new int[qm2.qm_f];
                            for (int i = 0; i < qm2.qm_f; ++i) {
                                this.D[n4][i] = wl2.e(qm.b(n2, 2677));
                            }
                        }
                        ++n4;
                    }
                    break block8;
                }
                int n6 = wl2.d((byte)-86);
                this.F = new int[n6];
                for (int i = 0; i < n6; ++i) {
                    this.F[i] = wl2.e(3);
                }
                break block8;
            }
            this.H = ji.a('<', (byte)66, wl2.c((byte)-38));
        }
    }

    static final void me_a_applet(byte by, Applet applet) {
        try {
            URL uRL = applet.getCodeBase();
            String string = gn.a(uRL, -1, applet).getFile();
            nc.a("updatelinks", -14541, applet, new Object[]{"home", string + "home.ws"});
            int n = -128 / ((by - 10) / 61);
            nc.a("updatelinks", -14541, applet, new Object[]{"gamelist", string + "togamelist.ws"});
            nc.a("updatelinks", -14541, applet, new Object[]{"serverlist", string + "toserverlist.ws"});
            nc.a("updatelinks", -14541, applet, new Object[]{"options", string + "options.ws"});
            nc.a("updatelinks", -14541, applet, new Object[]{"terms", string + "terms.ws"});
            nc.a("updatelinks", -14541, applet, new Object[]{"privacy", string + "privacy.ws"});
        }
        catch (Throwable throwable) {}
    }

    me() {
    }

    static final ck a(ck ck2, boolean bl, byte by, boolean bl2) {
        int n;
        int n2;
        int n3;
        int n4;
        ck ck3;
        boolean bl3 = client.A;
        ck2.b();
        ck ck4 = ck3 = new ck(36, 36);
        int n5 = 0;
        while (-19 < ~n5) {
            n4 = 0;
            while (~n4 > -19) {
                n3 = ck2.D[n5 * 18 - -n4];
                if (-1 != ~n3) {
                    n3 += 0x1000000;
                }
                ck4.D[n5 * 72 + 2 * n4] = n3;
                ++n4;
            }
            n4 = 0;
            while (-18 < ~n4) {
                n2 = ck4.D[2 + n4 * 2 + n5 * 72];
                n3 = ck4.D[n4 * 2 + 72 * n5];
                n = ((n2 & 0xFEFEFF) >> -860505119) + ((0xFEFEFF & n3) >> 1709048353);
                if (-1 == ~n && ~(n2 | n3) != -1) {
                    n = 1;
                }
                if (-1 != ~n3 && ~n2 != -1) {
                    n += 0x1000000;
                }
                ck4.D[1 + n5 * 72 - -(n4 * 2)] = n;
                ++n4;
            }
            if (bl2) {
                n4 = ck3.D[34 + 72 * n5];
                n3 = ck3.D[72 * n5];
                n2 = ((0xFEFEFE & n4) >> -1241284703) + ((n3 & 0xFEFEFF) >> 395104033);
                if (n2 == 0 && (n3 | n4) != 0) {
                    n2 = 1;
                }
                if (~n4 != -1 && 0 != n3) {
                    n2 += 0x1000000;
                }
                ck4.D[34 + (n5 * 72 + 1)] = n2;
            }
            ++n5;
        }
        for (n5 = 0; n5 < 17; ++n5) {
            n4 = 0;
            while (-37 < ~n4) {
                n3 = ck3.D[n4 + n5 * 72];
                n2 = ck4.D[n4 + (n5 * 72 + 72)];
                n = ((n2 & 0xFEFEFF) >> 2082759745) + ((0xFEFEFF & n3) >> -1478008351);
                if (~(n3 | n2) > -16777217 && (~(0xFFFFFF & n3) == -1 || (0xFFFFFF & n2) == 0)) {
                    n = 0;
                } else if (~n == -1) {
                    n = 1;
                }
                ck4.D[36 + (n4 + 72 * n5)] = n;
                ++n4;
            }
        }
        if (bl) {
            n5 = 0;
            while (-37 < ~n5) {
                n4 = ck3.D[1224 - -n5];
                n3 = ck3.D[n5];
                n2 = (0x7F7F7F & n4 >> -1625883615) + ((0xFEFEFF & n3) >> 622570241);
                if (~(n3 | n4) > -16777217 && (~(n4 & 0xFFFFFF) == -1 || -1 == ~(0xFFFFFF & n3))) {
                    n2 = 0;
                } else if (~n2 == -1) {
                    n2 = 1;
                }
                ck4.D[36 + n5 + 1224] = n2;
                ++n5;
            }
        }
        n5 = 0;
        while (-19 < ~n5) {
            n4 = 0;
            while (~n4 > -37) {
                n3 = ck4.D[72 * n5 - -n4];
                ck4.D[n4 + 72 * n5] = n3 &= 0xFFFFFF;
                ++n4;
            }
            ++n5;
        }
        n5 = 23 % ((59 - by) / 42);
        return ck4;
    }

    static {
        B = "Orb coins: ";
        G = "By clicking Create, you agree to the <%0><hotspot=0>Terms of Use</hotspot><%1> and <%0><hotspot=1>Privacy Policy</hotspot><%1>.";
        C = "Members";
        J = new pi(0, 0, 0);
        y = 9;
        I = new int[8];
    }
}
