/*
 * Decompiled with CFR 0.152.
 */
abstract class mm
extends be {
    private lc[] z;
    private int[] G;
    private int[] L;
    private int[] P;
    private int[] W;
    int S = 0;
    private int[] V;
    private byte[] y;
    private int[] T;
    private static StringBuilder J = new StringBuilder(100);
    int C;
    int R;
    private static int U;
    private static int Q;
    private static int O;
    private static int I;
    int K;
    private static int N;
    private static int F;
    private static int D;
    private static int H;
    private static int B;
    private static int A;
    private static String[] E;

    static final String a(mm mm2, String string, int n) {
        if (mm2.a(string) <= n) {
            return string;
        }
        int n2 = mm2.a("...");
        int n3 = n - n2;
        int n4 = 0;
        int n5 = 0;
        while (n5 < string.length()) {
            int n6 = mm2.a(string.charAt(n5));
            if (n4 + n6 > n3) {
                return string.substring(0, n5 - 1) + "...";
            }
            n4 += n6;
            ++n5;
        }
        return null;
    }

    private static final int a(byte[][] byArray, byte[][] byArray2, int[] nArray, int[] nArray2, int[] nArray3, int n, int n2) {
        int n3;
        int n4 = nArray[n];
        int n5 = n4 + nArray3[n];
        int n6 = nArray[n2];
        int n7 = n6 + nArray3[n2];
        int n8 = n4;
        if (n6 > n4) {
            n8 = n6;
        }
        int n9 = n5;
        if (n7 < n5) {
            n9 = n7;
        }
        if (nArray2[n2] < (n3 = nArray2[n])) {
            n3 = nArray2[n2];
        }
        byte[] byArray3 = byArray2[n];
        byte[] byArray4 = byArray[n2];
        int n10 = n8 - n4;
        int n11 = n8 - n6;
        for (int i = n8; i < n9; ++i) {
            int n12;
            if ((n12 = byArray3[n10++] + byArray4[n11++]) >= n3) continue;
            n3 = n12;
        }
        return -n3;
    }

    final int a(String string, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
        int n11;
        int n12;
        if (string == null) {
            return 0;
        }
        this.a(n5, n6, n7);
        if (n10 == 0) {
            n10 = this.S;
        }
        int[] nArray = new int[]{n3};
        if (n4 < this.R + this.K + n10 && n4 < n10 + n10) {
            nArray = null;
        }
        int n13 = this.a(string, nArray, E);
        if (n9 == 3 && n13 == 1) {
            n9 = 1;
        }
        if (n9 == 0) {
            n12 = n2 + this.R;
        } else if (n9 == 1) {
            n12 = n2 + this.R + (n4 - this.R - this.K - (n13 - 1) * n10) / 2;
        } else if (n9 == 2) {
            n12 = n2 + n4 - this.K - (n13 - 1) * n10;
        } else {
            n11 = (n4 - this.R - this.K - (n13 - 1) * n10) / (n13 + 1);
            if (n11 < 0) {
                n11 = 0;
            }
            n12 = n2 + this.R + n11;
            n10 += n11;
        }
        for (n11 = 0; n11 < n13; ++n11) {
            if (n8 == 0) {
                this.a(E[n11], n, n12);
            } else if (n8 == 1) {
                this.a(E[n11], n + (n3 - this.a(E[n11])) / 2, n12);
            } else if (n8 == 2) {
                this.a(E[n11], n + n3 - this.a(E[n11]), n12);
            } else if (n11 == n13 - 1) {
                this.a(E[n11], n, n12);
            } else {
                this.c(E[n11], n3);
                this.a(E[n11], n, n12);
                B = 0;
            }
            n12 += n10;
        }
        return n13;
    }

    private final void a(int n, int n2, int n3) {
        F = -1;
        Q = -1;
        U = I = n2;
        D = A = n;
        H = N = n3;
        B = 0;
        O = 0;
    }

    final int b(String string, int n) {
        int n2 = this.a(string, new int[]{n}, E);
        int n3 = 0;
        for (int i = 0; i < n2; ++i) {
            int n4 = this.a(E[i]);
            if (n4 <= n3) continue;
            n3 = n4;
        }
        return n3;
    }

    final int a(String string, int[] nArray, String[] stringArray) {
        int n;
        block37: {
            if (string == null) {
                return 0;
            }
            vf.a(J, -23510, 0, ' ');
            int n2 = 0;
            int n3 = 0;
            int n4 = -1;
            int n5 = 0;
            int n6 = 0;
            int n7 = -1;
            int n8 = 0;
            n = 0;
            int n9 = string.length();
            for (int i = 0; i < n9; ++i) {
                int n10 = string.charAt(i);
                if (n10 == 60) {
                    n7 = i;
                    continue;
                }
                if (n10 == 62 && n7 != -1) {
                    String string2 = string.substring(n7 + 1, i).toLowerCase();
                    n7 = -1;
                    J.append('<');
                    J.append(string2);
                    J.append('>');
                    if (string2.equals("br")) {
                        stringArray[n] = J.toString().substring(n3, J.length());
                        ++n;
                        n3 = J.length();
                        n2 = 0;
                        n4 = -1;
                        n8 = 0;
                    } else if (string2.equals("lt")) {
                        n2 += this.a('<');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 60];
                        }
                        n8 = 60;
                    } else if (string2.equals("gt")) {
                        n2 += this.a('>');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 62];
                        }
                        n8 = 62;
                    } else if (string2.equals("nbsp")) {
                        n2 += this.a('\u00a0');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 160];
                        }
                        n8 = 160;
                    } else if (string2.equals("shy")) {
                        n2 += this.a('\u00ad');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 173];
                        }
                        n8 = 173;
                    } else if (string2.equals("times")) {
                        n2 += this.a('\u00d7');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 215];
                        }
                        n8 = 215;
                    } else if (string2.equals("euro")) {
                        n2 += this.a('\u20ac');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 128];
                        }
                        n8 = 8364;
                    } else if (string2.equals("copy")) {
                        n2 += this.a('\u00a9');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 169];
                        }
                        n8 = 169;
                    } else if (string2.equals("reg")) {
                        n2 += this.a('\u00ae');
                        if (this.y != null && n8 != 0) {
                            n2 += this.y[(n8 << 8) + 174];
                        }
                        n8 = 174;
                    } else if (string2.startsWith("img=")) {
                        try {
                            int n11 = cb.a((byte)-77, string2.substring(4));
                            n2 += this.z[n11].lc_a;
                            n8 = 0;
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                    }
                    n10 = 0;
                }
                if (n7 != -1) continue;
                if (n10 != 0) {
                    J.append((char)n10);
                    n10 = (char)(j.a((char)n10, (byte)28) & 0xFF);
                    n2 += this.L[n10];
                    if (this.y != null && n8 != 0) {
                        n2 += this.y[(n8 << 8) + n10];
                    }
                    n8 = n10;
                }
                if (n10 == 32) {
                    n4 = J.length();
                    n5 = n2;
                    n6 = 1;
                }
                if (nArray != null && n2 > nArray[n < nArray.length ? n : nArray.length - 1] && n4 >= 0) {
                    stringArray[n] = J.toString().substring(n3, n4 - n6);
                    ++n;
                    n3 = n4;
                    n4 = -1;
                    n2 -= n5;
                    n8 = 0;
                }
                if (n10 != 45) continue;
                n4 = J.length();
                n5 = n2;
                n6 = 0;
            }
            if (J.length() <= n3) break block37;
            stringArray[n] = J.toString().substring(n3, J.length());
            ++n;
        }
        return n;
    }

    private final void a(String string, int n, int n2) {
        n2 -= this.S;
        int n3 = -1;
        int n4 = 0;
        int n5 = string.length();
        for (int i = 0; i < n5; ++i) {
            int n6;
            int n7 = string.charAt(i);
            if (n7 == 60) {
                n3 = i;
                continue;
            }
            if (n7 == 62 && n3 != -1) {
                String string2 = string.substring(n3 + 1, i).toLowerCase();
                n3 = -1;
                if (string2.equals("lt")) {
                    n7 = 60;
                } else if (string2.equals("gt")) {
                    n7 = 62;
                } else if (string2.equals("nbsp")) {
                    n7 = 160;
                } else if (string2.equals("shy")) {
                    n7 = 173;
                } else if (string2.equals("times")) {
                    n7 = 215;
                } else if (string2.equals("euro")) {
                    n7 = 8364;
                } else if (string2.equals("copy")) {
                    n7 = 169;
                } else if (string2.equals("reg")) {
                    n7 = 174;
                } else {
                    if (string2.startsWith("img=")) {
                        try {
                            int n8;
                            n6 = cb.a((byte)40, string2.substring(4));
                            lc lc2 = this.z[n6];
                            int n9 = n8 = this.W != null ? this.W[n6] : lc2.lc_g;
                            if (H == 256) {
                                lc2.a(n, n2 + this.S - n8);
                            } else {
                                lc2.a(n, n2 + this.S - n8, H);
                            }
                            n += lc2.lc_a;
                            n4 = 0;
                        }
                        catch (Exception exception) {}
                        continue;
                    }
                    this.b(string2);
                    continue;
                }
            }
            if (n3 != -1) continue;
            n7 = (char)(j.a((char)n7, (byte)28) & 0xFF);
            if (this.y != null && n4 != 0) {
                n += this.y[(n4 << 8) + n7];
            }
            int n10 = this.V[n7];
            n6 = this.G[n7];
            int n11 = n;
            if (n7 != 32) {
                if (H == 256) {
                    if (U != -1) {
                        this.a(n7, n + this.T[n7] + 1, n2 + this.P[n7] + 1, n10, n6, U, true);
                    }
                    this.a(n7, n + this.T[n7], n2 + this.P[n7], n10, n6, D, false);
                } else {
                    if (U != -1) {
                        this.a(n7, n + this.T[n7] + 1, n2 + this.P[n7] + 1, n10, n6, U, H, true);
                    }
                    this.a(n7, n + this.T[n7], n2 + this.P[n7], n10, n6, D, H, false);
                }
            } else if (B > 0) {
                n += (O += B) >> 8;
                O &= 0xFF;
            }
            n += this.L[n7];
            if (F != -1) {
                hk.a(n11, n2 + (int)((double)this.S * 0.7), n - n11, F);
            }
            if (Q != -1) {
                hk.a(n11, n2 + this.S + 1, n - n11, Q);
            }
            n4 = n7;
        }
    }

    final int a(char c) {
        return this.L[j.a(c, (byte)28) & 0xFF];
    }

    final int a(String string) {
        if (string == null) {
            return 0;
        }
        int n = -1;
        int n2 = 0;
        int n3 = 0;
        int n4 = string.length();
        for (int i = 0; i < n4; ++i) {
            int n5 = string.charAt(i);
            if (n5 == 60) {
                n = i;
                continue;
            }
            if (n5 == 62 && n != -1) {
                String string2 = string.substring(n + 1, i).toLowerCase();
                n = -1;
                if (string2.equals("lt")) {
                    n5 = 60;
                } else if (string2.equals("gt")) {
                    n5 = 62;
                } else if (string2.equals("nbsp")) {
                    n5 = 160;
                } else if (string2.equals("shy")) {
                    n5 = 173;
                } else if (string2.equals("times")) {
                    n5 = 215;
                } else if (string2.equals("euro")) {
                    n5 = 8364;
                } else if (string2.equals("copy")) {
                    n5 = 169;
                } else if (string2.equals("reg")) {
                    n5 = 174;
                } else {
                    if (!string2.startsWith("img=")) continue;
                    try {
                        int n6 = cb.a((byte)91, string2.substring(4));
                        n3 += this.z[n6].lc_a;
                        n2 = 0;
                    }
                    catch (Exception exception) {}
                    continue;
                }
            }
            if (n != -1) continue;
            n5 = (char)(j.a((char)n5, (byte)28) & 0xFF);
            n3 += this.L[n5];
            if (this.y != null && n2 != 0) {
                n3 += this.y[(n2 << 8) + n5];
            }
            n2 = n5;
        }
        return n3;
    }

    final void a(lc[] lcArray, int[] nArray) {
        if (nArray != null && nArray.length != lcArray.length) {
            throw new IllegalArgumentException();
        }
        this.z = lcArray;
        this.W = nArray;
    }

    private final void b(String string) {
        try {
            if (string.startsWith("col=")) {
                D = bh.a(16, false, string.substring(4));
            } else if (string.equals("/col")) {
                D = A;
            } else if (string.startsWith("trans=")) {
                H = cb.a((byte)46, string.substring(6));
            } else if (string.equals("/trans")) {
                H = N;
            } else if (string.startsWith("str=")) {
                F = bh.a(16, false, string.substring(4));
            } else if (string.equals("str")) {
                F = 0x800000;
            } else if (string.equals("/str")) {
                F = -1;
            } else if (string.startsWith("u=")) {
                Q = bh.a(16, false, string.substring(2));
            } else if (string.equals("u")) {
                Q = 0;
            } else if (string.equals("/u")) {
                Q = -1;
            } else if (string.startsWith("shad=")) {
                U = bh.a(16, false, string.substring(5));
            } else if (string.equals("shad")) {
                U = 0;
            } else if (string.equals("/shad")) {
                U = I;
            } else if (string.equals("br")) {
                this.a(A, I, N);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    final void b(String string, int n, int n2, int n3, int n4) {
        if (string == null) {
            return;
        }
        this.b(n3, n4);
        this.a(string, n - this.a(string) / 2, n2);
    }

    abstract void a(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8);

    private final void b(int n, int n2) {
        F = -1;
        Q = -1;
        U = I = n2;
        D = A = n;
        N = 256;
        H = 256;
        B = 0;
        O = 0;
    }

    final void a(String string, int n, int n2, int n3, int n4) {
        if (string == null) {
            return;
        }
        this.b(n3, n4);
        this.a(string, n, n2);
    }

    private final void a(byte[] byArray) {
        this.L = new int[256];
        if (byArray.length == 257) {
            for (int i = 0; i < this.L.length; ++i) {
                this.L[i] = byArray[i] & 0xFF;
            }
            this.S = byArray[256] & 0xFF;
        } else {
            int n;
            int n2;
            int n3;
            int n4 = 0;
            for (int i = 0; i < 256; ++i) {
                this.L[i] = byArray[n4++] & 0xFF;
            }
            int[] nArray = new int[256];
            int[] nArray2 = new int[256];
            for (n3 = 0; n3 < 256; ++n3) {
                nArray[n3] = byArray[n4++] & 0xFF;
            }
            for (n3 = 0; n3 < 256; ++n3) {
                nArray2[n3] = byArray[n4++] & 0xFF;
            }
            byte[][] byArrayArray = new byte[256][];
            for (int i = 0; i < 256; ++i) {
                byArrayArray[i] = new byte[nArray[i]];
                n2 = 0;
                for (n = 0; n < byArrayArray[i].length; ++n) {
                    n2 = (byte)(n2 + byArray[n4++]);
                    byArrayArray[i][n] = (byte)n2;
                }
            }
            byte[][] byArrayArray2 = new byte[256][];
            for (n2 = 0; n2 < 256; ++n2) {
                byArrayArray2[n2] = new byte[nArray[n2]];
                n = 0;
                for (int i = 0; i < byArrayArray2[n2].length; ++i) {
                    n = (byte)(n + byArray[n4++]);
                    byArrayArray2[n2][i] = (byte)n;
                }
            }
            this.y = new byte[65536];
            for (n2 = 0; n2 < 256; ++n2) {
                if (n2 == 32 || n2 == 160) continue;
                for (n = 0; n < 256; ++n) {
                    if (n == 32 || n == 160) continue;
                    this.y[(n2 << 8) + n] = (byte)mm.a(byArrayArray, byArrayArray2, nArray2, this.L, nArray, n2, n);
                }
            }
            this.S = nArray2[32] + nArray[32];
        }
    }

    abstract void a(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7);

    final int a(String string, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9) {
        return this.a(string, n, n2, n3, n4, n5, n6, 256, n7, n8, n9);
    }

    final void b(String string, int n, int n2, int n3, int n4, int n5) {
        if (string == null) {
            return;
        }
        this.a(n3, n4, n5);
        this.a(string, n - this.a(string) / 2, n2);
    }

    final void a(String string, int n, int n2, int n3, int n4, int n5) {
        if (string == null) {
            return;
        }
        this.a(n3, n4, n5);
        this.a(string, n - this.a(string), n2);
    }

    final int b(String string, int n, int n2) {
        if (n2 == 0) {
            n2 = this.S;
        }
        int n3 = this.a(string, new int[]{n}, E);
        int n4 = (n3 - 1) * n2;
        return this.R + n4 + this.K;
    }

    final void c(String string, int n, int n2, int n3, int n4) {
        if (string == null) {
            return;
        }
        this.b(n3, n4);
        this.a(string, n - this.a(string), n2);
    }

    public static void a() {
        J = null;
        E = null;
    }

    final int a(String string, int n) {
        return this.a(string, new int[]{n}, E);
    }

    final void c(String string, int n, int n2, int n3, int n4, int n5) {
        if (string == null) {
            return;
        }
        this.a(n3, n4, n5);
        this.a(string, n, n2);
    }

    private final void c(String string, int n) {
        int n2 = 0;
        boolean bl = false;
        int n3 = string.length();
        for (int i = 0; i < n3; ++i) {
            char c = string.charAt(i);
            if (c == '<') {
                bl = true;
                continue;
            }
            if (c == '>') {
                bl = false;
                continue;
            }
            if (bl || c != ' ') continue;
            ++n2;
        }
        if (n2 > 0) {
            B = (n - this.a(string) << 8) / n2;
            return;
        }
    }

    static final String c(String string) {
        int n;
        int n2 = string.length();
        int n3 = 0;
        for (int i = 0; i < n2; ++i) {
            n = string.charAt(i);
            if (n != 60 && n != 62) continue;
            n3 += 3;
        }
        StringBuilder stringBuilder = new StringBuilder(n2 + n3);
        for (n = 0; n < n2; ++n) {
            char c = string.charAt(n);
            if (c == '<') {
                stringBuilder.append("<lt>");
                continue;
            }
            if (c == '>') {
                stringBuilder.append("<gt>");
                continue;
            }
            stringBuilder.append(c);
        }
        return stringBuilder.toString();
    }

    mm(byte[] byArray, int[] nArray, int[] nArray2, int[] nArray3, int[] nArray4) {
        this.T = nArray;
        this.P = nArray2;
        this.V = nArray3;
        this.G = nArray4;
        this.a(byArray);
        int n = Integer.MAX_VALUE;
        int n2 = Integer.MIN_VALUE;
        for (int i = 0; i < 256; ++i) {
            if (this.P[i] < n && this.G[i] != 0) {
                n = this.P[i];
            }
            if (this.P[i] + this.G[i] <= n2) continue;
            n2 = this.P[i] + this.G[i];
        }
        this.R = this.S - n;
        this.K = n2 - this.S;
        this.C = this.S - this.P[88];
    }

    static {
        O = 0;
        U = -1;
        Q = -1;
        I = -1;
        H = 256;
        N = 256;
        A = 0;
        F = -1;
        B = 0;
        D = 0;
        E = new String[100];
    }
}
