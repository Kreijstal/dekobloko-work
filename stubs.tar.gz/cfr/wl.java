/*
 * Decompiled with CFR 0.152.
 */
import java.math.BigInteger;

class wl
extends bh {
    byte[] wl_r;
    int wl_n = 0;
    static String wl_s;
    static boolean wl_p;
    static int wl_o;
    static String wl_q;

    final int h(int n) {
        if (n != 65280) {
            this.g(20);
        }
        this.wl_n += 3;
        return ((this.wl_r[this.wl_n - 3] & 0xFF) << 1300671472) + ((0xFF00 & this.wl_r[this.wl_n - 2] << -1993524632) - -(0xFF & this.wl_r[this.wl_n - 1]));
    }

    final int e(byte by) {
        int n = -108 % ((by - 71) / 55);
        int n2 = this.wl_r[this.wl_n] & 0xFF;
        if (~n2 > -129) {
            return -64 + this.d((byte)-78);
        }
        return this.e(3) + -49152;
    }

    final long f(byte by) {
        long l = (long)this.i(7553) & 0xFFFFFFFFL;
        if (by != -108) {
            return 17L;
        }
        long l2 = (long)this.i(by ^ 0xFFFFE215) & 0xFFFFFFFFL;
        return l2 + (l << 1053413728);
    }

    final void a(int n, String string) {
        int n2 = string.indexOf(0);
        if (n2 >= 0) {
            throw new IllegalArgumentException("");
        }
        this.wl_n += da.a(string.length(), this.wl_n, -8218, string, this.wl_r, n);
        this.wl_r[this.wl_n++] = 0;
    }

    final void b(int n, boolean bl) {
        if (!bl) {
            this.f(22);
        }
        this.wl_r[this.wl_n - (n - -1)] = (byte)n;
    }

    final void a(byte[] byArray, int n, byte by, int n2) {
        boolean bl = client.A;
        if (by < 124) {
            return;
        }
        for (int i = n; i < n2 + n; ++i) {
            byArray[i] = this.wl_r[this.wl_n++];
        }
    }

    final void a(long l, byte by) {
        this.wl_r[this.wl_n++] = (byte)(l >> 2067771960);
        if (by != 0) {
            return;
        }
        this.wl_r[this.wl_n++] = (byte)(l >> 616442608);
        this.wl_r[this.wl_n++] = (byte)(l >> 2048124072);
        this.wl_r[this.wl_n++] = (byte)(l >> 276000096);
        this.wl_r[this.wl_n++] = (byte)(l >> -257706600);
        this.wl_r[this.wl_n++] = (byte)(l >> 685028240);
        this.wl_r[this.wl_n++] = (byte)(l >> -1661920632);
        this.wl_r[this.wl_n++] = (byte)l;
    }

    final int i(int n) {
        block0: {
            this.wl_n += 4;
            if (n == 7553) break block0;
            wl_o = -83;
        }
        return (0xFF00 & this.wl_r[this.wl_n - 2] << 1869128008) + (this.wl_r[-3 + this.wl_n] << 1115022384 & 0xFF0000) + (((this.wl_r[-4 + this.wl_n] & 0xFF) << 926323544) + (0xFF & this.wl_r[-1 + this.wl_n]));
    }

    final int e(int n) {
        if (n != 3) {
            this.a(false);
        }
        this.wl_n += 2;
        return (0xFF & this.wl_r[this.wl_n + -1]) + ((0xFF & this.wl_r[this.wl_n + -2]) << -248574136);
    }

    final int a(byte by, int n) {
        if (by != -15) {
            return 11;
        }
        int n2 = pe.a(this.wl_r, this.wl_n, -109, n);
        this.a(n2, false);
        return n2;
    }

    final String c(byte by) {
        int n = this.wl_n;
        if (by != -38) {
            this.wl_r = null;
        }
        while (-1 != ~this.wl_r[this.wl_n++]) {
        }
        int n2 = -1 + -n + this.wl_n;
        if (n2 == 0) {
            return "";
        }
        return un.a(this.wl_r, 0, n, n2);
    }

    final String c(int n) {
        if (n != -16829) {
            this.wl_r = null;
        }
        if (-1 == ~this.wl_r[this.wl_n]) {
            ++this.wl_n;
            return null;
        }
        return this.c((byte)-38);
    }

    final boolean g(int n) {
        int n2;
        this.wl_n -= 4;
        int n3 = pe.a(this.wl_r, this.wl_n, -112, n);
        return n3 == (n2 = this.i(7553));
    }

    final void d(int n, int n2) {
        block0: {
            this.wl_r[this.wl_n++] = (byte)(n2 >> 2116451496);
            this.wl_r[this.wl_n++] = (byte)n2;
            if (n == -1) break block0;
            this.c((byte)-104);
        }
    }

    final int a(int n) {
        boolean bl = client.A;
        byte by = this.wl_r[this.wl_n++];
        int n2 = -49 / ((n - 60) / 55);
        int n3 = 0;
        while (~by > -1) {
            n3 = (n3 | 0x7F & by) << 1821124103;
            by = this.wl_r[this.wl_n++];
        }
        return n3 | by;
    }

    final void b(boolean bl, int n) {
        this.wl_r[-2 + (-n + this.wl_n)] = (byte)(n >> 1813211912);
        if (!bl) {
            wl_p = false;
        }
        this.wl_r[-1 + this.wl_n - n] = (byte)n;
    }

    final void a(int n, long l) {
        this.wl_r[this.wl_n++] = (byte)(l >> -1562537760);
        this.wl_r[this.wl_n++] = (byte)(l >> -235841960);
        this.wl_r[this.wl_n++] = (byte)(l >> 1970006928);
        if (n > -70) {
            return;
        }
        this.wl_r[this.wl_n++] = (byte)(l >> 948247560);
        this.wl_r[this.wl_n++] = (byte)l;
    }

    final void a(boolean bl, int n, byte[] byArray, int n2) {
        boolean bl2 = client.A;
        if (bl) {
            this.f(50);
        }
        for (int i = n2; i < n + n2; ++i) {
            this.wl_r[this.wl_n++] = byArray[i];
        }
    }

    final void a(int n, boolean bl) {
        this.wl_r[this.wl_n++] = (byte)(n >> -271514312);
        this.wl_r[this.wl_n++] = (byte)(n >> 570127632);
        this.wl_r[this.wl_n++] = (byte)(n >> -762997816);
        if (bl) {
            wl_o = -50;
        }
        this.wl_r[this.wl_n++] = (byte)n;
    }

    private final void a(long l, int n) {
        this.wl_r[this.wl_n++] = (byte)(l >> -1151961680);
        if (n != -34637912) {
            return;
        }
        this.wl_r[this.wl_n++] = (byte)(l >> -34637912);
        this.wl_r[this.wl_n++] = (byte)(l >> 1086883104);
        this.wl_r[this.wl_n++] = (byte)(l >> 630212760);
        this.wl_r[this.wl_n++] = (byte)(l >> -549746352);
        this.wl_r[this.wl_n++] = (byte)(l >> -110093432);
        this.wl_r[this.wl_n++] = (byte)l;
    }

    final void a(BigInteger bigInteger, BigInteger bigInteger2, boolean bl) {
        if (!bl) {
            return;
        }
        int n = this.wl_n;
        this.wl_n = 0;
        byte[] byArray = new byte[n];
        this.a(byArray, 0, (byte)125, n);
        BigInteger bigInteger3 = new BigInteger(byArray);
        BigInteger bigInteger4 = bigInteger3.modPow(bigInteger, bigInteger2);
        byte[] byArray2 = bigInteger4.toByteArray();
        this.wl_n = 0;
        this.d(-1, byArray2.length);
        this.a(false, byArray2.length, byArray2, 0);
    }

    final void e(int n, int n2) {
        boolean bl = client.A;
        if (n <= 87) {
            wl.d(11);
        }
        while (~this.wl_n > ~n2) {
            this.wl_r[this.wl_n++] = 0;
        }
    }

    final int d(byte by) {
        if (by >= -18) {
            return 39;
        }
        return 0xFF & this.wl_r[this.wl_n++];
    }

    final void b(int n, int n2) {
        int n3 = 24 % ((-42 - n) / 34);
        if (n2 < 64 && -64 <= n2) {
            this.a(true, n2 + 64);
            return;
        }
        if (~n2 > -16385 && -16384 <= n2) {
            this.d(-1, 49152 + n2);
            return;
        }
        throw new IllegalArgumentException();
    }

    final void a(byte by, int[] nArray) {
        block2: {
            boolean bl = client.A;
            int n = this.wl_n / 8;
            this.wl_n = 0;
            int n2 = 0;
            while (~n < ~n2) {
                int n3 = this.i(7553);
                int n4 = this.i(7553);
                int n5 = 0;
                int n6 = -1640531527;
                int n7 = 32;
                while (0 < n7--) {
                    n4 += (n5 += n6) - -nArray[(n5 & 0x1BC4) >>> 969158955] ^ (n3 += n5 - -nArray[3 & n5] ^ (n4 >>> 14594309 ^ n4 << -1673337436) - -n4) + (n3 << -1811365180 ^ n3 >>> -1964008539);
                }
                this.wl_n -= 8;
                this.a(n3, false);
                this.a(n4, false);
                ++n2;
            }
            if (by < -4) break block2;
            wl_s = null;
        }
    }

    final String b(boolean bl) {
        byte by;
        if (0 != (by = this.wl_r[this.wl_n++])) {
            throw new IllegalStateException("");
        }
        int n = this.wl_n;
        while (this.wl_r[this.wl_n++] != 0) {
        }
        int n2 = -1 + this.wl_n + -n;
        if (!bl) {
            wl_p = true;
        }
        if (n2 == 0) {
            return "";
        }
        return un.a(this.wl_r, 0, n, n2);
    }

    final void c(int n, int n2) {
        if (0 <= n && ~n > -129) {
            this.a(true, n);
            return;
        }
        if (n >= 0 && 32768 > n) {
            this.d(-1, n + 32768);
            return;
        }
        if (n2 != 57) {
            this.wl_n = 112;
        }
        throw new IllegalArgumentException();
    }

    final void b(byte by, int n) {
        if (by != 46) {
            wl_q = null;
        }
        this.wl_r[this.wl_n++] = (byte)(n >> 1945402352);
        this.wl_r[this.wl_n++] = (byte)(n >> 1137364040);
        this.wl_r[this.wl_n++] = (byte)n;
    }

    final void a(String string, boolean bl) {
        boolean bl2 = client.A;
        long l = 0L;
        long l2 = 0L;
        int n = string.length();
        int n2 = 19;
        while (~n2 <= -1) {
            l *= 38L;
            if (n > n2) {
                char c = string.charAt(n2);
                l = c < 'A' || c > 'Z' ? ('a' <= c && c <= 'z' ? (l += (long)(-95 + c)) : ('0' > c || '9' < c ? ++l : (l += (long)(-20 - -c)))) : (l += (long)(c + 2 - 65));
            }
            if (10 == n2) {
                l2 = l;
                l = 0L;
            }
            --n2;
        }
        if (!bl) {
            this.a(false);
        }
        this.a(l, -34637912);
        this.a(l2, -34637912);
    }

    public static void d(int n) {
        if (n != 8) {
            wl_q = null;
        }
        wl_q = null;
        wl_s = null;
    }

    final int a(boolean bl) {
        if (bl) {
            return -54;
        }
        int n = 0xFF & this.wl_r[this.wl_n];
        if (-129 >= ~n) {
            return this.e(3) - 32768;
        }
        return this.d((byte)-32);
    }

    final byte g(byte by) {
        if (by > -83) {
            this.a(false);
        }
        return this.wl_r[this.wl_n++];
    }

    wl(int n) {
        this.wl_r = uj.a(5, n);
    }

    final int f(int n) {
        if (n != 21663) {
            this.i(-114);
        }
        if (-1 < ~this.wl_r[this.wl_n]) {
            return Integer.MAX_VALUE & this.i(7553);
        }
        return this.e(3);
    }

    final void a(boolean bl, int n) {
        block0: {
            this.wl_r[this.wl_n++] = (byte)n;
            if (bl) break block0;
            wl_o = 83;
        }
    }

    wl(byte[] byArray) {
        this.wl_r = byArray;
    }

    final void b(int n, String string) {
        int n2;
        if (n != 8) {
            this.f(-80);
        }
        if ((n2 = string.indexOf(0)) >= 0) {
            throw new IllegalArgumentException("");
        }
        this.wl_r[this.wl_n++] = 0;
        this.wl_n += da.a(string.length(), this.wl_n, -8218, string, this.wl_r, 0);
        this.wl_r[this.wl_n++] = 0;
    }

    final void a(byte by, int n, int[] nArray, int n2) {
        boolean bl = client.A;
        int n3 = this.wl_n;
        this.wl_n = n;
        if (by < 10) {
            this.wl_r = null;
        }
        int n4 = (-n + n2) / 8;
        for (int i = 0; i < n4; ++i) {
            int n5 = this.i(7553);
            int n6 = this.i(7553);
            int n7 = -957401312;
            int n8 = -1640531527;
            int n9 = 32;
            while (-1 > ~n9--) {
                n5 -= (n7 -= n8) + nArray[3 & n7] ^ ((n6 -= n7 - -nArray[(0x1D3B & n7) >>> 1467095883] ^ n5 + (n5 << -1602078364 ^ n5 >>> -798506139)) >>> -1334700603 ^ n6 << 1171830180) + n6;
            }
            this.wl_n -= 8;
            this.a(n5, false);
            this.a(n6, false);
        }
        this.wl_n = n3;
    }

    static {
        wl_o = 2;
        wl_s = "Defeated";
        wl_q = "This option is restricted. Your rating is currently <%0>.<br>Can you achieve the qualifying rating of <%1>?";
    }
}
