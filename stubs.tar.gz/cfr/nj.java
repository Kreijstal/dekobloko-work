/*
 * Decompiled with CFR 0.152.
 */
final class nj
extends mm {
    private byte[][] M = new byte[256][];

    private static final byte[][] a(int[] nArray, byte[][] byArray) {
        int n;
        for (int i = 0; i < nArray.length; ++i) {
            n = nArray[i];
            int n2 = (n >> 15 & 0x1FE) + (n & 0xFF);
            nArray[i] = n2 / 3 + (n >> 8 & 0xFF) >> 1;
        }
        byte[][] byArray2 = byArray;
        for (n = 0; n < byArray2.length; ++n) {
            byte[] byArray3 = byArray2[n];
            for (int i = 0; i < byArray3.length; ++i) {
                byte by = byArray3[i];
                if (by == 0) continue;
                byArray3[i] = (byte)nArray[by];
            }
        }
        return byArray;
    }

    @Override
    final void a(int n, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        int n7;
        int n8 = n2 + n3 * hk.hk_j;
        int n9 = hk.hk_j - n4;
        int n10 = 0;
        int n11 = 0;
        if (n3 < hk.hk_h) {
            n7 = hk.hk_h - n3;
            n5 -= n7;
            n3 = hk.hk_h;
            n11 += n7 * n4;
            n8 += n7 * hk.hk_j;
        }
        if (n3 + n5 > hk.hk_b) {
            n5 -= n3 + n5 - hk.hk_b;
        }
        if (n2 < hk.hk_c) {
            n7 = hk.hk_c - n2;
            n4 -= n7;
            n2 = hk.hk_c;
            n11 += n7;
            n8 += n7;
            n10 += n7;
            n9 += n7;
        }
        if (n2 + n4 > hk.hk_g) {
            n7 = n2 + n4 - hk.hk_g;
            n4 -= n7;
            n10 += n7;
            n9 += n7;
        }
        if (n4 > 0) {
            if (n5 <= 0) {
                return;
            }
            if (bl) {
                lm.a(hk.hk_l, this.M[n], n6, n11, n8, n4, n5, n9, n10);
            } else {
                nj.a(hk.hk_l, this.M[n], n6, n11, n8, n4, n5, n9, n10);
            }
            return;
        }
    }

    @Override
    final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, boolean bl) {
        int n8;
        int n9 = n2 + n3 * hk.hk_j;
        int n10 = hk.hk_j - n4;
        int n11 = 0;
        int n12 = 0;
        if (n3 < hk.hk_h) {
            n8 = hk.hk_h - n3;
            n5 -= n8;
            n3 = hk.hk_h;
            n12 += n8 * n4;
            n9 += n8 * hk.hk_j;
        }
        if (n3 + n5 > hk.hk_b) {
            n5 -= n3 + n5 - hk.hk_b;
        }
        if (n2 < hk.hk_c) {
            n8 = hk.hk_c - n2;
            n4 -= n8;
            n2 = hk.hk_c;
            n12 += n8;
            n9 += n8;
            n11 += n8;
            n10 += n8;
        }
        if (n2 + n4 > hk.hk_g) {
            n8 = n2 + n4 - hk.hk_g;
            n4 -= n8;
            n11 += n8;
            n10 += n8;
        }
        if (n4 > 0) {
            if (n5 <= 0) {
                return;
            }
            if (bl) {
                lm.a(hk.hk_l, this.M[n], n6, n12, n9, n4, n5, n10, n11, n7);
            } else {
                nj.a(hk.hk_l, this.M[n], n6, n12, n9, n4, n5, n10, n11, n7);
            }
            return;
        }
    }

    private static final void a(int[] nArray, byte[] byArray, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        for (int i = -n5; i < 0; ++i) {
            for (int j = -n4; j < 0; ++j) {
                int n9;
                if ((n9 = (0xFF & byArray[n2++]) * n8 >> 8) != 0) {
                    int n10 = ((n & 0xFF00FF) * n9 & 0xFF00FF00) + ((n & 0xFF00) * n9 & 0xFF0000) >> 8;
                    n9 = 256 - n9;
                    int n11 = nArray[n3];
                    nArray[n3++] = (((n11 & 0xFF00FF) * n9 & 0xFF00FF00) + ((n11 & 0xFF00) * n9 & 0xFF0000) >> 8) + n10;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    private static final void a(int[] nArray, byte[] byArray, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        for (int i = -n5; i < 0; ++i) {
            for (int j = -n4; j < 0; ++j) {
                int n8;
                if ((n8 = 0xFF & byArray[n2++]) != 0) {
                    int n9 = ((n & 0xFF00FF) * n8 & 0xFF00FF00) + ((n & 0xFF00) * n8 & 0xFF0000) >> 8;
                    n8 = 256 - n8;
                    int n10 = nArray[n3];
                    nArray[n3++] = (((n10 & 0xFF00FF) * n8 & 0xFF00FF00) + ((n10 & 0xFF00) * n8 & 0xFF0000) >> 8) + n9;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    nj(byte[] byArray, int[] nArray, int[] nArray2, int[] nArray3, int[] nArray4, int[] nArray5, byte[][] byArray2) {
        super(byArray, nArray, nArray2, nArray3, nArray4);
        this.M = nj.a(nArray5, byArray2);
    }
}
