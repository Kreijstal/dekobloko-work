/*
 * Decompiled with CFR 0.152.
 */
final class uc {
    static hm uc_e;
    static boolean uc_a;
    static long uc_g;
    static af uc_c;
    static int uc_d;
    static String uc_f;
    static String uc_b;

    public static void a(boolean bl) {
        uc_e = null;
        if (!bl) {
            return;
        }
        uc_b = null;
        uc_c = null;
        uc_f = null;
    }

    static final void a(boolean bl, boolean bl2, int n) {
        if (!bl) {
            hk.b();
        } else {
            hk.a(0, 0, hk.hk_j, hk.hk_i, 0, 192);
        }
        if (n <= 39) {
            return;
        }
        cg.a(bl, 91);
    }

    static final void a(int n, boolean bl, boolean bl2, int n2) {
        if (!bl) {
            uc_b = null;
        }
        si.a(kf.O, bl2, nk.nk_b, hn.hn_a, n, (byte)-41, n2);
    }

    static final void a(int n, boolean bl, int n2, int n3, int n4, int n5, ve ve2, boolean bl2) {
        block31: {
            boolean bl3 = client.A;
            if (~n5 < ~n2) {
                int n6;
                int n7;
                qd[] qdArray;
                qd[] qdArray2 = qdArray = qa.qa_v[0 == ~n2 ? 1 : n2 + 4];
                boolean bl4 = true;
                if (bl) {
                    if (n2 == -1) {
                        for (n7 = 0; b.P.length > n7; ++n7) {
                            if ((kk.kk_l[n7 / 8] & 1 << (7 & n7)) == 0) continue;
                            bl4 = false;
                            break;
                        }
                    } else {
                        for (n7 = 0; qdArray.length + -1 > n7; ++n7) {
                            if (0 == (v.v_a[(n3 + n7) / 8] & 1 << (7 & n3 + n7))) continue;
                            bl4 = false;
                            break;
                        }
                        n3 += 0xFF & rb.rb_k[n2];
                    }
                }
                n7 = 0;
                for (n6 = 0; n6 < (~n2 == 0 ? b.P.length : -1 + qdArray.length); ++n6) {
                    boolean bl5;
                    if (0 == ~n2) {
                        n = n6;
                    } else {
                        km.D[n2] = (byte)n6;
                    }
                    if (0 == ~n2 && b.P.length == 1) {
                        bl5 = true;
                    } else {
                        qd qd2 = qdArray[1 + n6];
                        if (!bl) {
                            bl5 = ~n2 == 0 ? ~cd.cd_m.ve_mc == ~b.P[n6] : ~n6 == ~(0xFF & cd.cd_m.ve_kc[n2]);
                        } else {
                            boolean bl6 = bl5 = qd2.w_ab || bl4 && qd2.Hb;
                        }
                    }
                    if (bl5) {
                        uc.a(n, bl, n2 - -1, n3, n4, n5, ve2, false);
                        n7 = 1;
                    }
                    if (!ve.ve_ac) continue;
                    return;
                }
                if (n7 == 0) {
                    for (n6 = 0; n6 < -1 + qdArray.length; ++n6) {
                        if (-1 != n2) {
                            km.D[n2] = (byte)n6;
                        } else {
                            n = n6;
                        }
                        uc.a(n, bl, 1 + n2, n3, n4, n5, ve2, false);
                        if (!ve.ve_ac) continue;
                        return;
                    }
                }
            } else {
                boolean bl7 = true;
                block4: for (int k = 0; bc.D.length > k; ++k) {
                    int n8;
                    int[] nArray = bc.D[k];
                    boolean bl8 = false;
                    int n9 = 0;
                    while (~n9 > ~nArray.length) {
                        n8 = nArray[n9];
                        int n10 = nArray[1 + n9];
                        if (~n8 != 0) {
                            if (~n2 == ~n8 && n4 == n10) {
                                bl8 = true;
                            } else if (n2 <= n8 || ~(km.D[n8] & 0xFF) != ~n10) continue block4;
                        } else if (~b.P[n] != ~n10) continue block4;
                        n9 += 2;
                    }
                    if (!bl8 && ~n2 != ~j.j_b) continue;
                    bl7 = false;
                    n9 = 0;
                    while (~n9 > ~nArray.length) {
                        n8 = nArray[n9];
                        if (~n8 != 0) {
                            if (~n8 > ~n2) {
                                rd.rd_c[n8] = true;
                            }
                        } else {
                            gd.gd_b = true;
                        }
                        n9 += 2;
                    }
                }
                if (bl7) {
                    ve.ve_ac = true;
                }
            }
            if (!bl2) break block31;
            uc_b = null;
        }
    }

    static {
        uc_a = true;
        uc_c = new af();
        uc_f = "Accept";
        uc_b = "Lobby";
    }
}
