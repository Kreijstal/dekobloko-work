/*
 * Decompiled with CFR 0.152.
 */
final class oc {
    static int oc_c;
    static vj oc_b;
    static String oc_d;
    private int[] oc_a;

    public static void a(boolean bl) {
        if (!bl) {
            oc_d = null;
        }
        oc_d = null;
        oc_b = null;
    }

    final int a(byte by, int n) {
        boolean bl = client.A;
        int n2 = -1 + (this.oc_a.length >> 1043895585);
        if (by != -68) {
            return 51;
        }
        int n3 = n2 & n;
        int n4;
        while (0 != ~(n4 = this.oc_a[1 + (n3 + n3)])) {
            if (this.oc_a[n3 - -n3] == n) {
                return n4;
            }
            n3 = 1 + n3 & n2;
        }
        return -1;
    }

    static final ij[] a(byte by) {
        if (by != 27) {
            oc.a(false);
        }
        return new ij[]{ah.ah_f, ge.ge_g, hn.hn_c};
    }

    oc(int[] nArray) {
        int n = 1;
        while (~n >= ~(nArray.length + (nArray.length >> -1972935807))) {
            n <<= 1;
        }
        this.oc_a = new int[n - -n];
        int n2 = 0;
        while (~(n + n) < ~n2) {
            this.oc_a[n2] = -1;
            ++n2;
        }
        n2 = 0;
        while (~n2 > ~nArray.length) {
            int n3 = nArray[n2] & -1 + n;
            while (-1 != this.oc_a[n3 - (-n3 + -1)]) {
                n3 = -1 + n & n3 - -1;
            }
            this.oc_a[n3 + n3] = nArray[n2];
            this.oc_a[1 + n3 + n3] = n2++;
        }
    }

    static {
        oc_d = "Confirm Email:";
    }
}
