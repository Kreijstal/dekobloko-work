/*
 * Decompiled with CFR 0.152.
 */
final class hh {
    static String hh_c;
    static int hh_f;
    static ck hh_a;
    static mm hh_e;
    static String hh_d;
    static String hh_b;
    private static final String z;

    public static void a(int n) {
        hh_c = null;
        hh_b = null;
        hh_a = null;
        hh_e = null;
        if (n != -9724) {
            return;
        }
        hh_d = null;
    }

    static {
        z = "hh.A(";
        hh_d = "The game options are not all set.";
        hh_c = "Creating a Jagex account is simple and free. Your account will remember your progress, highscores and achievements in every game. You can also use it to play some of our multiplayer games - and Jagex's other games!<br><br><col=2164A2>Please note - if you have a RuneScape account, you can click 'Go Back' and use your existing account to log in!</col>";
    }
}
