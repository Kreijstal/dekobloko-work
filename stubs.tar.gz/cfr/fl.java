/*
 * Decompiled with CFR 0.152.
 */
final class fl {
    static int[][] fl_d;
    static String fl_c;
    static ck fl_f;
    static String fl_a;
    static w fl_b;
    static String fl_e;

    static final boolean a(char c, byte by) {
        if (by != 23) {
            fl.a(-17);
        }
        return '0' <= c && c <= '9';
    }

    public static void a(int n) {
        fl_d = null;
        if (n != 29047) {
            fl_c = null;
        }
        fl_c = null;
        fl_e = null;
        fl_f = null;
        fl_b = null;
        fl_a = null;
    }

    static final int a(int n, int n2, int n3, int n4, int n5) {
        int n6;
        int n7;
        int n8;
        int n9 = 0xFF & n4 >> 1441470864;
        int n10 = 0xFF & n4 >> 625963720;
        int n11 = 0xFF & n4;
        int n12 = n >> 2103927024 & 0xFF;
        int n13 = (n & 0xFFE8) >> 869977736;
        int n14 = n & 0xFF;
        if (n5 <= 100) {
            return 39;
        }
        if (~n3 != -257) {
            n8 = n3 * ((-n2 + 256) * n9 + n12 * n2) >> -58785616;
            n7 = (n14 * n2 + (-n2 + 256) * n11) * n3 >> 1520454800;
            n6 = n3 * (n13 * n2 + n10 * (256 + -n2)) >> 1169540304;
        } else {
            n6 = n2 * n13 + n10 * (256 + -n2) >> -1790237528;
            n7 = (256 - n2) * n11 + n2 * n14 >> -785939032;
            n8 = n2 * n12 + n9 * (-n2 + 256) >> 1045223560;
        }
        return n8 << 757731664 | n6 << 364164456 | n7;
    }

    static final ck[] a(int n, int n2, int n3, int n4) {
        block0: {
            if (n4 == 32140) break block0;
            fl.a(-57, -94, 1, 10, -127);
        }
        return ce.a(1, -109, n, n3, n2);
    }

    static final void a(int n, tj tj2, nm nm2, int n2, int n3, int n4, int n5) {
        sl.a(tj2.Rb, null, (byte)89, nm2, tj2, tj2.Yb, tj2.tj_cc, -1, -1);
        w.H.a(true, 29072);
        w.H.a(0, (byte)-43, null);
        if (n4 >= -53) {
            fl.a((byte)105);
        }
        w.H.a(17);
        pf pf2 = w.H;
        int n6 = n2;
        int n7 = n5;
        int n8 = n3;
        int n9 = n;
        pf2.pf_h.b(n7, n6, 101, n9, n8);
    }

    static final void b(int n, int n2, int n3, int n4, int n5) {
        if (n4 != 0) {
            return;
        }
        vb.V = n2;
        hb.Wb = n;
        pa.pa_fb = n5;
        ma.I = n3;
    }

    static final void a(int n, int n2, int n3, String string, int n4, mm mm2) {
        int n5 = 2;
        if (se.S == mm2) {
            n5 = 1;
        }
        mm2.a(string, -n5 + n4, n - n5, 0, -1);
        mm2.a(string, -n5 + n4, n, 0, -1);
        mm2.a(string, -n5 + n4, n + n5, 0, -1);
        mm2.a(string, n4, n + -n5, 0, -1);
        mm2.a(string, n4, n - -n5, 0, -1);
        if (n2 != 256) {
            return;
        }
        mm2.a(string, n4 - -n5, -n5 + n, 0, -1);
        mm2.a(string, n5 + n4, n, 0, -1);
        mm2.a(string, n4 + n5, n - -n5, 0, -1);
        if (w.w_kb == mm2) {
            mm2.a(string, n4 + 1, -n5 + n, 0, -1);
            mm2.a(string, -1 + n4, -n5 + n, 0, -1);
            mm2.a(string, n4 - -n5, n + -1, 0, -1);
            mm2.a(string, n4 + -n5, -1 + n, 0, -1);
            mm2.a(string, n4 + n5, n + 1, 0, -1);
            mm2.a(string, n4 + -n5, n + 1, 0, -1);
            mm2.a(string, n4 - -1, n5 + n, 0, -1);
            mm2.a(string, -1 + n4, n5 + n, 0, -1);
        }
        mm2.a(string, n4, n, n3, -1);
    }

    static final int a(byte by) {
        block0: {
            if (by == -108) break block0;
            fl.a(29, -113, -26, -55, -110);
        }
        return om.om_d;
    }

    static {
        fl_a = "(<%0> players want to join)";
        fl_d = new int[][]{null, {0, 0, 0, 1500, 2000}, null, null, null};
        fl_c = "Join <%0>'s game";
        fl_e = "Remove friend";
    }
}
