/*
 * Decompiled with CFR 0.152.
 */
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.OptionalDataException;
import java.io.StreamCorruptedException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

abstract class ba
implements nb {
    static um ba_f;
    static String ba_e;
    private long ba_a;
    static wl ba_b;
    static int ba_d;
    static boolean ba_c;

    @Override
    public final void c(byte by) {
        if (by != -51) {
            this.ba_a = -32L;
        }
        this.ba_a = ik.a(by + 55);
    }

    static final boolean a(ji ji2, int n) {
        block0: {
            if (n == Integer.MIN_VALUE) break block0;
            ba_f = null;
        }
        return ji2.a(false);
    }

    abstract String e(byte var1);

    public static void d(byte by) {
        ba_f = null;
        ba_e = null;
        if (by < 70) {
            return;
        }
        ba_b = null;
    }

    @Override
    public final String b(byte by) {
        if (this.a((byte)-101)) {
            return null;
        }
        if (by < 52) {
            return null;
        }
        if ((ik.a(4) ^ 0xFFFFFFFFFFFFFFFFL) > (350L + this.ba_a ^ 0xFFFFFFFFFFFFFFFFL)) {
            return null;
        }
        return this.e((byte)49);
    }

    abstract tb b(int var1);

    static final void a(int n, uf uf2) {
        boolean bl = client.A;
        kl kl2 = (kl)aa.aa_f.c((byte)-54);
        kl kl3 = kl2;
        if (null == kl3) {
            return;
        }
        boolean bl2 = false;
        if (n != -32141) {
            return;
        }
        int n2 = 0;
        while (~kl3.kl_o < ~n2) {
            if (kl2.y[n2] != null) {
                if (-3 == ~kl2.y[n2].mh_c) {
                    kl2.A[n2] = -5;
                }
                if (~kl2.y[n2].mh_c == -1) {
                    bl2 = true;
                }
            }
            if (kl2.kl_t[n2] != null) {
                if (~kl2.kl_t[n2].mh_c == -3) {
                    kl2.A[n2] = -6;
                }
                if (-1 == ~kl2.kl_t[n2].mh_c) {
                    bl2 = true;
                }
            }
            ++n2;
        }
        if (bl2) {
            return;
        }
        n2 = uf2.wl_n;
        uf2.a(kl3.C, false);
        int n3 = 0;
        while (~n3 > ~kl3.kl_o) {
            if (0 != kl2.A[n3]) {
                uf2.a(true, kl2.A[n3]);
            } else {
                try {
                    int n4;
                    AccessibleObject accessibleObject;
                    int n5 = kl2.kl_u[n3];
                    if (n5 != 0) {
                        if (-2 != ~n5) {
                            if (-3 == ~n5) {
                                accessibleObject = (Field)kl2.y[n3].mh_b;
                                n4 = ((Field)accessibleObject).getModifiers();
                                uf2.a(true, 0);
                                uf2.a(n4, false);
                            }
                        } else {
                            Field field = (Field)kl2.y[n3].mh_b;
                            accessibleObject = field;
                            field.setInt(null, kl2.kl_q[n3]);
                            uf2.a(true, 0);
                        }
                    } else {
                        accessibleObject = (Field)kl2.y[n3].mh_b;
                        int n6 = ((Field)accessibleObject).getInt(null);
                        uf2.a(true, 0);
                        uf2.a(n6, false);
                    }
                    if (3 == n5) {
                        accessibleObject = (Method)kl2.kl_t[n3].mh_b;
                        byte[][] byArray = kl2.kl_s[n3];
                        Object[] objectArray = new Object[byArray.length];
                        int n7 = 0;
                        while (~n7 > ~byArray.length) {
                            ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(byArray[n7]));
                            objectArray[n7] = objectInputStream.readObject();
                            ++n7;
                        }
                        Object object = ((Method)accessibleObject).invoke(null, objectArray);
                        if (object != null) {
                            if (!(object instanceof Number)) {
                                if (object instanceof String) {
                                    uf2.a(true, 2);
                                    uf2.a(0, (String)object);
                                } else {
                                    uf2.a(true, 4);
                                }
                            } else {
                                uf2.a(true, 1);
                                uf2.a(((Number)object).longValue(), (byte)0);
                            }
                        } else {
                            uf2.a(true, 0);
                        }
                    } else if (4 == n5) {
                        accessibleObject = (Method)kl2.kl_t[n3].mh_b;
                        n4 = ((Method)accessibleObject).getModifiers();
                        uf2.a(true, 0);
                        uf2.a(n4, false);
                    }
                }
                catch (ClassNotFoundException classNotFoundException) {
                    uf2.a(true, -10);
                }
                catch (InvalidClassException invalidClassException) {
                    uf2.a(true, -11);
                }
                catch (StreamCorruptedException streamCorruptedException) {
                    uf2.a(true, -12);
                }
                catch (OptionalDataException optionalDataException) {
                    uf2.a(true, -13);
                }
                catch (IllegalAccessException illegalAccessException) {
                    uf2.a(true, -14);
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    uf2.a(true, -15);
                }
                catch (InvocationTargetException invocationTargetException) {
                    uf2.a(true, -16);
                }
                catch (SecurityException securityException) {
                    uf2.a(true, -17);
                }
                catch (IOException iOException) {
                    uf2.a(true, -18);
                }
                catch (NullPointerException nullPointerException) {
                    uf2.a(true, -19);
                }
                catch (Exception exception) {
                    uf2.a(true, -20);
                }
                catch (Throwable throwable) {
                    uf2.a(true, -21);
                }
            }
            ++n3;
        }
        uf2.a((byte)-15, n2);
        kl3.b((byte)103);
    }

    @Override
    public final tb a(int n) {
        if (this.a((byte)119)) {
            return ki.ki_t;
        }
        if (n != 20350) {
            ba.a(-21, -85, -33);
        }
        if (ik.a(4) < this.ba_a + 350L) {
            return le.le_o;
        }
        return this.b(n + -25870);
    }

    static final void a(int n, int n2, int n3) {
        if (null == db.db_b || db.db_b.length < n2) {
            db.db_b = new int[2 * n2];
        }
        if (ad.ad_i == null || ad.ad_i.length < n2) {
            ad.ad_i = new int[n2 * 2];
        }
        if (oa.oa_e == null || oa.oa_e.length < n2) {
            oa.oa_e = new int[2 * n2];
        }
        if (ln.ln_a == null || n2 > ln.ln_a.length) {
            ln.ln_a = new int[2 * n2];
        }
        if (null == mk.mk_b || ~n2 < ~mk.mk_b.length) {
            mk.mk_b = new int[2 * n2];
        }
        if (null == cc.cc_h || cc.cc_h.length < n2) {
            cc.cc_h = new int[n2 * 2];
        }
        if (null == ch.ch_a || ch.ch_a.length < n2 - -n3) {
            ch.ch_a = new int[(n3 + n2) * 2];
        }
        if (null == oe.L || oe.L.length < n2) {
            oe.L = new boolean[2 * n2];
        }
        ge.ge_b = Integer.MAX_VALUE;
        bg.bg_d = Integer.MIN_VALUE;
        og.og_eb = 0;
        mf.Q = n;
        rf.rf_g = Integer.MIN_VALUE;
    }

    ba() {
    }

    static {
        ba_e = "Players";
        ba_f = new um();
    }
}
