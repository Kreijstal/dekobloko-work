/*
 * Decompiled with CFR 0.152.
 */
abstract class ie {
    static qm ie_d = new qm(2, 4, 4, 0);
    static w ie_a;
    static int ie_b;
    static ud ie_e;
    static w ie_c;

    abstract int a(byte var1, long var2);

    abstract void b(int var1);

    abstract long a(int var1);

    static final void a(ck[] ckArray, mm mm2, ck[] ckArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, mm mm3, ck[] ckArray3, int n10, int n11, int n12, int n13, int n14, int n15) {
        if (n12 != 10406) {
            return;
        }
        dh.a(mm2, n5, n4, new cc(ckArray), new cc(ckArray2), new cc(ckArray3), n10, n, mm3, n8, n14, n9, n3, false, n11, n7, n13, n2, n6, n15);
    }

    public static void a(byte by) {
        ie_d = null;
        ie_c = null;
        if (by >= -117) {
            ck[] ckArray = null;
            ie.a(null, null, null, 49, -127, -49, -3, 31, 17, -85, 4, 92, null, ckArray, -45, 72, 26, 15, 123, 106);
        }
        ie_a = null;
        ie_e = null;
    }

    final int a(long l, int n) {
        long l2;
        if (n != 4) {
            ie_e = null;
        }
        if (0L < (l2 = this.a(n ^ 0xFFFFA64A))) {
            ua.a(l2, n ^ 0xFFFFFF84);
        }
        return this.a((byte)109, l);
    }

    ie() {
    }
}
