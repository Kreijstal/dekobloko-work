/*
 * Decompiled with CFR 0.152.
 */
final class af {
    static int[][] af_b;
    static String af_e;
    static int af_f;
    static int af_d;
    static String af_g;
    static String af_c;
    static String af_a;

    af() {
    }

    static final ck a(int n, int n2, ji ji2, int n3) {
        block1: {
            if (!gb.a(n3, ji2, n, 49)) {
                return null;
            }
            if (n2 == 50) break block1;
            af.a((byte)-13);
        }
        return nm.g((byte)26);
    }

    static final void a(int n, int n2) {
        qd.Ob = n2 * n / 50;
        ib.ib_kb = n2 * 20 / 50;
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    public static void a(byte by) {
        af_g = null;
        af_a = null;
        af_c = null;
        int n = -41 % ((3 - by) / 37);
        af_b = null;
        af_e = null;
    }

    static final boolean a(int n, int[] nArray, int[] nArray2) {
        boolean bl = client.A;
        for (int i = n; i < 8; ++i) {
            if (nArray[i] == nArray2[i]) continue;
            return false;
        }
        return true;
    }

    static {
        af_g = "FULL ACCESS";
        af_c = "Here you can set up a rated game. If you win, your rating will go up. If<nbsp>you lose, it will go down!<br><br>Please specify your preferences and click '<%0>'. Our system will then attempt to find suitable opponents in under a minute, depending on how busy the lobby<nbsp>is.<br><br>This is an excellent way to get to know new people!";
        af_e = "Friends can be added in the multiplayer<nbsp>lobby";
        af_a = "Sorry, you were removed from the game you were in. This can happen if you are disconnected for too long or if the server is updated.";
    }
}
