/*
 * Decompiled with CFR 0.152.
 */
final class dn
extends ie {
    private long dn_g = 0L;
    static int dn_r;
    static nm dn_l;
    static boolean dn_k;
    private long[] dn_f = new long[10];
    private long dn_m = 0L;
    static String dn_s;
    private long dn_h = 0L;
    static ck[] dn_p;
    static String dn_j;
    static String dn_q;
    static boolean dn_i;
    private int dn_n = 1;
    private int dn_o = 0;

    @Override
    final int a(byte by, long l) {
        boolean bl = client.A;
        if (by != 109) {
            return -6;
        }
        if (this.dn_g < this.dn_m) {
            this.dn_h += -this.dn_g + this.dn_m;
            this.dn_g += this.dn_m - this.dn_g;
            this.dn_m += l;
            return 1;
        }
        int n = 0;
        do {
            this.dn_m += l;
        } while (++n < 10 && this.dn_m < this.dn_g);
        if (this.dn_m < this.dn_g) {
            this.dn_m = this.dn_g;
        }
        return n;
    }

    @Override
    final void b(int n) {
        block1: {
            if (n != -30693) {
                return;
            }
            this.dn_h = 0L;
            if (this.dn_g >= this.dn_m) break block1;
            this.dn_g += -this.dn_g + this.dn_m;
        }
    }

    public static void d(int n) {
        block0: {
            dn_j = null;
            dn_q = null;
            dn_l = null;
            dn_s = null;
            dn_p = null;
            if (n > 65) break block0;
            dn.b((byte)101);
        }
    }

    @Override
    final long a(int n) {
        this.dn_g += this.c(-8325);
        if (n != -22962) {
            this.dn_o = 53;
        }
        if (this.dn_g < this.dn_m) {
            return (-this.dn_g + this.dn_m) / 1000000L;
        }
        return 0L;
    }

    static final ac b(byte by) {
        boolean bl = client.A;
        try {
            if (by < 25) {
                dn_j = null;
            }
            int n = 0;
            while (true) {
                ac ac2 = oi.oi_a.a(-39, n);
                if (ac2.D) {
                    return ac2;
                }
                ++n;
            }
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return null;
        }
    }

    private final long c(int n) {
        boolean bl = client.A;
        long l = System.nanoTime();
        long l2 = l - this.dn_h;
        if (n != -8325) {
            this.a(110);
        }
        this.dn_h = l;
        if (l2 > -5000000000L && (l2 ^ 0xFFFFFFFFFFFFFFFFL) > -5000000001L) {
            this.dn_f[this.dn_o] = l2;
            if (-2 < ~this.dn_n) {
                ++this.dn_n;
            }
            this.dn_o = (1 + this.dn_o) % 10;
        }
        long l3 = 0L;
        int n2 = 1;
        while (~n2 >= ~this.dn_n) {
            l3 += this.dn_f[(10 + (this.dn_o - n2)) % 10];
            ++n2;
        }
        return l3 / (long)this.dn_n;
    }

    dn() {
        this.dn_g = System.nanoTime();
        this.dn_m = System.nanoTime();
    }

    static {
        dn_s = "Service unavailable";
        dn_j = "Flowers";
        dn_r = 20;
        dn_q = "Match 4 or more to make them disappear, like this:";
        dn_p = new ck[8];
    }
}
