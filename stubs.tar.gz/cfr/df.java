/*
 * Decompiled with CFR 0.152.
 */
final class df
extends kf
implements vn {
    static String Z = "(Including <%0>)";
    static pi[] Y;
    static w df_ab;
    private String[] V;
    private ek[] df_bb;
    private fi W;
    static int[][] U;
    static String X;
    static String T;
    static String S;

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        block3: {
            boolean bl = client.A;
            int n4 = 0;
            if (by != 67) {
                df.a(123, -2, -15);
            }
            while (n4 < this.V.length) {
                if (this.df_bb[n4] == ek2) {
                    this.W.a(this.V[n4], by + -28531);
                }
                ++n4;
            }
            if (ek2 != this.df_bb[this.V.length]) break block3;
            this.W.a(25);
        }
    }

    @Override
    final boolean a(int n, int n2, ce ce2, char c) {
        if (super.a(86, n2, ce2, c)) {
            return true;
        }
        int n3 = 11 / ((-22 - n) / 49);
        if (~n2 == -99) {
            return this.a(ce2, (byte)-121);
        }
        if (n2 != 99) {
            return false;
        }
        return this.a(32, ce2);
    }

    df(fi fi2) {
        super(0, 0, 0, 0, null);
        this.W = fi2;
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        block2: {
            super.a(n, -124, n3, n4);
            if (-1 != ~n3) {
                return;
            }
            if (n2 > -103) {
                this.a(-127, -2, -30, -66);
            }
            mm mm2 = hh.hh_e;
            if (this.V == null) break block2;
            mm2.a(g.K, n - -this.ce_u, n4 + this.D, this.ce_t, 20, 0xFFFFFF, -1, 0, 0, mm2.R - -mm2.K);
        }
    }

    public static void a(int n) {
        df_ab = null;
        Y = null;
        X = null;
        U = null;
        T = null;
        if (n != 1) {
            df.a(-31);
        }
        Z = null;
        S = null;
    }

    static final w i(int n) {
        int n2 = -96 / ((45 - n) / 63);
        return ec.ec_k.Ob;
    }

    static final ck[] a(int n, int n2, int n3) {
        block0: {
            if (n2 == 0) break block0;
            df.a(10);
        }
        return ob.a(n3, n, -3932, 1);
    }

    final void a(int n, String[] stringArray) {
        boolean bl = client.A;
        this.H.c(126);
        if (null == stringArray || stringArray.length == 0) {
            this.V = null;
            return;
        }
        if (n != 32) {
            df.a(-125, -89, -29);
        }
        int n2 = stringArray.length;
        this.V = new String[n2];
        int n3 = 0;
        while (~n2 < ~n3) {
            this.V[n3] = ua.a(stringArray[n3], true).replace('\u00a0', ' ');
            ++n3;
        }
        on on2 = new on(hh.hh_e, 0, 1);
        this.df_bb = new ek[1 + n2];
        for (int i = 0; n2 > i; ++i) {
            this.df_bb[i] = new ek(this.V[i], this);
            this.df_bb[i].ce_p = on2;
            this.df_bb[i].B = client.B;
            this.df_bb[i].b(15, 80, 0, i * 16 + 20, -16555);
            this.b(this.df_bb[i], (byte)-55);
        }
        this.df_bb[n2] = new ek(cc.cc_e, this);
        this.df_bb[n2].ce_p = on2;
        this.df_bb[n2].b(15, 100, 0, 20 + 16 * (1 + n2), -16555);
        this.b(this.df_bb[n2], (byte)-55);
    }

    static {
        X = "Fullscreen play is an option available to subscribing members only. For more details see the website.";
        S = "Press TAB to chat or F10 to open Quick Chat.";
        T = "Reject <%0> from this game";
    }
}
