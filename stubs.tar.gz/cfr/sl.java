/*
 * Decompiled with CFR 0.152.
 */
final class sl {
    static String sl_a = "Username: ";
    static String sl_g;
    static int sl_f;
    static boolean sl_c;
    static String sl_b;
    static String sl_d;
    static String sl_e;

    static final void a(String string, int[] nArray, byte by, nm nm2, w w2, String string2, long l, int n, int n2) {
        block0: {
            ki.ki_w = nm2;
            w.H = new pf(w2, l, string, string2, n2, n, nArray);
            if (by > 84) break block0;
            sl_g = null;
        }
    }

    public static void a(byte by) {
        sl_e = null;
        sl_d = null;
        sl_b = null;
        sl_g = null;
        if (by != 110) {
            sl_c = true;
        }
        sl_a = null;
    }

    static final void a(int n, int n2, int n3, int n4) {
        int n5 = mc.mc_b[jm.jm_p];
        int n6 = mc.mc_b[(jm.jm_p - -1) % mc.mc_b.length];
        int n7 = fl.a(n6, jg.jg_g, n4, n5, 110);
        int n8 = sb.sb_o[jm.jm_p];
        if (n2 >= -35) {
            sl.a((byte)86);
        }
        int n9 = sb.sb_o[(jm.jm_p - -1) % mc.mc_b.length];
        int n10 = fl.a(n9, jg.jg_g, n4, n8, 114);
        hk.d(n3, n, 640, 480, n7, n10);
    }

    static final long a(int n) {
        block0: {
            if (n == -1) break block0;
            sl.a(null, null, (byte)24, null, null, null, -106L, 12, -60);
        }
        return -p.p_a + ik.a(4);
    }

    static {
        sl_b = "Score";
        sl_d = "You have been removed from <%0>'s game.";
        sl_e = "Passwords must be between 5 and 20 letters and numbers";
        sl_f = 0;
    }
}
