/*
 * Decompiled with CFR 0.152.
 */
import java.util.Hashtable;

class ek
extends ce {
    boolean H;
    boolean I = true;
    private boolean G = false;
    private boolean J = true;

    @Override
    boolean a(boolean bl, ce ce2) {
        if (!this.I || !this.J) {
            return false;
        }
        if (bl) {
            this.d((byte)59);
        }
        ce2.d((byte)-95);
        this.G = true;
        if (this.ce_v != null) {
            if (!(this.ce_v instanceof m)) {
                return true;
            }
            ((m)this.ce_v).a(-28841, this.G, this);
        }
        return true;
    }

    void b(int n, int n2, int n3, int n4) {
        block1: {
            if (n4 != 520) {
                this.J = false;
            }
            if (null == this.ce_v || !(this.ce_v instanceof vn)) break block1;
            ((vn)this.ce_v).a((byte)67, n3, this, n, n2);
        }
    }

    @Override
    boolean a(int n, int n2, ce ce2, int n3, int n4, int n5, byte by) {
        if (by != -55) {
            this.G = true;
        }
        if (this.I && this.a(n2, (byte)-48, n4, n, n5)) {
            this.a(false, ce2);
            this.ce_o = n3;
            if (null != this.ce_v && this.ce_v instanceof sj) {
                ((sj)this.ce_v).a(n3, -4040, this, n5, n, n4, n2);
            }
            return true;
        }
        return false;
    }

    @Override
    final void d(byte by) {
        block2: {
            if (this.G) {
                this.G = false;
                if (this.ce_v != null && this.ce_v instanceof m) {
                    ((m)this.ce_v).a(-28841, this.G, this);
                }
            }
            if (by == -95) break block2;
            ce ce2 = null;
            this.a(ce2, -106, -89, 48);
        }
    }

    static final ck[] a(String string, String string2, int n, ji ji2) {
        ck[] ckArray;
        ck[] ckArray2 = ckArray = bb.a(18064, string2, ji2, string);
        if (n > -43) {
            ji ji3 = null;
            ek.a(null, (String)null, -51, ji3);
        }
        ckArray[1].C = ckArray[1].H;
        ckArray[7].C = ckArray[7].H;
        return ckArray2;
    }

    @Override
    final StringBuilder a(Hashtable hashtable, int n, StringBuilder stringBuilder, boolean bl) {
        if (!bl) {
            this.I = true;
        }
        if (this.a(0, n, hashtable, stringBuilder)) {
            this.a((byte)72, stringBuilder, hashtable, n);
            if (this.H) {
                stringBuilder.append(" active");
            }
            if (!this.I) {
                stringBuilder.append(" disabled");
            }
        }
        return stringBuilder;
    }

    static final void g(int n) {
        if (n != -1209) {
            return;
        }
        ph.Ab = false;
    }

    @Override
    void a(ce ce2, int n, int n2, int n3) {
        block2: {
            if (n < 38) {
                this.H = true;
            }
            super.a(ce2, 94, n2, n3);
            if (~this.ce_o == -1 || be.be_n == this.ce_o) break block2;
            if (this.a(bh.bh_g, (byte)-124, n2, pm.pm_f, n3) && be.be_n == 0) {
                this.b(-n3 + bh.bh_g, pm.pm_f + -n2, this.ce_o, 520);
            }
            this.a(pm.pm_f, 64, n3, ce2, n2, bh.bh_g);
        }
    }

    ek(String string, kg kg2) {
        this(string, bf.x.c_b, kg2);
    }

    @Override
    boolean a(int n, int n2, ce ce2, char c2) {
        int n3 = -127 / ((n - -22) / 49);
        if (this.a(true) && (-85 == ~n2 || ~n2 == -84)) {
            this.b(-1, -1, 1, 520);
            return true;
        }
        return false;
    }

    static final ke a(boolean bl, boolean bl2, int n) {
        ke ke2;
        ke ke3 = ke2 = new ke(3);
        ke3.a(new ec(25, jb.jb_h, a.a_t), 110);
        ke3.a(new ec(13, bl2 ? on.on_c : pc.pc_f, a.a_t), 120);
        ke3.a(new ec(26, og.og_hb, a.a_t), 122);
        ke2.ke_f[1].ec_n = 40 + a.a_t.a(ke2.ke_f[1].ec_o);
        ec ec2 = ke2.ke_f[0];
        ke2.ke_f[2].ec_n = 120;
        ec2.ec_n = 120;
        ke2.ke_f[1].ec_l = -(ke2.ke_f[1].ec_n / 2) + 320;
        ke2.ke_f[0].ec_l = 32;
        ke2.ke_f[2].ec_l = n + (-ke2.ke_f[2].ec_n + -32);
        ec ec3 = ke2.ke_f[0];
        ke2.ke_f[2].ec_m = 400;
        ec ec4 = ke2.ke_f[1];
        ec4.ec_m = 400;
        ke3.y = 520;
        ke3.ke_w = 60;
        ke3.ke_q = 284;
        ec3.ec_m = 400;
        ke3.z = 96;
        ke3.a(1, bl, n ^ 0xFFFFFDFF);
        ac.f((byte)-119);
        return ke3;
    }

    @Override
    final boolean a(boolean bl) {
        block0: {
            if (bl) break block0;
            this.I = false;
        }
        return this.G;
    }

    @Override
    final void a(int n, int n2, int n3, ce ce2, int n4, int n5) {
        block1: {
            if (null != this.ce_v && this.ce_v instanceof sj) {
                ((sj)this.ce_v).a(n, n3, n4, n5, this, n2 + 19001);
            }
            this.ce_o = 0;
            if (n2 == 64) break block1;
            this.G = false;
        }
    }

    ek(String string, gl gl2, kg kg2) {
        super(string, gl2, kg2);
    }

    protected ek() {
        this.ce_p = bf.x.c_g;
    }
}
