/*
 * Decompiled with CFR 0.152.
 */
final class jm
extends wm {
    private String jm_t;
    static vj jm_r = new vj();
    static String jm_u;
    static ud[] jm_v;
    static int jm_p;
    static ck jm_q;
    private boolean jm_s = false;

    jm(rk rk2) {
        super(rk2);
    }

    @Override
    final tb b(String string, byte by) {
        if (by != -40) {
            String string2 = null;
            jm.a('\ufffd', null, string2, 32);
        }
        if (!rd.a(string, by ^ 0x6B1A)) {
            return vm.vm_u;
        }
        if (!string.equals(this.jm_t)) {
            cd cd2 = f.a(by + -11039, string);
            if (null == cd2 || null != cd2.cd_f) {
                return jb.jb_j;
            }
            this.jm_s = cd2.cd_n;
            this.jm_t = string;
        }
        return !this.jm_s ? vm.vm_u : dc.dc_b;
    }

    final void a(boolean bl) {
        if (!bl) {
            this.jm_s = true;
        }
        this.jm_t = null;
    }

    static final void a(int n, boolean bl2) {
        if (n != 0) {
            String string = null;
            jm.a('_', null, string, -55);
        }
        if (ph.n(-30146)) {
            wj.a(0, -80, true, 2, bl2, bc.K);
        } else {
            we.we_b.f(9, -4);
            mn.mn_c = true;
            ef.N = dl.M;
        }
    }

    @Override
    final String wm_a_string(String string, byte by) {
        String string2 = ij.a(5, string);
        if (null != string2) {
            return string2;
        }
        if (!string.equals(this.jm_t)) {
            cd cd2 = f.a(by + -11068, string);
            if (cd2 == null) {
                return null;
            }
            if (null != cd2.cd_f) {
                return null;
            }
            this.jm_t = string;
            this.jm_s = cd2.cd_n;
        }
        if (by != -11) {
            jm.a(109, false);
        }
        if (!this.jm_s) {
            return of.of_g;
        }
        return ed.ed_e;
    }

    public static void e(int n) {
        jm_q = null;
        jm_r = null;
        jm_u = null;
        if (n <= 41) {
            jm_q = null;
        }
        jm_v = null;
    }

    static final String a(char c, String string, String string2, int n) {
        int n2;
        boolean bl2 = client.A;
        int n3 = string.length();
        int n4 = string2.length();
        int n5 = n3;
        int n6 = -1 + n4;
        if (~n6 != n) {
            int n7 = 0;
            while (-1 >= ~(n7 = string.indexOf(c, n7))) {
                n5 += n6;
                ++n7;
            }
        }
        StringBuilder stringBuilder = new StringBuilder(n5);
        int n8 = 0;
        while (~(n2 = string.indexOf(c, n8)) <= -1) {
            stringBuilder.append(string.substring(n8, n2));
            n8 = 1 + n2;
            stringBuilder.append(string2);
        }
        stringBuilder.append(string.substring(n8));
        return stringBuilder.toString();
    }

    static final void a(boolean bl2, fm fm2, int n, byte by, boolean bl3) {
        pd.pd_h[0] = gg.A.nextInt();
        pd.pd_h[1] = gg.A.nextInt();
        pd.pd_h[2] = (int)(lc.lc_j >> -457716384);
        vi.A.wl_n = 0;
        pd.pd_h[3] = (int)lc.lc_j;
        vi.A.a(pd.pd_h[0], false);
        vi.A.a(pd.pd_h[1], false);
        if (by < 123) {
            jm.e(2);
        }
        vi.A.a(pd.pd_h[2], false);
        vi.A.a(pd.pd_h[3], false);
        i.a(vi.A, 0);
        vi.A.d(-1, n);
        fm2.a(vi.A, (byte)124);
        we.we_b.wl_n = 0;
        if (bl2) {
            we.we_b.a(true, 18);
        } else {
            we.we_b.a(true, 16);
        }
        we.we_b.wl_n += 2;
        int n2 = we.we_b.wl_n;
        we.we_b.a(re.re_v, false);
        we.we_b.a(rm.rm_c, (byte)0);
        int n3 = 0;
        if (ce.ce_w) {
            n3 |= 1;
        }
        if (ci.ci_c) {
            n3 |= 4;
        }
        if (bl3) {
            n3 |= 8;
        }
        if (null != vh.vh_f) {
            n3 |= 0x10;
        }
        we.we_b.a(true, n3);
        String string = a.a(se.h(25144), (byte)114);
        if (string == null) {
            string = "";
        }
        we.we_b.a(0, string);
        if (vh.vh_f != null) {
            we.we_b.b(8, vh.vh_f);
        }
        re.a(uk.uk_p, ea.ea_k, we.we_b, vi.A, 0);
        we.we_b.b(true, we.we_b.wl_n - n2);
        wj.c(4792, -1);
    }

    static {
        jm_v = new ud[4];
        jm_p = 0;
    }
}
