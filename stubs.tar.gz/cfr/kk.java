/*
 * Decompiled with CFR 0.152.
 */
final class kk
implements gl {
    private int kk_f;
    private int kk_j;
    private int kk_o;
    static int kk_k;
    static String kk_i;
    static int kk_n;
    private int kk_d;
    static um kk_p;
    private int kk_a = 1;
    private int kk_r;
    private int kk_g;
    private int kk_s;
    static int kk_e;
    private mm kk_h;
    private int kk_c = 1;
    private int kk_m;
    private int kk_b;
    static String kk_q;
    static byte[] kk_l;

    static final String a(boolean bl, boolean bl2, boolean bl3, boolean bl4) {
        if (!bl4) {
            kk_p = null;
        }
        int n = 0;
        if (bl3) {
            n += 4;
        }
        if (bl) {
            n += 2;
        }
        if (bl2) {
            ++n;
        }
        return qk.qk_e[n];
    }

    static final void a(int n, int n2, ki ki2) {
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n3 = uf2.wl_n;
        uf2.a(true, 1);
        uf2.a(true, ki2.ki_v);
        if (n2 != -15016) {
            return;
        }
        uf2.a(true, ki2.ki_p);
        uf2.a(ki2.ki_s, false);
        uf2.a(ki2.ki_r, false);
        uf2.a(ki2.ki_o, false);
        uf2.a(ki2.ki_q, false);
        uf2.a((byte)-15, n3);
        uf2.b(uf2.wl_n - n3, true);
    }

    public static void a(byte by) {
        if (by > -54) {
            kk_q = null;
        }
        kk_l = null;
        kk_i = null;
        kk_q = null;
        kk_p = null;
    }

    @Override
    public final void a(boolean bl, int n, int n2, byte by, ce ce2) {
        block4: {
            dl dl2;
            if (by > -60) {
                kk.a((byte)-80);
            }
            if ((dl2 = (dl)(ce2 instanceof dl ? ce2 : null)) != null) {
                bl &= dl2.I;
            }
            int n3 = 0x555555;
            hk.a(n + ce2.ce_u, n2 - -ce2.D, ce2.ce_t, ce2.y, this.kk_o);
            if (bl) {
                n3 = 0xFFFFFF;
            }
            int n4 = n + ce2.ce_u - -this.kk_s;
            int n5 = ce2.D + n2 - -this.kk_j;
            hk.d(n4, n5, this.kk_m, this.kk_f, 0x555555);
            hk.a(n4, n5, this.kk_m, this.kk_f, n3);
            if (dl2.H) {
                hk.b(n4, n5, this.kk_m + n4, n5 + this.kk_f, 1);
                hk.b(n4 - -this.kk_m, n5, n4, this.kk_f + n5, 1);
            }
            if (this.kk_h == null) break block4;
            int n6 = this.kk_m - -this.kk_s + this.kk_g;
            this.kk_h.a(ce2.E, n + ce2.ce_u - -n6, this.kk_r + n2 + ce2.D, ce2.ce_t - (this.kk_g + n6), -(this.kk_g << 254703425) + ce2.y, this.kk_d, this.kk_b, this.kk_c, this.kk_a, 0);
        }
    }

    kk(mm mm2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9) {
        this.kk_j = n6;
        this.kk_g = n;
        this.kk_m = n8;
        this.kk_b = n4;
        this.kk_d = n3;
        this.kk_r = n2;
        this.kk_o = n9;
        this.kk_f = n7;
        this.kk_h = mm2;
        this.kk_s = n5;
    }

    static {
        kk_i = "Hide chat";
        kk_q = "<%0>: ";
        kk_p = new um();
    }
}
