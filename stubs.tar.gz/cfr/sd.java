/*
 * Decompiled with CFR 0.152.
 */
final class sd {
    private int sd_b;
    private int[] sd_d = new int[2];
    private int[] sd_c = new int[2];
    private int sd_k;
    private int sd_f = 2;
    private int sd_j;
    int sd_e;
    private int sd_g;
    int sd_a;
    private int sd_h;
    int sd_i;

    final int a(int n) {
        if (this.sd_k >= this.sd_b) {
            this.sd_j = this.sd_c[this.sd_g++] << 15;
            if (this.sd_g >= this.sd_f) {
                this.sd_g = this.sd_f - 1;
            }
            this.sd_b = (int)((double)this.sd_d[this.sd_g] / 65536.0 * (double)n);
            if (this.sd_b > this.sd_k) {
                this.sd_h = ((this.sd_c[this.sd_g] << 15) - this.sd_j) / (this.sd_b - this.sd_k);
            }
        }
        this.sd_j += this.sd_h;
        ++this.sd_k;
        return this.sd_j - this.sd_h >> 15;
    }

    final void a() {
        this.sd_b = 0;
        this.sd_g = 0;
        this.sd_h = 0;
        this.sd_j = 0;
        this.sd_k = 0;
    }

    final void b(wl wl2) {
        this.sd_a = wl2.d((byte)-28);
        this.sd_e = wl2.i(7553);
        this.sd_i = wl2.i(7553);
        this.a(wl2);
    }

    final void a(wl wl2) {
        this.sd_f = wl2.d((byte)-69);
        this.sd_d = new int[this.sd_f];
        this.sd_c = new int[this.sd_f];
        for (int i = 0; i < this.sd_f; ++i) {
            this.sd_d[i] = wl2.e(3);
            this.sd_c[i] = wl2.e(3);
        }
    }

    sd() {
        this.sd_d[0] = 0;
        this.sd_d[1] = 65535;
        this.sd_c[0] = 0;
        this.sd_c[1] = 65535;
    }
}
