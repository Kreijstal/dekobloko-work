/*
 * Decompiled with CFR 0.152.
 */
abstract class of {
    static String of_g = "That name is not available";
    static um of_a = new um();
    static boolean of_h;
    static int of_e;
    static boolean of_c;
    static byte[][] of_f;
    static String of_b;
    static int of_i;
    static int of_d;

    abstract ad a(boolean var1);

    public static void a(byte by) {
        of_b = null;
        if (by <= 88) {
            of_g = null;
        }
        of_f = null;
        of_g = null;
        of_a = null;
    }

    abstract int a(int var1, int var2);

    static final void a(int n) {
        block2: {
            block3: {
                ++bb.bb_f;
                if (n != 0) {
                    return;
                }
                ++jg.jg_g;
                if (bb.bb_f >= 131072) {
                    bb.bb_f = 0;
                }
                if (jg.jg_g <= 255) break block2;
                if (-21 > ~sl.sl_f) break block3;
                ++sl.sl_f;
                jg.jg_g = 255;
                break block2;
            }
            jg.jg_g = 0;
            sl.sl_f = 0;
            if (mc.mc_b.length > ++jm.jm_p) break block2;
            jm.jm_p = 0;
        }
    }

    of() {
    }

    abstract byte[] a(int var1, byte var2);

    static final void a(boolean bl, int n) {
        ki ki2;
        boolean bl2 = client.A;
        bh bh2 = ki2 = (ki)cg.cg_c.c((byte)-112);
        while (null != ki2) {
            kk.a(n, -15016, ki2);
            bh2 = (ki)cg.cg_c.d(true);
        }
        if (bl) {
            of.a(true, -48);
        }
        bh2 = rc.rc_e.c((byte)109);
        while (null != bh2) {
            gm.b(n, 47);
            bh2 = rc.rc_e.d(true);
        }
    }

    static {
        of_f = new byte[1000][];
        of_b = "ESC - cancel private message";
        of_d = -1;
    }
}
