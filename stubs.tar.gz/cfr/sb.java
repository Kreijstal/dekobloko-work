/*
 * Decompiled with CFR 0.152.
 */
final class sb
extends bh {
    static String sb_t = "Secret achievement";
    int sb_r;
    static ui[][] sb_u;
    static int[] sb_o;
    boolean sb_s;
    int[] sb_q;
    static String sb_n;
    static String sb_p;

    public static void a(int n) {
        block0: {
            sb_u = null;
            sb_p = null;
            sb_t = null;
            sb_o = null;
            sb_n = null;
            if (n == 13820388) break block0;
            sb_u = null;
        }
    }

    static final void c(byte by) {
        block12: {
            boolean bl = client.A;
            w w2 = (tj)i.i_b.c((byte)-53);
            while (null != w2) {
                if (~((tj)w2).Qb < -1) {
                    --((tj)w2).Qb;
                    if (-1 == ~((tj)w2).Qb) {
                        ((tj)w2).tj_hc = 0;
                        if (((tj)w2).g((byte)111)) {
                            w2.b((byte)112);
                        }
                    }
                }
                w2 = (tj)i.i_b.d(true);
            }
            w2 = (ve)h.h_b.c((byte)26);
            while (null != w2) {
                if (((ve)w2).Rb > 0) {
                    --((ve)w2).Rb;
                    if (-1 == ~((ve)w2).Rb) {
                        ((ve)w2).ve_oc = 0;
                        if (((ve)w2).i((byte)115)) {
                            w2.b((byte)113);
                        }
                    }
                }
                w2 = (ve)h.h_b.d(true);
            }
            w2 = (tj)oc.oc_b.c((byte)50);
            while (w2 != null) {
                if (0 >= ((tj)w2).Qb) {
                    w2 = (tj)oc.oc_b.d(true);
                    continue;
                }
                --((tj)w2).Qb;
                if (~((tj)w2).Qb == -1) {
                    ((tj)w2).tj_hc = 0;
                    if (((tj)w2).g((byte)59)) {
                        w2.b((byte)101);
                    }
                }
                w2 = (tj)oc.oc_b.d(true);
            }
            if (by == 123) break block12;
            String string = null;
            sb.a(-113L, null, false, string, 29);
        }
    }

    static final fm a(long l, String string, boolean bl, String string2, int n) {
        if ((long)n != l || null == string2) {
            if (bl) {
                return new qa(l, string);
            }
        } else {
            return new ob(string2, string);
        }
        return new wk(l, string);
    }

    sb() {
    }

    static {
        sb_o = new int[]{10076391, 4944180, 14961707, 16178128, 13820388};
        sb_u = new ui[8][4];
        sb_n = "Players: <%0>/<%1>";
        sb_p = "Show players in <%0>'s game";
    }
}
