/*
 * Decompiled with CFR 0.152.
 */
final class qg {
    private static int[] qg_i;
    static int qg_g;
    private static int[] qg_h;
    static int[] qg_f;
    static int qg_c;
    static int qg_a;
    static int qg_e;
    static int[] qg_b;
    static int[] qg_d;

    private static final void c() {
        qg_g = qg_a / 2;
        qg_c = qg_e / 2;
    }

    public static void a() {
        qg_d = null;
        qg_i = null;
        qg_h = null;
        qg_f = null;
        qg_b = null;
    }

    static final void b() {
        qg.a(hk.hk_c, hk.hk_h, hk.hk_g, hk.hk_b);
    }

    private static final void a(int n, int n2, int n3, int n4) {
        qg_a = n3 - n;
        qg_e = n4 - n2;
        qg.c();
        if (qg_d.length < qg_e) {
            qg_d = new int[oe.b(-10498, qg_e)];
        }
        int n5 = n2 * hk.hk_j + n;
        for (int i = 0; i < qg_e; ++i) {
            qg.qg_d[i] = n5;
            n5 += hk.hk_j;
        }
    }

    static {
        int n;
        qg_f = new int[2048];
        qg_h = new int[2048];
        qg_b = new int[2048];
        qg_d = new int[1024];
        qg_i = new int[512];
        for (n = 1; n < 512; ++n) {
            qg.qg_i[n] = 32768 / n;
        }
        for (n = 1; n < 2048; ++n) {
            qg.qg_h[n] = 65536 / n;
        }
        for (n = 0; n < 2048; ++n) {
            qg.qg_f[n] = (int)(65536.0 * Math.sin((double)n * 0.0030679615));
            qg.qg_b[n] = (int)(65536.0 * Math.cos((double)n * 0.0030679615));
        }
    }
}
