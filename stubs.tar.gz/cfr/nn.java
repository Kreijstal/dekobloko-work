/*
 * Decompiled with CFR 0.152.
 */
final class nn {
    static um nn_c = new um();
    static String nn_b = "Please remove <%0> from your friend list first.";
    static w nn_a;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final void a(int n, ui ui2, boolean bl) {
        if (!bl) {
            nn_c = null;
        }
        en en2 = km.z;
        synchronized (en2) {
            if (null != wj.Ob) {
                sh.sh_a.c(wj.Ob);
                wj.Ob = null;
            }
            if (null != ui2) {
                wj.Ob = new ia(ui2);
                wj.Ob.a(a.a_g * 50 / 128);
                wj.Ob.c(n);
                sh.sh_a.a(wj.Ob);
            }
            km.z.a();
            rc.rc_d = ui2;
        }
    }

    public static void a(int n) {
        block0: {
            nn_c = null;
            nn_b = null;
            nn_a = null;
            if (n == 14925) break block0;
            nn.a(-43);
        }
    }

    static final boolean a(boolean bl, String string, String string2) {
        String string3 = oa.a(string, -1);
        if (bl) {
            nn_c = null;
        }
        if (string2.indexOf(string) != -1 || -1 != string2.indexOf(string3)) {
            return true;
        }
        return string2.startsWith(string) || string2.startsWith(string3) || string2.endsWith(string) || string2.endsWith(string3);
    }
}
