/*
 * Decompiled with CFR 0.152.
 */
final class vj {
    static String[] vj_e;
    static ji vj_a;
    static int[] vj_d;
    bh vj_c;
    private bh vj_b;

    final boolean b(int n) {
        if (n >= -1) {
            vj_d = null;
        }
        return this.vj_c.bh_b == this.vj_c;
    }

    final void c(int n) {
        bh bh2;
        boolean bl = client.A;
        if (n < 104) {
            bh bh3 = null;
            this.a(bh3, 114);
        }
        while (this.vj_c != (bh2 = this.vj_c.bh_b)) {
            bh2.b((byte)120);
        }
        this.vj_b = null;
    }

    final bh d(int n) {
        if (n >= -23) {
            return null;
        }
        bh bh2 = this.vj_c.bh_a;
        if (this.vj_c == bh2) {
            return null;
        }
        bh2.b((byte)115);
        return bh2;
    }

    final void a(int n, bh bh2, vj vj2) {
        block1: {
            bh bh3 = this.vj_c.bh_a;
            this.vj_c.bh_a = bh2.bh_a;
            bh2.bh_a.bh_b = this.vj_c;
            if (n > -95) {
                this.vj_b = null;
            }
            if (bh2 == this.vj_c) break block1;
            bh2.bh_a = vj2.vj_c.bh_a;
            bh2.bh_a.bh_b = bh2;
            bh3.bh_b = vj2.vj_c;
            vj2.vj_c.bh_a = bh3;
        }
    }

    final bh a(int n, bh bh2) {
        bh bh3;
        if (n <= 1) {
            this.b(-55);
        }
        if (this.vj_c == (bh3 = null == bh2 ? this.vj_c.bh_b : bh2)) {
            this.vj_b = null;
            return null;
        }
        this.vj_b = bh3.bh_b;
        return bh3;
    }

    static final void a(boolean bl) {
        block2: {
            int n;
            boolean bl2 = client.A;
            cm.cm_f.b(-30693);
            for (n = 0; n < 32; ++n) {
                sf.y[n] = 0L;
            }
            n = 0;
            while (-33 < ~n) {
                jd.Ub[n] = 0L;
                ++n;
            }
            vm.vm_r = 0;
            if (bl) break block2;
            ck ck2 = null;
            vj.a(ck2, -91);
        }
    }

    final bh c(boolean bl) {
        bh bh2;
        if (!bl) {
            vj_d = null;
        }
        if ((bh2 = this.vj_b) == this.vj_c) {
            this.vj_b = null;
            return null;
        }
        this.vj_b = bh2.bh_a;
        return bh2;
    }

    public static void b(byte by) {
        if (by != 79) {
            return;
        }
        vj_e = null;
        vj_a = null;
        vj_d = null;
    }

    static final ck[] a(ck ck2, int n) {
        ck[] ckArray;
        if (n != 32169) {
            vj.e(-16);
        }
        ck[] ckArray2 = ckArray = new ck[9];
        ckArray[4] = ck2;
        return ckArray2;
    }

    final bh c(byte by) {
        int n = -55 / ((by - -17) / 35);
        bh bh2 = this.vj_c.bh_b;
        if (bh2 == this.vj_c) {
            this.vj_b = null;
            return null;
        }
        this.vj_b = bh2.bh_b;
        return bh2;
    }

    final void a(bh bh2, int n) {
        if (bh2.bh_a != null) {
            bh2.b((byte)124);
        }
        bh2.bh_b = this.vj_c;
        bh2.bh_a = this.vj_c.bh_a;
        if (n != 2777) {
            return;
        }
        bh2.bh_a.bh_b = bh2;
        bh2.bh_b.bh_a = bh2;
    }

    final bh d(boolean bl) {
        if (!bl) {
            return null;
        }
        bh bh2 = this.vj_b;
        if (bh2 == this.vj_c) {
            this.vj_b = null;
            return null;
        }
        this.vj_b = bh2.bh_b;
        return bh2;
    }

    final bh b(boolean bl) {
        if (!bl) {
            return null;
        }
        bh bh2 = this.vj_c.bh_a;
        if (this.vj_c == bh2) {
            this.vj_b = null;
            return null;
        }
        this.vj_b = bh2.bh_a;
        return bh2;
    }

    final void b(bh bh2, int n) {
        block1: {
            if (bh2.bh_a != null) {
                bh2.b((byte)115);
            }
            bh2.bh_b = this.vj_c.bh_b;
            bh2.bh_a = this.vj_c;
            bh2.bh_a.bh_b = bh2;
            bh2.bh_b.bh_a = bh2;
            if (n == 7143) break block1;
            this.d(false);
        }
    }

    final bh a(int n) {
        bh bh2 = this.vj_c.bh_b;
        if (this.vj_c == bh2) {
            return null;
        }
        bh2.b((byte)108);
        if (n != 4) {
            return null;
        }
        return bh2;
    }

    final int a(byte by) {
        boolean bl = client.A;
        int n = 0;
        int n2 = 60 % ((by - 13) / 50);
        bh bh2 = this.vj_c.bh_b;
        while (this.vj_c != bh2) {
            ++n;
            bh2 = bh2.bh_b;
        }
        return n;
    }

    public vj() {
        this.vj_c.bh_a = this.vj_c = new bh();
        this.vj_c.bh_b = this.vj_c;
    }

    static final qm[] e(int n) {
        if (n != -23521) {
            vj.a(false);
        }
        return new qm[]{nh.nh_i, ta.ta_a, ie.ie_d, gf.gf_e, ul.ul_e, oi.oi_d, nk.nk_f, vk.vk_d, rg.rg_g, wg.wg_a, de.U, qm.qm_g, rf.rf_k, gh.gh_c};
    }

    static {
        vj_d = new int[8192];
    }
}
