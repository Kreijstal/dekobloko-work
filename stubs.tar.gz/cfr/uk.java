/*
 * Decompiled with CFR 0.152.
 */
import java.math.BigInteger;

final class uk
extends bh {
    int uk_v;
    static BigInteger uk_p;
    int uk_o;
    int uk_n;
    int uk_r;
    int uk_t;
    int uk_w;
    int A;
    int uk_u;
    pi[] uk_q;
    static long[] x;
    static int[] z;
    static long[][] uk_s;
    static String y;

    final void b(int n, int n2) {
        boolean bl2 = client.A;
        if (n2 >= this.uk_n) {
            return;
        }
        uk uk2 = new uk();
        uk2.uk_v = this.uk_v;
        uk2.uk_u = this.uk_u;
        uk2.A = this.A;
        uk2.uk_w = this.uk_w;
        uk2.uk_r = this.uk_r;
        uk2.uk_t = this.uk_t;
        uk2.uk_q = new pi[this.uk_t * this.A];
        if (this.A > this.uk_t) {
            int n3 = ka.a((byte)53, this.uk_w * this.uk_t, tf.tf_cb) - -(this.uk_w * (this.A + -this.uk_t) / 2);
            int n4 = -1 + (this.A * this.uk_w - n3);
            int n5 = ka.a((byte)117, 1 + 2 * this.uk_t * this.uk_w, tf.tf_cb) - this.uk_t * this.uk_w;
            uk2.uk_n = (this.A * this.uk_w / 2 - n5 / 6) * this.uk_n / (this.uk_w * this.A);
            this.uk_n -= uk2.uk_n;
            int n6 = this.uk_t * this.uk_v;
            int n7 = n6 * n6;
            int n8 = 0;
            for (int i = 0; this.uk_t > i; ++i) {
                int n9;
                int n10 = this.A;
                int n11 = 0;
                int n12 = 0;
                while (~this.uk_v < ~n12) {
                    ub.ub_d[n12] = n9 = n3 + (n8 * (n4 - n3) / n6 - -((n6 + -n8) * (n8 * n5) / n7));
                    ++n8;
                    if (~n10 < ~(n9 / this.uk_w)) {
                        n10 = n9 / this.uk_w;
                    }
                    if (~((this.uk_w + n9 + -1) / this.uk_w) < ~n11) {
                        n11 = (n9 - (-this.uk_w + 1)) / this.uk_w;
                    }
                    ++n12;
                }
                if (n10 < 0) {
                    n10 = 0;
                }
                if (~n11 < ~this.A) {
                    n11 = this.A;
                }
                n12 = i * this.A;
                for (n9 = 0; n10 > n9; ++n9) {
                    uk2.uk_q[n12 - -n9] = me.J;
                }
                for (n9 = n10; n11 > n9; ++n9) {
                    pi pi2 = this.uk_q[n12 - -n9];
                    if (null != pi2 && me.J != pi2) {
                        pi2 = pi2.b();
                    }
                    uk2.uk_q[n9 + n12] = pi2;
                }
                n9 = n11;
                while (~this.A < ~n9) {
                    uk2.uk_q[n12 + n9] = this.uk_q[n9 + n12];
                    this.uk_q[n9 + n12] = me.J;
                    ++n9;
                }
                for (n9 = 0; this.uk_v > n9; ++n9) {
                    pi pi3;
                    int n13 = ub.ub_d[n9];
                    int n14 = this.uk_w * n10;
                    int n15 = n10;
                    int n16 = 0;
                    block6: while (~n14 > ~n13) {
                        pi3 = uk2.uk_q[i * this.A + n15];
                        while (n16 < this.uk_w) {
                            if (~n14 <= ~n13) break block6;
                            if (pi3 != me.J) {
                                if (pi3 == null) {
                                    pi3 = new pi(this.uk_w, this.uk_v, 0);
                                    an.a(pi3.pi_k, 0, this.uk_w * this.uk_v, (byte)1);
                                    uk2.uk_q[n15 + this.A * i] = pi3;
                                }
                                pi3.pi_k[n16 + n9 * this.uk_w] = 0;
                            }
                            ++n14;
                            ++n16;
                        }
                        ++n15;
                        n16 = 0;
                    }
                    while (~n15 > ~n11) {
                        pi3 = this.uk_q[n15 + this.A * i];
                        while (this.uk_w > n16) {
                            if (me.J != pi3) {
                                if (pi3 == null) {
                                    pi3 = new pi(this.uk_w, this.uk_v, 0);
                                    an.a(pi3.pi_k, 0, this.uk_w * this.uk_v, (byte)1);
                                    this.uk_q[this.A * i + n15] = pi3;
                                }
                                pi3.pi_k[n9 * this.uk_w + n16] = 0;
                            }
                            ++n16;
                            ++n14;
                        }
                        ++n15;
                        n16 = 0;
                    }
                }
            }
        } else {
            int n17 = ka.a((byte)51, this.A * this.uk_v, tf.tf_cb) + this.uk_v * (this.uk_t - this.A) / 2;
            int n18 = this.uk_v * this.uk_t - 1 + -n17;
            int n19 = ka.a((byte)56, this.A * (this.uk_v * 2) - -1, tf.tf_cb) + -(this.uk_v * this.A);
            uk2.uk_n = (-(n19 / 6) + this.uk_t * this.uk_v / 2) * this.uk_n / (this.uk_t * this.uk_v);
            this.uk_n -= uk2.uk_n;
            int n20 = this.A * this.uk_w;
            int n21 = n20 * n20;
            int n22 = 0;
            int n23 = 0;
            while (~this.A < ~n23) {
                int n24;
                int n25 = this.uk_t;
                int n26 = 0;
                int n27 = 0;
                while (~this.uk_w < ~n27) {
                    ub.ub_d[n27] = n24 = n17 - (-(n22 * (-n17 + n18) / n20) - n22 * n19 * (n20 - n22) / n21);
                    if (n25 > n24 / this.uk_v) {
                        n25 = n24 / this.uk_v;
                    }
                    ++n22;
                    if (~((this.uk_v + n24 - 1) / this.uk_v) < ~n26) {
                        n26 = (-1 + this.uk_v + n24) / this.uk_v;
                    }
                    ++n27;
                }
                if (~n26 < ~this.uk_t) {
                    n26 = this.uk_t;
                }
                if (n25 < 0) {
                    n25 = 0;
                }
                n24 = this.A * n25;
                for (n27 = n23; n27 < n24; n27 += this.A) {
                    uk2.uk_q[n27] = me.J;
                }
                n24 = this.A * n26;
                while (n27 < n24) {
                    pi pi4 = this.uk_q[n27];
                    if (pi4 != null && me.J != pi4) {
                        pi4 = pi4.b();
                    }
                    uk2.uk_q[n27] = pi4;
                    n27 += this.A;
                }
                n24 = this.A * this.uk_t;
                while (~n24 < ~n27) {
                    uk2.uk_q[n27] = this.uk_q[n27];
                    this.uk_q[n27] = me.J;
                    n27 += this.A;
                }
                int n28 = 0;
                while (~n28 > ~this.uk_w) {
                    pi pi5;
                    int n29 = ub.ub_d[n28];
                    int n30 = n25 * this.uk_v;
                    int n31 = n25;
                    int n32 = 0;
                    block16: while (n30 < n29) {
                        pi5 = uk2.uk_q[this.A * n31 + n23];
                        while (~this.uk_v < ~n32) {
                            if (n29 <= n30) break block16;
                            if (me.J != pi5) {
                                if (null == pi5) {
                                    pi5 = new pi(this.uk_w, this.uk_v, 0);
                                    an.a(pi5.pi_k, 0, this.uk_w * this.uk_v, (byte)1);
                                    uk2.uk_q[this.A * n31 + n23] = pi5;
                                }
                                pi5.pi_k[n32 * this.uk_w - -n28] = 0;
                            }
                            ++n32;
                            ++n30;
                        }
                        ++n31;
                        n32 = 0;
                    }
                    while (~n26 < ~n31) {
                        pi5 = this.uk_q[n23 + this.A * n31];
                        while (~this.uk_v < ~n32) {
                            if (pi5 != me.J) {
                                if (null == pi5) {
                                    pi5 = new pi(this.uk_w, this.uk_v, 0);
                                    an.a(pi5.pi_k, 0, this.uk_w * this.uk_v, (byte)1);
                                    this.uk_q[n23 + n31 * this.A] = pi5;
                                }
                                pi5.pi_k[n28 + this.uk_w * n32] = 0;
                            }
                            ++n30;
                            ++n32;
                        }
                        ++n31;
                        n32 = 0;
                    }
                    ++n28;
                }
                ++n23;
            }
        }
        this.d((byte)116);
        uk2.d((byte)-110);
        uk2.bh_b = this.bh_b;
        uk2.bh_a = this;
        uk2.bh_a.bh_b = uk2;
        uk2.bh_b.bh_a = uk2;
        this.b(11976, n2);
        uk2.b(n, n2);
    }

    static final boolean c(byte by) {
        if (by != -17) {
            uk.c((byte)22);
        }
        return pa.V == ka.P;
    }

    public static void c(int n) {
        x = null;
        z = null;
        uk_s = null;
        y = null;
        if (n <= 122) {
            return;
        }
        uk_p = null;
    }

    static final boolean a(int n) {
        if (n != -22802) {
            y = null;
        }
        return u.u_i != null && u.u_i.g((byte)-104) != null;
    }

    private final void d(byte by) {
        block11: {
            int n;
            int n2;
            boolean bl2 = client.A;
            int n3 = 0;
            int n4 = this.A;
            int n5 = 0;
            int n6 = this.uk_t;
            block0: while (n5 < n6) {
                --n6;
                n2 = n3;
                while (~n2 > ~n4) {
                    if (this.uk_q[n6 * this.A + n2] != me.J) {
                        ++n6;
                        break block0;
                    }
                    ++n2;
                }
            }
            n2 = 32 / ((-48 - by) / 43);
            block2: while (~n6 < ~n5) {
                n = n3;
                while (~n > ~n4) {
                    if (me.J != this.uk_q[n5 * this.A + n]) break block2;
                    ++n;
                }
                ++n5;
            }
            block4: while (~n4 < ~n3) {
                --n4;
                for (n = n5; n < n6; ++n) {
                    if (this.uk_q[n4 + this.A * n] == me.J) continue;
                    ++n4;
                    break block4;
                }
            }
            block6: while (~n3 > ~n4) {
                for (n = n5; n < n6; ++n) {
                    if (me.J != this.uk_q[n3 + this.A * n]) break block6;
                }
                ++n3;
            }
            if (0 >= n3 && ~this.A >= ~n4 && 0 >= n5 && ~this.uk_t >= ~n6) break block11;
            n = n4 - n3;
            int n7 = -n5 + n6;
            pi[] piArray = new pi[n * n7];
            int n8 = 0;
            while (~n7 < ~n8) {
                int n9 = 0;
                while (~n < ~n9) {
                    piArray[n9 + n8 * n] = this.uk_q[(n8 + n5) * this.A - (-n3 + -n9)];
                    ++n9;
                }
                ++n8;
            }
            this.uk_u += n5;
            this.A = n;
            this.uk_t = n7;
            this.uk_r += n3;
            this.uk_q = piArray;
        }
    }

    uk() {
    }

    static {
        int n;
        int n2;
        uk_p = new BigInteger("6757747274818513864204534133465045479284128469717186816691454417744823753827902036844748836683348383638677747113757906301249837209713747402067689777172847");
        z = new int[8192];
        x = new long[11];
        uk_s = new long[8][256];
        for (n2 = 0; 256 > n2; ++n2) {
            n = "\u1823\uc6e8\u87b8\u014f\u36a6\ud2f5\u796f\u9152\u60bc\u9b8e\ua30c\u7b35\u1de0\ud7c2\u2e4b\ufe57\u1577\u37e5\u9ff0\u4ada\u58c9\u290a\ub1a0\u6b85\ubd5d\u10f4\ucb3e\u0567\ue427\u418b\ua77d\u95d8\ufbee\u7c66\udd17\u479e\uca2d\ubf07\uad5a\u8333\u6302\uaa71\uc819\u49d9\uf2e3\u5b88\u9a26\u32b0\ue90f\ud580\ubecd\u3448\uff7a\u905f\u2068\u1aae\ub454\u9322\u64f1\u7312\u4008\uc3ec\udba1\u8d3d\u9700\ucf2b\u7682\ud61b\ub5af\u6a50\u45f3\u30ef\u3f55\ua2ea\u65ba\u2fc0\ude1c\ufd4d\u9275\u068a\ub2e6\u0e1f\u62d4\ua896\uf9c5\u2559\u8472\u394c\u5e78\u388c\ud1a5\ue261\ub321\u9c1e\u43c7\ufc04\u5199\u6d0d\ufadf\u7e24\u3bab\uce11\u8f4e\ub7eb\u3c81\u94f7\ub913\u2cd3\ue76e\uc403\u5644\u7fa9\u2abb\uc153\udc0b\u9d6c\u3174\uf646\uac89\u14e1\u163a\u6909\u70b6\ud0ed\ucc42\u98a4\u285c\uf886".charAt(n2 / 2);
            long l = 0 == (1 & n2) ? (long)(n >>> 1748502536) : (long)(n & 0xFF);
            long l2 = l << -1739026111;
            if ((l2 ^ 0xFFFFFFFFFFFFFFFFL) <= -257L) {
                l2 ^= 0x11DL;
            }
            long l3 = l2 << -2116044543;
            if ((l3 ^ 0xFFFFFFFFFFFFFFFFL) <= -257L) {
                l3 ^= 0x11DL;
            }
            long l4 = l ^ l3;
            long l5 = l3 << -1833427391;
            if (-257L >= (l5 ^ 0xFFFFFFFFFFFFFFFFL)) {
                l5 ^= 0x11DL;
            }
            long l6 = l5 ^ l;
            uk.uk_s[0][n2] = jj.a(jj.a(jj.a(l4 << -536369200, jj.a(l5 << 1383493720, jj.a(jj.a(l3 << -473011736, jj.a(l << 962775152, l << 851384312)), l << -1186783072))), l2 << -1696148856), l6);
            int n3 = 1;
            while (-9 < ~n3) {
                uk.uk_s[n3][n2] = jj.a(uk_s[n3 + -1][n2] >>> 225008840, uk_s[n3 + -1][n2] << 538906104);
                ++n3;
            }
        }
        uk.x[0] = 0L;
        for (n2 = 1; 10 >= n2; ++n2) {
            n = (-1 + n2) * 8;
            uk.x[n2] = pj.a(jg.a(255L, uk_s[7][7 + n]), pj.a(pj.a(pj.a(pj.a(pj.a(pj.a(jg.a(uk_s[1][n - -1], 0xFF000000000000L), jg.a(uk_s[0][n], -72057594037927936L)), jg.a(uk_s[2][2 + n], 0xFF0000000000L)), jg.a(0xFF00000000L, uk_s[3][n - -3])), jg.a(0xFF000000L, uk_s[4][n - -4])), jg.a(0xFF0000L, uk_s[5][n - -5])), jg.a(65280L, uk_s[6][n - -6])));
        }
        y = "Passwords can only contain letters and numbers";
    }
}
