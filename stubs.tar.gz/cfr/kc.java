/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

final class kc
extends bh {
    int kc_v;
    String[][] kc_r;
    int kc_n;
    int kc_o;
    int[][] kc_u;
    boolean kc_p;
    long[][] kc_t;
    static String kc_s;
    static String kc_q;

    static final void b(int n, int n2) {
        boolean bl = client.A;
        int n3 = 0;
        int n4 = gd.gd_e;
        if (n4 < 5) {
            n3 = 8192 * (n4 * n4) / 1100;
        } else if (-106 < ~n4) {
            n3 = (-40960 + 16384 * n4) / 220;
        } else if (120 > n4) {
            n4 = -n4 + 120;
            n3 = -(n4 * n4 * 8192 / 3300) + 8192;
        }
        if (n != 8192) {
            return;
        }
        int n5 = 1;
        int n6 = 0;
        if (n2 == 1) {
            n6 = 1;
        }
        if (-4 == ~n2) {
            n5 = -1;
        }
        if (n2 == 4) {
            n5 = 1;
            n6 = 1;
        }
        if (-6 == ~n2) {
            n5 = -1;
            n6 = 1;
        }
        if (-7 == ~n2) {
            n5 = 1;
            n6 = -1;
        }
        if (n2 == 7 || 8 == n2) {
            n5 = -1;
            n6 = -1;
        }
        if (11 == n2) {
            n5 = -1;
        }
        if (-13 == ~n2) {
            n5 = -1;
            n6 = -1;
        }
        if (13 == n2) {
            n6 = -1;
            n5 = 1;
        }
        if (14 == n2) {
            n6 = 1;
            n5 = -1;
        }
        if (15 == n2) {
            n5 = 1;
            n6 = 1;
        }
        o.o_e = em.a(n6 * n3, n3 * n5, (byte)90);
    }

    static final ji a(boolean bl2, int n, int n2, boolean bl3, boolean bl4, boolean bl5) {
        try {
            if (bl4) {
                return null;
            }
            kh kh2 = null;
            kh kh3 = null;
            if (bl.U.fd_i != null) {
                mk.mk_d = new nh(bl.U.fd_i, 5200, 0);
                bl.U.fd_i = null;
                kh2 = new kh(255, mk.mk_d, new nh(bl.U.fd_l, 12000, 0), 0x200000);
            }
            if (mk.mk_d != null) {
                if (ig.ig_cc == null) {
                    ig.ig_cc = new nh[bl.U.fd_o.length];
                }
                if (ig.ig_cc[n2] == null) {
                    ig.ig_cc[n2] = new nh(bl.U.fd_o[n2], 12000, 0);
                    bl.U.fd_o[n2] = null;
                }
                kh3 = new kh(n2, mk.mk_d, ig.ig_cc[n2], 0x200000);
            }
            le le2 = sc.sc_l.a((byte)-86, n2, kh3, kh2, bl3);
            if (bl5) {
                le2.b((byte)0);
            }
            return new ji(le2, bl2, n);
        }
        catch (IOException iOException) {
            throw new RuntimeException(iOException.toString());
        }
    }

    kc() {
    }

    public static void a(int n) {
        block0: {
            kc_q = null;
            kc_s = null;
            if (n >= 40) break block0;
            kc_s = null;
        }
    }

    static {
        kc_q = "In Multiplayer";
        kc_s = "The Basics";
    }
}
