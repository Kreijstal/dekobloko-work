/*
 * Decompiled with CFR 0.152.
 */
final class ui {
    int N;
    int[] ui_d;
    int[] M;
    int[][] ui_q;
    static w x;
    int[] B;
    static gh ui_t;
    int[] I;
    int[] G;
    int[][] ui_a;
    int ui_m;
    int[] ui_j;
    private int A;
    int[] J;
    int[] ui_l;
    int[] ui_s;
    int[][] F;
    private int[] D;
    int[] O;
    int[] ui_f;
    private int[] y;
    int[] ui_b;
    static w[] E;
    int[] z;
    private int ui_u;
    int[] ui_w;
    int[][] ui_c;
    int[] K;
    static String ui_o;
    byte[][] ui_e;
    int H;
    int[] ui_n;
    int ui_k;
    int[][] ui_p;
    int[] C;
    int[] ui_r;
    int[] ui_v;
    int ui_i;
    ud[] ui_g;
    private pl ui_h;
    static String L;

    static final ta a(int n, String string) {
        if (n != 0) {
            E = null;
        }
        return new ta(string);
    }

    static final String a(int n) {
        if (n != -12040) {
            return null;
        }
        return de.V.c((byte)-38);
    }

    public static void b(int n) {
        block0: {
            ui_o = null;
            ui_t = null;
            L = null;
            x = null;
            E = null;
            if (n == 31158) break block0;
            x = null;
        }
    }

    private final void a(byte by) {
        block6: {
            boolean bl = client.A;
            if (this.ui_h == null) {
                return;
            }
            boolean bl2 = true;
            if (by != 103) {
                ui.a(-5);
            }
            int n = 0;
            while (~n > ~this.ui_g.length) {
                if (this.ui_g[n] == null) {
                    ud ud2 = this.M[n] >> 1040524164 != 0 ? this.ui_h.b(this.y[n], this.D[n], -1) : this.ui_h.a(-62, this.y[n], this.D[n]);
                    if (ud2 == null) {
                        bl2 = false;
                    } else {
                        this.M[n] = lb.a(this.M[n], 15);
                        this.ui_g[n] = ud2;
                    }
                }
                ++n;
            }
            if (!bl2) break block6;
            this.ui_h = null;
            this.D = null;
            this.y = null;
        }
    }

    ui(wl wl2, pl pl2) {
        int n;
        this.ui_h = pl2;
        this.ui_i = 1 + wl2.d((byte)-58);
        wl2.d((byte)-61);
        this.H = 1 + wl2.d((byte)-112);
        this.ui_u = 1 + wl2.d((byte)-84);
        this.A = wl2.d((byte)-122) + 1;
        int n2 = wl2.d((byte)-98);
        this.N = 1 & n2;
        this.ui_k = wl2.d((byte)-27);
        this.ui_m = wl2.d((byte)-30);
        this.ui_s = new int[this.ui_i];
        int n3 = 0;
        int n4 = 0;
        while (~n4 > ~this.ui_i) {
            this.ui_s[n4] = lb.a(255, n3 += wl2.d((byte)-126));
            ++n4;
        }
        this.ui_e = new byte[256][];
        this.ui_d = new int[256];
        an.a(this.ui_d, 0, 256, 64);
        n4 = 0;
        while (~n4 > -257) {
            this.ui_e[n4] = client.D;
            ++n4;
        }
        for (n4 = 0; n4 < this.ui_u; ++n4) {
            this.ui_d[n4] = 1 + wl2.d((byte)-103);
            n = wl2.e(3);
            byte[] byArray = new byte[n];
            if (0 >= n) continue;
            wl2.a(byArray, 0, (byte)127, n);
            this.ui_e[n4] = byArray;
        }
        this.z = new int[this.A];
        this.ui_v = new int[this.A];
        this.J = new int[this.A];
        this.F = new int[this.A][];
        this.K = new int[this.A];
        this.ui_p = new int[this.A][96];
        this.ui_j = new int[this.A];
        this.ui_a = new int[this.A][];
        this.C = new int[this.A];
        this.I = new int[this.A];
        this.ui_c = new int[this.A][];
        this.O = new int[this.A];
        this.ui_r = new int[this.A];
        this.ui_q = new int[this.A][];
        n4 = wl2.e(3);
        this.M = new int[n4];
        this.D = new int[n4];
        this.ui_f = new int[n4];
        this.ui_b = new int[n4];
        this.ui_w = new int[n4];
        this.y = new int[n4];
        this.G = new int[n4];
        this.ui_n = new int[n4];
        this.ui_l = new int[n4];
        this.ui_g = new ud[n4];
        this.B = new int[n4];
        n4 = 0;
        for (n = 0; this.A > n; ++n) {
            int n5;
            int n6;
            int n7 = wl2.d((byte)-33);
            if (-1 <= ~n7) continue;
            n3 = 0;
            for (n6 = 0; 96 > n6; ++n6) {
                this.ui_p[n][n6] = n4 - -lb.a(n3 += wl2.d((byte)-79), 255);
            }
            this.z[n] = wl2.d((byte)-64);
            n6 = wl2.d((byte)-99);
            this.ui_r[n] = wl2.d((byte)-19);
            this.ui_j[n] = wl2.d((byte)-110);
            this.K[n] = this.ui_j[n] + wl2.d((byte)-66);
            this.O[n] = wl2.d((byte)-110);
            int n8 = wl2.d((byte)-78);
            this.J[n] = wl2.d((byte)-64);
            this.C[n] = wl2.d((byte)-46);
            this.I[n] = this.C[n] + wl2.d((byte)-58);
            this.ui_q[n] = new int[n6];
            n3 = 0;
            int n9 = 0;
            for (n5 = 0; n6 > n5; ++n5) {
                this.ui_q[n][n5] = n3 += (n9 += wl2.e((byte)126));
            }
            n3 = 0;
            this.F[n] = new int[n6];
            for (n5 = 0; n5 < n6; ++n5) {
                this.F[n][n5] = lb.a(255, n3 += wl2.d((byte)-27));
            }
            n9 = 0;
            this.ui_c[n] = new int[n8];
            n3 = 0;
            n5 = 0;
            while (~n8 < ~n5) {
                this.ui_c[n][n5] = n3 += (n9 += wl2.e((byte)-2));
                ++n5;
            }
            n3 = 0;
            this.ui_a[n] = new int[n8];
            for (n5 = 0; n8 > n5; ++n5) {
                this.ui_a[n][n5] = lb.a(255, n3 += wl2.d((byte)-110));
            }
            this.ui_v[n] = wl2.e(3);
            for (n5 = 0; n7 > n5; ++n5) {
                this.B[n4] = wl2.h(65280);
                this.ui_w[n4] = wl2.h(65280);
                this.ui_f[n4] = this.ui_w[n4] + wl2.h(65280);
                this.G[n4] = wl2.d((byte)-112);
                this.ui_l[n4] = wl2.g((byte)-104);
                this.M[n4] = wl2.d((byte)-65);
                this.ui_n[n4] = wl2.d((byte)-54);
                this.ui_b[n4] = -1 + wl2.g((byte)-108);
                this.D[n4] = wl2.e(3);
                this.y[n4] = wl2.e(3);
                ++n4;
            }
        }
        this.a((byte)103);
    }

    static {
        ui_o = "Steady...";
        ui_t = new gh(2);
        L = "Some players haven't unlocked the currently selected game options.<br>Please see the player list on the left for details.";
    }
}
