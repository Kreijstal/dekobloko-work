/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Frame;

final class hg {
    static Frame hg_c;
    static nk hg_e;
    static int hg_b;
    static String hg_d;
    static ck hg_a;

    static final void a(boolean bl, int n) {
        block30: {
            boolean bl2 = client.A;
            if (bl || null == cd.cd_m) {
                dn.dn_k = false;
            }
            if (!bl) {
                if (null != cd.cd_m) {
                    if (0 >= lg.W) {
                        if (0 >= bf.bf_r) {
                            if (tg.tg_e < dl.M) {
                                if (tg.tg_e == 0) {
                                    mg.b(0, false);
                                }
                                ++tg.tg_e;
                            }
                        } else {
                            --bf.bf_r;
                        }
                    } else {
                        --lg.W;
                    }
                } else if (null != g.N) {
                    if (lg.W <= 0) {
                        if (~tg.tg_e >= -1) {
                            if (~dl.M < ~bf.bf_r) {
                                if (0 == bf.bf_r) {
                                    mg.b(n + 1843, true);
                                }
                                ++bf.bf_r;
                            }
                        } else {
                            --tg.tg_e;
                        }
                    } else {
                        --lg.W;
                    }
                } else {
                    dn.dn_k = false;
                    if (-1 <= ~bf.bf_r) {
                        if (tg.tg_e <= 0) {
                            if (dl.M > lg.W) {
                                if (-1 == ~lg.W) {
                                    tj.h((byte)-40);
                                }
                                ++lg.W;
                            }
                        } else {
                            --tg.tg_e;
                        }
                    } else {
                        --bf.bf_r;
                    }
                }
            } else if (0 >= lg.W) {
                if (~bf.bf_r >= -1) {
                    if (tg.tg_e > 0) {
                        --tg.tg_e;
                    }
                } else {
                    --bf.bf_r;
                }
            } else {
                --lg.W;
            }
            if (n == -1843) break block30;
            hg_b = -111;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        boolean bl = client.A;
        if (n < 59) {
            hg.a(true, -112);
        }
        if (null == gn.gn_e || ~gn.gn_e.length >= ~te.te_w) {
            int n7 = te.te_w * 2;
            if (~n7 == -1) {
                n7 = 80;
            }
            int[] nArray = new int[n7];
            int n8 = 0;
            while (~te.te_w < ~n8) {
                nArray[n8] = gn.gn_e[n8];
                ++n8;
            }
            gn.gn_e = nArray;
        }
        gn.gn_e[te.te_w++] = n3;
        gn.gn_e[te.te_w++] = n2;
        gn.gn_e[te.te_w++] = n6;
        gn.gn_e[te.te_w++] = n5;
        gn.gn_e[te.te_w++] = n4;
    }

    public static void a(byte by) {
        hg_e = null;
        if (by <= 87) {
            return;
        }
        hg_d = null;
        hg_c = null;
        hg_a = null;
    }

    static {
        hg_d = "Activating Special Items";
    }
}
