/*
 * Decompiled with CFR 0.152.
 */
final class ah {
    static ij ah_f;
    static w ah_h;
    static boolean[] ah_b;
    static ji ah_d;
    static ka ah_c;
    static ji ah_i;
    static String ah_a;
    static String ah_g;
    static String ah_e;
    private static final String z;

    public static void a(int n) {
        ah_e = null;
        ah_h = null;
        ah_d = null;
        ah_b = null;
        ah_g = null;
        ah_i = null;
        ah_c = null;
        ah_f = null;
        if (n != 8) {
            ah_b = null;
        }
        ah_a = null;
    }

    static {
        z = "ah.A(";
        ah_b = new boolean[8];
        ah_f = new ij("email");
        ah_a = "This game has been updated! Please reload this page.";
        ah_g = "Solid shapes can come back to your bucket - watch out!";
        ah_e = "Unable to add friend - system busy";
    }
}
