/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.MalformedURLException;
import java.net.URL;

final class c {
    int c_q;
    static ck c_i;
    int c_h;
    private boolean c_e = true;
    int c_o;
    mm c_p;
    int c_c;
    static vj c_r;
    gl c_b;
    int c_d;
    int c_n;
    gl c_l;
    int c_f;
    gl c_g;
    gl c_a;
    gl c_k;
    private int c_j;
    static ck[] c_m;

    public static void a(int n) {
        c_m = null;
        if (n != 23302) {
            return;
        }
        c_r = null;
        c_i = null;
    }

    final void a(byte by, int n, int n2, int n3, int n4, int n5, int n6) {
        hk.a(n6, n, n3, n4, n5, n2);
        int n7 = -40 / ((by - -68) / 42);
    }

    static final void a(byte by, String string, boolean bl, Applet applet) {
        if (fd.fd_d.startsWith("win") && fc.a((byte)-19, string)) {
            return;
        }
        try {
            applet.getAppletContext().showDocument(new URL(string), "_blank");
            if (by <= 72) {
                c_m = null;
            }
        }
        catch (MalformedURLException malformedURLException) {
            qb.a(null, 16408, "MGR1: " + string);
        }
    }

    final void a(int n, mm mm2) {
        boolean bl = client.A;
        a a2 = new a(mm2, 2, 2, 0x222222, 1, 1, 1, 2 + mm2.K + mm2.R);
        a2.a_q = 0xFFFFFF;
        this.c_k = a2;
        bc bc2 = new bc();
        a2.a(-12253, bc2);
        bc2.a_c = 0xB2B2B2;
        bc2.a_v = 0xEEEEEE;
        this.c_h = 3;
        this.c_p = mm2;
        this.c_j = 0xEEEEEE;
        this.c_n = -1;
        this.c_c = 3;
        this.c_f = 0x555555;
        this.c_o = 0xEEEEEE;
        this.c_d = 3;
        this.c_q = 3;
        bc2.a(0, 117).a(0xEEEEEE, (byte)106).a(120, fl.a(0x777777, 0x888888, 0x999999, 32140));
        bc2.a(1, n ^ 0xCCCCD4).a(-50, fl.a(0xCCCCCC, 0xAAAAAA, 0x999999, 32140));
        bc2.a(3, 101).a(121, fl.a(0x999999, 0x888888, 0x777777, 32140)).c(-1, 1).a(1, Integer.MIN_VALUE);
        ck[] ckArray = new ck[9];
        ld ld2 = new ld(32, 32);
        Object object = ld2;
        for (int i = 0; ((ld)object).D.length > i; ++i) {
            ld2.D[i] = 0x40404040;
        }
        ckArray[4] = ld2;
        bc2.a(4, 25).a(n + -13438370, true).a(113, ckArray);
        bc2.a(5, 44).a(n ^ 0xCCCCAB, ta.a(false, 0, 65793, 0, 0)).a(n + -13438370, true).a(-1, (byte)106);
        this.c_b = bc2;
        object = new bc(bc2, true);
        ((bc)object).a_f = 0;
        bc bc3 = new bc(bc2, true);
        bc3.a_f = 0;
        bc3.a(qm.a(9, 0x888888), false);
        bc3.a(1, 95).a(-128, qm.a(9, 0xAAAAAA)).a(0x222222, (byte)106);
        this.c_a = new kk(mm2, 2, 2, 0xFFFFFF, -1, 5, 5, 15, 15, 0x444444);
        new al(mm2, 2, 2, 0xFFFFFF, -1, 0xFFFFFF, 0xFF4444, 0x444444);
        new qj(mm2, 0xFFFFFF, -1, 0x7777777, 0x444444, 3, 0xFFFFFFF);
        bc bc4 = new bc();
        a2.a(-12253, bc4);
        bc4.a(0, 78).a(n ^ 0xFF333354, fl.a(0x999999, 0xEEEEEE, 0x777777, n + -13389632)).a(0x111111, (byte)106).b(-83, -1);
        bc4.a(4, n ^ 0xCCCCF4).a(-16598, true).a(-27, ckArray);
        this.c_l = bc4;
        ck[] ckArray2 = new ck[9];
        ckArray2[4] = new ck(2, 1);
        ck[] ckArray3 = new ck[9];
        ckArray3[4] = new ck(1, 2);
        ckArray2[4].D = new int[]{0x666666, 0x777777};
        ckArray3[4].D = ckArray2[4].D;
        bc bc5 = new bc();
        bc bc6 = new bc();
        bc5.a(119, ckArray2, 0);
        bc6.a(n ^ 0xCCCCB6, ckArray3, 0);
        ck ck2 = new ck(7, 4);
        ck2.D = new int[]{0x888888, 0x888888, 0x888888, 0xCCCCCC, 0x888888, 0x888888, 0x888888, 0x888888, 0x888888, n, 0xCCCCCC, 0xCCCCCC, 0x888888, 0x888888, 0x888888, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC, 0x888888, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC, 0xCCCCCC};
        bc bc7 = new bc(bc2, true);
        bc7.a(ck2.c(), 2);
        ck2.d();
        bc7 = new bc(bc2, true);
        bc7.a(ck2.c(), 2);
        ck2.d();
        bc7 = new bc(bc2, true);
        bc7.a(ck2.c(), 2);
        ck2.d();
        bc7 = new bc(bc2, true);
        bc7.a(ck2, 2);
    }

    private final void a(int n, String string, int n2, int n3) {
        if (n < 50) {
            return;
        }
        int n4 = this.c_p.a(string);
        int n5 = this.c_p.K + this.c_p.C;
        int n6 = n2;
        if (~hk.hk_j > ~(n6 + (n4 - -6))) {
            n6 = -n4 + (hk.hk_j + -6);
        }
        int n7 = 32 + (-this.c_p.C + n3);
        if (hk.hk_i < n7 - (-n5 + -6)) {
            n7 = -6 + hk.hk_i - n5;
        }
        hk.f(n6, n7, n4 + 6, 6 + n5, this.c_j);
        hk.a(1 + n6, n7 - -1, n4 - -4, 4 + n5, this.c_f);
        this.c_p.a(string, n6 + 3, n7 - (-3 + -this.c_p.C), this.c_j, -1);
    }

    final void a(int n, int n2, int n3, int n4, byte by, int n5) {
        int n6 = 111 % ((by - -23) / 54);
        hk.b(n3, n2, n, n5, n4);
    }

    private final void a(int n, int n2, String string, int n3) {
        int n4;
        int n5;
        boolean bl = client.A;
        int n6 = this.c_c + this.c_d;
        int n7 = this.c_h + this.c_q;
        int n8 = this.c_n;
        if (n8 == -1) {
            n8 = this.c_p.K + this.c_p.R;
        }
        if (n2 != 16521) {
            return;
        }
        int n9 = hk.hk_j >> 631180802;
        int n10 = this.c_p.a(string);
        int n11 = this.c_p.R + this.c_p.K;
        int n12 = 1;
        if (n10 > n9 || -1 != string.indexOf("<br>")) {
            if (n9 >= n10) {
                n5 = n9;
            } else {
                n4 = n10 / n9;
                n5 = n9 + 2 * ((-1 + (n10 % n9 - -n4)) / n4);
            }
            if (el.L == null) {
                el.L = new String[16];
            }
            n12 = this.c_p.a(string, new int[]{n5}, el.L);
            n11 += (-1 + n12) * n8;
            n10 = 0;
            n4 = 0;
            while (~n12 < ~n4) {
                int n13 = this.c_p.a(el.L[n4]);
                if (~n13 < ~n10) {
                    n10 = n13;
                }
                ++n4;
            }
        }
        if (n6 + (n5 = n) + n10 > hk.hk_j) {
            n5 = hk.hk_j + (-n10 + -n6);
        }
        n4 = 32 + n3 + -this.c_p.C;
        if (~hk.hk_i > ~(n4 - (-n11 + -n7))) {
            n4 = -n7 + (n3 - n11);
        }
        hk.f(n5, n4, n6 + n10, n11 - -n7, this.c_o);
        hk.a(1 + n5, 1 + n4, n6 + (n10 - 2), n11 - (-n7 + 2), this.c_f);
        this.c_p.a(string, this.c_c + n5, this.c_q + n4, n10, n11, this.c_j, -1, 0, 0, n8);
    }

    final void a(String string, int n, int n2, int n3) {
        block2: {
            if (this.c_e) {
                this.a(n3, 16521, string, n2);
            } else {
                this.a(n ^ 0xFFFFFFC9, string, n3, n2);
            }
            if (n == -1) break block2;
            this.a(124, 123, -118, 6, (byte)-71, 127);
        }
    }

    static {
        c_r = new vj();
    }
}
