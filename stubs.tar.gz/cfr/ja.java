/*
 * Decompiled with CFR 0.152.
 */
final class ja {
    private int[] ja_b;
    private int ja_e;
    private int[] ja_c;
    int ja_d;
    private float[][] ja_f;
    private int[] ja_a;

    private static final int a(int n, int n2) {
        int n3 = (int)Math.pow(n, 1.0 / (double)n2) + 1;
        while (vb.a(n3, n2, false) > n) {
            --n3;
        }
        return n3;
    }

    private final void c() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int[] nArray = new int[this.ja_e];
        int[] nArray2 = new int[33];
        for (n7 = 0; n7 < this.ja_e; ++n7) {
            int n8;
            n6 = this.ja_a[n7];
            if (n6 == 0) continue;
            n5 = 1 << 32 - n6;
            nArray[n7] = n4 = nArray2[n6];
            if ((n4 & n5) != 0) {
                n3 = nArray2[n6 - 1];
            } else {
                n3 = n4 | n5;
                for (n2 = n6 - 1; n2 >= 1 && (n8 = nArray2[n2]) == n4; --n2) {
                    n = 1 << 32 - n2;
                    if ((n8 & n) != 0) {
                        nArray2[n2] = nArray2[n2 - 1];
                        break;
                    }
                    nArray2[n2] = n8 | n;
                }
            }
            nArray2[n6] = n3;
            for (n2 = n6 + 1; n2 <= 32; ++n2) {
                n8 = nArray2[n2];
                if (n8 != n4) continue;
                nArray2[n2] = n3;
            }
        }
        this.ja_b = new int[8];
        int n9 = 0;
        for (n7 = 0; n7 < this.ja_e; ++n7) {
            n6 = this.ja_a[n7];
            if (n6 == 0) continue;
            n5 = nArray[n7];
            n4 = 0;
            for (n3 = 0; n3 < n6; ++n3) {
                n2 = Integer.MIN_VALUE >>> n3;
                if ((n5 & n2) != 0) {
                    if (this.ja_b[n4] == 0) {
                        this.ja_b[n4] = n9;
                    }
                    n4 = this.ja_b[n4];
                } else {
                    ++n4;
                }
                if (n4 >= this.ja_b.length) {
                    int n10;
                    int[] nArray3 = new int[this.ja_b.length * 2];
                    n = n10 = 0;
                    while (n10 < this.ja_b.length) {
                        nArray3[n10] = this.ja_b[n10];
                        ++n10;
                    }
                    this.ja_b = nArray3;
                }
                n2 >>>= 1;
            }
            this.ja_b[n4] = ~n7;
            if (n4 < n9) continue;
            n9 = n4 + 1;
        }
    }

    final float[] b() {
        return this.ja_f[this.a()];
    }

    ja() {
        int n;
        int n2;
        int n3;
        boolean bl;
        va.c(24);
        this.ja_d = va.c(16);
        this.ja_e = va.c(24);
        this.ja_a = new int[this.ja_e];
        boolean bl2 = bl = va.b() != 0;
        if (bl) {
            n3 = 0;
            n2 = va.c(5) + 1;
            while (n3 < this.ja_e) {
                int n4 = va.c(s.b((byte)120, this.ja_e - n3));
                for (n = 0; n < n4; ++n) {
                    this.ja_a[n3++] = n2;
                }
                ++n2;
            }
        } else {
            int n5;
            n3 = va.b() != 0 ? 1 : 0;
            n2 = n5 = 0;
            while (n5 < this.ja_e) {
                this.ja_a[n5] = n3 != 0 && va.b() == 0 ? 0 : va.c(5) + 1;
                ++n5;
            }
        }
        this.c();
        n3 = va.c(4);
        if (n3 > 0) {
            int n6;
            float f = va.a(va.c(32));
            float f2 = va.a(va.c(32));
            n = va.c(4) + 1;
            boolean bl3 = va.b() != 0;
            int n7 = n3 == 1 ? ja.a(this.ja_e, this.ja_d) : this.ja_e * this.ja_d;
            this.ja_c = new int[n7];
            for (n6 = 0; n6 < n7; ++n6) {
                this.ja_c[n6] = va.c(n);
            }
            this.ja_f = new float[this.ja_e][this.ja_d];
            if (n3 == 1) {
                for (n6 = 0; n6 < this.ja_e; ++n6) {
                    float f3 = 0.0f;
                    int n8 = 1;
                    for (int i = 0; i < this.ja_d; ++i) {
                        float f4;
                        int n9 = n6 / n8 % n7;
                        this.ja_f[n6][i] = f4 = (float)this.ja_c[n9] * f2 + f + f3;
                        if (bl3) {
                            f3 = f4;
                        }
                        n8 *= n7;
                    }
                }
            } else {
                for (n6 = 0; n6 < this.ja_e; ++n6) {
                    float f5 = 0.0f;
                    int n10 = n6 * this.ja_d;
                    for (int i = 0; i < this.ja_d; ++i) {
                        float f6;
                        this.ja_f[n6][i] = f6 = (float)this.ja_c[n10] * f2 + f + f5;
                        if (bl3) {
                            f5 = f6;
                        }
                        ++n10;
                    }
                }
            }
            return;
        }
    }

    final int a() {
        int n = 0;
        while (this.ja_b[n] >= 0) {
            n = va.b() != 0 ? this.ja_b[n] : n + 1;
        }
        return ~this.ja_b[n];
    }
}
