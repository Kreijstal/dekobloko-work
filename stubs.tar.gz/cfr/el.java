/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;

final class el
extends sf {
    byte[] H;
    static char G;
    static String[] L;
    static long J;
    static String I;
    int F;
    kh K;

    @Override
    final byte[] g(byte by) {
        block1: {
            if (this.z) {
                throw new RuntimeException();
            }
            if (by >= 65) break block1;
            this.a(true);
        }
        return this.H;
    }

    public static void b(boolean bl) {
        block0: {
            L = null;
            I = null;
            if (bl) break block0;
            Component component = null;
            el.a(-15, (byte)51, -90, component);
        }
    }

    static final eh a(int n, byte by, int n2, Component component) {
        try {
            if (by < 5) {
                return null;
            }
            Class<?> clazz = Class.forName("rj");
            eh eh2 = (eh)clazz.newInstance();
            eh2.a(n2, (byte)83, n, component);
            return eh2;
        }
        catch (Throwable throwable) {
            wf wf2 = new wf();
            ((eh)wf2).a(n2, (byte)83, n, component);
            return wf2;
        }
    }

    el() {
    }

    @Override
    final int a(boolean bl) {
        block1: {
            if (this.z) {
                return 0;
            }
            if (!bl) break block1;
            I = null;
        }
        return 100;
    }

    static {
        I = "The invitation has been withdrawn.";
    }
}
