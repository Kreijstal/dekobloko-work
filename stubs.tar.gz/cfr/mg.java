/*
 * Decompiled with CFR 0.152.
 */
final class mg
extends w {
    static boolean Nb = false;
    static ig mg_bc;
    private w mg_ac;
    private StringBuilder Ub;
    private ha Qb;
    private w Xb;
    static int[][] Ob;
    private w[] Yb;
    long Tb;
    private w mg_cc;
    private w Sb;
    static boolean Zb;
    private w Pb;
    private w Wb;
    static int Vb;
    private int Rb = -2;

    public static void f(int n) {
        Ob = null;
        if (n != 256) {
            return;
        }
        mg_bc = null;
    }

    static final ck a(int n, int n2, String string, lm lm2, int n3, int n4, byte by) {
        ck ck2;
        block8: {
            int n5;
            int n6;
            int n7;
            boolean bl = client.A;
            int n8 = lm2.a(string) - 1;
            while (n3 * (2 + n8) >= 620) {
                --n3;
            }
            int n9 = lm2.K + lm2.R;
            int n10 = n3;
            int n11 = n10 / 4;
            int[] nArray = hk.hk_l;
            int n12 = hk.hk_j;
            int n13 = hk.hk_i;
            ck ck3 = new ck(n8, n9);
            ck3.a();
            lm2.a(string, 0, lm2.R, 0xFFFFFF, -1);
            if (0 == n4) {
                n4 = 65793;
            }
            hk.a(nArray, n12, n13);
            int[] nArray2 = ck3.D;
            ck2 = new ck((2 + n8) * n10, n10 * (2 + n9));
            ck2.a();
            int n14 = 0;
            while (~n9 < ~n14) {
                for (n7 = 0; n8 > n7; ++n7) {
                    if (~nArray2[n14 * n8 + n7] == -1) continue;
                    n6 = n10 * (n7 - -1);
                    n5 = (n14 - -1) * n10;
                    hk.e(n6, n5, n10 - n11, n4 | 0xFF000000);
                    hk.e(-1 + n10 + n6, n5, n10 + -n11, n4 | 0xFF000000);
                    hk.e(n6, n5 - -n10 - 1, -n11 + n10, n4 | 0xFF000000);
                    hk.e(n6 + (n10 + -1), n10 + n5 - 1, -n11 + n10, n4 | 0xFF000000);
                }
                ++n14;
            }
            hk.a(nArray, n12, n13);
            n14 = 0;
            while (~n14 > ~n9) {
                for (n7 = 0; n8 > n7; ++n7) {
                    if (0 == nArray2[n7 - -(n14 * n8)]) continue;
                    n6 = n10 + n7 * n10;
                    n5 = n6 - -n10;
                    int n15 = n10 * n14 - -n10;
                    int n16 = n10 + n15;
                    for (int i = n15; i < n16; ++i) {
                        int n17 = 256 * (i - n10) / (n10 * n9);
                        int n18 = fl.a(n2, n17, 256, n, 124);
                        for (int j = n6; n5 > j; ++j) {
                            ck2.D[j - -(ck2.I * i)] = de.b(-16777216, n18);
                        }
                    }
                }
                ++n14;
            }
            if (by >= 84) break block8;
            mg.f(17);
        }
        return ck2;
    }

    final boolean b(boolean bl) {
        if (bl) {
            return false;
        }
        if (1 != ~this.Rb) {
            return false;
        }
        if (-14 == ~wh.wh_c) {
            this.Rb = -1;
        }
        return true;
    }

    static final void a(int n, ck ck2, ck ck3) {
        boolean bl = client.A;
        int[] nArray = ck3.D;
        int[] nArray2 = ck3.D;
        int[] nArray3 = ck2.D;
        int n2 = nArray.length;
        int n3 = n;
        while (~n3 > ~n2) {
            if (0 == nArray3[n3]) {
                nArray[n3] = 0;
            }
            ++n3;
        }
    }

    private final int a(w w2, int n, int n2, w w3, int n3, String string) {
        w w4 = new w(0L, w2, 0, n, n2, n3, string);
        w3.a(w4, -16834);
        return n += 32;
    }

    private final int a(boolean bl, w w2, w w3, int n, int n2) {
        n += 8;
        if (!bl) {
            Ob = null;
        }
        int n3 = w2.J.b(w2.Y, n2 + -(w2.w_ub * 2), w2.Db);
        w2.a(n2, 0, n, n3, 0);
        w3.a(w2, -16834);
        return n += n3 - 0;
    }

    final int c(int n, boolean bl) {
        boolean bl2 = client.A;
        this.a(false, bl);
        if (n != 497) {
            return -95;
        }
        if (null != this.Wb) {
            this.Wb.Y = this.Ub.toString();
            this.Wb.w_vb = (this.w_mb - this.Wb.J.a(this.Wb.Y)) / 2;
            this.Wb.w_mb = this.w_mb + -this.Wb.w_vb;
            if (null != this.Qb && 0 != this.Qb.w_ob) {
                this.Qb.w_ab = !this.Qb.w_ab;
            }
            for (int i = 0; qb.qb_u > i; ++i) {
                if (this.Yb[i] == null) continue;
                boolean bl3 = this.Yb[i].Hb = -1 > ~this.Ub.length();
                if (!this.Yb[i].Hb || 0 == this.Yb[i].w_ob) continue;
                return i;
            }
        }
        if (-1 != ~this.mg_ac.w_ob) {
            return -1;
        }
        if (bl && 0 != ig.Yb && 0 == this.w_ob) {
            return -1;
        }
        return this.Rb;
    }

    final boolean e(int n) {
        if (n != 5658) {
            mg.f(-70);
        }
        return null != this.Qb && this.Qb.w_ab;
    }

    final String g(byte by) {
        block0: {
            if (by == -96) break block0;
            Nb = true;
        }
        return this.Ub.toString();
    }

    static final void b(int n, boolean bl) {
        je.je_f = bl ? new ak(ue.ue_c, cl.cl_n) : new ak(eg.eg_b, in.in_o);
        ee.ee_i = new w(0L, null);
        ee.ee_i.a(je.je_f.ak_h, -16834);
        ee.ee_i.a(ma.G, -16834);
        mn.mn_e = new w(n, ui.x);
        cl.C = new w(0L, null);
        mn.mn_e.a(ie.ie_a, -16834);
        mn.mn_e.a(cl.C, -16834);
        cl.C.a(gg.y, -16834);
        cl.C.a(qc.qc_q, -16834);
        vb.a(bl, -2);
    }

    mg(int n, int n2, int n3, int n4, int n5, w w2, w w3, w w4, w w5, ha ha2, w w6, String string, long l) {
        super(0L, w2);
        this.Tb = l;
        this.mg_cc = new w(0L, w3, ue.ue_a.toUpperCase());
        this.mg_cc.X = 1;
        this.a(this.mg_cc, -16834);
        this.mg_ac = new w(0L, w4);
        this.mg_cc.a(this.mg_ac, -16834);
        this.Pb = new w(0L, null);
        this.a(this.Pb, -16834);
        if (null == string) {
            this.Xb = new w(0L, w5, hc.hc_f);
            this.Xb.G = 0xAAAAAA;
            this.Xb.X = 1;
            this.Pb.a(this.Xb, -16834);
            int n6 = 226;
            int n7 = 10;
            int n8 = this.Xb.J.a(this.Xb.Y, n6);
            this.Xb.a(n6, 0, n7, kf.O * n8, 13);
            this.Pb.a(n6 + 13 - -13, 0, 24, 10 - -(n7 += kf.O * n8), 0);
            this.Pb.w_lb = ea.a(0x202020, -20982, 3, this.Pb.N, 0x808080, 0xB0B0B0);
            int n9 = 26 - -n6;
            int n10 = n7 + 34;
            int n11 = vh.a(n3, -18265, n9, n);
            int n12 = o.a(n4, 0, n10, n2);
            this.a(n9, 0, n12, n10, n11);
        } else {
            int n13;
            int n14;
            w[] wArray;
            this.Xb = new w(0L, w5, ph.Hb);
            this.Xb.X = 1;
            this.Xb.G = 0xAAAAAA;
            this.Pb.a(this.Xb, -16834);
            this.Sb = new w(0L, w5, pc.pc_c);
            this.Sb.X = 1;
            this.Sb.G = 0xAAAAAA;
            this.Pb.a(this.Sb, -16834);
            this.Wb = new w(0L, w5);
            this.Wb.G = 0xFFCC66;
            this.Pb.a(this.Wb, -16834);
            this.Wb.T = "|";
            if (~d.d_b <= -6 || ~te.te_p <= -3) {
                this.Qb = new ha(0L, ha2, -8 < ~d.d_b && -3 < ~te.te_p ? rk.rk_bb : si.si_j);
                this.Pb.a(this.Qb, -16834);
            }
            w[] wArray2 = wArray = new w[3];
            wArray[0] = new w(0L, null);
            this.Pb.a(wArray[0], -16834);
            wArray[1] = new w(0L, null);
            this.Pb.a(wArray[1], -16834);
            wArray[2] = new w(0L, null);
            this.Pb.a(wArray[2], -16834);
            this.Yb = new w[qb.qb_u];
            for (n14 = 0; n14 < qb.qb_u; ++n14) {
                if (pn.pn_bb[n14] == null) continue;
                this.Yb[n14] = new w(0L, w6, pn.pn_bb[n14]);
                this.Yb[n14].X = 0;
                this.Yb[n14].Hb = null != string;
                this.Pb.a(this.Yb[n14], -16834);
            }
            this.Ub = new StringBuilder(12);
            if (null != string) {
                this.Ub.append(string);
            }
            n14 = 0;
            int n15 = w3.J.a(cf.cf_g);
            if (n15 > n14) {
                n14 = n15;
            }
            if (n14 < (n15 = w3.J.a(ul.ul_a))) {
                n14 = n15;
            }
            if (~(n15 = w3.J.a(k.k_d)) < ~n14) {
                n14 = n15;
            }
            n15 = 0;
            while (~n15 > ~qb.qb_u) {
                if (this.Yb[n15] != null && (n13 = this.Yb[n15].a(true)) > n14) {
                    n14 = n13;
                }
                ++n15;
            }
            if (-141 > ~n14) {
                n14 = 140;
            }
            n15 = 0;
            n13 = 0;
            n13 = 0;
            n13 = this.a(w3, n13, n14, wArray[0], 24, cf.cf_g);
            n13 = this.a(true, this.Yb[6], wArray[0], n13, n14);
            n13 = this.a(true, this.Yb[9], wArray[0], n13, n14);
            n13 = this.a(true, this.Yb[5], wArray[0], n13, n14);
            n13 = this.a(true, this.Yb[7], wArray[0], n13, n14);
            n13 = this.a(true, this.Yb[15], wArray[0], n13, n14);
            if ((n13 = this.a(true, this.Yb[4], wArray[0], n13, n14)) > n15) {
                n15 = n13;
            }
            n13 = 0;
            n13 = this.a(w3, n13, n14, wArray[1], 24, ul.ul_a);
            n13 = this.a(true, this.Yb[16], wArray[1], n13, n14);
            n13 = this.a(true, this.Yb[17], wArray[1], n13, n14);
            n13 = this.a(true, this.Yb[18], wArray[1], n13, n14);
            n13 = this.a(true, this.Yb[19], wArray[1], n13, n14);
            if (~n15 > ~(n13 = this.a(true, this.Yb[20], wArray[1], n13, n14))) {
                n15 = n13;
            }
            n13 = 0;
            n13 = this.a(w3, n13, n14, wArray[2], 24, k.k_d);
            n13 = this.a(true, this.Yb[13], wArray[2], n13, n14);
            n13 = this.a(true, this.Yb[21], wArray[2], n13, n14);
            if (n15 < (n13 = this.a(true, this.Yb[11], wArray[2], n13, n14))) {
                n15 = n13;
            }
            int n16 = 3 * n14 - -26;
            int n17 = this.mg_cc.a(true);
            if (~n17 < ~n16) {
                n16 = n17;
            }
            if (this.Qb != null && ~n16 > ~(n17 = this.Qb.c(4, -4168))) {
                n16 = n17;
            }
            this.mg_cc.a(13 - (-n16 + -13), 0, 0, 24, 0);
            this.mg_ac.a(15, 0, 5, 15, -20 + this.mg_cc.w_mb);
            int n18 = 10;
            this.Xb.a(n16, 0, n18, kf.O * 2, 13);
            this.Sb.a(n16, 0, n18 += 2 * kf.O, kf.O * 2, 13);
            this.Wb.a(0, 0, n18 += 2 * kf.O + 10, kf.O, 0);
            n18 += kf.O + 10;
            if (null != this.Qb) {
                n17 = this.Qb.c(4, -4168);
                this.Qb.a(n17, 8, n18, (n16 + -n17) / 2 + 13, 4, kf.O);
                n18 += 10 + kf.O;
            }
            wArray[0].a(n14, 0, n18, n15, 13);
            wArray[1].a(n14, 0, n18, n15, 13 + (n14 + 13));
            wArray[2].a(n14, 0, n18, n15, 2 * n14 + 13 - -26);
            int n19 = n18;
            this.Pb.a(13 - -n16 + 13, 0, 24, 10 + n15 + n19, 0);
            this.Pb.w_lb = ea.a(0x202020, -20982, 3, this.Pb.N, 0x808080, 0xB0B0B0);
            int n20 = 13 - -n16 + 13;
            int n21 = 10 + (n19 + (24 + n15));
            int n22 = vh.a(n3, -18265, n20, n);
            int n23 = o.a(n4, 0, n21, n2);
            this.a(n20, 0, n23, n21, n22);
        }
    }
}
