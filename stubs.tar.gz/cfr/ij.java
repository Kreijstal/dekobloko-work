/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class ij {
    static boolean ij_e = true;
    private String ij_a;
    static ck ij_d;
    static int ij_c;
    static String ij_b;

    final boolean a(String string, int n) {
        int n2 = -19 % ((42 - n) / 60);
        return this.ij_a.equals(string);
    }

    final void a(int n, Applet applet) {
        if (n >= -40) {
            ij_e = true;
        }
        pf.a(applet, "jagex-last-login-method", 31536000L, (byte)96, this.ij_a);
    }

    static final int a(int n, wl wl2, String string) {
        int n2;
        block0: {
            n2 = wl2.wl_n;
            byte[] byArray = km.a(n ^ 0xFFFFB78D, (CharSequence)string);
            wl2.c(byArray.length, 57);
            wl2.wl_n += me.z.a(wl2.wl_r, byArray, byArray.length, wl2.wl_n, 0, 8);
            if (n == -20539) break block0;
            String string2 = null;
            ij.a(null, string2, (byte)-115);
        }
        return -n2 + wl2.wl_n;
    }

    public static void a(int n) {
        if (n >= -38) {
            String string = null;
            ij.a(null, string, (byte)-11);
        }
        ij_d = null;
        ij_b = null;
    }

    static final String a(int n, CharSequence charSequence) {
        if (n != 5) {
            return null;
        }
        return wc.a(false, charSequence, n + -5);
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    static final boolean a(String string, String string2, byte by) {
        string2 = jm.a('_', string2, "", -1);
        if (by > -101) {
            ij.a(-68, -120);
        }
        String string3 = oa.a(string, -1);
        return string2.indexOf(string) != -1 || -1 != string2.indexOf(string3);
    }

    static final void a(int n, int n2) {
        qc.Y = n;
        if (bl.T != dl.M) {
            int n3 = dl.M * dl.M;
            int n4 = n3 - bl.T * bl.T;
            n += n4 * (ac.B - n) / n3;
        }
        if (n2 > -24) {
            ij.a(105);
        }
        ea.D.a(640, 0, n, 120, vh.vh_g);
        gi.a(-24 + ac.B, j.j_c, 640, nk.nk_b, 0, 5, (byte)-113);
    }

    ij(String string) {
        this.ij_a = string;
    }

    static {
        ij_b = "Player Name: ";
    }
}
