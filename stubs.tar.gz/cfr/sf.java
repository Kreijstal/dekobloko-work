/*
 * Decompiled with CFR 0.152.
 */
abstract class sf
extends be {
    static String[] E;
    boolean D;
    static int B;
    static int[] C;
    static long[] y;
    volatile boolean z = true;
    boolean A;

    abstract byte[] g(byte var1);

    static final String c(int n2) {
        boolean bl2 = client.A;
        String string = null;
        String string2 = null;
        if (~pk.pk_r == -1 && g.N != null) {
            string2 = gh.gh_f;
        }
        if (2 == pk.pk_r && !hl.a((byte)-53)) {
            string2 = !qe.a(cf.cf_c, 3) ? cm.a((byte)96, se.V, new String[]{ed.ed_c}) : cm.a((byte)87, dc.dc_k, new String[]{ed.ed_c});
            if (jh.jh_h) {
                ca.a(null, null, string2, (byte)125, 2, 0);
                qn.l(13);
            }
        }
        if (null == string2 && !sc.sc_m && tf.tf_gb == null) {
            string2 = bl.W;
        }
        if (null == string2) {
            String string3;
            String string4 = oa.oa_f;
            string4 = string3 = b.a(107, string4);
            String string5 = "";
            String string6 = "|";
            int n3 = pk.pk_r;
            int n4 = 0;
            if (n3 == 2) {
                string5 = cm.a((byte)81, oj.oj_b, new String[]{ed.ed_c});
                String string7 = cm.a((byte)125, im.im_j, new String[]{string3});
                n4 = -485 + jb.jb_f.w_mb + wj.Mb.w_mb - (-ff.ff_o.a(string7) + ff.ff_o.a(string5));
                if (0 > n4) {
                    n4 = 0;
                }
            } else {
                if (0 == n3) {
                    if (cd.cd_m == null && ii.ii_q) {
                        string5 = "[" + uc.uc_b + "] ";
                    }
                    if (null != cd.cd_m) {
                        string5 = wh.wh_b && null != f.f_q ? "[" + f.f_q + "] " : "[" + cm.a((byte)115, hf.hf_a, new String[]{cd.cd_m.Vb}) + "] ";
                        n3 = 1;
                    }
                }
                String string8 = !rc.a(false) ? "<img=3>: " : ": ";
                string5 = string5 + string4 + string8;
                if (!wc.wc_n) {
                    if (wl.wl_p) {
                        string6 = "";
                        string5 = "<col=999999>" + string5 + ci.ci_d + "</col>";
                    }
                } else {
                    string6 = "";
                    string5 = "<col=999999>" + string5 + vg.vg_s + "</col>";
                }
                int n5 = ff.ff_o.a(string5);
                if (!rc.a(false)) {
                    if (wj.Mb.w_jb && ~(bh.bh_g + -wj.Mb.E) > ~n5) {
                        string = !wc.wc_n ? ci.ci_d : "Broken!";
                    }
                    if (-1 != ~wj.Mb.w_ob && ~n5 < ~wj.Mb.xb && !wc.wc_n) {
                        aj.a(-1045);
                    }
                }
            }
            cl.a(string6, n4, tl.tl_q[n3], string5 + mm.c(dj.dj_ab.toString()), -24503);
            if (!jg.jg_i) {
                jb.jb_f.w_jb = false;
            }
            if (jb.jb_f.w_jb) {
                string = cm.a((byte)126, vf.vf_d, new String[]{string3, ed.ed_c});
            }
        } else {
            cl.a(null, 0, ij.ij_c, string2, -24503);
        }
        int n6 = 125 % ((30 - n2) / 41);
        return string;
    }

    abstract int a(boolean var1);

    public static void f(byte by) {
        y = null;
        E = null;
        if (by > -123) {
            B = -69;
        }
        C = null;
    }

    sf() {
    }

    static {
        C = new int[8192];
        y = new long[32];
        B = 0;
        E = new String[]{"All scores", "My scores", "Best each"};
    }
}
