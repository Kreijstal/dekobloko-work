/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Random;

final class bf
extends bh {
    static w bf_v;
    byte[] bf_n;
    static c x;
    static Random y;
    int bf_s;
    long bf_p;
    static int bf_r;
    static String bf_q;
    static ud bf_w;
    static int bf_o;
    static w bf_t;
    static ud bf_u;

    static final void a(int n, boolean bl, int n2, String string, Color color) {
        try {
            Graphics graphics = jh.jh_b.getGraphics();
            if (wf.wf_s == null) {
                wf.wf_s = new Font("Helvetica", 1, 13);
            }
            if (bl) {
                graphics.setColor(Color.black);
                graphics.fillRect(0, 0, de.M, ob.ob_g);
            }
            if (null == color) {
                color = new Color(140, 17, 17);
            }
            try {
                if (null == lj.lj_a) {
                    lj.lj_a = jh.jh_b.createImage(304, 34);
                }
                Graphics graphics2 = lj.lj_a.getGraphics();
                graphics2.setColor(color);
                graphics2.drawRect(0, 0, 303, 33);
                graphics2.fillRect(2, 2, 3 * n, 30);
                graphics2.setColor(Color.black);
                graphics2.drawRect(1, 1, 301, 31);
                graphics2.fillRect(n * 3 + 2, 2, 300 + -(n * 3), 30);
                graphics2.setFont(wf.wf_s);
                graphics2.setColor(Color.white);
                graphics2.drawString(string, (-(n2 * string.length()) + 304) / 2, 22);
                graphics.drawImage(lj.lj_a, de.M / 2 - 152, ob.ob_g / 2 + -18, null);
            }
            catch (Exception exception) {
                int n3 = -152 + de.M / 2;
                int n4 = ob.ob_g / 2 - 18;
                graphics.setColor(color);
                graphics.drawRect(n3, n4, 303, 33);
                graphics.fillRect(2 + n3, n4 - -2, n * 3, 30);
                graphics.setColor(Color.black);
                graphics.drawRect(1 + n3, n4 + 1, 301, 31);
                graphics.fillRect(2 + (n3 - -(3 * n)), 2 + n4, 300 + -(n * 3), 30);
                graphics.setFont(wf.wf_s);
                graphics.setColor(Color.white);
                graphics.drawString(string, n3 - -((304 - 6 * string.length()) / 2), 22 + n4);
            }
            if (null != te.te_t) {
                graphics.setFont(wf.wf_s);
                graphics.setColor(Color.white);
                graphics.drawString(te.te_t, de.M / 2 - 6 * te.te_t.length() / 2, ob.ob_g / 2 - 26);
            }
        }
        catch (Exception exception) {
            jh.jh_b.repaint();
        }
    }

    static final int a(byte by, kn kn2, int n, kc kc2) {
        boolean bl = client.A;
        if (kc2 == null || null == kc2.kc_u || kn2 == null || kn2.x != kc2.kc_n) {
            return -1;
        }
        int n2 = kn2.kn_s.length;
        if (by != 107) {
            return -88;
        }
        int n3 = kc2.kc_u[n].length / n2;
        int n4 = 0;
        while (~n3 < ~n4) {
            block6: {
                if (kc2.kc_t[n][n4] == kn2.kn_o && k.a(kc2.kc_r[n][n4], true)) {
                    for (int i = 0; i < n2; ++i) {
                        if (kc2.kc_u[n][n2 * n4 + i] == kn2.kn_s[i]) {
                            continue;
                        }
                        break block6;
                    }
                    return n4;
                }
            }
            ++n4;
        }
        return -1;
    }

    public static void a(int n) {
        bf_u = null;
        bf_q = null;
        bf_t = null;
        y = null;
        bf_v = null;
        if (n >= -38) {
            return;
        }
        x = null;
        bf_w = null;
    }

    static final void c(byte by) {
        gh.gh_b.a(gg.y.w_mb - (!pd.pd_a ? 0 : 44 + vh.vh_e), 0, 0, 18, 0);
        int n = 44 / ((-28 - by) / 43);
        kn.kn_r.a(vh.vh_e + 42, 0, 0, 18, -2 + gg.y.w_mb + -vh.vh_e - 40);
        ec.ec_k.a(6, 20, vh.vh_e, 0, -20 + gg.y.N, gg.y.w_mb, 2);
    }

    static final void b(int n, int n2) {
        if (n != -20861) {
            return;
        }
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        uf2.a(true, 1);
        uf2.a(true, 0);
    }

    static final void a(boolean bl) {
        dh.dh_b = null;
        fj.fj_e = bl;
        vb.U = null;
        wb.Qb = null;
        tg.tg_g = null;
    }

    bf(long l, int n, byte[] byArray) {
        this.bf_n = byArray;
        this.bf_s = n;
        this.bf_p = l;
    }

    static {
        y = new Random();
        bf_q = "Invalid date";
    }
}
