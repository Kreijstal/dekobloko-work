/*
 * Decompiled with CFR 0.152.
 */
import java.util.Hashtable;

class ce
extends bh {
    int x = 0;
    static w A;
    int D;
    int F = 0;
    static boolean ce_w;
    String E;
    static int ce_r;
    int ce_t;
    int y;
    gl ce_p;
    static String z;
    static ck[] ce_s;
    int ce_o;
    boolean ce_q;
    int ce_u;
    static qc C;
    String B;
    cf ce_n;
    kg ce_v;

    String c(byte by) {
        if (by != 113) {
            ce_s = null;
        }
        return !this.ce_q ? null : this.B;
    }

    boolean a(boolean bl, ce ce2) {
        if (bl) {
            A = null;
        }
        return false;
    }

    final void f(int n) {
        if (n <= 106) {
            this.d(52);
        }
        this.b(this.y, this.ce_t, this.ce_u, this.D, -16555);
    }

    StringBuilder a(Hashtable hashtable, int n, StringBuilder stringBuilder, boolean bl) {
        if (!bl) {
            return null;
        }
        if (this.a(0, n, hashtable, stringBuilder)) {
            this.a((byte)72, stringBuilder, hashtable, n);
        }
        return stringBuilder;
    }

    final boolean a(int n, int n2, Hashtable hashtable, StringBuilder stringBuilder) {
        if (n != 0) {
            return true;
        }
        if (!hashtable.containsKey(this)) {
            hashtable.put(this, this);
            return true;
        }
        stringBuilder.append("<circular [0x").append(Integer.toHexString(this.hashCode())).append("]>");
        return false;
    }

    final boolean a(int n, char c, byte by) {
        if (this.a(true) && this.a(59, n, this, c)) {
            return true;
        }
        int n2 = n;
        if (-81 == ~n2) {
            return this.a(false, this);
        }
        return by < 100;
    }

    boolean a(int n, int n2, int n3, ce ce2, int n4, int n5, boolean bl) {
        if (bl) {
            C = null;
        }
        return false;
    }

    void a(int n, int n2, int n3, int n4) {
        block1: {
            if (n3 == 0 && null != this.ce_p) {
                this.ce_p.a(true, n, n4, (byte)-118, this);
            }
            if (n2 <= -103) break block1;
            fd fd2 = null;
            ce.a(-50, -124, -49, 105, 114, null, fd2, -111, -67);
        }
    }

    ce(String string, kg kg2) {
        this(string, bf.x.c_k, kg2);
    }

    static final void a(int n, byte by, int n2, String string, int n3, String string2) {
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n4 = uf2.wl_n;
        uf2.a(true, n2);
        if (by != -85) {
            ce.e(9);
        }
        if (2 == n2) {
            uf2.a(0, string);
        }
        if (null == string2) {
            uf2.d(-1, n3);
        } else {
            ij.a(-20539, uf2, string2);
        }
        uf2.b(uf2.wl_n - n4, true);
    }

    static final void a(int n, ki ki2, int n2) {
        if (n2 != -697) {
            return;
        }
        cg.cg_c.a(ki2, 2777);
        kk.a(n, -15016, ki2);
    }

    void b(int n, int n2, int n3, int n4, int n5) {
        block0: {
            this.y = n;
            this.ce_t = n2;
            this.D = n4;
            this.ce_u = n3;
            if (n5 == -16555) break block0;
            this.a(68, true, -45, 80);
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, String string, fd fd2, int n6, int n7) {
        cb.cb_c = n5;
        fh.fh_f = n3;
        bl.U = fd2;
        gm.H = n;
        hh.hh_f = n7;
        pe.pe_b = string;
        cn.U = n4;
        if (n6 != 0) {
            return;
        }
        vm.vm_w = n2;
        ta.ta_k = new qb();
        qb.qb_r = new im(fd2);
        sc.sc_l = new ne(ta.ta_k, qb.qb_r);
    }

    int d(int n) {
        int n2 = 7 / ((n - 36) / 51);
        return 0;
    }

    static final void e(int n) {
        block1: {
            if (null != ub.ub_c) {
                String string;
                String string2 = string = ub.ub_c;
                jb.a((byte)107, cm.a((byte)117, sl.sl_d, new String[]{string}));
                ub.ub_c = null;
            }
            if (n > 99) break block1;
            C = null;
        }
    }

    boolean a(int n, int n2, ce ce2, int n3, int n4, int n5, byte by) {
        if (this.a(n2, (byte)-83, n4, n, n5)) {
            this.ce_o = n3;
        }
        if (by != -55) {
            this.a(19, (byte)11, -125, -81, -78);
        }
        return false;
    }

    void a(ce ce2, int n, int n2, int n3) {
        block2: {
            boolean bl2;
            if (!this.ce_q == (bl2 = this.a(bh.bh_g, (byte)-87, n2, pm.pm_f, n3))) {
                this.ce_q = bl2;
                if (this.ce_v != null && this.ce_v instanceof gj) {
                    ((gj)this.ce_v).a(bl2, this, true);
                }
            }
            if (n >= 38) break block2;
            ce_w = false;
        }
    }

    void d(byte by) {
        block0: {
            if (by == -95) break block0;
            this.B = null;
        }
    }

    final void a(int n, int n2, byte by) {
        block2: {
            boolean bl2 = client.A;
            int n3 = this.d(94);
            int n4 = 0;
            if (by != -72) {
                this.a(-73, -87, 50, 71);
            }
            while (~n4 >= ~n3) {
                this.a(n2, -118, n4, n);
                ++n4;
            }
            String string = ea.b(true);
            if (string == null) break block2;
            bf.x.a(string, by + 71, dh.dh_e, pa.Z);
        }
    }

    void a(int n, int n2, int n3, ce ce2, int n4, int n5) {
        block0: {
            this.ce_o = 0;
            if (n2 == 64) break block0;
            this.toString();
        }
    }

    final boolean a(int n, boolean bl2, int n2, int n3) {
        boolean bl3 = client.A;
        this.a(this, 79, n, n2);
        boolean bl4 = this.a(true);
        if (bl2) {
            if (~jk.jk_c != -1 && bl4) {
                this.a(pm.pm_f, n, bh.bh_g, this, jk.jk_c, n2, false);
            }
            if (~ig.Yb != -1) {
                if (this.a(nf.nf_h, he.S, this, ig.Yb, n, n2, (byte)-55)) {
                    bl2 = false;
                } else if (bl4) {
                    this.d((byte)-95);
                }
            }
            if (-1 == ~be.be_n && tm.tm_d != 0) {
                this.a(pm.pm_f, 64, n2, this, n, bh.bh_g);
                se se2 = lg.Y;
                if (null != se2) {
                    if (se2.ce_v instanceof na) {
                        ((na)se2.ce_v).a(se2, null, (byte)-128);
                    }
                    lg.Y = null;
                }
            }
        } else if (bl4 && ig.Yb != 0) {
            this.d((byte)-95);
        }
        if (n3 != 29166) {
            this.D = 110;
        }
        tm.tm_d = be.be_n;
        sa.a(this.c((byte)113), -1);
        return bl2;
    }

    public final String toString() {
        return this.a(new Hashtable(), 0, new StringBuilder(), true).toString();
    }

    final boolean a(int n, byte by, int n2, int n3, int n4) {
        if (by > -29) {
            String string = null;
            ce.a(-81, (byte)-68, -126, null, 93, string);
        }
        return n >= n4 + this.ce_u && ~(n2 - -this.D) >= ~n3 && ~(this.ce_t + (this.ce_u + n4)) < ~n && n3 < this.y + this.D + n2;
    }

    boolean a(int n, int n2, ce ce2, char c2) {
        int n3 = -128 / ((-22 - n) / 49);
        return false;
    }

    public static void c(int n) {
        block0: {
            ce_s = null;
            A = null;
            C = null;
            z = null;
            if (n > 52) break block0;
            fd fd2 = null;
            ce.a(-104, 121, -47, 103, 95, null, fd2, -67, -90);
        }
    }

    final void a(byte by, StringBuilder stringBuilder, Hashtable hashtable, int n) {
        block9: {
            boolean bl2 = client.A;
            if (by != 72) {
                String string = null;
                ce.a(80, (byte)-66, 85, null, 114, string);
            }
            stringBuilder.append(this.getClass().getName()).append("[0x").append(Integer.toHexString(this.hashCode())).append("] @").append(this.ce_u).append(",").append(this.D).append(" ").append(this.ce_t).append("x").append(this.y);
            if (this.E != null) {
                stringBuilder.append(" text=\"").append(this.E).append('\"');
            }
            if (this.ce_q) {
                stringBuilder.append(" mouseover");
            }
            if (this.a(true)) {
                stringBuilder.append(" focused");
            }
            if (null != this.ce_p) {
                stringBuilder.append(" renderer=");
                if (this.ce_p instanceof ce) {
                    stringBuilder = this.a(hashtable, n + 1, stringBuilder, true);
                } else {
                    stringBuilder.append(this.ce_p);
                }
            }
            if (this.ce_v == null) break block9;
            stringBuilder.append(" listener=");
            if (!(this.ce_v instanceof ce)) {
                stringBuilder.append(this.ce_v);
            } else {
                stringBuilder = this.a(hashtable, 1 + n, stringBuilder, true);
            }
        }
    }

    boolean a(boolean bl2) {
        if (!bl2) {
            ce.e(120);
        }
        return false;
    }

    static final ck[] a(int n, int n2, int n3, int n4, int n5) {
        ck[] ckArray;
        ck[] ckArray2 = ckArray = new ck[9];
        if (n2 >= -10) {
            z = null;
        }
        ckArray2[3] = ckArray[6] = sm.a((byte)-125, n, n4);
        ckArray2[2] = ckArray[6];
        ckArray2[1] = ckArray[6];
        ckArray2[0] = ckArray[6];
        ckArray2[7] = ckArray[8] = sm.a((byte)-109, n, n3);
        ckArray2[5] = ckArray[8];
        if (0 != n5) {
            ckArray[4] = sm.a((byte)-121, 64, n5);
        }
        return ckArray2;
    }

    protected ce() {
    }

    ce(String string, gl gl2, kg kg2) {
        this.ce_v = kg2;
        this.E = string;
        this.ce_p = gl2;
        if (this.ce_p instanceof nl) {
            nl nl2 = (nl)((Object)this.ce_p);
            this.ce_t = nl2.b(this, 0);
            this.y = nl2.a(this, -49);
        }
    }

    ce(int n, int n2, int n3, int n4, gl gl2, kg kg2) {
        this.D = n2;
        this.y = n4;
        this.ce_u = n;
        this.ce_t = n3;
        this.ce_p = gl2;
        this.ce_v = kg2;
    }

    static {
        z = "To server list";
    }
}
