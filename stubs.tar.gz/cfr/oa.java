/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class oa {
    static String oa_f;
    static int[] oa_e;
    static String oa_c;
    static int oa_a;
    static String oa_d;
    static ck[] oa_b;

    static final void a(int n) {
        if (n <= 125) {
            return;
        }
        sg.sg_d = null;
        tc.Nb = null;
        hc.hc_c = null;
        tm.tm_a = null;
        fh.fh_a = null;
        mb.mb_d = null;
    }

    static final void a(Applet applet, int n, String string) {
        u.u_a = string;
        try {
            String string2 = applet.getParameter("cookieprefix");
            String string3 = applet.getParameter("cookiehost");
            String string4 = string2 + "session=" + string + "; version=1; path=/; domain=" + string3;
            if (n == ~string.length()) {
                string4 = string4 + "; Expires=Thu, 01-Jan-1970 00:00:00 GMT; Max-Age=0";
            }
            nc.a((byte)-51, applet, "document.cookie=\"" + string4 + "\"");
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        me.me_a_applet((byte)121, applet);
    }

    static final String a(String string, int n) {
        boolean bl = client.A;
        int n2 = string.length();
        char[] cArray = new char[n2];
        int n3 = 0;
        while (~n3 > ~n2) {
            cArray[-n3 + n2 + -1] = string.charAt(n3);
            ++n3;
        }
        if (n != -1) {
            oa_f = null;
        }
        return new String(cArray);
    }

    public static void b(int n) {
        if (n != -1) {
            oa_e = null;
        }
        oa_f = null;
        oa_e = null;
        oa_b = null;
        oa_d = null;
        oa_c = null;
    }

    static {
        oa_c = "Enter multiplayer lobby";
        oa_d = "You must play 1 more rated game before playing with the current options.";
    }
}
