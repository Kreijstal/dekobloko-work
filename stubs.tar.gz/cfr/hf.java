/*
 * Decompiled with CFR 0.152.
 */
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

final class hf {
    static String hf_b = "Visit the Account Management section on the main site to view.";
    static String hf_c;
    static String hf_g;
    static ck[][] hf_e;
    static String hf_h;
    private RandomAccessFile hf_f;
    static String hf_a;
    private long hf_i;
    private long hf_d;

    final int a(byte[] byArray, byte by, int n, int n2) throws IOException {
        int n3;
        block1: {
            if (by > -33) {
                hf_h = null;
            }
            if (0 >= (n3 = this.hf_f.read(byArray, n, n2))) break block1;
            this.hf_d += (long)n3;
        }
        return n3;
    }

    public static void b(int n) {
        hf_g = null;
        hf_h = null;
        hf_c = null;
        if (n != 12741) {
            hf_g = null;
        }
        hf_a = null;
        hf_b = null;
        hf_e = null;
    }

    final void a(int n) throws IOException {
        block1: {
            if (this.hf_f != null) {
                this.hf_f.close();
                this.hf_f = null;
            }
            if (n < -4) break block1;
            CharSequence[] charSequenceArray = null;
            hf.a(-21, 99, charSequenceArray, (byte)32);
        }
    }

    protected final void finalize() throws Throwable {
        block0: {
            if (null == this.hf_f) break block0;
            System.out.println("");
            this.a(-86);
        }
    }

    final void a(long l, int n) throws IOException {
        block0: {
            this.hf_f.seek(l);
            this.hf_d = l;
            if (n >= 3) break block0;
            CharSequence[] charSequenceArray = null;
            hf.a(69, 18, charSequenceArray, (byte)126);
        }
    }

    static final String a(int n, int n2, CharSequence[] charSequenceArray, byte by) {
        boolean bl = client.A;
        if (-1 == ~n) {
            return "";
        }
        if (n == 1) {
            CharSequence charSequence = charSequenceArray[n2];
            if (null == charSequence) {
                return "null";
            }
            return ((Object)charSequence).toString();
        }
        int n3 = n + n2;
        int n4 = 0;
        int n5 = n2;
        while (~n5 > ~n3) {
            CharSequence charSequence = charSequenceArray[n5];
            n4 = null != charSequence ? (n4 += charSequence.length()) : (n4 += 4);
            ++n5;
        }
        StringBuilder stringBuilder = new StringBuilder(n4);
        if (by != 74) {
            CharSequence[] charSequenceArray2 = null;
            hf.a(-7, 123, charSequenceArray2, (byte)21);
        }
        int n6 = n2;
        while (~n6 > ~n3) {
            CharSequence charSequence = charSequenceArray[n6];
            if (null != charSequence) {
                stringBuilder.append(charSequence);
            } else {
                stringBuilder.append("null");
            }
            ++n6;
        }
        return stringBuilder.toString();
    }

    final long a(byte by) throws IOException {
        if (by != -50) {
            return -2L;
        }
        return this.hf_f.length();
    }

    final void a(byte[] byArray, int n, int n2, int n3) throws IOException {
        if (((long)n3 - -this.hf_d ^ 0xFFFFFFFFFFFFFFFFL) < (this.hf_i ^ 0xFFFFFFFFFFFFFFFFL)) {
            this.hf_f.seek(this.hf_i);
            this.hf_f.write(1);
            throw new EOFException();
        }
        int n4 = 96 % ((n - -35) / 49);
        this.hf_f.write(byArray, n2, n3);
        this.hf_d += (long)n3;
    }

    hf(File file, String string, long l) throws IOException {
        if (-1L == l) {
            l = Long.MAX_VALUE;
        }
        if (l < file.length()) {
            file.delete();
        }
        this.hf_f = new RandomAccessFile(file, string);
        this.hf_d = 0L;
        this.hf_i = l;
        int n = this.hf_f.read();
        if (n != -1 && !string.equals("r")) {
            this.hf_f.seek(0L);
            this.hf_f.write(n);
        }
        this.hf_f.seek(0L);
    }

    static {
        hf_a = "<%0>'s game";
        hf_h = "Report abuse";
        hf_e = new ck[8][];
        hf_g = "No players";
        hf_c = "<%0> has joined your game.";
    }
}
