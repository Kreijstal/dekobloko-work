/*
 * Decompiled with CFR 0.152.
 */
final class in
extends bh {
    boolean in_p;
    static String in_u = "All games";
    static w in_o;
    private ck in_t;
    static String in_s;
    int in_r = 0;
    private int[] in_q;
    static lm in_n;

    private final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, int n14, boolean bl, boolean bl2) {
        int n15;
        int n16 = n10;
        int n17 = -n8;
        int n18 = this.in_t.D[n12 * this.in_t.K + n11];
        int n19 = (n18 & 0x18) >> 3;
        ck[] ckArray = null;
        pi pi2 = null;
        int n20 = 0;
        int n21 = 2;
        int n22 = Math.abs(n10);
        if (n19 == 1) {
            if (n11 > 0 && ((this.in_t.D[n12 * this.in_t.K + (n11 - 1)] ^ n18) & 0x1F) == 0) {
                ++n20;
            }
            if (n11 < this.in_t.K - 1 && ((this.in_t.D[n12 * this.in_t.K + (n11 + 1)] ^ n18) & 0x1F) == 0) {
                n20 += 2;
            }
            if (n12 > 0 && ((this.in_t.D[(n12 - 1) * this.in_t.K + n11] ^ n18) & 0x1F) == 0) {
                n20 += 4;
            }
            if (n12 < this.in_t.C - 1 && ((this.in_t.D[(n12 + 1) * this.in_t.K + n11] ^ n18) & 0x1F) == 0) {
                n20 += 8;
            }
            ckArray = ob.ob_j[n][n18 & 7];
            pi2 = gf.gf_f[n20];
        }
        int n23 = this.in_q[n12 * this.in_t.K + n11];
        byte by = (byte)n23;
        byte by2 = (byte)(n23 >> 8);
        int n24 = n23 >> 16 & 0xFF;
        int n25 = n23 >> 24;
        int n26 = (n14 + n25 - 60) * 1000 / 60;
        if (bl && n26 > (n15 = (int)(333.0 * Math.sin((double)(uf.A + n25) * 0.045)))) {
            n26 = n15;
        }
        n26 = n26 * n26 / 1000;
        n15 = (n14 + n25 / 2 - 60) * 2000 / 60;
        if (bl && n15 > 0) {
            n15 = 0;
        } else {
            n15 = n15 * n15 / 2000;
            n15 = n15 * n15 / 2000;
            n15 = n15 * n15 / 2000;
        }
        int n27 = n24 * (n26 + n15) / 10;
        int n28 = n27 * by / ((this.in_t.K + this.in_t.C) * 4);
        int n29 = n27 * by2 / ((this.in_t.K + this.in_t.C) * 4) + (int)(100.0 * Math.sin((double)(uf.A + n25 * 4) * 0.07));
        int n30 = 4000000 / n4;
        int n31 = (n28 * n8 + n27 * n10) / (n30 * 2);
        int n32 = (n28 * n10 - n27 * n8) / (n30 * 2);
        n5 += n31;
        n6 += n29;
        n7 += n32;
        if (ckArray != null) {
            if (n22 < n8 * 2) {
                n21 = 1 + ((n21 - 1) * n22 + n8 / 2) / n8;
            }
            int n33 = Integer.MAX_VALUE;
            int n34 = Integer.MIN_VALUE;
            int n35 = Integer.MAX_VALUE;
            int n36 = Integer.MIN_VALUE;
            for (int i = -n21; i <= n21; i += 2) {
                int n37 = i;
                int n38 = i;
                int n39 = this.in_t.K * n21 * 2;
                int n40 = n5 + (n11 * n8 * n21 * 2 + n16 * n37) / n39;
                int n41 = n5 + ((n11 + 1) * n8 * n21 * 2 + n16 * n38) / n39;
                int n42 = n6 + n12 * n9 / this.in_t.C;
                int n43 = n6 + (n12 + 1) * n9 / this.in_t.C;
                int n44 = n7 + (n11 * n10 * n21 * 2 + n17 * n37) / n39;
                int n45 = n7 + ((n11 + 1) * n10 * n21 * 2 + n17 * n38) / n39;
                if (n44 < 500 || n45 < 500) continue;
                int n46 = n2 + n40 * n4 / n44;
                int n47 = n2 + n41 * n4 / n45;
                int n48 = n3 + n42 * n4 / n44;
                int n49 = n3 + n42 * n4 / n45;
                int n50 = n3 + n43 * n4 / n44;
                int n51 = n3 + n43 * n4 / n45;
                if (bl2) {
                    if (n46 < n33) {
                        n33 = n46;
                    }
                    if (n47 > n34) {
                        n34 = n47;
                    }
                    if (n48 < n35) {
                        n35 = n48;
                    }
                    if (n49 < n35) {
                        n35 = n49;
                    }
                    if (n50 > n36) {
                        n36 = n50;
                    }
                    if (n51 <= n36) continue;
                    n36 = n51;
                    continue;
                }
                ck ck2 = ckArray[i == n21 ? n20 : n20 & 0xC];
                int n52 = 0;
                if (n11 < n13) {
                    n52 = (n21 - i) * ck2.K / (n21 * 2);
                }
                if (n11 > n13) {
                    n52 = (n21 + i) * ck2.K / (n21 * 2);
                }
                cg.a(ck2, pi2, n46, n47, n48, n49, n50, n51, i < n21, false, n52, -1);
            }
            if (n33 != Integer.MAX_VALUE) {
                hk.c(n33 - 2, n35 - 2, n34 - n33 + 4, n36 - n35 + 4, 2, 0);
            }
            return;
        }
    }

    in(String string, int n, boolean bl2) {
        this.in_p = bl2;
        int n2 = in_n.b(string, Integer.MAX_VALUE);
        int n3 = in_n.b(string, Integer.MAX_VALUE, 8);
        this.in_t = new ck(--n2, n3);
        int[] nArray = hk.hk_l;
        int n4 = hk.hk_j;
        int n5 = hk.hk_i;
        this.in_t.a();
        in_n.a(string, 0, 0, 1 + n2, n3, n, -1, 1, 1, 8);
        hk.a(nArray, n4, n5);
        this.in_q = new int[n2 * n3];
        int[] nArray2 = new int[n3 * n2];
        int n6 = 0;
        while (~n6 > ~n3) {
            int n7 = 0;
            while (~n2 < ~n7) {
                int n8;
                if (-1 == ~this.in_q[n6 * n2 + n7] && -1 != ~(0x18 & (n8 = this.in_t.D[n2 * n6 - -n7]))) {
                    int n9;
                    int n10;
                    int n11;
                    int n12;
                    int n13 = n7;
                    int n14 = n7;
                    int n15 = n6;
                    int n16 = n6;
                    int n17 = 0;
                    int n18 = 1;
                    nArray2[0] = n6 * n2 + n7;
                    int n19 = n2 * n6 + n7;
                    this.in_t.D[n19] = this.in_t.D[n19] + Integer.MIN_VALUE;
                    if (-9 == ~(0x18 & n8)) {
                        n12 = 0x1F & n8;
                        while (~n17 > ~n18) {
                            if ((n11 = (n10 = nArray2[n17++]) % n2) < n13) {
                                n13 = n11;
                            }
                            if (~n14 > ~n11) {
                                n14 = n11;
                            }
                            if (n16 < (n9 = n10 / n2)) {
                                n16 = n9;
                            }
                            if (n15 > n9) {
                                n15 = n9;
                            }
                            if (0 < n11 && (0x8000001F & this.in_t.D[n10 + -1]) == n12) {
                                nArray2[n18++] = -1 + n10;
                                int n20 = -1 + n10;
                                this.in_t.D[n20] = this.in_t.D[n20] + Integer.MIN_VALUE;
                            }
                            if (-1 + n2 > n11 && (this.in_t.D[1 + n10] & 0x8000001F) == n12) {
                                nArray2[n18++] = 1 + n10;
                                int n21 = n10 - -1;
                                this.in_t.D[n21] = this.in_t.D[n21] + Integer.MIN_VALUE;
                            }
                            if (n9 > 0 && (this.in_t.D[-n2 + n10] & 0x8000001F) == n12) {
                                nArray2[n18++] = n10 - n2;
                                int n22 = -n2 + n10;
                                this.in_t.D[n22] = this.in_t.D[n22] + Integer.MIN_VALUE;
                            }
                            if (n9 >= n3 + -1 || n12 != (this.in_t.D[n10 + n2] & 0x8000001F)) continue;
                            nArray2[n18++] = n10 - -n2;
                            int n23 = n10 + n2;
                            this.in_t.D[n23] = this.in_t.D[n23] + Integer.MIN_VALUE;
                        }
                    }
                    n12 = -n2 + (n13 - -n14 - -1);
                    n10 = 1 + n16 + n15 - n3;
                    n9 = n11 = 150 - -ka.a((byte)116, 51, tf.tf_cb);
                    int n24 = -8 + ka.a((byte)50, 17, tf.tf_cb);
                    int n25 = (n24 << 1645931960) + (n9 << 2006781008) + ((n10 << 1634433896 & 0xFF00) + (0xFF & n12));
                    for (int i = 0; i < n18; ++i) {
                        int n26;
                        int n27 = n26 = nArray2[i];
                        this.in_t.D[n27] = this.in_t.D[n27] - Integer.MIN_VALUE;
                        this.in_q[n26] = n25;
                    }
                }
                ++n7;
            }
            ++n6;
        }
    }

    private final void a(int n, int n2, int n3, int n4, int n5, byte by, boolean bl2, int n6, int n7, int n8, int n9, int n10, int n11) {
        int n12;
        int n13;
        boolean bl3 = client.A;
        int n14 = vl.a(23841, (n5 -= n4) * n5 - -((n7 -= n11) * n7), this.in_t.K * -(n5 * n4 - -(n11 * n7)));
        int n15 = vl.a(23841, n9 -= n, this.in_t.C * -n);
        int n16 = n14;
        if (n15 < 0) {
            n15 = 0;
        } else if (~this.in_t.C > ~n15) {
            n15 = this.in_t.C;
        }
        if (-1 < ~n14) {
            n14 = 0;
        } else if (~this.in_t.K > ~n14) {
            n14 = this.in_t.K;
        }
        if (by != 72) {
            return;
        }
        for (n13 = 0; n13 < this.in_t.K; ++n13) {
            for (n12 = 0; this.in_t.C > n12; ++n12) {
                this.a(n8, n10, n2, n6, n4, n, n11, n5, n9, n7, n13, n12, n16, n3, bl2, true);
            }
        }
        n13 = 0;
        while (~n14 < ~n13) {
            for (n12 = 0; n12 < n15; ++n12) {
                this.a(n8, n10, n2, n6, n4, n, n11, n5, n9, n7, n13, n12, n16, n3, bl2, false);
            }
            for (n12 = this.in_t.C + -1; n15 <= n12; --n12) {
                this.a(n8, n10, n2, n6, n4, n, n11, n5, n9, n7, n13, n12, n16, n3, bl2, false);
            }
            ++n13;
        }
        for (n13 = this.in_t.K + -1; n13 >= n14; --n13) {
            n12 = 0;
            while (~n12 > ~n15) {
                this.a(n8, n10, n2, n6, n4, n, n11, n5, n9, n7, n13, n12, n16, n3, bl2, false);
                ++n12;
            }
            n12 = this.in_t.C - 1;
            while (~n15 >= ~n12) {
                this.a(n8, n10, n2, n6, n4, n, n11, n5, n9, n7, n13, n12, n16, n3, bl2, false);
                --n12;
            }
        }
    }

    public static void a(int n) {
        in_s = null;
        in_n = null;
        in_u = null;
        if (n < 121) {
            return;
        }
        in_o = null;
    }

    static final void c(byte by) {
        block0: {
            db.a(by + -76, te.te_q, ve.Gc, true);
            dc.dc_d = true;
            if (by == -51) break block0;
            ug ug2 = null;
            in.a(ug2, (byte)121, -105);
        }
    }

    final void a(int n, int n2, int n3, int n4, boolean bl2, int n5, int n6) {
        int n7 = 2000;
        int n8 = 1500;
        if (bl2) {
            n8 = 600;
        }
        if (n2 != 1) {
            return;
        }
        if (n8 * this.in_t.K <= this.in_t.C * n7) {
            n7 = n8 * this.in_t.K / this.in_t.C;
        } else {
            n8 = this.in_t.C * n7 / this.in_t.K;
        }
        int n9 = !(!bl2) ? 5 * this.in_r : 0;
        this.a(-n8 + -n9, n3, n6, -n7, n7, (byte)72, bl2, n, 10000, n5, -n9 + n8, n4, 10000);
    }

    static final void a(ug ug2, byte by, int n) {
        uf uf2 = we.we_b;
        uf2.f(n, by ^ 0x46);
        if (by != -70) {
            ug ug3 = null;
            in.a(ug3, (byte)-31, 108);
        }
        uf2.a(true, ug2.ug_o);
        uf2.d(-1, ug2.ug_p);
    }

    static {
        in_s = "<%0> is not a member, and cannot play with the current options.";
    }
}
