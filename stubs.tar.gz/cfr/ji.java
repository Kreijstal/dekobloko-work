/*
 * Decompiled with CFR 0.152.
 */
final class ji {
    static String ji_h;
    int ji_g;
    private ad ji_f = null;
    private of ji_a;
    static String ji_c;
    private Object[][] ji_e;
    private Object[] ji_d;
    boolean ji_b;

    private final synchronized void a(int n, int n2) {
        block0: {
            this.ji_d[n2] = this.ji_b ? (Object)this.ji_a.a(n2, (byte)91) : qk.a(this.ji_a.a(n2, (byte)91), -1389597532, false);
            if (n == 20351) break block0;
            ji_c = null;
        }
    }

    final synchronized boolean b(int n, byte by) {
        if (!this.a(n, (byte)-83)) {
            return false;
        }
        if (this.ji_d[n] != null) {
            return true;
        }
        if (by != -106) {
            return ((boolean[])this.ji_d[0])[0];
        }
        this.a(20351, n);
        return null != this.ji_d[n];
    }

    final int b(int n, String string) {
        int n2;
        if (!this.a((byte)121)) {
            return -1;
        }
        if (n != -1) {
            ji_h = null;
        }
        if (!this.a(n2 = this.ji_f.ad_e.a((byte)-68, ta.a(string = string.toLowerCase(), 90)), (byte)-83)) {
            return -1;
        }
        return n2;
    }

    final boolean a(String string, boolean bl, String string2) {
        if (!bl) {
            return true;
        }
        if (!this.a((byte)121)) {
            return false;
        }
        string2 = string2.toLowerCase();
        string = string.toLowerCase();
        int n = this.ji_f.ad_e.a((byte)-68, ta.a(string2, -10));
        if (!this.a(n, (byte)-83)) {
            return false;
        }
        int n2 = this.ji_f.ad_o[n].a((byte)-68, ta.a(string, 11));
        return this.a((byte)-84, n2, n);
    }

    final int b(int n, int n2) {
        if (n != -5228) {
            return -48;
        }
        if (!this.a(n2, (byte)-83)) {
            return 0;
        }
        return this.ji_f.ad_k[n2];
    }

    public static void a(int n) {
        block0: {
            ji_c = null;
            ji_h = null;
            if (n >= 125) break block0;
            ji_c = null;
        }
    }

    final boolean a(String string, byte by) {
        if (!this.a((byte)121)) {
            return false;
        }
        string = string.toLowerCase();
        int n = -49 / ((by - 13) / 42);
        int n2 = this.ji_f.ad_e.a((byte)-68, ta.a(string, -112));
        return this.b(n2, (byte)-106);
    }

    final boolean a(String string, int n) {
        if (!this.a((byte)121)) {
            return false;
        }
        int n2 = this.ji_f.ad_e.a((byte)-68, ta.a(string = string.toLowerCase(), 86));
        return n2 >= n;
    }

    private final synchronized boolean a(int[] nArray, int n, int n2, int n3) {
        byte[] byArray;
        byte[] byArray2;
        boolean bl = client.A;
        if (!this.a(n, (byte)-83)) {
            return false;
        }
        if (null == this.ji_d[n]) {
            return false;
        }
        int n4 = this.ji_f.B[n];
        int[] nArray2 = this.ji_f.ad_v[n];
        if (this.ji_e[n] == null) {
            this.ji_e[n] = new Object[this.ji_f.ad_k[n]];
        }
        if (n3 != 26687) {
            return ((boolean[])((Object[])this.ji_d[3])[13])[3];
        }
        Object[] objectArray = this.ji_e[n];
        boolean bl2 = true;
        int n5 = 0;
        while (~n5 > ~n4) {
            int n6 = nArray2 == null ? n5 : nArray2[n5];
            if (objectArray[n6] == null) {
                bl2 = false;
                break;
            }
            ++n5;
        }
        if (bl2) {
            return true;
        }
        if (nArray != null && (nArray[0] != 0 || nArray[1] != 0 || nArray[2] != 0 || 0 != nArray[3])) {
            byArray2 = cf.a(true, 78, this.ji_d[n]);
            wl wl2 = new wl(byArray2);
            wl2.a((byte)51, 5, nArray, wl2.wl_r.length);
        } else {
            byArray2 = cf.a(false, n3 ^ 0x685D, this.ji_d[n]);
        }
        byte[] byArray3 = byArray = i.a(byArray2, -120);
        if (this.ji_b) {
            this.ji_d[n] = null;
        }
        if (-2 > ~n4) {
            if (-3 != ~this.ji_g) {
                int n7;
                int n8;
                int n9;
                int n10 = byArray.length;
                int n11 = byArray[--n10] & 0xFF;
                wl wl3 = new wl(byArray3);
                int[] nArray3 = new int[n4];
                wl3.wl_n = n10 -= 4 * (n11 * n4);
                for (int j = 0; j < n11; ++j) {
                    n9 = 0;
                    n8 = 0;
                    while (n4 > n8) {
                        int n12 = n8++;
                        nArray3[n12] = nArray3[n12] + (n9 += wl3.i(7553));
                    }
                }
                byte[][] byArrayArray = new byte[n4][];
                n9 = 0;
                while (~n4 < ~n9) {
                    byArrayArray[n9] = new byte[nArray3[n9]];
                    nArray3[n9] = 0;
                    ++n9;
                }
                wl3.wl_n = n10;
                n9 = 0;
                for (n8 = 0; n8 < n11; ++n8) {
                    n7 = 0;
                    int n13 = 0;
                    while (~n13 > ~n4) {
                        an.a(byArray, n9, byArrayArray[n13], nArray3[n13], n7 += wl3.i(7553));
                        int n14 = n13++;
                        nArray3[n14] = nArray3[n14] + n7;
                        n9 += n7;
                    }
                }
                n8 = 0;
                while (~n8 > ~n4) {
                    n7 = null == nArray2 ? n8 : nArray2[n8];
                    objectArray[n7] = ~this.ji_g != -1 ? (Object)byArrayArray[n8] : qk.a(byArrayArray[n8], -1389597532, false);
                    ++n8;
                }
            } else {
                int n15;
                int n16;
                int n17;
                int n18 = byArray.length;
                int n19 = 0xFF & byArray[--n18];
                wl wl4 = new wl(byArray3);
                int n20 = 0;
                wl4.wl_n = n18 -= n19 * n4 * 4;
                int n21 = 0;
                for (int j = 0; n19 > j; ++j) {
                    n17 = 0;
                    n16 = 0;
                    while (~n16 > ~n4) {
                        n17 += wl4.i(7553);
                        n15 = nArray2 != null ? nArray2[n16] : n16;
                        if (n2 == n15) {
                            n21 = n15;
                            n20 += n17;
                        }
                        ++n16;
                    }
                }
                if (~n20 == -1) {
                    return true;
                }
                byte[] byArray4 = new byte[n20];
                wl4.wl_n = n18;
                n20 = 0;
                n17 = 0;
                for (n16 = 0; n16 < n19; ++n16) {
                    n15 = 0;
                    int n22 = 0;
                    while (~n22 > ~n4) {
                        n15 += wl4.i(n3 ^ 0x75BE);
                        int n23 = null == nArray2 ? n22 : nArray2[n22];
                        if (n23 == n2) {
                            an.a(byArray3, n17, byArray4, n20, n15);
                            n20 += n15;
                        }
                        n17 += n15;
                        ++n22;
                    }
                }
                objectArray[n21] = byArray4;
            }
        } else {
            int n24 = nArray2 != null ? nArray2[0] : 0;
            objectArray[n24] = -1 == ~this.ji_g ? qk.a(byArray, -1389597532, false) : (Object)byArray;
        }
        return true;
    }

    final synchronized int b(byte by) {
        int n;
        boolean bl = client.A;
        if (!this.a((byte)121)) {
            return 0;
        }
        if (by > -44) {
            this.a(91, ((int[])((Object[])this.ji_d[2])[0])[0]);
        }
        int n2 = 0;
        int n3 = 0;
        for (n = 0; this.ji_d.length > n; ++n) {
            if (this.ji_f.B[n] <= 0) continue;
            n3 += this.a((byte)34, n);
            n2 += 100;
        }
        if (0 == n2) {
            return 100;
        }
        n = 100 * n3 / n2;
        return n;
    }

    final synchronized boolean a(byte by) {
        if (this.ji_f == null) {
            this.ji_f = this.ji_a.a(true);
            if (null == this.ji_f) {
                return false;
            }
            this.ji_e = new Object[this.ji_f.ad_n][];
            this.ji_d = new Object[this.ji_f.ad_n];
        }
        return by == 121;
    }

    final synchronized byte[] a(int n, String string, String string2) {
        if (!this.a((byte)121)) {
            return null;
        }
        string2 = string2.toLowerCase();
        string = string.toLowerCase();
        int n2 = this.ji_f.ad_e.a((byte)-68, ta.a(string2, 79));
        if (!this.a(n2, (byte)-83)) {
            return null;
        }
        if (n != 0) {
            return null;
        }
        int n3 = this.ji_f.ad_o[n2].a((byte)-68, ta.a(string, -112));
        return this.a(n3, 32, n2);
    }

    private final synchronized boolean a(int n, int n2, byte by) {
        if (!this.a((byte)121)) {
            return false;
        }
        if (by != -33) {
            this.a((byte)6, ((int[])this.ji_d[0])[26]);
        }
        if (~n <= -1 && ~n2 <= -1 && n < this.ji_f.ad_k.length && ~this.ji_f.ad_k[n] < ~n2) {
            return true;
        }
        if (cd.cd_i) {
            throw new IllegalArgumentException(n + " " + n2);
        }
        return false;
    }

    final byte[] a(int n, int n2, int n3) {
        int n4 = 118 / ((n2 - -44) / 62);
        return this.a(n, null, n3, (byte)-33);
    }

    static final String[] a(char c, byte by, String string) {
        boolean bl = client.A;
        if (by != 66) {
            return null;
        }
        int n = wg.a(true, string, c);
        String[] stringArray = new String[1 + n];
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        while (~n4 > ~n) {
            int n5 = n3;
            while (string.charAt(n5) != c) {
                ++n5;
            }
            stringArray[n2++] = string.substring(n3, n5);
            n3 = n5 + 1;
            ++n4;
        }
        stringArray[n] = string.substring(n3);
        return stringArray;
    }

    private final synchronized boolean a(int n, byte by) {
        if (by != -83) {
            this.ji_a = (of)this.ji_d[0];
        }
        if (!this.a((byte)121)) {
            return false;
        }
        if (-1 < ~n || n >= this.ji_f.ad_k.length || -1 == ~this.ji_f.ad_k[n]) {
            if (!cd.cd_i) {
                return false;
            }
            throw new IllegalArgumentException(Integer.toString(n));
        }
        return true;
    }

    static final void a(int n, int n2, boolean bl) {
        block2: {
            int n3;
            if (null != pd.pd_f && -2 != (n3 = pd.pd_f.c(497, bl))) {
                if (~n3 != 0) {
                    boolean bl2 = pd.pd_f.e(5658);
                    sn.a(pd.pd_f.Tb, n, pd.pd_f.g((byte)-96), 97, bl2, n3);
                }
                pd.pd_f = null;
                tf.i((byte)-76);
            }
            if (n2 == 0) break block2;
            ji_c = null;
        }
    }

    final int a(int n, int n2, String string) {
        int n3;
        if (!this.a(n, (byte)-83)) {
            return -1;
        }
        if (n2 != 13030) {
            this.ji_d = new Object[6];
        }
        if (!this.a(n, n3 = this.ji_f.ad_o[n].a((byte)-68, ta.a(string = string.toLowerCase(), -127)), (byte)-33)) {
            return -1;
        }
        return n3;
    }

    static final void c(int n, int n2) {
        uf uf2 = we.we_b;
        uf2.f(n, n2 ^ 0xFFFFFFFD);
        uf2.a(true, n2);
        uf2.a(true, 3);
    }

    final synchronized int a(byte by, int n) {
        if (!this.a(n, (byte)-83)) {
            return 0;
        }
        if (by != 34) {
            ji_h = null;
        }
        if (this.ji_d[n] != null) {
            return 100;
        }
        return this.ji_a.a(n, by ^ 0xFFFFFF9A);
    }

    final int a(int n, String string) {
        if (!this.a((byte)121)) {
            return 0;
        }
        string = string.toLowerCase();
        int n2 = this.ji_f.ad_e.a((byte)-68, ta.a(string, -128));
        int n3 = 39 / ((n - -55) / 53);
        return this.a((byte)34, n2);
    }

    private final synchronized byte[] a(int n, int[] nArray, int n2, byte by) {
        byte[] byArray;
        if (!this.a(n2, n, by)) {
            return null;
        }
        byte[] byArray2 = null;
        if (!(this.ji_e[n2] != null && this.ji_e[n2][n] != null || this.a(nArray, n2, n, 26687))) {
            this.a(20351, n2);
            if (!this.a(nArray, n2, n, by + 26720)) {
                return null;
            }
        }
        if (null == this.ji_e[n2]) {
            throw new RuntimeException("");
        }
        if (this.ji_e[n2][n] != null && (byArray = cf.a(false, 95, this.ji_e[n2][n])) == null) {
            throw new RuntimeException("");
        }
        if (null != byArray2) {
            if (-2 != ~this.ji_g) {
                if (~this.ji_g == -3) {
                    this.ji_e[n2] = null;
                }
            } else {
                this.ji_e[n2][n] = null;
                if (~this.ji_f.ad_k[n2] == -2) {
                    this.ji_e[n2] = null;
                }
            }
        }
        return byArray2;
    }

    final synchronized boolean a(boolean bl) {
        boolean bl2 = client.A;
        if (!this.a((byte)121)) {
            return false;
        }
        if (bl) {
            return true;
        }
        boolean bl3 = true;
        for (int j = 0; j < this.ji_f.ad_f.length; ++j) {
            int n = this.ji_f.ad_f[j];
            if (this.ji_d[n] != null) continue;
            this.a(20351, n);
            if (null != this.ji_d[n]) continue;
            bl3 = false;
        }
        return bl3;
    }

    final synchronized boolean a(byte by, int n, int n2) {
        if (!this.a(n2, n, (byte)-33)) {
            return false;
        }
        if (null != this.ji_e[n2] && this.ji_e[n2][n] != null) {
            return true;
        }
        if (null != this.ji_d[n2]) {
            return true;
        }
        this.a(20351, n2);
        if (null != this.ji_d[n2]) {
            return true;
        }
        if (by >= -59) {
            this.a(false);
        }
        return false;
    }

    ji(of of2, boolean bl, int n) {
        if (-1 < ~n || 2 < n) {
            throw new IllegalArgumentException("");
        }
        this.ji_b = bl;
        this.ji_a = of2;
        this.ji_g = n;
    }

    static {
        ji_c = "Offer rematch";
        ji_h = "FINAL!";
    }
}
