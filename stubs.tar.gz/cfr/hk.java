/*
 * Decompiled with CFR 0.152.
 */
final class hk {
    static int hk_h;
    private static int[] hk_a;
    private static int[] hk_e;
    static int hk_g;
    static int hk_c;
    static int hk_b;
    private static int[] hk_d;
    static int[] hk_k;
    static int hk_i;
    static int[] hk_f;
    static int[] hk_l;
    static int hk_j;

    static final void a(int n, int n2, int n3) {
        if (n >= hk_c) {
            if (n2 < hk_h || n >= hk_g || n2 >= hk_b) {
                return;
            }
            hk.hk_l[n + n2 * hk.hk_j] = n3;
            return;
        }
    }

    static final void d() {
        hk_c = 0;
        hk_h = 0;
        hk_g = hk_j;
        hk_b = hk_i;
        hk.c();
    }

    static final void a(int[] nArray, int n, int n2) {
        hk_l = nArray;
        hk_j = n;
        hk_i = n2;
        hk.b(0, 0, n, n2);
    }

    static final void b() {
        int n = 0;
        int n2 = hk_j * hk_i - 7;
        while (n < n2) {
            hk.hk_l[n++] = 0;
            hk.hk_l[n++] = 0;
            hk.hk_l[n++] = 0;
            hk.hk_l[n++] = 0;
            hk.hk_l[n++] = 0;
            hk.hk_l[n++] = 0;
            hk.hk_l[n++] = 0;
            hk.hk_l[n++] = 0;
        }
        n2 += 7;
        while (n < n2) {
            hk.hk_l[n++] = 0;
        }
    }

    static final void b(int n, int n2, int n3, int n4, int n5, int n6) {
        hk.a(hk_l, 0, n3 + n4 * hk_j, n, n3, n5, hk_j - n5, n6);
        hk.a(hk_l, 0, n3 + n4 * hk_j, n2, n4, n6, hk_j - n5, n3, n5);
    }

    static final void g(int n, int n2, int n3, int n4) {
        if (n >= hk_c) {
            if (n >= hk_g) {
                return;
            }
            if (n2 < hk_h) {
                n3 -= hk_h - n2;
                n2 = hk_h;
            }
            if (n2 + n3 > hk_b) {
                n3 = hk_b - n2;
            }
            int n5 = n + n2 * hk_j;
            int n6 = 0;
            while (n6 < n3) {
                hk.hk_l[n5] = n4;
                ++n6;
                n5 += hk_j;
            }
            return;
        }
    }

    static final void f(int n, int n2, int n3, int n4, int n5) {
        hk.a(n, n2, n3, n5);
        hk.a(n, n2 + n4 - 1, n3, n5);
        hk.g(n, n2, n4, n5);
        hk.g(n + n3 - 1, n2, n4, n5);
    }

    static final void a(int n, int n2, int n3, int n4, int n5) {
        if (n < hk_c) {
            n3 -= hk_c - n;
            n = hk_c;
        }
        if (n2 < hk_h) {
            n4 -= hk_h - n2;
            n2 = hk_h;
        }
        if (n + n3 > hk_g) {
            n3 = hk_g - n;
        }
        if (n2 + n4 > hk_b) {
            n4 = hk_b - n2;
        }
        int n6 = hk_j - n3;
        int n7 = n + n2 * hk_j;
        for (int i = -n4; i < 0; ++i) {
            for (int j = -n3; j < 0; ++j) {
                hk.hk_l[n7++] = n5;
            }
            n7 += n6;
        }
    }

    static final void f(int n, int n2, int n3, int n4) {
        if (hk_c < n) {
            hk_c = n;
        }
        if (hk_h < n2) {
            hk_h = n2;
        }
        if (hk_g > n3) {
            hk_g = n3;
        }
        if (hk_b > n4) {
            hk_b = n4;
        }
        hk.c();
    }

    private static final void a(int n, int[] nArray, int n2, int n3, int n4, int n5) {
        while (n4 < 0) {
            n2 = n + n3 - 7;
            while (n < n2) {
                nArray[n] = (nArray[n] & 0xFEFEFE) >> 1;
                nArray[++n] = (nArray[n] & 0xFEFEFE) >> 1;
                nArray[++n] = (nArray[n] & 0xFEFEFE) >> 1;
                nArray[++n] = (nArray[n] & 0xFEFEFE) >> 1;
                nArray[++n] = (nArray[n] & 0xFEFEFE) >> 1;
                nArray[++n] = (nArray[n] & 0xFEFEFE) >> 1;
                nArray[++n] = (nArray[n] & 0xFEFEFE) >> 1;
                nArray[++n] = (nArray[n] & 0xFEFEFE) >> 1;
                ++n;
            }
            n2 += 7;
            while (n < n2) {
                nArray[n] = (nArray[n] & 0xFEFEFE) >> 1;
                ++n;
            }
            n += n5;
            ++n4;
        }
    }

    private static final void a(int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8;
        int n9 = 16384 / (2 * n3 + 1);
        int n10 = 1 + n3 - n5 - n4;
        if (0 < n10) {
            n10 = 0;
        }
        if (0 < (n8 = hk_j - n4 - n5 - n3)) {
            n8 = 0;
        }
        int n11 = 0;
        int n12 = n4 + n3 + 1;
        if (hk_j < n12) {
            n11 = n12 - hk_j;
            n12 = hk_j;
        }
        for (int i = -n7; i < 0; ++i) {
            int n13;
            int n14;
            int n15;
            int n16 = 0;
            int n17 = 0;
            int n18 = 0;
            int n19 = n2 - n3;
            int n20 = n19 - (n3 << 1) - 1;
            int n21 = n4 - n3;
            if (n21 < 0) {
                n19 -= n21;
                n20 -= n21;
                n21 = 0;
            }
            int n22 = n12 - n21;
            while (n21 < n12) {
                n = nArray[n19];
                n16 += n >> 16 & 0xFF;
                n17 += n >> 8 & 0xFF;
                n18 += n & 0xFF;
                ++n19;
                ++n20;
                ++n21;
            }
            n20 += n11;
            nArray[n2++] = (n16 / n22 << 16) + (n17 / n22 << 8) + n18 / n22;
            for (n21 = 1 - n5; n21 < n10; ++n21) {
                ++n20;
                if (n4 + n5 + n21 + n3 < hk_g) {
                    n = nArray[n19];
                    ++n19;
                    n16 += n >> 16 & 0xFF;
                    n17 += n >> 8 & 0xFF;
                    n18 += n & 0xFF;
                    ++n22;
                }
                n15 = n16 / n22;
                n14 = n17 / n22;
                n13 = n18 / n22;
                nArray[n2++] = (n15 << 16) + (n14 << 8) + n13;
            }
            while (n21 < n8) {
                if ((n16 -= (n = nArray[n20++]) >> 16 & 0xFF) < 0) {
                    n16 = 0;
                }
                if ((n17 -= n >> 8 & 0xFF) < 0) {
                    n17 = 0;
                }
                if ((n18 -= n & 0xFF) < 0) {
                    n18 = 0;
                }
                n = nArray[n19];
                ++n19;
                n15 = (n16 += n >> 16 & 0xFF) * n9 >> 14;
                n14 = (n17 += n >> 8 & 0xFF) * n9 >> 14;
                n13 = (n18 += n & 0xFF) * n9 >> 14;
                if (n15 > 255) {
                    n15 = 255;
                }
                if (n14 > 255) {
                    n14 = 255;
                }
                if (n13 > 255) {
                    n13 = 255;
                }
                nArray[n2++] = (n15 << 16) + (n14 << 8) + n13;
                ++n21;
            }
            while (n21 < 0) {
                n = nArray[n20++];
                n15 = (n16 -= n >> 16 & 0xFF) / --n22;
                n14 = (n17 -= n >> 8 & 0xFF) / n22;
                n13 = (n18 -= n & 0xFF) / n22;
                if (n15 < 0) {
                    n15 = 0;
                } else if (n15 > 255) {
                    n15 = 255;
                }
                if (n14 < 0) {
                    n14 = 0;
                } else if (n14 > 255) {
                    n14 = 255;
                }
                if (n13 < 0) {
                    n13 = 0;
                } else if (n13 > 255) {
                    n13 = 255;
                }
                nArray[n2++] = (n15 << 16) + (n14 << 8) + n13;
                ++n21;
            }
            n2 += n6;
        }
    }

    public static void a() {
        hk_l = null;
        hk_k = null;
        hk_f = null;
        hk_d = null;
        hk_e = null;
        hk_a = null;
    }

    static final void c(int n, int n2, int n3, int n4, int n5) {
        if (n2 >= hk_h) {
            if (n2 >= hk_b) {
                return;
            }
            if (n < hk_c) {
                n3 -= hk_c - n;
                n = hk_c;
            }
            if (n + n3 > hk_g) {
                n3 = hk_g - n;
            }
            int n6 = 256 - n5;
            int n7 = (n4 >> 16 & 0xFF) * n5;
            int n8 = (n4 >> 8 & 0xFF) * n5;
            int n9 = (n4 & 0xFF) * n5;
            int n10 = n + n2 * hk_j;
            for (int i = 0; i < n3; ++i) {
                int n11 = (hk_l[n10] >> 16 & 0xFF) * n6;
                int n12 = (hk_l[n10] >> 8 & 0xFF) * n6;
                int n13 = (hk_l[n10] & 0xFF) * n6;
                int n14 = (n7 + n11 >> 8 << 16) + (n8 + n12 >> 8 << 8) + (n9 + n13 >> 8);
                hk.hk_l[n10++] = n14;
            }
            return;
        }
    }

    private static final void e(int n, int n2, int n3, int n4, int n5) {
        if (n >= hk_c) {
            if (n >= hk_g) {
                return;
            }
            if (n2 < hk_h) {
                n3 -= hk_h - n2;
                n2 = hk_h;
            }
            if (n2 + n3 > hk_b) {
                n3 = hk_b - n2;
            }
            int n6 = 256 - n5;
            int n7 = (n4 >> 16 & 0xFF) * n5;
            int n8 = (n4 >> 8 & 0xFF) * n5;
            int n9 = (n4 & 0xFF) * n5;
            int n10 = n + n2 * hk_j;
            for (int i = 0; i < n3; ++i) {
                int n11;
                int n12 = (hk_l[n10] >> 16 & 0xFF) * n6;
                int n13 = (hk_l[n10] >> 8 & 0xFF) * n6;
                int n14 = (hk_l[n10] & 0xFF) * n6;
                hk.hk_l[n10] = n11 = (n7 + n12 >> 8 << 16) + (n8 + n13 >> 8 << 8) + (n9 + n14 >> 8);
                n10 += hk_j;
            }
            return;
        }
    }

    private static final void c() {
        hk_k = null;
        hk_f = null;
    }

    static final void d(int n, int n2, int n3, int n4) {
        if (n < hk_c) {
            n3 -= hk_c - n;
            n = hk_c;
        }
        if (n2 < hk_h) {
            n4 -= hk_h - n2;
            n2 = hk_h;
        }
        if (n + n3 > hk_g) {
            n3 = hk_g - n;
        }
        if (n2 + n4 > hk_b) {
            n4 = hk_b - n2;
        }
        int n5 = hk_j - n3;
        int n6 = n + n2 * hk_j;
        hk.a(n6, hk_l, 0, n3, -n4, n5);
    }

    static final void c(int n, int n2, int n3, int n4, int n5, int n6) {
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        if (n5 == 0) {
            hk.a(n, n2, n3, n4, n6);
            return;
        }
        if (n5 < 0) {
            n5 = -n5;
        }
        int n12 = n + n5;
        int n13 = n2 + n5;
        int n14 = n2;
        if (n14 < hk_h) {
            n14 = hk_h;
        }
        if ((n11 = n2 + n4) > hk_b) {
            n11 = hk_b;
        }
        int n15 = n3 - n5 - n5 - 1;
        int n16 = n14;
        int n17 = n5 * n5;
        int n18 = 0;
        int n19 = n13 - n16;
        int n20 = n19 * n19;
        int n21 = n20 - n19;
        if (n13 > n11) {
            n13 = n11;
        }
        while (n16 < n13) {
            while (n21 <= n17 || n20 <= n17) {
                n20 += n18 + n18;
                n21 += n18++ + n18;
            }
            n10 = n12 - n18 + 1;
            if (n10 < hk_c) {
                n10 = hk_c;
            }
            if ((n9 = n12 + n15 + n18) > hk_g) {
                n9 = hk_g;
            }
            n8 = n10 + n16 * hk_j;
            for (n7 = n10; n7 < n9; ++n7) {
                hk.hk_l[n8++] = n6;
            }
            ++n16;
            n20 -= n19-- + n19;
            n21 -= n19 + n19;
        }
        n19 = n16 - n13;
        n10 = n;
        if (n10 < hk_c) {
            n10 = hk_c;
        }
        if ((n9 = n + n3) > hk_g) {
            n9 = hk_g;
        }
        n8 = n10 + n16 * hk_j;
        n7 = hk_j + n10 - n9;
        int n22 = n2 + n4 - n5 - 1;
        if (n22 > hk_b) {
            n22 = hk_b;
        }
        while (n16 < n22) {
            for (int i = n10; i < n9; ++i) {
                hk.hk_l[n8++] = n6;
            }
            ++n16;
            n8 += n7;
        }
        n19 = 0;
        n18 = n5;
        n21 = n19 * n19 + n17;
        n20 = n21 - n18;
        n21 -= n19;
        while (n16 < n11) {
            while (n21 > n17 && n20 > n17) {
                n21 -= n18-- + n18;
                n20 -= n18 + n18;
            }
            n10 = n12 - n18;
            if (n10 < hk_c) {
                n10 = hk_c;
            }
            if ((n9 = n12 + n15 + n18) > hk_g - 1) {
                n9 = hk_g - 1;
            }
            n8 = n10 + n16 * hk_j;
            for (n7 = n10; n7 <= n9; ++n7) {
                hk.hk_l[n8++] = n6;
            }
            ++n16;
            n21 += n19 + n19;
            n20 += n19++ + n19;
        }
    }

    static final void d(int n, int n2, int n3, int n4, int n5, int n6) {
        int n7 = 0;
        int n8 = 65536 / n4;
        if (n < hk_c) {
            n3 -= hk_c - n;
            n = hk_c;
        }
        if (n2 < hk_h) {
            n7 += (hk_h - n2) * n8;
            n4 -= hk_h - n2;
            n2 = hk_h;
        }
        if (n + n3 > hk_g) {
            n3 = hk_g - n;
        }
        if (n2 + n4 > hk_b) {
            n4 = hk_b - n2;
        }
        int n9 = hk_j - n3;
        int n10 = n + n2 * hk_j;
        for (int i = -n4; i < 0; ++i) {
            int n11 = 65536 - n7 >> 8;
            int n12 = n7 >> 8;
            int n13 = ((n5 & 0xFF00FF) * n11 + (n6 & 0xFF00FF) * n12 & 0xFF00FF00) + ((n5 & 0xFF00) * n11 + (n6 & 0xFF00) * n12 & 0xFF0000) >>> 8;
            for (int j = -n3; j < 0; ++j) {
                hk.hk_l[n10++] = n13;
            }
            n10 += n9;
            n7 += n8;
        }
    }

    private static final void a(int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        if (hk_d == null || hk_d.length < n8) {
            hk_d = new int[n8];
            hk_e = new int[n8];
            hk_a = new int[n8];
        }
        int[] nArray2 = hk_d;
        int[] nArray3 = hk_e;
        int[] nArray4 = hk_a;
        an.a(nArray2, 0, n8);
        an.a(nArray3, 0, n8);
        an.a(nArray4, 0, n8);
        int n14 = 16384 / (2 * n3 + 1);
        int n15 = n4 - n3;
        if (n15 < 0) {
            n15 = 0;
        }
        int n16 = n7 + n15 * hk_j;
        int n17 = n4 + n3;
        int n18 = 0;
        if (n17 >= hk_i) {
            n18 = n17 - hk_i + 1;
            n17 = hk_i - 1;
        }
        int n19 = n17 - n15 + 1;
        while (n15 <= n17) {
            n13 = 0;
            while (n13 < n8) {
                n = nArray[n16++];
                int n20 = n13;
                nArray2[n20] = nArray2[n20] + (n >> 16 & 0xFF);
                int n21 = n13;
                nArray3[n21] = nArray3[n21] + (n >> 8 & 0xFF);
                int n22 = n13++;
                nArray4[n22] = nArray4[n22] + (n & 0xFF);
            }
            n16 += n6;
            ++n15;
        }
        n16 += n18 * hk_j;
        for (n13 = 0; n13 < n8; ++n13) {
            nArray[n2++] = (nArray2[n13] / n19 << 16) + (nArray3[n13] / n19 << 8) + nArray4[n13] / n19;
        }
        n2 += n6;
        n15 = 1 - n5;
        n13 = 1 + n3 - n5 - n4;
        if (0 < n13) {
            n13 = 0;
        }
        int n23 = n7 + (n4 - n3) * hk_j;
        if (n15 < n13) {
            n23 += (n13 - n15) * hk_j;
        }
        while (n15 < n13) {
            if (n15 + n4 + n5 + n3 < hk_b) {
                n12 = 0;
                while (n12 < n8) {
                    n = nArray[n16++];
                    int n24 = n12;
                    nArray2[n24] = nArray2[n24] + (n >> 16 & 0xFF);
                    int n25 = n12;
                    nArray3[n25] = nArray3[n25] + (n >> 8 & 0xFF);
                    int n26 = n12++;
                    nArray4[n26] = nArray4[n26] + (n & 0xFF);
                }
                n16 += n6;
                ++n19;
            } else {
                n16 += hk_j;
            }
            for (n12 = 0; n12 < n8; ++n12) {
                n11 = nArray2[n12] / n19;
                n10 = nArray3[n12] / n19;
                n9 = nArray4[n12] / n19;
                nArray[n2++] = (n11 << 16) + (n10 << 8) + n9;
            }
            n2 += n6;
            ++n15;
        }
        n13 = hk_i - n4 - n5 - n3;
        if (0 < n13) {
            n13 = 0;
        }
        while (n15 < n13) {
            for (n12 = 0; n12 < n8; ++n12) {
                nArray2[n12] = (n11 = nArray2[n12] - ((n = nArray[n23++]) >> 16 & 0xFF)) < 0 ? 0 : n11;
                n11 = nArray3[n12] - (n >> 8 & 0xFF);
                nArray3[n12] = n11 < 0 ? 0 : n11;
                n11 = nArray4[n12] - (n & 0xFF);
                nArray4[n12] = n11 < 0 ? 0 : n11;
            }
            n23 += n6;
            n12 = 0;
            while (n12 < n8) {
                n = nArray[n16++];
                int n27 = n12;
                nArray2[n27] = nArray2[n27] + (n >> 16 & 0xFF);
                int n28 = n12;
                nArray3[n28] = nArray3[n28] + (n >> 8 & 0xFF);
                int n29 = n12++;
                nArray4[n29] = nArray4[n29] + (n & 0xFF);
            }
            n16 += n6;
            for (n12 = 0; n12 < n8; ++n12) {
                n11 = nArray2[n12] * n14 >> 14;
                n10 = nArray3[n12] * n14 >> 14;
                n9 = nArray4[n12] * n14 >> 14;
                if (n11 > 255) {
                    n11 = 255;
                }
                if (n10 > 255) {
                    n10 = 255;
                }
                if (n9 > 255) {
                    n9 = 255;
                }
                nArray[n2++] = (n11 << 16) + (n10 << 8) + n9;
            }
            n2 += n6;
            ++n15;
        }
        while (n15 < 0) {
            n12 = 0;
            while (n12 < n8) {
                n = nArray[n23++];
                int n30 = n12;
                nArray2[n30] = nArray2[n30] - (n >> 16 & 0xFF);
                int n31 = n12;
                nArray3[n31] = nArray3[n31] - (n >> 8 & 0xFF);
                int n32 = n12++;
                nArray4[n32] = nArray4[n32] - (n & 0xFF);
            }
            n23 += n6;
            --n19;
            for (n12 = 0; n12 < n8; ++n12) {
                n11 = nArray2[n12] / n19;
                n10 = nArray3[n12] / n19;
                n9 = nArray4[n12] / n19;
                if (n11 < 0) {
                    n11 = 0;
                } else if (n11 > 255) {
                    n11 = 255;
                }
                if (n10 < 0) {
                    n10 = 0;
                } else if (n10 > 255) {
                    n10 = 255;
                }
                if (n9 < 0) {
                    n9 = 0;
                } else if (n9 > 255) {
                    n9 = 255;
                }
                nArray[n2++] = (n11 << 16) + (n10 << 8) + n9;
            }
            n2 += n6;
            ++n15;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        if (n < hk_c) {
            n3 -= hk_c - n;
            n = hk_c;
        }
        if (n2 < hk_h) {
            n4 -= hk_h - n2;
            n2 = hk_h;
        }
        if (n + n3 > hk_g) {
            n3 = hk_g - n;
        }
        if (n2 + n4 > hk_b) {
            n4 = hk_b - n2;
        }
        n5 = ((n5 & 0xFF00FF) * n6 >> 8 & 0xFF00FF) + ((n5 & 0xFF00) * n6 >> 8 & 0xFF00);
        int n7 = 256 - n6;
        int n8 = hk_j - n3;
        int n9 = n + n2 * hk_j;
        for (int i = 0; i < n4; ++i) {
            for (int j = -n3; j < 0; ++j) {
                int n10 = hk_l[n9];
                n10 = ((n10 & 0xFF00FF) * n7 >> 8 & 0xFF00FF) + ((n10 & 0xFF00) * n7 >> 8 & 0xFF00);
                hk.hk_l[n9++] = n5 + n10;
            }
            n9 += n8;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        if (n7 == 256) {
            hk.c(n, n2, n3, n4, n5, n6);
            return;
        }
        if (n5 == 0) {
            hk.a(n, n2, n3, n4, n6, n7);
            return;
        }
        int n14 = 256 - n7;
        n6 = ((n6 & 0xFF00FF) * n7 >> 8 & 0xFF00FF) + ((n6 & 0xFF00) * n7 >> 8 & 0xFF00);
        if (n5 < 0) {
            n5 = -n5;
        }
        int n15 = n + n5;
        int n16 = n2 + n5;
        int n17 = n2;
        if (n17 < hk_h) {
            n17 = hk_h;
        }
        if ((n13 = n2 + n4) > hk_b) {
            n13 = hk_b;
        }
        int n18 = n3 - n5 - n5 - 1;
        int n19 = n17;
        int n20 = n5 * n5;
        int n21 = 0;
        int n22 = n16 - n19;
        int n23 = n22 * n22;
        int n24 = n23 - n22;
        if (n16 > n13) {
            n16 = n13;
        }
        while (n19 < n16) {
            while (n24 <= n20 || n23 <= n20) {
                n23 += n21 + n21;
                n24 += n21++ + n21;
            }
            n12 = n15 - n21 + 1;
            if (n12 < hk_c) {
                n12 = hk_c;
            }
            if ((n11 = n15 + n18 + n21) > hk_g) {
                n11 = hk_g;
            }
            n10 = n12 + n19 * hk_j;
            for (n9 = n12; n9 < n11; ++n9) {
                n8 = hk_l[n10];
                n8 = ((n8 & 0xFF00FF) * n14 >> 8 & 0xFF00FF) + ((n8 & 0xFF00) * n14 >> 8 & 0xFF00);
                hk.hk_l[n10++] = n6 + n8;
            }
            ++n19;
            n23 -= n22-- + n22;
            n24 -= n22 + n22;
        }
        n22 = n19 - n16;
        n12 = n;
        if (n12 < hk_c) {
            n12 = hk_c;
        }
        if ((n11 = n + n3) > hk_g) {
            n11 = hk_g;
        }
        n10 = n12 + n19 * hk_j;
        n9 = hk_j + n12 - n11;
        n8 = n2 + n4 - n5 - 1;
        if (n8 > hk_b) {
            n8 = hk_b;
        }
        while (n19 < n8) {
            for (int i = n12; i < n11; ++i) {
                int n25 = hk_l[n10];
                n25 = ((n25 & 0xFF00FF) * n14 >> 8 & 0xFF00FF) + ((n25 & 0xFF00) * n14 >> 8 & 0xFF00);
                hk.hk_l[n10++] = n6 + n25;
            }
            ++n19;
            n10 += n9;
        }
        n22 = 0;
        n21 = n5;
        n24 = n22 * n22 + n20;
        n23 = n24 - n21;
        n24 -= n22;
        while (n19 < n13) {
            while (n24 > n20 && n23 > n20) {
                n24 -= n21-- + n21;
                n23 -= n21 + n21;
            }
            n12 = n15 - n21;
            if (n12 < hk_c) {
                n12 = hk_c;
            }
            if ((n11 = n15 + n18 + n21) > hk_g - 1) {
                n11 = hk_g - 1;
            }
            n10 = n12 + n19 * hk_j;
            for (n9 = n12; n9 <= n11; ++n9) {
                n8 = hk_l[n10];
                n8 = ((n8 & 0xFF00FF) * n14 >> 8 & 0xFF00FF) + ((n8 & 0xFF00) * n14 >> 8 & 0xFF00);
                hk.hk_l[n10++] = n6 + n8;
            }
            ++n19;
            n24 += n22 + n22;
            n23 += n22++ + n22;
        }
    }

    static final void e(int n, int n2, int n3, int n4) {
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        if (n3 == 0) {
            hk.a(n, n2, n4);
            return;
        }
        if (n3 < 0) {
            n3 = -n3;
        }
        if ((n10 = n2 - n3) < hk_h) {
            n10 = hk_h;
        }
        if ((n9 = n2 + n3 + 1) > hk_b) {
            n9 = hk_b;
        }
        int n11 = n10;
        int n12 = n3 * n3;
        int n13 = 0;
        int n14 = n2 - n11;
        int n15 = n14 * n14;
        int n16 = n15 - n14;
        if (n2 > n9) {
            n2 = n9;
        }
        while (n11 < n2) {
            while (n16 <= n12 || n15 <= n12) {
                n15 += n13 + n13;
                n16 += n13++ + n13;
            }
            n8 = n - n13 + 1;
            if (n8 < hk_c) {
                n8 = hk_c;
            }
            if ((n7 = n + n13) > hk_g) {
                n7 = hk_g;
            }
            n6 = n8 + n11 * hk_j;
            for (n5 = n8; n5 < n7; ++n5) {
                hk.hk_l[n6++] = n4;
            }
            ++n11;
            n15 -= n14-- + n14;
            n16 -= n14 + n14;
        }
        n13 = n3;
        n14 = n11 - n2;
        n16 = n14 * n14 + n12;
        n15 = n16 - n13;
        n16 -= n14;
        while (n11 < n9) {
            while (n16 > n12 && n15 > n12) {
                n16 -= n13-- + n13;
                n15 -= n13 + n13;
            }
            n8 = n - n13;
            if (n8 < hk_c) {
                n8 = hk_c;
            }
            if ((n7 = n + n13) > hk_g - 1) {
                n7 = hk_g - 1;
            }
            n6 = n8 + n11 * hk_j;
            for (n5 = n8; n5 <= n7; ++n5) {
                hk.hk_l[n6++] = n4;
            }
            ++n11;
            n16 += n14 + n14;
            n15 += n14++ + n14;
        }
    }

    static final void b(int[] nArray) {
        nArray[0] = hk_c;
        nArray[1] = hk_h;
        nArray[2] = hk_g;
        nArray[3] = hk_b;
    }

    static final void c(int n, int n2, int n3, int n4) {
        if (n < hk_c) {
            n3 -= hk_c - n;
            n = hk_c;
        }
        if (n + n3 > hk_g) {
            n3 = hk_g - n;
        }
        if (n2 < hk_h) {
            n4 -= hk_h - n2;
            n2 = hk_h;
        }
        if (n2 + n4 > hk_b) {
            n4 = hk_b - n2;
        }
        int n5 = n + n2 * hk_j;
        if (n3 > 0) {
            if (n4 <= 0) {
                return;
            }
            for (int i = 0; i < n4; ++i) {
                for (int j = 0; j < n3; ++j) {
                    int n6 = hk_l[n5];
                    int n7 = n6 >> 15 & 0x1FE;
                    int n8 = n6 >> 8 & 0xFF;
                    int n9 = n6 & 0xFF;
                    int n10 = (n9 + n7) / 3 + n8 >> 1;
                    hk.hk_l[n5++] = (n10 << 16) + (n10 << 8) + n10;
                }
                n5 += hk_j - n3;
            }
            return;
        }
    }

    static final void a(int[] nArray) {
        hk_c = nArray[0];
        hk_h = nArray[1];
        hk_g = nArray[2];
        hk_b = nArray[3];
        hk.c();
    }

    static final void b(int n, int n2, int n3, int n4, int n5) {
        n3 -= n;
        if ((n4 -= n2) == 0) {
            if (n3 >= 0) {
                hk.a(n, n2, n3 + 1, n5);
            } else {
                hk.a(n + n3, n2, -n3 + 1, n5);
            }
            return;
        }
        if (n3 == 0) {
            if (n4 >= 0) {
                hk.g(n, n2, n4 + 1, n5);
            } else {
                hk.g(n, n2 + n4, -n4 + 1, n5);
            }
            return;
        }
        if (n3 + n4 < 0) {
            n += n3;
            n3 = -n3;
            n2 += n4;
            n4 = -n4;
        }
        if (n3 > n4) {
            n2 <<= 16;
            n2 += 32768;
            int n6 = (int)Math.floor((double)(n4 <<= 16) / (double)n3 + 0.5);
            n3 += n;
            if (n < hk_c) {
                n2 += n6 * (hk_c - n);
                n = hk_c;
            }
            if (n3 >= hk_g) {
                n3 = hk_g - 1;
            }
            while (n <= n3) {
                int n7 = n2 >> 16;
                if (n7 >= hk_h && n7 < hk_b) {
                    hk.hk_l[n + n7 * hk.hk_j] = n5;
                }
                n2 += n6;
                ++n;
            }
        } else {
            n <<= 16;
            n += 32768;
            int n8 = (int)Math.floor((double)(n3 <<= 16) / (double)n4 + 0.5);
            n4 += n2;
            if (n2 < hk_h) {
                n += n8 * (hk_h - n2);
                n2 = hk_h;
            }
            if (n4 >= hk_b) {
                n4 = hk_b - 1;
            }
            while (n2 <= n4) {
                int n9 = n >> 16;
                if (n9 >= hk_c && n9 < hk_g) {
                    hk.hk_l[n9 + n2 * hk.hk_j] = n5;
                }
                n += n8;
                ++n2;
            }
            return;
        }
    }

    static final void d(int n, int n2, int n3, int n4, int n5) {
        for (int i = 0; i < 4; ++i) {
            int n6 = 128 - (i << 5);
            hk.c(n + i, n2 + n4 + i, n3, n5, n6);
            hk.e(n + n3 + i, n2 + i, n4 + 1, n5, n6);
        }
    }

    static final void b(int n, int n2, int n3, int n4) {
        if (n < 0) {
            n = 0;
        }
        if (n2 < 0) {
            n2 = 0;
        }
        if (n3 > hk_j) {
            n3 = hk_j;
        }
        if (n4 > hk_i) {
            n4 = hk_i;
        }
        hk_c = n;
        hk_h = n2;
        hk_g = n3;
        hk_b = n4;
        hk.c();
    }

    static final void a(int n, int n2, int n3, int n4) {
        if (n2 >= hk_h) {
            if (n2 >= hk_b) {
                return;
            }
            if (n < hk_c) {
                n3 -= hk_c - n;
                n = hk_c;
            }
            if (n + n3 > hk_g) {
                n3 = hk_g - n;
            }
            int n5 = n + n2 * hk_j;
            for (int i = 0; i < n3; ++i) {
                hk.hk_l[n5 + i] = n4;
            }
            return;
        }
    }

    static {
        hk_g = 0;
        hk_b = 0;
        hk_h = 0;
        hk_c = 0;
    }
}
