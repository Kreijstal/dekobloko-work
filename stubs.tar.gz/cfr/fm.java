/*
 * Decompiled with CFR 0.152.
 */
abstract class fm {
    static boolean fm_e;
    static String fm_c;
    static boolean fm_b;
    static long fm_d;
    static boolean fm_f;
    static String fm_a;

    static final void a(byte by, bh bh2, bh bh3) {
        int n = 32 % ((by - 60) / 49);
        if (null != bh2.bh_a) {
            bh2.b((byte)113);
        }
        bh2.bh_b = bh3;
        bh2.bh_a = bh3.bh_a;
        bh2.bh_a.bh_b = bh2;
        bh2.bh_b.bh_a = bh2;
    }

    fm() {
    }

    static final void a(byte by, int n, kn kn2) {
        block1: {
            uf uf2;
            boolean bl = client.A;
            uf uf3 = uf2 = we.we_b;
            uf3.f(n, -4);
            ++uf3.wl_n;
            int n2 = uf3.wl_n;
            uf3.a(true, 1);
            uf3.d(-1, kn2.kn_u);
            uf3.d(-1, kn2.x);
            uf3.d(-1, kn2.kn_q);
            uf3.a(kn2.kn_t, false);
            uf3.a(kn2.kn_v, false);
            uf3.a(kn2.kn_w, false);
            uf3.a(kn2.y, false);
            uf3.a(true, kn2.kn_s.length);
            for (int i = 0; i < kn2.kn_s.length; ++i) {
                uf2.a(kn2.kn_s[i], false);
            }
            uf3.a((byte)-15, n2);
            uf3.b(uf3.wl_n - n2, true);
            if (by <= -90) break block1;
            fm_b = true;
        }
    }

    abstract void a(wl var1, byte var2);

    public static void a(boolean bl) {
        block0: {
            fm_a = null;
            fm_c = null;
            if (bl) break block0;
            kn kn2 = null;
            fm.a((byte)8, -15, kn2);
        }
    }

    abstract gh a(int var1);

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        boolean bl = client.A;
        int n8 = 80 <= n5 ? 54 : n5 / 20 * 18;
        int n9 = 0;
        if (60 > n5) {
            n8 += vl.a(23841, 80, n4 * 18 - -40);
        } else if (~n5 <= -81) {
            if (n5 >= 93) {
                hk.a(n2 + -36 + -3, n3 + 36 - 3, 78, 60, 4, 65280, 100);
            } else {
                n9 = vl.a(23841, 80, 18 * ve.ve_ic[1 + n5 - 80] - -40);
            }
        } else {
            n8 += vl.a(23841, 80, n7 * 18 - -40);
        }
        cg.a(n, 2, 5, n2 - -18, n3 + 73, -2, -2);
        cg.a(n, 2, 12, 18 + n2, n3 - -55, -2, -1);
        cg.a(n, 2, 8, 18 + n2, 36 + (n3 - -1), -2, -1);
        cg.a(n, 2, 2, n2, 1 + n3 + 72, -1, -2);
        fb.fb_c[n][2].c(n2 + -18, 72 + n3, 18, 18);
        fb.fb_c[n][2].c(-36 + n2, n3 + 72, 18, 18);
        int n10 = 16 / ((59 - n6) / 43);
        fb.fb_c[n][2].c(n2, n3 - -54, 18, 18);
        fb.fb_c[n][2].c(n2 + -18, n3 - -n8 + n9, 18, 18 + -n9);
    }

    static {
        fm_c = "In Single-player";
        fm_a = "Connection restored.";
    }
}
