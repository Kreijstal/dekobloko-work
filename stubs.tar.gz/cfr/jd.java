/*
 * Decompiled with CFR 0.152.
 */
final class jd
extends w {
    private int Nb;
    private w Sb;
    private w Vb;
    static long[] Ub;
    private w Wb;
    static String Xb;
    static boolean Qb;
    private w Rb;
    static String Ob;
    static String Zb;
    private w Pb;
    private w Tb;
    static int Yb;

    final int a(boolean bl, byte by, int n, int n2) {
        if (by != 88) {
            return -14;
        }
        int n3 = 0;
        int n4 = -this.Tb.N + this.Pb.N;
        if (0 < n4) {
            int n5 = this.Tb.Ib;
            int n6 = -n + n2;
            n3 = (n5 * n6 - -(n4 / 2)) / n4;
        }
        if (bl) {
            if (-1 < ~n3) {
                n3 = 0;
            }
            if (n3 > -n + n2) {
                n3 = -n + n2;
            }
        } else {
            if (~n3 < ~(n2 - n)) {
                n3 = n2 + -n;
            }
            if (n3 < 0) {
                n3 = 0;
            }
        }
        return n3;
    }

    static final byte[] a(int n, byte[] byArray) {
        int n2 = byArray.length;
        byte[] byArray2 = new byte[n2];
        an.a(byArray, 0, byArray2, n, n2);
        return byArray2;
    }

    final boolean i(byte by) {
        if (-1 != ~this.Sb.w_ob) {
            this.Nb = 20;
            return true;
        }
        if (this.Sb.w_gb != 0) {
            if (-1 > ~this.Nb) {
                --this.Nb;
            }
            if (-1 == ~this.Nb) {
                this.Nb = 3;
                return true;
            }
        }
        if (by != 7) {
            this.g((byte)-98);
        }
        return false;
    }

    final boolean g(byte by) {
        if (by >= -59) {
            this.Tb = null;
        }
        if (this.Wb.w_ob != 0) {
            this.Nb = 20;
            return true;
        }
        if (this.Wb.w_gb != 0) {
            if (0 < this.Nb) {
                --this.Nb;
            }
            if (-1 == ~this.Nb && this.Tb.w_pb - -this.Tb.Mb > pm.pm_f) {
                this.Nb = 3;
                return true;
            }
        }
        return false;
    }

    final void a(int n, byte by, int n2, int n3, int n4, int n5, int n6, int n7) {
        this.w_mb = n4;
        this.Ib = n7;
        this.w_vb = n;
        this.N = n2;
        int n8 = 91 / ((73 - by) / 40);
        this.a(n6, n3, -91, n5);
    }

    static final void g(int n) {
        block5: {
            boolean bl = client.A;
            if (n <= 4) {
                return;
            }
            fj.fj_h = false;
            cd.cd_m = null;
            g.N = null;
            if (null != i.i_b) {
                i.i_b.c(120);
                i.i_b = null;
            }
            ob.ob_i = null;
            if (null != h.h_b) {
                h.h_b.c(118);
                h.h_b = null;
            }
            tg.tg_b = null;
            if (oc.oc_b != null) {
                oc.oc_b.c(113);
                oc.oc_b = null;
            }
            hn.hn_h = null;
            if (ob.ob_i == null) break block5;
            tj tj2 = (tj)ob.ob_i.c(-9443);
            while (tj2 != null) {
                tj2.e((byte)69);
                tj2 = (tj)ob.ob_i.b(-123);
            }
            ob.ob_i = null;
        }
    }

    final boolean h(byte by) {
        if (0 != this.Vb.w_ob) {
            this.Nb = 20;
            return true;
        }
        if (~this.Vb.w_gb != -1) {
            if (-1 > ~this.Nb) {
                --this.Nb;
            }
            if (this.Nb == 0) {
                this.Nb = 3;
                return true;
            }
        }
        if (by < 67) {
            this.Wb = null;
        }
        return false;
    }

    public static void e(int n) {
        if (n != 32) {
            return;
        }
        Zb = null;
        Ub = null;
        Ob = null;
        Xb = null;
    }

    jd(long l, w w2, w w3, w w4, w w5) {
        super(l, null);
        this.Sb = new w(0L, w2);
        this.Vb = new w(0L, w3);
        this.a(this.Sb, -16834);
        this.a(this.Vb, -16834);
        this.Pb = new w(0L, null);
        this.a(this.Pb, -16834);
        this.Wb = new w(0L, w4);
        this.Rb = new w(0L, w4);
        w w6 = this.Wb;
        this.Rb.Gb = true;
        w6.Gb = true;
        this.Pb.a(this.Wb, -16834);
        this.Pb.a(this.Rb, -16834);
        this.Tb = new w(0L, w5);
        this.Tb.U = true;
        this.Pb.a(this.Tb, -16834);
    }

    final void a(int n, int n2, int n3, int n4) {
        int n5;
        int n6;
        int n7;
        if (~this.N <= ~(2 * this.w_mb)) {
            n7 = -this.w_mb + this.N;
            n6 = this.w_mb;
        } else {
            n6 = n7 = this.N / 2;
        }
        int n8 = n5 = n7 - n6;
        if (0 < n2) {
            if (this.w_mb > (n8 = n8 * n / n2)) {
                n8 = this.w_mb;
            }
            if (~n5 > ~n8) {
                n8 = n5;
            }
        }
        int n9 = n2 - n;
        int n10 = -n8 + n5;
        int n11 = 0;
        if (-1 > ~n9) {
            n11 = (n4 * n10 + n9 / 2) / n9;
        }
        int n12 = n11 - -(n8 / 2);
        w w2 = this.Sb;
        w2.w_mb = this.w_mb;
        int n13 = 103 % ((n3 - -29) / 46);
        w2.N = n6;
        w2.Ib = 0;
        w2.w_vb = 0;
        w w3 = this.Vb;
        w3.Ib = n7;
        w3.w_mb = this.w_mb;
        w3.N = this.N - n7;
        w3.w_vb = 0;
        w w4 = this.Pb;
        w4.N = n5;
        w4.w_mb = this.w_mb;
        w4.w_vb = 0;
        w4.Ib = n6;
        w w5 = this.Wb;
        w5.w_vb = 0;
        w5.N = n12;
        w5.Ib = 0;
        w5.w_mb = this.w_mb;
        w w6 = this.Rb;
        w6.Ib = n12;
        w6.w_vb = 0;
        w6.N = -n12 + n5;
        w6.w_mb = this.w_mb;
        w w7 = this.Tb;
        w7.w_mb = this.w_mb;
        w7.N = n8;
        w7.Ib = n11;
        this.Pb.Hb = ~n2 < ~n;
        this.Vb.Hb = this.Pb.Hb;
        this.Sb.Hb = this.Pb.Hb;
        w7.w_vb = 0;
    }

    jd(long l, jd jd2) {
        this(l, jd2.Sb, jd2.Vb, jd2.Wb, jd2.Tb);
    }

    final boolean f(int n) {
        if (this.Rb.w_ob != n) {
            this.Nb = 20;
            return true;
        }
        if (-1 == ~this.Rb.w_gb) {
            return false;
        }
        if (this.Nb > 0) {
            --this.Nb;
        }
        if (~this.Nb == -1 && pm.pm_f >= this.Tb.F + (this.Tb.N + this.Tb.Mb + this.Tb.w_pb)) {
            this.Nb = 3;
            return true;
        }
        return false;
    }

    final boolean j(byte by) {
        if (by != -2) {
            this.a(58, -105, -107, 34);
        }
        return -1 != ~this.Tb.w_gb;
    }

    static {
        Zb = "Buying or selling an account";
        Ub = new long[32];
        Xb = "Orb points: ";
        Ob = "To Highscores";
    }
}
