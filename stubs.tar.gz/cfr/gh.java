/*
 * Decompiled with CFR 0.152.
 */
final class gh {
    int gh_a;
    static qm gh_c = new qm(15, 0, 1, 0);
    static String gh_d = "Macroing or use of bots";
    static w gh_b;
    static kn gh_e;
    static String gh_f;

    static final void a(boolean bl) {
        block1: {
            if (hc.hc_d == 10 || !bd.d((byte)-124)) {
                ne.e(-5);
                hc.hc_d = 11;
            }
            tf.tf_bb = true;
            if (!bl) break block1;
            gh_f = null;
        }
    }

    gh(int n) {
        this.gh_a = n;
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    public static void a(int n) {
        gh_d = null;
        gh_f = null;
        if (n <= 42) {
            return;
        }
        gh_b = null;
        gh_c = null;
        gh_e = null;
    }

    static {
        gh_e = null;
        gh_f = "Public chat is unavailable while setting up a rated game.";
    }
}
