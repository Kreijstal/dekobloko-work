/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

final class wb
extends w {
    String Pb;
    w Sb;
    static int Rb;
    w Wb;
    String Vb;
    static int[] Zb;
    int Xb;
    static Boolean Ub;
    static fm Nb;
    w Yb;
    String Tb;
    String Ob;
    static String[] Qb;

    static final void a(kc kc2, int n, int n2) {
        uf uf2 = we.we_b;
        uf2.f(n, n2 + -64);
        if (n2 != 60) {
            Nb = null;
        }
        uf2.a(true, 5);
        uf2.a(true, 0);
        uf2.d(n2 ^ 0xFFFFFFC3, kc2.kc_n);
        uf2.a(true, kc2.kc_o);
        uf2.a(true, kc2.kc_v);
    }

    static final void a(Applet applet, int n) {
        try {
            String string = applet.getDocumentBase().getFile();
            if (n != 30307) {
                Rb = 64;
            }
            int n2 = string.indexOf(63);
            String string2 = "reload.ws";
            if (0 <= n2) {
                string2 = string2 + string.substring(n2);
            }
            URL uRL = new URL(applet.getCodeBase(), string2);
            applet.getAppletContext().showDocument(gn.a(uRL, -1, applet), "_self");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        boolean bl = client.A;
        if (~hk.hk_c < ~n2) {
            n6 -= -n2 + hk.hk_c;
            n2 = hk.hk_c;
        }
        if (~(n2 + n6) < ~hk.hk_g) {
            n6 = hk.hk_g + -n2;
        }
        if (hk.hk_h > n4) {
            n3 -= -n4 + hk.hk_h;
            n4 = hk.hk_h;
        }
        if (n4 + n3 > hk.hk_b) {
            n3 = -n4 + hk.hk_b;
        }
        if (0 < n6) {
            if (n3 <= 0) {
                return;
            }
            int n7 = n4 * hk.hk_j + n2;
            if (n != 31) {
                Qb = null;
            }
            int n8 = -n6 + hk.hk_j;
            n4 = -n3;
            while (-1 < ~n4) {
                n2 = -n6;
                while (-1 < ~n2) {
                    int n9 = hk.hk_l[n7];
                    if ((0xFF00 & n9) >> 1753310408 > n5 && ~(0xFF & n9 >> 459642768) >= ~(n9 >> -1566086360 & 0xFF)) {
                        int n10 = ((0xFF0000 & n9) >> -1904407857) - 60;
                        if (-256 > ~n10) {
                            n10 = 255;
                        }
                        int n11 = n9 & 0xFF00;
                        n11 = (n11 >> -14574239) + -(n11 >> -1326998683) & 0xFF00;
                        int n12 = 0x1F & n9 >> 44010979;
                        hk.hk_l[n7] = de.b(n12, de.b(n10 << -1621456400, n11));
                    }
                    ++n7;
                    ++n2;
                }
                n7 += n8;
                ++n4;
            }
            return;
        }
    }

    public static void e(int n) {
        if (n >= -73) {
            Zb = null;
        }
        Qb = null;
        Zb = null;
        Nb = null;
        Ub = null;
    }

    static final int b(byte by, int n) {
        int n2 = n >>> -691332351;
        n2 |= n2 >>> 285134945;
        if (by > -77) {
            kc kc2 = null;
            wb.a(kc2, -48, 106);
        }
        n2 |= n2 >>> 2037729058;
        n2 |= n2 >>> -501559868;
        n2 |= n2 >>> -1143914328;
        n2 |= n2 >>> -1995022320;
        return n & ~n2;
    }

    wb() {
        super(0L, null);
    }

    static {
        Nb = null;
    }
}
