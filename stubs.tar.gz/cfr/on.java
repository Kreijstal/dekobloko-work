/*
 * Decompiled with CFR 0.152.
 */
final class on
implements gl {
    private int on_b;
    private mm on_j;
    static String on_i = "No options available";
    static ck[] on_e;
    static boolean on_d;
    private int on_f;
    static String on_h;
    static String on_c;
    static String on_a;
    static int[] on_g;

    static final nj a(byte[] byArray, byte by) {
        if (byArray == null) {
            return null;
        }
        if (by <= 7) {
            return null;
        }
        nj nj2 = new nj(byArray, sg.sg_d, fh.fh_a, tm.tm_a, hc.hc_c, mb.mb_d, tc.Nb);
        oa.a(126);
        return nj2;
    }

    static final void a(boolean bl, int[] nArray, boolean bl2, int[] nArray2, boolean bl3, boolean bl4, vg vg2) {
        boolean bl5 = client.A;
        int n = Integer.MAX_VALUE;
        if (!bl) {
            return;
        }
        int n2 = Integer.MIN_VALUE;
        int n3 = nArray[3] >> -271266366;
        int n4 = nArray[4] >> -1473161854;
        int n5 = nArray[5] >> -1133877790;
        int n6 = nArray[6] >> -142707454;
        int n7 = nArray[7] >> 1029153442;
        int n8 = nArray[8] >> -2000365214;
        int n9 = nArray[9] >> 1213195106;
        int n10 = nArray[10] >> 1851497538;
        int n11 = nArray[11] >> -1209643166;
        int n12 = n8 * nArray2[5] + n6 * nArray2[3] + n7 * nArray2[4] >> -855007538;
        int n13 = nArray2[5] * n5 + nArray2[3] * n3 - -(nArray2[4] * n4) >> 416957870;
        int n14 = nArray2[6] * n3 - (-(nArray2[7] * n4) - n5 * nArray2[8]) >> 1706468014;
        int n15 = nArray2[11] * n5 + nArray2[10] * n4 + nArray2[9] * n3 >> -896953074;
        int n16 = n8 * nArray2[11] + (nArray2[10] * n7 + n6 * nArray2[9]) >> 699680526;
        int n17 = n11 * nArray2[5] + (nArray2[4] * n10 + nArray2[3] * n9) >> -1719218162;
        int n18 = nArray2[10] * n10 + (n9 * nArray2[9] + n11 * nArray2[11]) >> 323688910;
        int n19 = nArray2[6] * n9 - -(n10 * nArray2[7]) + n11 * nArray2[8] >> 1880148654;
        int n20 = nArray2[7] * n7 + (n6 * nArray2[6] - -(n8 * nArray2[8])) >> -1690955026;
        n3 = nArray2[0] - nArray[0];
        n4 = -nArray[1] + nArray2[1];
        n5 = -nArray[2] + nArray2[2];
        int n21 = n3 * nArray[3] - (-(nArray[4] * n4) - nArray[5] * n5) >> -me.y + 16;
        int n22 = nArray[6] * n3 - -(nArray[7] * n4) + n5 * nArray[8] >> 16 + -me.y;
        int n23 = n5 * nArray[11] + nArray[10] * n4 + n3 * nArray[9] >> -1661035472;
        n3 = qg.qg_g;
        n4 = qg.qg_c;
        n5 = 0;
        while (~n5 > ~vg2.vg_l) {
            n6 = vg2.J[n5];
            n7 = vg2.vg_o[n5];
            n8 = vg2.vg_e[n5];
            n9 = (n7 * n14 + (n6 * n13 - -(n8 * n15)) >> -me.y + 16) + n21;
            n10 = (n16 * n8 + (n6 * n12 + n20 * n7) >> 16 + -me.y) + n22;
            n11 = n23 + (n18 * n8 + n17 * n6 + n19 * n7 >> -1758160208);
            if (-51 >= ~n11) {
                kl.kl_n[n5] = n9 / n11 + n3;
                rn.rn_b[n5] = n4 - -(n10 / n11);
                if (n > n11) {
                    n = n11;
                }
                vg.G[n5] = n11;
                if (n11 > n2) {
                    n2 = n11;
                }
            } else {
                vg.G[n5] = Integer.MIN_VALUE;
            }
            if (bl4) {
                dd.dd_a[n5] = n9 >> me.y;
                uk.z[n5] = n10 >> me.y;
                vj.vj_d[n5] = n11;
            }
            ++n5;
        }
        if (null != vg2.vg_q && vg2.K != null && vg2.vg_m != null && vg2.T != null && null != vg2.vg_w && vg2.S != null && vg2.vg_g != null && vg2.vg_v != null && vg2.R != null) {
            n5 = 0;
            while (~n5 > ~vg2.L) {
                n6 = vg2.vg_q[n5];
                n7 = vg2.K[n5];
                n8 = vg2.vg_m[n5];
                ec.ec_f[n5] = n21 - -(n14 * n7 + (n6 * n13 + n8 * n15) >> -10040400);
                fc.fc_d[n5] = n22 - -(n7 * n20 + n6 * n12 + n16 * n8 >> -1882097328);
                jg.jg_h[n5] = n23 - -(n19 * n7 + (n6 * n17 - -(n18 * n8)) >> 244466000);
                n6 = vg2.T[n5];
                n7 = vg2.vg_w[n5];
                n8 = vg2.S[n5];
                kb.kb_a[n5] = (n8 * n15 + n13 * n6 - -(n7 * n14) >> -509058384) + n21;
                cd.cd_b[n5] = n22 + (n20 * n7 + n12 * n6 - -(n16 * n8) >> 1942215600);
                be.be_t[n5] = (n8 * n18 + (n19 * n7 + n17 * n6) >> 394422448) + n23;
                n6 = vg2.vg_g[n5];
                n7 = vg2.vg_v[n5];
                n8 = vg2.R[n5];
                ke.ke_h[n5] = n21 + (n15 * n8 + (n13 * n6 + n7 * n14) >> -1054127888);
                b.M[n5] = n22 - -(n16 * n8 + n12 * n6 + n7 * n20 >> -580391568);
                d.d_d[n5] = n23 - -(n8 * n18 + n19 * n7 + n17 * n6 >> -222955856);
                ++n5;
            }
        }
        if (bl3) {
            int n24;
            n21 = nArray2[3];
            n22 = nArray2[4];
            n23 = nArray2[5];
            n13 = nArray2[6];
            n12 = nArray2[7];
            n17 = nArray2[8];
            n14 = nArray2[9];
            n20 = nArray2[10];
            n19 = nArray2[11];
            n15 = n24 = 0;
            while (n24 < vg2.D && id.M.length > n24) {
                n16 = vg2.vg_k[n24];
                n18 = vg2.vg_u[n24];
                n3 = vg2.O[n24];
                id.M[n24] = n3 * n14 + (n13 * n18 + n16 * n21) >> -1950371088;
                bc.I[n24] = n20 * n3 + n22 * n16 - -(n18 * n12) >> 1478870704;
                sf.C[n24] = n18 * n17 + n23 * n16 - -(n3 * n19) >> 862528240;
                ++n24;
            }
        }
        em.a(vg2, bl2, n2, (byte)103, n);
    }

    @Override
    public final void a(boolean bl, int n, int n2, byte by, ce ce2) {
        block7: {
            int n3;
            boolean bl2 = client.A;
            int n4 = n3 = ce2.ce_q || ce2.a(true) ? 3249872 : 2188450;
            if (by > -60) {
                return;
            }
            this.on_j.a("<u=" + Integer.toString(n3, 16) + ">" + ce2.E + "</u>", ce2.ce_u + n, ce2.D + n2, ce2.ce_t, ce2.y, n3, -1, this.on_b, this.on_f, this.on_j.K + this.on_j.R);
            if (!ce2.a(true)) break block7;
            int n5 = this.on_j.a(ce2.E);
            int n6 = this.on_j.K + this.on_j.R;
            int n7 = ce2.ce_u + n;
            if (2 != this.on_b) {
                if (-2 == ~this.on_b) {
                    n7 += ce2.ce_t + -n5 >> -1342247295;
                }
            } else {
                n7 += -n5 + ce2.ce_t;
            }
            int n8 = n2 + ce2.D;
            if (~this.on_f != -3) {
                if (-2 == ~this.on_f) {
                    n8 += ce2.y - n6 >> -254285407;
                }
            } else {
                n8 += ce2.y + -n6;
            }
            kd.a(4 + n5, -2 + n7, (byte)-96, n8 + 2, n6);
        }
    }

    static final void b(byte by) {
        int n = dl.M * dl.M;
        if (by != -100) {
            return;
        }
        int n2 = n - bl.T * bl.T;
        int n3 = qc.Y - -((ac.B - qc.Y) * n2 / n);
        ea.D.a(640, by + 100, n3, 120, vh.vh_g);
        gi.a(ac.B - 24, j.j_c, 640, nk.nk_b, 0, 5, (byte)-107);
    }

    public on() {
        this.on_j = hh.hh_e;
        this.on_f = 1;
        this.on_b = 1;
    }

    on(mm mm2, int n, int n2) {
        this.on_b = n;
        this.on_j = mm2;
        this.on_f = n2;
    }

    static final pi[] a(int n, byte by, int n2, ji ji2) {
        block1: {
            if (!gb.a(n2, ji2, n, 38)) {
                return null;
            }
            if (by == 37) break block1;
            on.b((byte)98);
        }
        return ci.b(-112);
    }

    public static void a(byte by) {
        on_h = null;
        on_e = null;
        on_i = null;
        if (by != 6) {
            return;
        }
        on_c = null;
        on_a = null;
        on_g = null;
    }

    static final void a(ck[] ckArray, int n) {
        boolean bl2 = client.A;
        if (n != 19264) {
            return;
        }
        if (null != ckArray) {
            int n2 = 0;
            while (~n2 > ~ckArray.length) {
                ckArray[n2].b();
                ++n2;
            }
        }
    }

    static {
        on_h = "<%0> AT ONCE";
        on_g = new int[]{200, 100, 200, 300, 200, 1000, 200, 1000, 300, 500, 500, 100, 100, 200, 500, 200, 300, 1000, 100, 200, 500, 300, 500, 500, 100, 100, 100, 100, 200, 200, 300};
        on_c = "Return to Options Menu";
        on_a = "Special Item Bonus: ";
    }
}
