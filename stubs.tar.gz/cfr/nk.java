/*
 * Decompiled with CFR 0.152.
 */
final class nk {
    static int nk_b;
    static String nk_c;
    static boolean nk_k;
    private int nk_a;
    private int nk_o = 0;
    private be nk_m;
    private be nk_n;
    static int nk_g;
    private be[] nk_e;
    private long nk_h;
    static qm nk_f;
    static int[] nk_j;
    static String[][] nk_d;
    static volatile int nk_l;
    static boolean nk_i;

    public static void a(int n) {
        block0: {
            nk_c = null;
            nk_d = null;
            nk_j = null;
            nk_f = null;
            if (n <= -31) break block0;
            nk.a(null, null, 83, -100, -58, null, null, 7, 17, -108);
        }
    }

    final be b(int n) {
        boolean bl = client.A;
        if (-1 > ~this.nk_o && this.nk_e[-1 + this.nk_o] != this.nk_m) {
            be be2 = this.nk_m;
            this.nk_m = be2.be_p;
            return be2;
        }
        while (~this.nk_o > ~this.nk_a) {
            be be3;
            be be4 = be3 = this.nk_e[this.nk_o++].be_p;
            if (be3 == this.nk_e[this.nk_o + -1]) continue;
            this.nk_m = be4.be_p;
            return be4;
        }
        int n2 = -38 / ((n - -21) / 56);
        return null;
    }

    final be d(int n) {
        boolean bl = client.A;
        if (null == this.nk_n) {
            return null;
        }
        if (n != -17713) {
            return null;
        }
        be be2 = this.nk_e[(int)((long)(this.nk_a - 1) & this.nk_h)];
        while (be2 != this.nk_n) {
            if (this.nk_n.be_r == this.nk_h) {
                be be3 = this.nk_n;
                this.nk_n = this.nk_n.be_p;
                return be3;
            }
            this.nk_n = this.nk_n.be_p;
        }
        this.nk_n = null;
        return null;
    }

    final void a(be be2, int n, long l) {
        block1: {
            be be3;
            if (null != be2.be_v) {
                be2.e((byte)75);
            }
            be2.be_p = be3 = this.nk_e[(int)((long)(this.nk_a - 1) & l)];
            be2.be_v = be3.be_v;
            be2.be_v.be_p = be2;
            be2.be_r = l;
            be2.be_p.be_v = be2;
            if (n == -1) break block1;
            this.b(85);
        }
    }

    final be c(int n) {
        block0: {
            this.nk_o = 0;
            if (n == -9443) break block0;
            nk_i = true;
        }
        return this.b(-81);
    }

    static final void a(w w2, w w3, int n, int n2, int n3, w w4, byte[] byArray, int n4, int n5, int n6) {
        boolean bl = client.A;
        rb.rb_k = byArray;
        uc.uc_g = -1L;
        hg.hg_b = n2;
        j.j_b = byArray.length;
        kk.kk_l = new byte[(hg.hg_b - -7) / 8];
        fj.fj_h = false;
        g.N = null;
        cd.cd_m = null;
        int n7 = n;
        int n8 = 0;
        while (~n8 > ~rb.rb_k.length) {
            n7 += 0xFF & rb.rb_k[n8];
            ++n8;
        }
        n7 = (7 + n7) / 8;
        v.v_a = new byte[n7];
        if (null == w3.M) {
            w3.M = new vj();
        }
        i.i_b = w3.M;
        i.i_b.c(118);
        ob.ob_i = new nk(n3);
        rf.rf_o = -1;
        de.R = -1;
        cj.cj_a = 0;
        ta.ta_b = 0;
        if (null == w2.M) {
            w2.M = new vj();
        }
        h.h_b = w2.M;
        h.h_b.c(n ^ 0x69);
        tg.tg_b = new nk(n6);
        if (w4.M == null) {
            w4.M = new vj();
        }
        oc.oc_b = w4.M;
        oc.oc_b.c(121);
        hn.hn_h = new nk(n5);
        oa.oa_a = n4;
        km.C = 0L;
    }

    static final boolean a(String string, byte by, tf tf2, boolean bl2, int n, String string2, String string3) {
        if (uc.uc_c != sh.sh_d) {
            return false;
        }
        wj wj2 = new wj(ah.ah_c, tf2);
        ah.ah_c.a((byte)-123, (ce)wj2);
        if (dg.b(-40)) {
            wj2.b(true);
        } else {
            ve.Gc = string;
            ea.x = null;
            te.te_q = string3;
            sh.sh_d = pa.V;
            qb.qb_t = string2;
            jk.jk_e = n;
            cf.cf_i = bl2;
        }
        return by > 120;
    }

    nk(int n) {
        this.nk_e = new be[n];
        this.nk_a = n;
        int n2 = 0;
        while (~n < ~n2) {
            be be2;
            this.nk_e[n2] = be2 = new be();
            be2.be_v = be2;
            be2.be_p = be2;
            ++n2;
        }
    }

    final be a(int n, long l) {
        boolean bl2 = client.A;
        this.nk_h = l;
        be be2 = this.nk_e[(int)((long)(-1 + this.nk_a) & l)];
        this.nk_n = be2.be_p;
        while (be2 != this.nk_n) {
            if ((this.nk_n.be_r ^ 0xFFFFFFFFFFFFFFFFL) == (l ^ 0xFFFFFFFFFFFFFFFFL)) {
                be be3 = this.nk_n;
                this.nk_n = this.nk_n.be_p;
                return be3;
            }
            this.nk_n = this.nk_n.be_p;
        }
        if (n != 24710) {
            String string = null;
            nk.a(null, (byte)91, null, false, 64, null, string);
        }
        this.nk_n = null;
        return null;
    }

    static {
        nk_c = "The wildcard special item can be used in place of any other colour.";
        nk_j = new int[8];
        nk_d = new String[][]{{"Earthquake", "Causes stacks of loose pieces to collapse."}, {"Drill", "Individually pops every piece in its path."}, {"Bomb", "When you pop a shape touching a bomb, everything in your bucket of the same colour will explode."}, {"Power Drill", "Pops every entire shape, loose or solid, in its path. Loose shapes take touching solid shapes with them!"}, {"Water Capsule", "Turns every solid shape in your bucket into loose pieces. Can be quite spectacular."}, {"Poison", "Turns all the loose pieces in your bucket into solid shapes. Not good!"}, {"Wildcard", "Can be used in place of any other loose piece."}};
        nk_f = new qm(8, 0, 4, 1);
        nk_l = 0;
        nk_i = false;
    }
}
