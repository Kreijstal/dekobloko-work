/*
 * Decompiled with CFR 0.152.
 */
final class im
implements Runnable {
    static String im_c = "Please wait while we search.<br>Games usually start within a minute, provided the server is busy enough.<br><br>The longer you are forced to wait, the earlier in the list of players you are likely to appear.<br><br>If the game doesn't start, click 'Cancel' and then try choosing 'Don't mind' for more options or switching to a busier lobby.";
    private ab im_e = new ab();
    static boolean im_f;
    static String im_d;
    static ck[] im_i;
    private Thread im_h;
    static String im_g;
    int im_b = 0;
    private boolean im_a = false;
    static String im_j;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final void a(byte by) {
        int n = 53 % ((by - -50) / 38);
        this.im_a = true;
        ab ab2 = this.im_e;
        synchronized (ab2) {
            this.im_e.notifyAll();
        }
        try {
            this.im_h.join();
        }
        catch (InterruptedException interruptedException) {
            // empty catch block
        }
        this.im_h = null;
    }

    public static void a(int n) {
        im_g = null;
        if (n != 0) {
            return;
        }
        im_d = null;
        im_c = null;
        im_i = null;
        im_j = null;
    }

    static final void a(int n, int n2, boolean bl, int n3) {
        ff.a(bl, 10891);
        if (n >= -87) {
            im_j = null;
        }
        gb.a(n3, bl, (byte)-126, n2);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public final void run() {
        boolean bl = client.A;
        while (!this.im_a) {
            el el2;
            ab ab2 = this.im_e;
            synchronized (ab2) {
                el2 = (el)this.im_e.a((byte)79);
                if (el2 == null) {
                    try {
                        this.im_e.wait();
                    }
                    catch (InterruptedException interruptedException) {
                        // empty catch block
                    }
                    continue;
                }
                --this.im_b;
            }
            try {
                if (2 != el2.F) {
                    if (3 == el2.F) {
                        el2.H = el2.K.a((int)el2.be_r, (byte)117);
                    }
                } else {
                    el2.K.a((byte)43, el2.H, (int)el2.be_r, el2.H.length);
                }
            }
            catch (Exception exception) {
                qb.a(exception, 16408, null);
            }
            el2.z = false;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void a(byte by, el el2) {
        ab ab2 = this.im_e;
        synchronized (ab2) {
            int n = 78 % ((by - -34) / 50);
            this.im_e.a(el2, -7267);
            ++this.im_b;
            this.im_e.notifyAll();
        }
    }

    static final void a(int n, String string) {
        block0: {
            System.out.println("Error: " + bh.a(0, string, "\n", "%0a"));
            if (n == 18239) break block0;
            im.a(56, -121, true, -33);
        }
    }

    final el a(int n, kh kh2, byte by) {
        el el2 = new el();
        el2.D = false;
        el2.F = 3;
        if (by != 61) {
            String string = null;
            im.a(109, string);
        }
        el2.K = kh2;
        el2.be_r = n;
        this.a((byte)-115, el2);
        return el2;
    }

    final el a(int n, kh kh2, byte[] byArray, byte by) {
        int n2 = 63 / ((-8 - by) / 56);
        el el2 = new el();
        el2.D = false;
        el2.F = 2;
        el2.be_r = n;
        el2.K = kh2;
        el2.H = byArray;
        this.a((byte)-121, el2);
        return el2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final el a(int n, kh kh2, int n2) {
        boolean bl = client.A;
        el el2 = new el();
        el2.F = 1;
        ab ab2 = this.im_e;
        synchronized (ab2) {
            el el3 = (el)this.im_e.b(-2198);
            while (null != el3) {
                if (el3.be_r == (long)n && kh2 == el3.K && 2 == el3.F) {
                    el2.H = el3.H;
                    el2.z = false;
                    return el2;
                }
                el3 = (el)this.im_e.b((byte)20);
            }
        }
        int n3 = 84 % ((n2 - 77) / 46);
        el2.H = kh2.a(n, (byte)49);
        el2.z = false;
        el2.D = true;
        return el2;
    }

    im(fd fd2) {
        mh mh2 = fd2.a((byte)-104, 5, this);
        while (0 == mh2.mh_c) {
            ua.a(10L, -128);
        }
        if (mh2.mh_c == 2) {
            throw new RuntimeException();
        }
        this.im_h = (Thread)mh2.mh_b;
    }

    static {
        im_j = "From <%0>: ";
        im_g = "Options Menu";
        im_d = "Exploiting a bug";
    }
}
