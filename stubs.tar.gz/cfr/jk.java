/*
 * Decompiled with CFR 0.152.
 */
final class jk {
    static String jk_a;
    static int jk_e;
    private int[] jk_d;
    static String jk_g;
    static int jk_c;
    private int[] jk_f;
    private byte[] jk_b;

    static final void a(int n, boolean bl2) {
        block7: {
            int n2;
            boolean bl3 = client.A;
            if (eh.eh_a <= 0) {
                n2 = !ph.n(-30146) ? 1 : 0;
            } else {
                if (li.li_b != null) {
                    cl.cl_v = li.li_b.c(27134);
                    p.a(2, (byte)-30);
                } else {
                    cl.cl_v = sg.a(640, lf.lf_e, 0, 0, 82, 480);
                }
                if (null != cl.cl_v) {
                    hl.a(cl.cl_v, (byte)-42);
                    n2 = 2;
                } else {
                    n2 = 3;
                }
            }
            if (n != 2) {
                jk_e = -30;
            }
            if (li.li_b != null || !ij.ij_e) break block7;
            bl.a(n + -73, n2, bl2);
        }
    }

    public static void a(byte by) {
        int n = -5 % ((-29 - by) / 55);
        jk_g = null;
        jk_a = null;
    }

    final int a(int n, byte by, int n2, byte[] byArray, byte[] byArray2, int n3) {
        boolean bl2 = client.A;
        if (~n3 == -1) {
            return 0;
        }
        if (by <= 86) {
            jk.a(-83, true);
        }
        n3 += n2;
        int n4 = 0;
        int n5 = n;
        while (true) {
            byte by2;
            n4 = 0 > (by2 = byArray2[n5]) ? this.jk_f[n4] : ++n4;
            int n6 = this.jk_f[n4];
            if (~n6 > -1) {
                byArray[n2++] = (byte)(~n6);
                if (n3 <= n2) break;
                n4 = 0;
            }
            n4 = (by2 & 0x40) == 0 ? ++n4 : this.jk_f[n4];
            n6 = this.jk_f[n4];
            if (~n6 > -1) {
                byArray[n2++] = (byte)(~n6);
                if (n2 >= n3) break;
                n4 = 0;
            }
            n4 = -1 == ~(0x20 & by2) ? ++n4 : this.jk_f[n4];
            n6 = this.jk_f[n4];
            if (-1 < ~n6) {
                byArray[n2++] = (byte)(~n6);
                if (n3 <= n2) break;
                n4 = 0;
            }
            n4 = ~(0x10 & by2) != -1 ? this.jk_f[n4] : ++n4;
            n6 = this.jk_f[n4];
            if (-1 < ~n6) {
                byArray[n2++] = (byte)(~n6);
                if (n3 <= n2) break;
                n4 = 0;
            }
            n4 = 0 == (8 & by2) ? ++n4 : this.jk_f[n4];
            n6 = this.jk_f[n4];
            if (n6 < 0) {
                byArray[n2++] = (byte)(~n6);
                if (~n3 >= ~n2) {
                    return n5 - (-1 - -n);
                }
                n4 = 0;
            }
            n4 = ~(4 & by2) != -1 ? this.jk_f[n4] : ++n4;
            n6 = this.jk_f[n4];
            if (~n6 > -1) {
                byArray[n2++] = (byte)(~n6);
                if (~n3 >= ~n2) break;
                n4 = 0;
            }
            n4 = -1 != ~(2 & by2) ? this.jk_f[n4] : ++n4;
            n6 = this.jk_f[n4];
            if (0 > n6) {
                byArray[n2++] = (byte)(~n6);
                if (~n2 <= ~n3) break;
                n4 = 0;
            }
            n4 = -1 == ~(1 & by2) ? ++n4 : this.jk_f[n4];
            n6 = this.jk_f[n4];
            if (n6 < 0) {
                byArray[n2++] = (byte)(~n6);
                if (~n3 >= ~n2) break;
                n4 = 0;
            }
            ++n5;
        }
        return n5 - (-1 - -n);
    }

    final int a(byte[] byArray, byte[] byArray2, int n, int n2, int n3, int n4) {
        boolean bl2 = client.A;
        if (n4 != 8) {
            jk_c = -58;
        }
        int n5 = 0;
        int n6 = n2 << -1718073853;
        n += n3;
        while (~n < ~n3) {
            int n7 = 0xFF & byArray2[n3];
            int n8 = this.jk_d[n7];
            byte by = this.jk_b[n7];
            if (~by == -1) {
                throw new RuntimeException("" + n7);
            }
            int n9 = n6 >> 1407045219;
            int n10 = n6 & 7;
            n5 &= -n10 >> -1061197921;
            int n11 = n9 - -(n10 + (by + -1) >> 425602563);
            n5 = de.b(n5, n8 >>> (n10 += 24));
            byArray[n9] = (byte)n5;
            if (n11 > n9) {
                n5 = n8 >>> (n10 -= 8);
                byArray[++n9] = (byte)n5;
                if (~n9 > ~n11) {
                    n5 = n8 >>> (n10 -= 8);
                    byArray[++n9] = (byte)n5;
                    if (~n9 > ~n11) {
                        n5 = n8 >>> (n10 -= 8);
                        byArray[++n9] = (byte)n5;
                        if (n11 > n9) {
                            n5 = n8 << -(n10 -= 8);
                            byArray[++n9] = (byte)n5;
                        }
                    }
                }
            }
            n6 += by;
            ++n3;
        }
        return -n2 + (n6 + 7 >> -1057081885);
    }

    jk(byte[] byArray) {
        int n = byArray.length;
        this.jk_b = byArray;
        this.jk_d = new int[n];
        this.jk_f = new int[8];
        int[] nArray = new int[33];
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            byte by = byArray[i];
            if (0 == by) continue;
            int n8 = 1 << -by + 32;
            this.jk_d[i] = n7 = nArray[by];
            if ((n7 & n8) != 0) {
                n6 = nArray[by - 1];
            } else {
                n6 = n7 | n8;
                n5 = -1 + by;
                while (~n5 <= -2 && ~n7 == ~(n4 = nArray[n5])) {
                    n3 = 1 << 32 + -n5;
                    if ((n3 & n4) != 0) {
                        nArray[n5] = nArray[n5 - 1];
                        break;
                    }
                    nArray[n5] = de.b(n4, n3);
                    --n5;
                }
            }
            nArray[by] = n6;
            n5 = by + 1;
            while (~n5 >= -33) {
                if (n7 == nArray[n5]) {
                    nArray[n5] = n6;
                }
                ++n5;
            }
            n5 = 0;
            n4 = 0;
            while (~by < ~n4) {
                n3 = Integer.MIN_VALUE >>> n4;
                if (-1 != ~(n3 & n7)) {
                    if (~this.jk_f[n5] == -1) {
                        this.jk_f[n5] = n2;
                    }
                    n5 = this.jk_f[n5];
                } else {
                    ++n5;
                }
                n3 >>>= 1;
                if (~this.jk_f.length >= ~n5) {
                    int[] nArray2 = new int[2 * this.jk_f.length];
                    int n9 = 0;
                    while (~n9 > ~this.jk_f.length) {
                        nArray2[n9] = this.jk_f[n9];
                        ++n9;
                    }
                    this.jk_f = nArray2;
                }
                ++n4;
            }
            if (~n5 <= ~n2) {
                n2 = 1 + n5;
            }
            this.jk_f[n5] = ~i;
        }
    }

    static {
        jk_g = "Names can only contain letters, numbers, spaces and underscores";
    }
}
