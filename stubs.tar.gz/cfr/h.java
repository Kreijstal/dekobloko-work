/*
 * Decompiled with CFR 0.152.
 */
final class h {
    static String h_e;
    static String h_a;
    static String h_c;
    static String h_g;
    static vj h_b;
    static String h_f;
    static ke h_d;

    static final void a(int n) {
        block1: {
            int n2 = -63 % ((n - -6) / 38);
            if (-141 >= ~(++kk.kk_n)) {
                kk.kk_n = 0;
            }
            cb.b((byte)71);
            if (0 != kk.kk_n % 20) break block1;
            cg.a(true);
        }
    }

    static final void a(byte by) {
        if (by != 11) {
            return;
        }
        wg.wg_i = ik.a(4);
        af.af_d = 0;
    }

    static final void a(int n, boolean bl) {
        fl.a(130, 256, 16694016, bj.bj_c, n + 82, w.w_kb);
        int n2 = 1 == kd.kd_p ? 140 : 145;
        fb.fb_c[0][1].c(82 + n, n2, 18, 18);
        n2 += (-2 != ~kd.kd_p ? 16 : 8) + 16 * ga.a(198, 0, n2, rf.rf_i, 16, 64, 0xFFFFFF, se.S, (byte)-125, 0, 110 - -n);
        fb.fb_c[0][2].c(n + 108, n2, 18, 18);
        fb.fb_c[0][2].c(n + 108, n2 + 18, 18, 18);
        fb.fb_c[0][2].c(108 - -n, n2 - -36, 18, 18);
        fb.fb_c[0][2].c(n + 126, 36 + n2, 18, 18);
        ma.K.c(156 - -n, 10 + n2);
        cg.a(0, 2, 6, 230 + n, 36 + n2, 3, -2);
        cg.a(0, 2, 12, n + 230, n2 - -18, 3, -1);
        cg.a(0, 2, 8, n + 230, n2, 3, -1);
        cg.a(0, 2, 1, n + 248, n2 + 36, 2, -2);
        fb.fb_c[3][1].c(82 + n, n2 += 54 - -(kd.kd_p == 1 ? 8 : 16), 18, 18);
        n2 += ga.a(140, 0, n2, rk.N, 16, 64, 0xFFFFFF, se.S, (byte)-127, 0, 110 - -n) * 16;
        wa.a(gi.gi_c, nf.nf_e, n2 - (90 + (-2 != ~kd.kd_p ? 0 : 16)), n + 242, -1, 0, kk.kk_n);
        hk.g(309 - -n, 117, 242, 263172);
        hk.g(n + 310, 117, 242, 0x606060);
        fl.a(130, 256, 16694016, kc.kc_q, 322 + n, w.w_kb);
        ga.a(120, 0, 145, di.D, 16, 64, 0xFFFFFF, se.S, (byte)-127, 0, n + 320);
        aj.aj_c.c(455 + n, 123);
        if (bl) {
            return;
        }
        fl.a(240, 256, 16694016, fm.fm_c, 322 - -n, w.w_kb);
        ga.a(120, 0, 255, ah.ah_g, 16, 64, 0xFFFFFF, se.S, (byte)-127, 0, 320 + n);
        li.li_i.c(465 + n, 235);
    }

    static final int a(int n, byte by) {
        block0: {
            if (by == -122) break block0;
            h_f = null;
        }
        return qg.qg_f[n & 0x7FF];
    }

    public static void b(byte by) {
        h_a = null;
        h_b = null;
        h_g = null;
        h_c = null;
        h_f = null;
        if (by > -127) {
            return;
        }
        h_e = null;
        h_d = null;
    }

    static final boolean a(boolean bl2) {
        if (bl2) {
            return true;
        }
        return ph.n(-30146) || eh.eh_a <= 0;
    }

    static final void a(ke ke2, byte by) {
        block22: {
            if (ab.e(-28199) != 0) {
                ke2 = null;
            }
            if (kf.G != ke2 && ~kf.G.ke_o < -1) {
                --kf.G.ke_o;
            }
            if (pd.pd_d != null && ke2 != pd.pd_d && 0 < pd.pd_d.ke_o) {
                --pd.pd_d.ke_o;
            }
            if (h_d != null && h_d != ke2 && 0 < h.h_d.ke_o) {
                --h.h_d.ke_o;
            }
            if (null != cl.B && cl.B != ke2 && cl.B.ke_o > 0) {
                --cl.B.ke_o;
            }
            if (null != am.am_a && ke2 != am.am_a && -1 > ~am.am_a.ke_o) {
                --am.am_a.ke_o;
            }
            if (ca.ca_wb != null && ke2 != ca.ca_wb && -1 > ~ca.ca_wb.ke_o) {
                --ca.ca_wb.ke_o;
            }
            if (null != f.f_s && ke2 != f.f_s && ~f.f_s.ke_o < -1) {
                --f.f_s.ke_o;
            }
            if (hh.hh_a == ue.ue_b && null != ke2 && 20 > ke2.ke_o) {
                ke2.ke_c += 16;
                ++ke2.ke_o;
            }
            if (null != pd.pd_d && !ba.ba_c && ~pd.pd_d.ke_o == -1) {
                pd.pd_d = null;
            }
            if (am.am_a != null && !fm.fm_e && ~am.am_a.ke_o == -1) {
                am.am_a = null;
            }
            if (null != cl.B && !mg.Zb && -1 == ~cl.B.ke_o) {
                cl.B = null;
            }
            if (null != h_d && !lk.F && h.h_d.ke_o == 0) {
                h_d = null;
            }
            if (null != ca.ca_wb && !ve.Hc && ~ca.ca_wb.ke_o == -1) {
                ca.ca_wb = null;
            }
            if (f.f_s != null && !nk.nk_k && -1 == ~f.f_s.ke_o) {
                f.f_s = null;
            }
            if (null != kf.G) {
                kf.G.k((byte)111);
            }
            if (pd.pd_d != null) {
                pd.pd_d.k((byte)118);
            }
            if (by != 95) {
                return;
            }
            if (null != h_d) {
                h_d.k((byte)122);
            }
            if (cl.B != null) {
                cl.B.k((byte)127);
            }
            if (null != am.am_a) {
                am.am_a.k((byte)122);
            }
            if (null != ca.ca_wb) {
                ca.ca_wb.k((byte)108);
            }
            if (f.f_s == null) break block22;
            f.f_s.k((byte)122);
        }
    }

    static final int a(int n2, int n3) {
        int n4 = 77 / ((n3 - -6) / 41);
        n2 = ((n2 & 0xAAAAAAAA) >>> -984139903) + (n2 & 0x55555555);
        n2 = (n2 & 0x33333333) + ((0xCCCCCCCC & n2) >>> -1525474366);
        n2 = 0xF0F0F0F & n2 + (n2 >>> 1797532260);
        n2 += n2 >>> -2062994456;
        n2 += n2 >>> -601060496;
        return n2 & 0xFF;
    }

    static {
        h_a = "Please send me news and updates (I can unsubscribe at any time)";
        h_g = "Enter name of friend to add to list";
        h_e = "Waiting for <%0> to start the game...";
        h_f = "Yes";
    }
}
