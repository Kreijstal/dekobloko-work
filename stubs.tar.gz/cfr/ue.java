/*
 * Decompiled with CFR 0.152.
 */
final class ue {
    static ck ue_b;
    static String ue_d;
    static String ue_a;
    static String ue_c;

    static final boolean a(int n, String string) {
        if (null == jk.jk_a) {
            return false;
        }
        if (n != 2048) {
            String string2 = null;
            ue.a(-5, string2);
        }
        return -1 >= ~string.toLowerCase().indexOf(jk.jk_a.toLowerCase());
    }

    public static void a(byte by) {
        ue_b = null;
        ue_a = null;
        ue_d = null;
        if (by >= -4) {
            ue.a(-36, 12);
        }
        ue_c = null;
    }

    static final int a(int n, int n2) {
        int n3 = -44 % ((n2 - -3) / 44);
        if (~(n &= 0x1FFF) > -4097) {
            return 2048 <= n ? -pd.pd_i[-2048 + n] : pd.pd_i[-n + 2048];
        }
        return n >= 6144 ? pd.pd_i[-6144 + n] : -pd.pd_i[-n + 6144];
    }

    static {
        ue_d = "Solicitation";
        ue_c = "Tips";
        ue_a = "Report abuse";
    }
}
