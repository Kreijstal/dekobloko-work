/*
 * Decompiled with CFR 0.152.
 */
final class cg {
    static int cg_a;
    static vj cg_c;
    static float cg_d;
    static String cg_b;

    static final void a(int n, w w2, int n2) {
        String string;
        ck ck2;
        pf pf2;
        sl.a(null, null, (byte)90, null, w2, null, 0L, n2, -1);
        if (0 == n2) {
            pf2 = w.H;
            ck2 = ef.O[0];
            string = nh.nh_f;
            pf2.pf_h.a(4193, 11, ck2, string);
            pf2 = w.H;
            ck2 = ef.O[1];
            string = dj.dj_bb;
            pf2.pf_h.a(4193, 12, ck2, string);
            pf2 = w.H;
            ck2 = ef.O[2];
            string = gf.gf_h;
            pf2.pf_h.a(n ^ 0x1060, 13, ck2, string);
        }
        if (n == n2) {
            pf2 = w.H;
            ck2 = ef.O[0];
            string = dj.dj_db;
            pf2.pf_h.a(4193, 11, ck2, string);
            pf2 = w.H;
            ck2 = ef.O[1];
            string = rf.rf_h;
            pf2.pf_h.a(n ^ 0x1060, 12, ck2, string);
            pf2 = w.H;
            ck2 = ef.O[2];
            string = dk.dk_d;
            pf2.pf_h.a(4193, 13, ck2, string);
        }
        if (~n2 == -3) {
            pf2 = w.H;
            ck2 = ef.O[0];
            string = client.y;
            pf2.pf_h.a(4193, 11, ck2, string);
            pf2 = w.H;
            ck2 = ef.O[1];
            string = om.om_e;
            pf2.pf_h.a(n ^ 0x1060, 12, ck2, string);
            pf2 = w.H;
            ck2 = ef.O[2];
            string = ci.ci_g;
            pf2.pf_h.a(4193, 13, ck2, string);
        }
        pf2 = w.H;
        int n3 = w2.E;
        int n4 = w2.w_pb;
        int n5 = w2.w_mb;
        int n6 = w2.N;
        pf2.pf_h.b(n4, n3, 43, n6, n5);
    }

    public static void a(int n) {
        cg_c = null;
        if (n <= 123) {
            cg_d = 0.37232396f;
        }
        cg_b = null;
    }

    static final void a(boolean bl) {
        wg.wg_d = 8;
        nf.nf_e = 0;
        gi.gi_c = 0;
        if (!bl) {
            cg_a = 78;
        }
        bf.bf_o = 8;
    }

    static final void b(boolean bl, int n) {
        block2: {
            if (-1 > ~lg.W && ve.Qb) {
                hk.d(0, 0, hk.hk_j, ea.D.w_pb);
                tc.Ob.a(n ^ 0x4402E2A3, bl);
            }
            if ((~bf.bf_r < -1 || -1 > ~tg.tg_e) && dn.dn_k) {
                hk.d(0, 0, hk.hk_j, ea.D.w_pb);
                mn.mn_e.a(1141039778, bl);
            }
            if (n == 1) break block2;
            cg_d = 1.5652884f;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int[] nArray = ob.ob_j[n][n2][n3].D;
        byte[] byArray = gf.gf_f[n3].pi_k;
        int[] nArray2 = ad.ad_d.D;
        int n8 = 0;
        int n9 = 0;
        for (int i = 0; i < 18; ++i) {
            for (int j = 0; j < 18; ++j) {
                int n10 = 0;
                if (byArray[n8] != 0) {
                    n10 = nArray[n8];
                }
                nArray2[n9++] = n10;
                n8 += 2;
            }
            n8 += 36;
        }
        ad.ad_d.e(n4 + n6, n5 + n7, 128);
        ad.ad_d.c(n4, n5);
    }

    static final ck[] a(byte by, ck[] ckArray) {
        boolean bl = client.A;
        if (by < 112) {
            w w2 = null;
            cg.a(-46, w2, 53);
        }
        int n = 0;
        while (~ckArray.length < ~n) {
            ck ck2 = ckArray[n];
            ckArray[n].z = 0;
            ck2.F = 0;
            ckArray[n].K = ckArray[n].I;
            ckArray[n].C = ckArray[n].H;
            ++n;
        }
        return ckArray;
    }

    static final void a(ck ck2, pi pi2, int n, int n2, int n3, int n4, int n5, int n6, boolean bl, boolean bl2, int n7, int n8) {
        int n9;
        int n10 = ck2.K;
        int n11 = ck2.C;
        int n12 = n2 - n;
        int n13 = n;
        if (n13 < hk.hk_c) {
            n13 = hk.hk_c;
        }
        if ((n9 = n2) > hk.hk_g) {
            n9 = hk.hk_g;
        }
        for (int i = n13; i < n9; ++i) {
            int n14;
            int n15 = (n10 * (i - n) + (n12 >> 1)) / n12;
            if (n15 >= n10) {
                n15 = n10 - 1;
            }
            int n16 = (n15 + n7) % n10;
            if (n8 >= 0) {
                n15 = n8;
            }
            int n17 = n3 * n12 + (n4 - n3) * (i - n) + (n4 - n3 >> 1);
            int n18 = n5 * n12 + (n6 - n5) * (i - n) + (n6 - n5 >> 1);
            int n19 = n18 - n17;
            int n20 = vl.a(23841, n12, n17 + (n12 >> 1));
            if (n20 < hk.hk_h) {
                n20 = hk.hk_h;
            }
            if ((n14 = vl.a(23841, n12, n18 + (n12 >> 1))) > hk.hk_b) {
                n14 = hk.hk_b;
            }
            if (n14 <= n20) continue;
            int n21 = n11 * (n20 * n12 - n17) + (n19 >> 1);
            int n22 = n11 * ((n14 - 1) * n12 - n17) + (n19 >> 1);
            if (n21 <= -n19) {
                n21 = -n19 + 1;
            }
            if (n21 >= n11 * n19) {
                n21 = n11 * n19 - 1;
            }
            if (n22 >= n11 * n19) {
                n22 = n11 * n19 - 1;
            }
            int n23 = 0;
            if (n22 > n21) {
                n23 = (n22 - n21) / (n14 - n20 - 1);
            }
            int n24 = n20 * hk.hk_j + i;
            for (int j = n20; j < n14; ++j) {
                int n25 = n21 / n19;
                int n26 = n25 * n10;
                int n27 = ck2.D[n26 + n16];
                if (n27 != 0 && (pi2 == null || pi2.pi_k[n26 + n15] != 0)) {
                    if (bl) {
                        n27 = n27 >> 1 & 0x7F7F7F;
                    }
                    if (bl2) {
                        n27 += hk.hk_l[n24] >> 1 & 0x7F7F7F;
                    }
                    hk.hk_l[n24] = n27;
                }
                n24 += hk.hk_j;
                n21 += n23;
            }
        }
    }

    static final void a(boolean bl2, int n) {
        if (n < 89) {
            cg_d = 0.6883823f;
        }
        ah.ah_c.a(0, 0, (byte)-72);
    }

    static final ck a(int n, int n2, int n3) {
        ck ck2 = new ck(36, 36);
        int[] nArray = ob.ob_j[n][n2][n3].D;
        byte[] byArray = gf.gf_f[n3].pi_k;
        int[] nArray2 = ck2.D;
        int n4 = 0;
        int n5 = 0;
        for (int i = 0; i < 36; ++i) {
            for (int j = 0; j < 36; ++j) {
                int n6 = 0;
                if (byArray[n4] != 0) {
                    n6 = nArray[n4];
                }
                nArray2[n5++] = n6;
                ++n4;
            }
        }
        return ck2;
    }

    static final Class a(String string, byte by) throws ClassNotFoundException {
        if (string.equals("B")) {
            return Byte.TYPE;
        }
        if (string.equals("I")) {
            return Integer.TYPE;
        }
        if (string.equals("S")) {
            return Short.TYPE;
        }
        if (string.equals("J")) {
            return Long.TYPE;
        }
        if (string.equals("Z")) {
            return Boolean.TYPE;
        }
        if (string.equals("F")) {
            return Float.TYPE;
        }
        if (string.equals("D")) {
            return Double.TYPE;
        }
        if (string.equals("C")) {
            return Character.TYPE;
        }
        int n = 85 / ((-49 - by) / 43);
        return Class.forName(string);
    }

    static final void a(int n, byte by, int n2) {
        uf uf2 = we.we_b;
        if (by != -9) {
            cg_c = null;
        }
        uf2.f(n2, -4);
        uf2.a(true, 3);
        uf2.a(true, 8);
        uf2.d(-1, n);
    }

    static {
        cg_c = new vj();
        cg_b = " Press 'ESC' to accept.";
    }
}
