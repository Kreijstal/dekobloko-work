/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;

final class hl {
    int hl_n;
    int hl_k;
    static int[] hl_e = new int[4];
    int hl_l;
    String hl_o;
    static int hl_d;
    int hl_m;
    w hl_f;
    boolean hl_j;
    int hl_i;
    static String hl_b;
    int[] hl_q;
    static String hl_c;
    String hl_h;
    static String hl_a;
    String hl_p;
    String hl_g;
    long hl_r;

    final int b(byte by) {
        if (this.hl_j || 2 == this.hl_m && -1 > ~this.hl_l) {
            return 2;
        }
        if ((uc.uc_g ^ 0xFFFFFFFFFFFFFFFFL) == (this.hl_r ^ 0xFFFFFFFFFFFFFFFFL)) {
            return 1;
        }
        if (2 == jj.jj_b && qe.a(this.hl_o, 3)) {
            return 1;
        }
        if (by != 94) {
            this.hl_p = null;
        }
        return 0;
    }

    static final boolean a(byte by) {
        if (by != -53) {
            return false;
        }
        return sg.a(cf.cf_c, 113, fm.fm_d);
    }

    static final void a(Canvas canvas, byte by) {
        block1: {
            db.a(canvas, false);
            if (by >= -29) {
                Canvas canvas2 = null;
                hl.a(canvas2, (byte)-79);
            }
            al.a(-2204, canvas);
            if (uc.uc_e == null) break block1;
            uc.uc_e.a(canvas, -63);
        }
    }

    public static void a(int n) {
        hl_c = null;
        if (n != -21128) {
            hl.a(-128);
        }
        hl_e = null;
        hl_a = null;
        hl_b = null;
    }

    hl(boolean bl) {
        this.hl_i = vl.vl_k;
        this.hl_r = fc.fc_h;
        this.hl_g = qm.qm_e;
        this.hl_p = ad.x;
        this.hl_n = ic.ic_a;
        this.hl_l = tg.tg_c;
        this.hl_q = (int[])(!bl ? null : fa.fa_q);
        this.hl_m = mf.R;
        this.hl_j = fm.fm_f;
        this.hl_k = dh.dh_d;
        this.hl_h = ib.ib_pb;
        this.hl_o = sa.B;
    }

    hl(int n, String string, int n2, String string2, String string3) {
        this.hl_i = 0;
        this.hl_n = 0;
        this.hl_m = n;
        this.hl_g = string2;
        this.hl_l = 0;
        this.hl_k = n2;
        this.hl_q = null;
        this.hl_r = 0L;
        this.hl_o = string;
        this.hl_h = string3;
        this.hl_j = true;
        this.hl_p = string;
    }

    static {
        hl_b = "Decline invitation to <%0>'s game";
        hl_c = "Who can join";
        hl_a = null;
    }
}
