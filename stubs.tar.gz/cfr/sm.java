/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

final class sm {
    static int sm_d;
    private ji sm_f;
    private la sm_a;
    private ji sm_b;
    static a sm_c;
    static int sm_e;

    static final int a(jg jg2, jg jg3, int n) {
        int n2 = -118 / ((-48 - n) / 32);
        return qb.a(false, 0, jg2, 100, 0, jg3, null);
    }

    static final ck a(byte by, int n, int n2) {
        ck ck2;
        boolean bl = client.A;
        ck ck3 = ck2 = new ck(n, n);
        int n3 = 0;
        if (by >= -96) {
            sm_e = 97;
        }
        while (ck3.D.length > n3) {
            ck2.D[n3] = n2;
            ++n3;
        }
        return ck3;
    }

    public static void a(int n) {
        if (n != 30553) {
            sm_e = 92;
        }
        sm_c = null;
    }

    static final void a(byte by, Applet applet) {
        if (by != -65) {
            return;
        }
        try {
            URL uRL = new URL(applet.getCodeBase(), "subscribe.ws");
            applet.getAppletContext().showDocument(gn.a(uRL, -1, applet), "_top");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    static final int a(byte by) {
        block0: {
            if (by <= -63) break block0;
            sm_e = 90;
        }
        return jk.jk_e;
    }

    static final boolean b(int n) {
        if (n != 1) {
            return false;
        }
        return cf.cf_i;
    }

    sm(int n, ji ji2, ji ji3, lh lh2) {
        block1: {
            this.sm_a = new la(64);
            this.sm_f = ji2;
            this.sm_b = ji3;
            if (null != this.sm_f) {
                this.sm_f.b(-5228, 1);
            }
            if (null == this.sm_b) break block1;
            this.sm_b.b(-5228, 1);
        }
    }

    final me a(int n, int n2) {
        me me2;
        block3: {
            me2 = (me)this.sm_a.a((long)n2, (byte)-63);
            if (me2 != null) {
                return me2;
            }
            byte[] byArray = -32769 < ~n2 ? this.sm_f.a(n2, 88, 1) : this.sm_b.a(Short.MAX_VALUE & n2, -112, 1);
            me2 = new me();
            if (null != byArray) {
                me2.me_a_wl((byte)80, new wl(byArray));
            }
            if (32768 <= n2) {
                me2.d(19423);
            }
            this.sm_a.a(me2, n2, 125);
            if (n >= 123) break block3;
            sm.a((byte)69);
        }
        return me2;
    }
}
