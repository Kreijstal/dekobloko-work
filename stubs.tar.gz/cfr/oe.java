/*
 * Decompiled with CFR 0.152.
 */
import java.util.Hashtable;

abstract class oe
extends ce
implements ra {
    ce[] K;
    static vj I;
    static String[] M;
    static boolean[] L;
    static int[] J;
    static int H;
    static int G;

    @Override
    final int d(int n) {
        boolean bl = client.A;
        int n2 = 0;
        ce[] ceArray = this.K;
        int n3 = 22 % ((36 - n) / 51);
        for (int i = 0; i < ceArray.length; ++i) {
            int n4;
            ce ce2 = ceArray[i];
            if (ce2 == null || ~n2 <= ~(n4 = ce2.d(-30))) continue;
            n2 = n4;
        }
        return n2;
    }

    oe(int n, int n2, int n3, int n4, gl gl2) {
        super(n, n2, n3, n4, gl2, null);
    }

    @Override
    final boolean a(boolean bl, ce ce2) {
        boolean bl2 = client.A;
        ce[] ceArray = this.K;
        ce[] ceArray2 = this.K;
        int n = 0;
        while (~ceArray.length < ~n) {
            ce ce3 = ceArray[n];
            if (null != ce3 && ce3.a(false, ce2)) {
                return true;
            }
            ++n;
        }
        if (bl) {
            this.K = null;
        }
        return false;
    }

    private final boolean a(ce ce2, int n, int n2) {
        boolean bl = client.A;
        if (null == this.K) {
            return false;
        }
        int n3 = this.K.length - 1;
        while (~n3 <= -1) {
            ce ce3 = this.K[n3];
            if (ce3 != null && ce3.a(true)) {
                n3 -= n;
                while (~n3 <= -1) {
                    ce ce4 = this.K[n3];
                    if (null != ce4 && ce4.a(false, ce2)) {
                        return true;
                    }
                    n3 -= n;
                }
            }
            --n3;
        }
        if (n2 != 0) {
            oe.a(-94, -2, 108, 7, 101, 46, -99);
        }
        return false;
    }

    @Override
    void a(ce ce2, int n, int n2, int n3) {
        boolean bl = client.A;
        super.a(ce2, 102, n2, n3);
        if (this.K == null) {
            return;
        }
        if (n <= 38) {
            return;
        }
        ce[] ceArray = this.K;
        ce[] ceArray2 = this.K;
        int n4 = 0;
        while (~ceArray.length < ~n4) {
            ce ce3 = ceArray[n4];
            if (ce3 != null) {
                ce3.a(ce2, 109, n2 + this.D, this.ce_u + n3);
            }
            ++n4;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        boolean bl = client.A;
        if (n == 0) {
            n = 1;
        }
        int n8 = 0;
        int n9 = 65536 / n;
        if (n4 != -1) {
            H = -1;
        }
        if (n7 < hk.hk_h) {
            n8 += n9 * (hk.hk_h - n7);
            n2 -= hk.hk_h + -n7;
            n7 = hk.hk_h;
        }
        if (hk.hk_c > n6) {
            n -= hk.hk_c - n6;
            n6 = hk.hk_c;
        }
        if (hk.hk_b < n2 + n7) {
            n2 = hk.hk_b + -n7;
        }
        if (hk.hk_g < n6 - -n) {
            n = hk.hk_g - n6;
        }
        int n10 = n6 + hk.hk_j * (n7 - -n2);
        for (int i = -n; 0 > i; ++i) {
            int n11 = -n8 + 65536 >> 1531409928;
            int n12 = n8 >> -1962121400;
            int n13 = (n11 * (n5 & 0xFF00FF) - -(n12 * (n3 & 0xFF00FF)) & 0xFF00FF00) - -(0xFF0000 & n12 * (0xFF00 & n3) + (0xFF00 & n5) * n11) >>> 1249901160;
            for (int j = -n2; 0 > j; ++j) {
                hk.hk_l[hk.hk_j * j + n10] = n13;
            }
            ++n10;
            n8 += n9;
        }
    }

    public static void b(boolean bl) {
        M = null;
        I = null;
        L = null;
        if (!bl) {
            return;
        }
        J = null;
    }

    @Override
    final void a(int n, int n2, int n3, ce ce2, int n4, int n5) {
        boolean bl = client.A;
        if (null == this.K) {
            return;
        }
        ce[] ceArray = this.K;
        ce[] ceArray2 = this.K;
        if (n2 != 64) {
            ce ce3 = null;
            this.a(ce3, -80, 51, 84);
        }
        int n6 = 0;
        while (~ceArray.length < ~n6) {
            ce ce4 = ceArray[n6];
            if (null != ce4) {
                ce4.a(n, n2 + 0, this.ce_u + n3, ce2, n4 + this.D, n5);
            }
            ++n6;
        }
    }

    private final void a(StringBuilder stringBuilder, int n, int n2, Hashtable hashtable) {
        block4: {
            boolean bl = client.A;
            if (null == this.K) {
                return;
            }
            ce[] ceArray = this.K;
            ce[] ceArray2 = this.K;
            for (int i = 0; ceArray.length > i; ++i) {
                ce ce2 = ceArray[i];
                stringBuilder.append('\n');
                for (int j = 0; j <= n; ++j) {
                    stringBuilder.append(' ');
                }
                if (ce2 == null) {
                    stringBuilder.append("null");
                    continue;
                }
                ce2.a(hashtable, n - -1, stringBuilder, true);
            }
            if (n2 == 3370) break block4;
            ce ce3 = null;
            this.a(85, -91, ce3, '\uffec');
        }
    }

    @Override
    final boolean a(boolean bl) {
        if (!bl) {
            return true;
        }
        return null != this.a(-98);
    }

    static final jc a(byte by, String string) {
        boolean bl = client.A;
        int n = string.length();
        if (by <= 64) {
            oe.c(true);
        }
        for (int i = 0; i < n; ++i) {
            char c = string.charAt(i);
            if (c < '0') {
                return null;
            }
            if ('9' >= c) continue;
            return null;
        }
        return be.x;
    }

    @Override
    final void d(byte by) {
        block2: {
            boolean bl = client.A;
            ce[] ceArray = this.K;
            ce[] ceArray2 = this.K;
            int n = 0;
            while (~n > ~ceArray.length) {
                ce ce2 = ceArray[n];
                if (ce2 != null) {
                    ce2.d((byte)-95);
                }
                ++n;
            }
            if (by == -95) break block2;
            oe.a('\uffa4', -111);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static final void c(boolean bl) {
        int n2;
        uf uf2;
        block22: {
            block23: {
                block21: {
                    wb wb2;
                    block17: {
                        String string;
                        String string2;
                        String string3;
                        block20: {
                            String string4;
                            block19: {
                                block18: {
                                    boolean bl2 = client.A;
                                    if (bl) {
                                        return;
                                    }
                                    uf2 = de.V;
                                    wb2 = null;
                                    n2 = uf2.d((byte)-25);
                                    if (-1 != ~n2) break block17;
                                    if (null == hg.hg_e) {
                                        hg.hg_e = new nk(128);
                                        ed.ed_g = 0;
                                    }
                                    boolean bl3 = ~uf2.d((byte)-111) == -2;
                                    string3 = uf2.c((byte)-38);
                                    string2 = bl3 ? uf2.c((byte)-38) : string3;
                                    wb2 = g.a(-3805, string3);
                                    string = uf2.c((byte)-38);
                                    string4 = kf.a(string3, (byte)2);
                                    if (null == string4) {
                                        string4 = string3;
                                    }
                                    if (null == wb2) break block18;
                                    if (wb2 == null) break block19;
                                    break block20;
                                }
                                wb2 = g.a(-3805, string);
                                if (null != wb2) {
                                    hg.hg_e.a(wb2, -1, string4.hashCode());
                                }
                                if (wb2 != null) break block20;
                            }
                            wb2 = new wb();
                            hg.hg_e.a(wb2, -1, string4.hashCode());
                            wb2.Xb = ed.ed_g++;
                            uf.z.a(wb2, 2777);
                        }
                        wb2.Pb = string2;
                        wb2.Ob = string3;
                        wb2.Tb = string;
                        return;
                    }
                    if (1 == n2) {
                        wb wb3;
                        if (mc.mc_a == null) {
                            mc.mc_a = new nk(128);
                            md.Z = 0;
                        }
                        String string = uf2.c((byte)-38);
                        if (string.equals("")) {
                            string = null;
                        }
                        String string5 = uf2.c((byte)-38);
                        String string6 = uf2.c((byte)-38);
                        wb2 = ed.a(string5, (byte)-109);
                        if (null == wb2 && null != (wb2 = ed.a(string6, (byte)71))) {
                            mc.mc_a.a(wb2, -1, kf.a(string5, (byte)2).hashCode());
                        }
                        if (wb2 == null) {
                            wb2 = new wb();
                            mc.mc_a.a(wb2, -1, kf.a(string5, (byte)2).hashCode());
                            wb2.Xb = md.Z++;
                            qi.S.a(wb2, 2777);
                        }
                        if (string != null) {
                            string = string.intern();
                        }
                        wb2.Vb = string;
                        wb2.Ob = string5;
                        wb2.Tb = string6;
                        wb2.b((byte)125);
                        wb wb4 = wb3 = (wb)qi.S.c((byte)18);
                        while (wb3 != null && pn.a(wb3, wb2, false)) {
                            wb4 = (wb)qi.S.d(true);
                        }
                        if (null != wb4) {
                            fm.a((byte)121, wb2, wb4);
                            return;
                        }
                        qi.S.a(wb2, 2777);
                        return;
                    }
                    if (2 == n2) break block21;
                    if (~n2 != -4) break block22;
                    break block23;
                }
                if (1 != jj.jj_b) {
                    return;
                }
                jj.jj_b = 2;
                return;
            }
            if (~jj.jj_b != -3) return;
            jj.jj_b = 1;
            return;
        }
        if (4 == n2) {
            jj.jj_b = 1;
            String string = uf2.c((byte)-38);
            f.f_w = string.intern();
            int n3 = uf2.d((byte)-125);
            nh.a((byte)12, n3);
            return;
        }
        qb.a(null, 16408, "F1: " + qk.d((byte)17));
        si.a(100);
    }

    @Override
    void a(int n2, int n3, int n4, int n5) {
        block4: {
            boolean bl = client.A;
            if (0 == n4 && null != this.ce_p) {
                this.ce_p.a(true, n2, n5, (byte)-62, this);
            }
            if (null != this.K) {
                int n6 = -1 + this.K.length;
                while (-1 >= ~n6) {
                    ce ce2 = this.K[n6];
                    if (ce2 != null) {
                        ce2.a(this.ce_u + n2, -109, n4, n5 - -this.D);
                    }
                    --n6;
                }
            }
            if (n3 < -103) break block4;
            this.b(36, 0, -79, -102, 25);
        }
    }

    @Override
    final boolean a(int n2, int n3, ce ce2, int n4, int n5, int n6, byte by) {
        boolean bl = client.A;
        if (this.K == null) {
            return false;
        }
        ce[] ceArray = this.K;
        ce[] ceArray2 = this.K;
        int n7 = 0;
        while (~n7 > ~ceArray.length) {
            ce ce3 = ceArray[n7];
            if (ce3 != null && ce3.a(n2, n3, ce2, n4, n5 - -this.D, this.ce_u + n6, (byte)-55)) {
                return true;
            }
            ++n7;
        }
        if (by != -55) {
            H = -1;
        }
        return false;
    }

    private final boolean b(ce ce2, int n2, int n3) {
        boolean bl = client.A;
        if (null == this.K) {
            return false;
        }
        if (n3 >= -127) {
            M = null;
        }
        for (int i = 0; i < this.K.length; ++i) {
            ce ce3 = this.K[i];
            if (ce3 == null || !ce3.a(true)) continue;
            i += n2;
            while (~i > ~this.K.length) {
                ce ce4 = this.K[i];
                if (null != ce4 && ce4.a(false, ce2)) {
                    return true;
                }
                i += n2;
            }
        }
        return false;
    }

    @Override
    final StringBuilder a(Hashtable hashtable, int n2, StringBuilder stringBuilder, boolean bl) {
        if (this.a(0, n2, hashtable, stringBuilder)) {
            this.a((byte)72, stringBuilder, hashtable, n2);
            this.a(stringBuilder, n2, 3370, hashtable);
        }
        if (!bl) {
            return null;
        }
        return stringBuilder;
    }

    private final boolean b(ce ce2, int n2) {
        block0: {
            if (n2 == 0) break block0;
            this.K = null;
        }
        return this.b(ce2, 1, n2 ^ 0xFFFFFF80);
    }

    private final ce a(int n2) {
        boolean bl = client.A;
        if (this.K == null) {
            return null;
        }
        int n3 = 36 % ((n2 - 6) / 63);
        ce[] ceArray = this.K;
        ce[] ceArray2 = this.K;
        int n4 = 0;
        while (n4 < ceArray.length) {
            ce ce2 = ceArray[n4];
            if (null != ce2 && ce2.a(true)) {
                return ce2;
            }
            ++n4;
        }
        return null;
    }

    static final int b(int n2, int n3) {
        --n3;
        n3 |= n3 >>> -1810527583;
        n3 |= n3 >>> -1027453694;
        if (n2 != -10498) {
            oe.a('\uff8f', -43);
        }
        n3 |= n3 >>> 499290852;
        n3 |= n3 >>> -972289368;
        n3 |= n3 >>> -1371497776;
        return n3 + 1;
    }

    static final boolean a(char c, int n2) {
        int n3;
        char c2;
        int n4;
        boolean bl = client.A;
        if (Character.isISOControl(c)) {
            return false;
        }
        if (j.a(-8241, c)) {
            return true;
        }
        char[] cArray = sc.sc_o;
        char[] cArray2 = sc.sc_o;
        if (n2 != -6237) {
            oe.a(35, -84, -82, 125, 125, -43, -29);
        }
        for (n4 = 0; cArray.length > n4; ++n4) {
            c2 = cArray[n4];
            if (c != c2) continue;
            return true;
        }
        char[] cArray3 = oh.oh_f;
        cArray2 = oh.oh_f;
        n4 = n3 = 0;
        while (~cArray3.length < ~n3) {
            c2 = cArray3[n3];
            if (c == c2) {
                return true;
            }
            ++n3;
        }
        return false;
    }

    @Override
    final boolean a(int n2, int n3, ce ce2, char c) {
        boolean bl = client.A;
        if (this.K == null) {
            return false;
        }
        int n4 = -117 % ((n2 - -22) / 49);
        ce[] ceArray = this.K;
        int n5 = 0;
        while (~ceArray.length < ~n5) {
            ce ce3 = ceArray[n5];
            if (null != ce3 && ce3.a(true) && ce3.a(98, n3, ce2, c)) {
                return true;
            }
            ++n5;
        }
        n4 = n3;
        if (~n4 != -81) {
            return false;
        }
        return bj.bj_d[81] ? this.a(ce2, 113) : this.b(ce2, 0);
    }

    @Override
    final String c(byte by) {
        boolean bl = client.A;
        if (this.K == null) {
            return null;
        }
        ce[] ceArray = this.K;
        ce[] ceArray2 = this.K;
        for (int i = 0; i < ceArray.length; ++i) {
            String string;
            ce ce2 = ceArray[i];
            if (null == ce2 || (string = ce2.c((byte)113)) == null) continue;
            return string;
        }
        if (by == 113) {
            return null;
        }
        this.K = null;
        return null;
    }

    @Override
    final boolean a(int n2, int n3, int n4, ce ce2, int n5, int n6, boolean bl) {
        boolean bl2 = client.A;
        if (this.K == null) {
            return false;
        }
        if (bl) {
            G = -21;
        }
        ce[] ceArray = this.K;
        ce[] ceArray2 = this.K;
        for (int i = 0; ceArray.length > i; ++i) {
            ce ce3 = ceArray[i];
            if (ce3 == null || !ce3.a(!bl) || !ce3.a(n2, n3, n4, ce2, n5, n6, false)) continue;
            return true;
        }
        return false;
    }

    private final boolean a(ce ce2, int n2) {
        if (n2 <= 33) {
            return true;
        }
        return this.a(ce2, 1, 0);
    }

    abstract void g(int var1);

    @Override
    final void b(int n2, int n3, int n4, int n5, int n6) {
        super.b(n2, n3, n4, n5, -16555);
        if (n6 != -16555) {
            oe.b(71, 20);
        }
        this.g(30);
    }

    static {
        M = new String[]{"Showing by rating", "Showing by win percentage"};
        I = new vj();
        J = new int[8];
    }
}
