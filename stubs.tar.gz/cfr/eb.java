/*
 * Decompiled with CFR 0.152.
 */
final class eb {
    int eb_e;
    String[] eb_q;
    static ji eb_k;
    int eb_l;
    lk[] eb_p;
    int eb_o;
    int eb_i;
    boolean eb_j;
    static String eb_n;
    int[] eb_f;
    int eb_a;
    int eb_d;
    static String eb_g;
    int eb_h;
    static String eb_r;
    int eb_m;
    static String eb_c;
    int eb_b;

    final int d(int n) {
        if (n != 6) {
            this.eb_p = null;
        }
        int n2 = 2;
        if (3 <= this.eb_m) {
            n2 = 4;
        }
        if (~this.eb_m <= -5) {
            n2 = 6;
        }
        return ka.a((byte)81, n2, tf.tf_cb) + 24;
    }

    public static void b(int n) {
        eb_g = null;
        eb_n = null;
        if (n != 92) {
            eb_n = null;
        }
        eb_r = null;
        eb_c = null;
        eb_k = null;
    }

    static final void c(int n) {
        be.be_w[93] = 43;
        be.be_w[59] = 57;
        be.be_w[45] = 26;
        be.be_w[46] = 72;
        be.be_w[61] = 27;
        be.be_w[92] = 74;
        int n2 = 118 % ((n - 62) / 56);
        be.be_w[520] = 59;
        be.be_w[192] = 28;
        be.be_w[222] = 58;
        be.be_w[47] = 73;
        be.be_w[91] = 42;
        be.be_w[44] = 71;
    }

    final void a(int n, byte by) {
        boolean bl2 = client.A;
        if (by > -49) {
            this.eb_h = 43;
        }
        this.eb_e = n;
        this.eb_j = true;
        int n2 = 0;
        while (~n2 > ~this.eb_b) {
            lk lk2 = this.eb_p[n2];
            if (lk2 != null) {
                lk2.k(-9897);
            }
            ++n2;
        }
    }

    static final void a(int n) {
        block0: {
            j.a(8225);
            if (n == 58) break block0;
            eb.b(-112);
        }
    }

    eb(int n, boolean bl2, int n2, int n3, int n4, int n5, String[] stringArray) {
        this.eb_l = n;
        this.eb_m = n5;
        this.eb_b = null != stringArray ? stringArray.length : 1;
        this.eb_f = new int[this.eb_b];
        this.eb_o = 0;
        this.eb_q = stringArray;
        this.eb_p = new lk[this.eb_b];
        for (int i = 0; this.eb_b > i; ++i) {
            this.eb_p[i] = new lk(bl2, n2, n3, n4, this.eb_m);
            this.eb_p[i].Q = i;
            this.eb_f[i] = -1;
        }
        this.eb_i = this.eb_b;
    }

    static {
        eb_g = "You need to play <%0> more rated games to unlock this option.";
        eb_r = "Quick Chat game";
        eb_c = "SPEED UP!";
    }
}
