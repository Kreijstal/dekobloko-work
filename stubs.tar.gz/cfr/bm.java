/*
 * Decompiled with CFR 0.152.
 */
final class bm {
    private int bm_e;
    private int[] bm_g;
    private int bm_d;
    private int bm_f;
    private int bm_a;
    private int bm_c = va.c(16);
    private int bm_b = va.c(24);

    final void a(float[] fArray, int n, boolean bl) {
        int n2;
        for (n2 = 0; n2 < n; ++n2) {
            fArray[n2] = 0.0f;
        }
        if (bl) {
            return;
        }
        n2 = va.S[this.bm_a].ja_d;
        int n3 = this.bm_f - this.bm_b;
        int n4 = n3 / this.bm_d;
        int[] nArray = new int[n4];
        for (int i = 0; i < 8; ++i) {
            int n5 = 0;
            block2: while (n5 < n4) {
                int n6;
                int n7;
                if (i == 0) {
                    n7 = va.S[this.bm_a].a();
                    for (n6 = n2 - 1; n6 >= 0; --n6) {
                        if (n5 + n6 < n4) {
                            nArray[n5 + n6] = n7 % this.bm_e;
                        }
                        n7 /= this.bm_e;
                    }
                }
                for (n7 = 0; n7 < n2; ++n7) {
                    n6 = nArray[n5];
                    int n8 = this.bm_g[n6 * 8 + i];
                    if (n8 >= 0) {
                        int n9;
                        int n10 = this.bm_b + n5 * this.bm_d;
                        ja ja2 = va.S[n8];
                        if (this.bm_c == 0) {
                            n9 = this.bm_d / ja2.ja_d;
                            for (int j = 0; j < n9; ++j) {
                                float[] fArray2 = ja2.b();
                                for (int k = 0; k < ja2.ja_d; ++k) {
                                    int n11 = n10 + j + k * n9;
                                    fArray[n11] = fArray[n11] + fArray2[k];
                                }
                            }
                        } else {
                            n9 = 0;
                            while (n9 < this.bm_d) {
                                float[] fArray3 = ja2.b();
                                for (int j = 0; j < ja2.ja_d; ++j) {
                                    int n12 = n10 + n9;
                                    fArray[n12] = fArray[n12] + fArray3[j];
                                    ++n9;
                                }
                            }
                        }
                    }
                    if (++n5 >= n4) continue block2;
                }
            }
        }
    }

    bm() {
        int n;
        int n2;
        this.bm_f = va.c(24);
        this.bm_d = va.c(24) + 1;
        this.bm_e = va.c(6) + 1;
        this.bm_a = va.c(8);
        int[] nArray = new int[this.bm_e];
        for (n2 = 0; n2 < this.bm_e; ++n2) {
            boolean bl;
            int n3 = 0;
            int n4 = va.c(3);
            boolean bl2 = bl = va.b() != 0;
            if (bl) {
                n3 = va.c(5);
            }
            nArray[n2] = n3 << 3 | n4;
        }
        this.bm_g = new int[this.bm_e * 8];
        n2 = n = 0;
        while (n < this.bm_e * 8) {
            this.bm_g[n] = (nArray[n >> 3] & 1 << (n & 7)) != 0 ? va.c(8) : -1;
            ++n;
        }
    }
}
