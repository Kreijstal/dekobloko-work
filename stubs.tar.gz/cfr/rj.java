/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBufferInt;
import java.awt.image.DirectColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.util.Hashtable;

final class rj
extends eh {
    private Component rj_k;

    @Override
    final void a(int n, byte by, int n2, Component component) {
        if (by != 83) {
            Graphics graphics = null;
            this.a((byte)-42, graphics, -83, -93);
        }
        this.eh_g = n;
        this.eh_i = n2;
        this.eh_f = new int[n2 * n + 1];
        DataBufferInt dataBufferInt = new DataBufferInt(this.eh_f, this.eh_f.length);
        DirectColorModel directColorModel = new DirectColorModel(32, 0xFF0000, 65280, 255);
        WritableRaster writableRaster = Raster.createWritableRaster(((ColorModel)directColorModel).createCompatibleSampleModel(this.eh_g, this.eh_i), dataBufferInt, null);
        this.eh_c = new BufferedImage(directColorModel, writableRaster, false, new Hashtable());
        this.rj_k = component;
        this.a((byte)-97);
    }

    @Override
    final void a(byte by, Graphics graphics, int n, int n2) {
        block0: {
            graphics.drawImage(this.eh_c, n, n2, this.rj_k);
            if (by > 38) break block0;
            Graphics graphics2 = null;
            this.a((byte)-30, graphics2, -118, 16);
        }
    }
}
