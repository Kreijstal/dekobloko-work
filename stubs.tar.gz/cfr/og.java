/*
 * Decompiled with CFR 0.152.
 */
final class og
extends rk
implements jl {
    static boolean og_ib;
    static String og_gb;
    static int og_eb;
    private nb og_fb;
    static String og_hb;
    private int og_db;

    @Override
    final String c(byte by) {
        block2: {
            if (!this.ce_q) {
                return null;
            }
            if (this.B == null) {
                return null;
            }
            kl.a(11024, bh.bh_g - (this.og_db + -this.ce_t), pm.pm_f);
            if (by == 113) break block2;
            og_gb = null;
        }
        return this.B;
    }

    @Override
    final void l(int n) {
        block0: {
            super.l(n);
            if (this.og_fb == null) break block0;
            this.og_fb.c((byte)-51);
        }
    }

    og(String string, kg kg2, int n) {
        super(string, kg2, n);
    }

    @Override
    public final nb a(int n) {
        block0: {
            if (n <= -86) break block0;
            og_gb = null;
        }
        return this.og_fb;
    }

    final void a(nb nb2, int n) {
        if (n != -5362) {
            return;
        }
        this.og_fb = nb2;
    }

    static final void a(boolean bl, int n, boolean bl2) {
        im.im_f = bl;
        if (!bl2) {
            og.a(false, -59, false);
        }
        gb.Ob = ve.ve_nc;
        fe.fe_b = n;
    }

    public static void i(byte by) {
        og_gb = null;
        if (by <= 106) {
            og_gb = null;
        }
        og_hb = null;
    }

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        super.a(ce2, 50, n2, n3);
        if (n < 38) {
            return;
        }
        this.og_db = bh.bh_g - this.ce_u + -n3;
    }

    static {
        og_gb = "Close";
        og_ib = true;
        og_hb = "Next";
    }
}
