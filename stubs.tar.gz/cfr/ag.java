/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

final class ag
extends hm
implements MouseWheelListener {
    private int ag_f = 0;

    @Override
    final void a(int n, Component component) {
        if (n <= 10) {
            this.ag_f = 89;
        }
        component.removeMouseWheelListener(this);
    }

    @Override
    public final synchronized void mouseWheelMoved(MouseWheelEvent mouseWheelEvent) {
        this.ag_f += mouseWheelEvent.getWheelRotation();
        mouseWheelEvent.consume();
    }

    @Override
    final void a(Component component, int n) {
        block0: {
            component.addMouseWheelListener(this);
            if (n == -63) break block0;
            Component component2 = null;
            this.a(component2, 100);
        }
    }

    ag() {
    }

    @Override
    final synchronized int a(int n) {
        int n2 = this.ag_f;
        if (n != 60) {
            this.ag_f = 41;
        }
        this.ag_f = 0;
        return n2;
    }
}
