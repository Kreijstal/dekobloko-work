/*
 * Decompiled with CFR 0.152.
 */
final class je {
    static int je_c;
    static ak je_f;
    static cd je_b;
    private int je_d;
    private int je_e;
    private int[][] je_a;

    static final qm a(int n, int n2) {
        qm[] qmArray;
        boolean bl = client.A;
        int n3 = -128 / ((n - -53) / 58);
        qm[] qmArray2 = qmArray = vj.e(-23521);
        int n4 = 0;
        while (n4 < qmArray.length) {
            if (qmArray[n4].qm_d == n2) {
                return qmArray[n4];
            }
            ++n4;
        }
        return null;
    }

    final byte[] a(int n, byte[] byArray) {
        block4: {
            boolean bl = client.A;
            if (null != this.je_a) {
                int n2;
                int n3;
                int n4;
                int n5 = (int)((long)this.je_e * (long)byArray.length / (long)this.je_d) + 14;
                int[] nArray = new int[n5];
                int n6 = 0;
                int n7 = 0;
                for (n4 = 0; n4 < byArray.length; ++n4) {
                    int n8;
                    n3 = byArray[n4];
                    int[] nArray2 = this.je_a[n7];
                    for (n8 = 0; 14 > n8; ++n8) {
                        int n9 = n8 + n6;
                        nArray[n9] = nArray[n9] + n3 * nArray2[n8];
                    }
                    n8 = (n7 += this.je_e) / this.je_d;
                    n6 += n8;
                    n7 -= n8 * this.je_d;
                }
                byArray = new byte[n5];
                n4 = n2 = 0;
                while (n2 < n5) {
                    n3 = nArray[n2] - Short.MIN_VALUE >> -1922369712;
                    byArray[n2] = n3 < -128 ? (byte)-128 : (-128 <= ~n3 ? (byte)n3 : (byte)127);
                    ++n2;
                }
            }
            if (n == 14) break block4;
            je_f = null;
        }
        return byArray;
    }

    static final cd a(int n) {
        if (sh.sh_d == uc.uc_c) {
            throw new IllegalStateException();
        }
        if (kl.z == sh.sh_d) {
            sh.sh_d = uc.uc_c;
            return ea.x;
        }
        if (n == 13) {
            return null;
        }
        je.a(-1);
        return null;
    }

    final int b(int n, int n2) {
        if (n2 < 17) {
            this.je_e = 12;
        }
        if (this.je_a != null) {
            n = 6 - -((int)((long)this.je_e * (long)n / (long)this.je_d));
        }
        return n;
    }

    static final String a(String string, int n2, byte by) {
        if (1 == n2) {
            return cm.a((byte)121, wk.wk_g, new String[]{string});
        }
        if (2 == n2) {
            return cm.a((byte)121, hf.hf_c, new String[]{string});
        }
        if (by != -128) {
            String string2 = null;
            je.a(string2, 71, (byte)-56);
        }
        if (3 == n2) {
            return cm.a((byte)83, bg.bg_a, new String[]{string});
        }
        if (-5 == ~n2) {
            return cm.a((byte)106, aj.aj_b, new String[]{string});
        }
        if (n2 == 5) {
            return cm.a((byte)96, ln.ln_b, new String[]{string});
        }
        if (n2 == 6) {
            return cm.a((byte)121, bj.bj_b, new String[]{string});
        }
        if (n2 == 7) {
            return cm.a((byte)123, f.x, new String[]{string});
        }
        if (-9 == ~n2) {
            return cm.a((byte)83, gf.gf_d, new String[]{string});
        }
        if (-12 == ~n2) {
            return cm.a((byte)123, em.em_b, new String[]{string});
        }
        if (n2 == 12) {
            return cm.a((byte)100, md.S, new String[]{string});
        }
        if (13 != n2) {
            return null;
        }
        return cm.a((byte)127, sh.sh_b, new String[]{string});
    }

    public static void b(int n2) {
        block0: {
            je_f = null;
            je_b = null;
            if (n2 == 23369) break block0;
            je_b = null;
        }
    }

    final int a(boolean bl, int n2) {
        if (bl) {
            return -86;
        }
        if (this.je_a != null) {
            n2 = (int)((long)this.je_e * (long)n2 / (long)this.je_d);
        }
        return n2;
    }

    je(int n2, int n3) {
        if (n3 == n2) {
            return;
        }
        int n4 = n.a(43, n2, n3);
        this.je_d = n2 /= n4;
        this.je_e = n3 /= n4;
        this.je_a = new int[n2][14];
        int n5 = 0;
        while (~n5 > ~n2) {
            int n6;
            int[] nArray = this.je_a[n5];
            double d = (double)n5 / (double)n2 + 6.0;
            int n7 = (int)Math.floor(-7.0 + d + 1.0);
            if (0 > n7) {
                n7 = 0;
            }
            if ((n6 = (int)Math.ceil(d + 7.0)) > 14) {
                n6 = 14;
            }
            double d2 = (double)n3 / (double)n2;
            while (n6 > n7) {
                double d3 = Math.PI * ((double)n7 - d);
                double d4 = d2;
                if (-1.0E-4 > d3 || d3 > 1.0E-4) {
                    d4 *= Math.sin(d3) / d3;
                }
                nArray[n7] = (int)Math.floor(0.5 + (d4 *= Math.cos(((double)n7 - d) * 0.2243994752564138) * 0.46 + 0.54) * 65536.0);
                ++n7;
            }
            ++n5;
        }
    }
}
