/*
 * Decompiled with CFR 0.152.
 */
abstract class lc {
    static String[][] lc_e;
    int lc_a;
    int lc_g;
    static volatile int lc_f;
    int lc_b;
    int lc_i;
    int lc_d;
    static long lc_j;
    int lc_c;
    static ji lc_h;

    abstract void a(int var1, int var2);

    static final rf b(int n, int n2, int n3) {
        rf rf2 = new rf(n);
        rf2.rf_c = new byte[2];
        rf2.rf_b = 2;
        rf2.rf_n = 1;
        rf2.rf_c[n2] = (byte)((lb.a(8, n3) != 0 ? 24 : 16) + lb.a(n3, 7));
        rf2.rf_c[1] = (byte)(lb.a(7, n3 >>= 4) + (-1 == ~lb.a(8, n3) ? 16 : 24));
        return rf2;
    }

    static final void a(int n, boolean bl) {
        if (!bl) {
            return;
        }
        ef.U = sg.sg_j[n];
        fe.fe_a = mn.mn_d[n];
        eb.eb_n = qc.C[n];
    }

    abstract void a(int var1, int var2, int var3);

    public static void a(int n) {
        block0: {
            lc_h = null;
            lc_e = null;
            if (n == -27983) break block0;
            lc.a(40, false);
        }
    }

    lc() {
    }

    static {
        lc_f = -1;
    }
}
