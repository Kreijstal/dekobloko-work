/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;

final class jf {
    static String jf_f = "Your game";
    static lf jf_g;
    static int jf_c;
    static String jf_b;
    static String jf_a;
    static long jf_d;
    static w jf_e;

    static final void a(Canvas canvas, boolean bl, int n) {
        block7: {
            boolean bl2 = client.A;
            if (ca.ca_vb < 10) {
                boolean bl3 = false;
                if (cd.cd_g) {
                    bl3 = true;
                    cd.cd_g = false;
                }
                bf.a(cn.b(true), bl3, 6, cf.a(-11777), fb.fb_g);
            } else if (dl.a(480)) {
                if (hc.hc_d == 0) {
                    uc.a(false, bl, 78);
                    mf.a(1, 0, 0, canvas);
                } else {
                    cn.a(true, canvas);
                }
            } else {
                hk.b();
                qc.a(240, 320, n ^ 0xFFFFAA1E);
                mf.a(1, 0, 0, canvas);
            }
            if (n == -6351) break block7;
            jf.a(-78);
        }
    }

    public static void a(int n) {
        jf_e = null;
        jf_f = null;
        int n2 = -128 % ((n - -47) / 61);
        jf_b = null;
        jf_g = null;
        jf_a = null;
    }

    static {
        jf_a = "Invite more players, or alternatively try changing the following settings:  ";
        jf_b = "<%0> might change the options - wait and see.";
        jf_c = 0;
        jf_g = new lf();
    }
}
