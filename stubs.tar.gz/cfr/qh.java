/*
 * Decompiled with CFR 0.152.
 */
interface qh
extends kg {
    public void a(int var1, rk var2);

    public void b(int var1, rk var2);
}
