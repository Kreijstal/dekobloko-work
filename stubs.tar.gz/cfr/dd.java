/*
 * Decompiled with CFR 0.152.
 */
abstract class dd {
    ab dd_d = new ab();
    static w dd_k;
    ab dd_g = new ab();
    static String dd_m;
    static int[] dd_a;
    ab dd_n = new ab();
    ab dd_l = new ab();
    wl dd_i = new wl(6);
    int dd_b;
    long dd_e;
    volatile int dd_o = 0;
    volatile int dd_j = 0;
    wl dd_c = new wl(10);
    byte dd_f = 0;
    pj dd_h;

    static final String b(String string, int n, int n2) {
        if (!dc.a(string, (byte)-70)) {
            return ge.ge_d;
        }
        if (k.a(string, true)) {
            return si.si_i;
        }
        if (-3 != ~jj.jj_b) {
            return qe.qe_h;
        }
        if (ik.a(string, (byte)-118)) {
            return cm.a((byte)114, ph.Bb, new String[]{string});
        }
        if (~ed.ed_g <= -101) {
            return ca.ca_ob;
        }
        if (qe.a(string, 3)) {
            return cm.a((byte)116, nn.nn_b, new String[]{string});
        }
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        ++uf2.wl_n;
        int n3 = -88 % ((n - 84) / 41);
        int n4 = uf2.wl_n;
        uf2.a(true, 2);
        uf2.a(0, string);
        uf2.b(uf2.wl_n + -n4, true);
        return null;
    }

    abstract void a(Object var1, byte var2, boolean var3);

    final int c(byte by) {
        block0: {
            if (by < -73) break block0;
            dd_a = null;
        }
        return this.dd_d.a(0) + this.dd_g.a(0);
    }

    static final void a(String string, int n, int n2) {
        block7: {
            tj.Vb = false;
            mg.Nb = false;
            if (cl.cl_r != null && cl.cl_r.S) {
                boolean bl2 = true;
                if (~n2 == -9) {
                    n2 = 2;
                    string = !vb.Z ? di.A : wa.wa_b;
                    dm.dm_c.a(hb.Ob, 30534);
                }
                if (n2 == 10) {
                    bl2 = false;
                    si.d(-31842);
                }
                if (bl2) {
                    if (tj.Vb) {
                        string = cm.a((byte)103, cm.cm_d, new String[]{string});
                    }
                    if (dc.dc_d) {
                        string = rg.rg_d;
                    }
                    cl.cl_r.a((byte)48, string, n2);
                }
                if (-257 != ~n2 && n2 != 10 && !vb.Z) {
                    dm.dm_c.a(51);
                }
            }
            if (n == 0) break block7;
            String string2 = null;
            dd.b(string2, 52, 86);
        }
    }

    abstract void d(byte var1);

    final boolean b(int n) {
        if (n != 0) {
            this.dd_j = -70;
        }
        return -21 >= ~this.c(0);
    }

    final pj a(boolean bl2, byte by, boolean bl3, int n, int n2) {
        long l = ((long)n << 440232928) - -((long)n2);
        if (!bl3) {
            return null;
        }
        pj pj2 = new pj();
        pj2.be_r = l;
        pj2.D = bl2;
        pj2.M = by;
        if (bl2) {
            if (~this.c((byte)-109) <= -21) {
                throw new RuntimeException();
            }
            this.dd_d.a(pj2, -7267);
        } else {
            if (20 <= this.c(0)) {
                throw new RuntimeException();
            }
            this.dd_n.a(pj2, -7267);
        }
        return pj2;
    }

    abstract boolean a(byte var1);

    final int c(int n) {
        block0: {
            if (n == 0) break block0;
            this.dd_h = null;
        }
        return this.dd_n.a(0) + this.dd_l.a(0);
    }

    static final void a(boolean bl2, boolean bl3, byte by) {
        if (by != 66) {
            dd_k = null;
        }
        rb.a(bl2, (byte)-85, null, bl3);
    }

    public static void b(byte by) {
        dd_k = null;
        dd_m = null;
        dd_a = null;
        int n = -6 % ((-1 - by) / 47);
    }

    final boolean a(boolean bl2) {
        if (!bl2) {
            this.dd_i = null;
        }
        return this.c((byte)-95) >= 20;
    }

    abstract void a(int var1);

    dd() {
    }

    static {
        dd_m = "Email address is unavailable";
        dd_a = new int[8192];
    }
}
