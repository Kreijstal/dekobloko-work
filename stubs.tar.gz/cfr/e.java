/*
 * Decompiled with CFR 0.152.
 */
final class e {
    static String e_c;
    static String e_a;
    static String e_d;
    static ck e_b;

    public static void a(int n) {
        e_a = null;
        if (n != -22811) {
            e.b(91);
        }
        e_c = null;
        e_b = null;
        e_d = null;
    }

    static final void b(int n) {
        block0: {
            lj.lj_a = null;
            wf.wf_s = null;
            if (n == -8621) break block0;
            e_c = null;
        }
    }

    static final nj a(ji ji2, int n, int n2, byte by, ji ji3) {
        if (!gb.a(n, ji3, n2, 102)) {
            return null;
        }
        if (by != -75) {
            return null;
        }
        return on.a(ji2.a(n2, 75, n), (byte)25);
    }

    static {
        e_d = "<%0> CHAIN";
        e_c = "Password is valid";
        e_a = "Cancel draw";
    }
}
