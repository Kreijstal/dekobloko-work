/*
 * Decompiled with CFR 0.152.
 */
final class lk {
    int lk_g;
    rf[] X = new rf[1];
    int[] P;
    int zb;
    private int lk_o;
    String lk_vb = null;
    private int lk_wb = 18;
    sa W;
    private int M;
    int lk_gb;
    private boolean lk_r = false;
    private int lk_p;
    int lk_k = 128;
    private int Cb;
    static String lk_i;
    private int E;
    private int[] T;
    private int Ab;
    int lk_j = 0;
    private int[] lk_b;
    int lk_eb;
    boolean Bb = false;
    static int I;
    int Q = -1;
    private int[] N;
    int K = 0;
    int O;
    int lk_q;
    int lk_n;
    int lk_lb = 128;
    private int lk_mb;
    private int V;
    private boolean Y = false;
    int U = -1;
    int lk_sb = 48;
    private int lk_e;
    int lk_f = 0;
    int lk_t;
    int x = 0;
    int[] lk_w;
    int lk_ib = 0;
    private int G = 0;
    private int lk_db;
    int xb;
    int lk_c;
    boolean S = false;
    int R = 0;
    int z;
    vj lk_cb;
    int J = 128;
    int lk_hb = 0;
    private int[] lk_tb;
    private boolean y;
    int lk_m;
    int lk_d;
    int lk_qb;
    private int lk_ob;
    boolean lk_kb;
    int lk_jb = 3;
    private int lk_l = 0;
    int L;
    int D;
    ee lk_u = null;
    static boolean F;
    int Z;
    private boolean lk_v = false;
    private int lk_ab;
    private int[] B;
    private boolean lk_s = false;
    int lk_fb;
    vj lk_rb;
    int yb;
    int lk_ub = 0;
    int lk_a;
    private int lk_h;
    int lk_nb;
    private int A;
    int H = 0;
    int lk_bb = 0;
    int C;
    int lk_pb = 0;

    final int f(int n) {
        boolean bl = client.A;
        int n2 = -1;
        int n3 = this.C * this.zb;
        if (n > -36) {
            this.k(5);
        }
        for (int i = 0; i < n3; ++i) {
            int n4 = this.T[i];
            if (-25 != ~(n4 & 0x18) || ~(n4 &= 7) >= ~n2) continue;
            n2 = n4;
        }
        return n2;
    }

    private final boolean q(int n) {
        int n2;
        int n3;
        boolean bl = client.A;
        int[] nArray = this.B;
        int[] nArray2 = this.B;
        if (null == nArray || nArray.length < this.C * this.zb) {
            this.B = nArray2 = new int[this.C * this.zb];
        }
        int n4 = 0;
        if (n != 21200) {
            this.lk_vb = null;
        }
        int n5 = 0;
        while (~n5 > ~this.zb) {
            n3 = -n5 + (-1 + this.zb);
            n2 = 0;
            while (~this.C < ~n2) {
                this.B[n3] = this.T[n4++];
                n3 += this.zb;
                ++n2;
            }
            ++n5;
        }
        n5 = this.lk_db + -this.zb + this.C - -this.lk_o >> 2027132385;
        n3 = this.lk_o + (this.zb + (-this.C - this.lk_db)) >> 1485015713;
        this.lk_q += n5;
        n4 = this.C;
        this.L += n3;
        this.C = this.zb;
        this.B = this.T;
        this.zb = n4;
        this.T = nArray2;
        if (!this.c((byte)-117)) {
            ++this.lk_ab;
            n4 = this.lk_db;
            this.lk_db = -this.lk_o;
            this.lk_o = n4;
            this.d(30968);
            n4 = 0;
            this.h(-1);
            n2 = 0;
            while (~n2 > ~this.zb) {
                int n6 = 0;
                while (~n6 > ~this.C) {
                    this.lk_tb[n4] = 0;
                    this.lk_b[n4] = (-1 + (this.C + this.lk_db - n6 * 2)) * -8 / this.C;
                    ++n4;
                    ++n6;
                }
                ++n2;
            }
            ge.a(this.lk_lb, this.lk_k / 4, (byte)127, ib.ib_ob);
            return true;
        }
        this.T = this.B;
        this.B = nArray2;
        this.zb = this.C;
        this.L -= n3;
        this.C = n4;
        this.lk_q -= n5;
        return false;
    }

    private final void a(int n, boolean bl, int n2) {
        block13: {
            int n3;
            int n4;
            int n5;
            block12: {
                boolean bl2 = client.A;
                if (n > -88) {
                    return;
                }
                n5 = 0;
                n4 = 0;
                n3 = 0;
                while (~(this.lk_a * this.O) < ~n3) {
                    int n6 = this.P[n3];
                    if (~(0x70000000 & n6) != -1) {
                        if (8 == (n6 & 0x18)) {
                            ++n4;
                        }
                        if (16 == (n6 & 0x18)) {
                            ++n5;
                        }
                        int n7 = (0x70000000 & n6) / 0x10000000;
                        if (8 == (n6 & 0x18) && ~n7 < ~mk.mk_e) {
                            mk.mk_e = n7;
                        }
                        this.lk_ib = n2;
                        if (-24 == ~(0x8FFFFFFF & n6) && n7 > fk.H) {
                            fk.H = n7;
                        }
                        this.P[n3] = !bl ? de.b(32, lb.a(n6, 0xFFFFFFF)) : 56;
                    } else {
                        this.P[n3] = lb.a(Integer.MAX_VALUE, n6);
                    }
                    ++n3;
                }
                if (bl) break block12;
                if (-1 > ~n5) {
                    n3 = ((int)((double)this.lk_k * Math.sqrt(n5)) - -1) / 2;
                    if (this.lk_k < n3) {
                        n3 = this.lk_k;
                    }
                    ge.a(this.lk_lb, n3, (byte)127, wd.wd_c);
                }
                if (0 >= n4) break block13;
                n3 = (2 + (int)((double)this.lk_k * Math.sqrt(n4))) / 4;
                if (~n3 < ~this.lk_k) {
                    n3 = this.lk_k;
                }
                ge.a(this.lk_lb, n3, (byte)127, sa.sa_w);
                break block13;
            }
            n3 = ((int)((double)this.lk_k * Math.sqrt(n5 + (16 - -n4))) + 8) / 16;
            if (this.lk_k < n3) {
                n3 = this.lk_k;
            }
            ge.a(this.lk_lb, n3, (byte)127, ee.ee_g);
        }
    }

    private final int l(int n) {
        int n2 = 95 % ((n - 43) / 54);
        return 80 + this.lk_g * this.lk_a;
    }

    final int a(int n, int n2, int n3) {
        int n4 = 0;
        if (n >= 0 && -1 >= ~n3 && ~n > ~this.O && this.lk_a > n3) {
            n4 = this.P[n + this.O * n3];
        }
        int n5 = 101 / ((n2 - 24) / 52);
        if (this.C != 0 && !this.S) {
            int n6;
            int n7 = -this.lk_q + n;
            int n8 = -this.L + n3;
            if (~n7 <= -1 && -1 >= ~n8 && this.C > n7 && this.zb > n8 && ~(n6 = this.T[n8 * this.C + n7]) != -1) {
                n4 = n6;
            }
        }
        return n4;
    }

    static final void a(int n, boolean bl, int n2, int n3, int n4, int n5, boolean bl2, int n6, boolean bl3, boolean bl4, boolean bl5, boolean bl6) {
        block0: {
            th.a(0xFFFFFF, n2, bl2, n6, bl5, bl6, bl, 0xFFFFFF, n, n4, n3, (byte)103, n5, bl3);
            if (bl4) break block0;
            lk.g(-50);
        }
    }

    private final void h(int n) {
        block3: {
            if (n != -1) {
                return;
            }
            if (!this.y) break block3;
            if (!this.a((byte)-93, true)) {
                this.y = false;
                this.c(30000, this.lk_g, 1);
            } else {
                this.lk_e = 20;
            }
        }
    }

    private final int a(boolean bl, int n, int n2, lk lk2, boolean bl2, int n3, int n4, int n5, oi oi2, boolean bl3, byte by) {
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        block29: {
            int n12;
            int n13;
            block30: {
                int n14;
                boolean bl4;
                block28: {
                    boolean bl5 = client.A;
                    n13 = this.P[n4];
                    if (~((n13 & 0x8FFFFFFF) >> -1240422525) != ~n) {
                        return 0;
                    }
                    n11 = 0;
                    if (n3 < 0 && ~(n13 & 0x8FFFFFFF) == -24) {
                        if (-2 == n3) {
                            int n15 = 0;
                            while (-8 < ~n15) {
                                n11 += this.a(bl, n, n2, lk2, bl2, n15, n4, n5, oi2, bl3, (byte)111);
                                ++n15;
                            }
                        }
                        return n11;
                    }
                    if (this.lk_v) {
                        n5 = 3;
                    }
                    n12 = 0;
                    this.lk_w[0] = n4;
                    n10 = 1;
                    this.P[n4] = de.b(Integer.MIN_VALUE, n13);
                    bl4 = false;
                    if (n3 >= 0) {
                        bl4 = true;
                        n13 = (0x8FFFFFF8 & n13) + n3;
                    }
                    if (bl) break block28;
                    n14 = -119 / ((by - 7) / 60);
                    if (bl4 || n10 < n2) break block29;
                    n13 = 8 | n13 & 7;
                    n12 = 0;
                    for (n9 = 0; n9 < n10; ++n9) {
                        n8 = this.lk_w[n9];
                        n7 = this.P[n8];
                        if (0x70000000 <= (0x70000000 & n7)) continue;
                        this.P[n8] = n7 - -268435456;
                    }
                    break block30;
                }
                n14 = !bl3 ? 23 : 0x18 ^ n13;
                while (n12 < n10) {
                    n9 = this.lk_w[n12++];
                    if (bl4 && 23 != (this.P[n9] & 0xFFFFFFF)) {
                        bl4 = false;
                    }
                    if (0 < n9 % this.O) {
                        n10 = this.a(-1 + n9, 124, n14, n10, n13);
                    }
                    if (this.O + -1 > n9 % this.O) {
                        n10 = this.a(1 + n9, 126, n14, n10, n13);
                    }
                    if (~n9 <= ~this.O) {
                        n10 = this.a(-this.O + n9, 126, n14, n10, n13);
                    }
                    if ((-1 + this.lk_a) * this.O <= n9) continue;
                    n10 = this.a(n9 - -this.O, 125, n14, n10, n13);
                }
                n14 = -119 / ((by - 7) / 60);
                if (!bl4 && n10 >= n2) {
                    n13 = 8 | n13 & 7;
                    n12 = 0;
                    for (n9 = 0; n9 < n10; ++n9) {
                        n8 = this.lk_w[n9];
                        n7 = this.P[n8];
                        if (0x70000000 <= (0x70000000 & n7)) continue;
                        this.P[n8] = n7 - -268435456;
                    }
                }
                break block29;
            }
            n9 = n10;
            if (bl2) {
                while (n10 > n12) {
                    if (~((n8 = this.lk_w[n12++]) % this.O) < -1) {
                        n10 = this.a(n10, n8 + -1, (byte)-44, n13);
                    }
                    if (n8 % this.O < -1 + this.O) {
                        n10 = this.a(n10, n8 - -1, (byte)-44, n13);
                    }
                    if (~this.O >= ~n8) {
                        n10 = this.a(n10, -this.O + n8, (byte)-44, n13);
                    }
                    if (~n8 <= ~((this.lk_a + -1) * this.O)) continue;
                    n10 = this.a(n10, this.O + n8, (byte)-44, n13);
                }
            }
            if (!bl3 && null != this.lk_rb) {
                if (~n5 == -4 && null != this.lk_rb) {
                    n7 = n8 = gg.b(n10, 27935);
                    he.he_ab += n7;
                    fb.fb_e += n7;
                    this.lk_hb += n8;
                    this.lk_rb.a(new sa(false, this.b(0, n10, 81), this.a(true, n10, 0), n8, a.a_u, -1 + n10, 8 | 7 & n13, new String[]{" <times> ", Integer.toString(n10), " = <b>", Integer.toString(n8)}), 2777);
                } else if (this.lk_rb != null) {
                    n8 = pa.b(n9, 65);
                    n7 = gg.b(n10 + -n9, 27935);
                    this.lk_f += n8;
                    n6 = n8;
                    he.he_ab += n6;
                    fb.fb_e += n6;
                    this.lk_hb += n7;
                    n6 = n7;
                    fb.fb_e += n6;
                    he.he_ab += n6;
                    if (0 < n7) {
                        this.lk_rb.a(new sa(false, this.b(n9, n10, 65), this.a(true, n10, n9), n7, a.a_u, n10 + -n9 - 1, 8 | 7 & n13, new String[]{" <times> ", Integer.toString(n10 + -n9), " = <b>", Integer.toString(n7)}), 2777);
                    }
                    this.lk_rb.a(new sa(false, this.b(0, n9, 112), this.a(true, n9, 0), n8, bc.J, -4 + n9, 0x10 | 7 & n13, new String[]{" <times> ", Integer.toString(n9), " = <b>", Integer.toString(n8)}), 2777);
                }
            }
            n11 = n10;
            if (this.D >= n5) {
                this.a(lk2, oi2, n13, 0, -3 >= ~this.D ? n10 : n9);
            }
        }
        if (!bl3) {
            n9 = 0;
            while (~n9 > ~n10) {
                n8 = this.lk_w[n9];
                n7 = this.P[n8];
                n6 = n7 & 0xFFFFFFF;
                if (23 == n6 || -3 != ~(n6 >> -536593437)) {
                    this.P[n8] = n7 &= Integer.MAX_VALUE;
                }
                ++n9;
            }
        }
        return n11;
    }

    final void d(int n, int n2) {
        block24: {
            boolean bl = client.A;
            if (0 == this.C) {
                throw new IllegalStateException();
            }
            int n3 = ~this.A & n;
            this.A = n;
            boolean bl2 = false;
            if (-1 > ~this.Ab) {
                --this.Ab;
                if (0 == (1 & n3)) {
                    if (~(n3 & 2) != -1) {
                        this.j(n2 ^ 0x9C2BEC85);
                        this.Cb = 10;
                    }
                } else {
                    this.b((byte)-116);
                    this.Cb = -10;
                }
                if (0 <= this.Cb) {
                    if (this.Cb > 0) {
                        if (~(n & 2) != -1) {
                            if (~(--this.Cb) == -1) {
                                this.j(4);
                                this.Cb = 3;
                            }
                        } else {
                            this.Cb = 0;
                        }
                    }
                } else if ((n & 1) == 0) {
                    this.Cb = 0;
                } else if (++this.Cb == 0) {
                    this.b((byte)-116);
                    this.Cb = -3;
                }
                if (0 != (n3 & 4)) {
                    this.c(false);
                }
                if (0 != (0x10 & n)) {
                    bl2 = true;
                }
                if (-1 != ~(8 & n3)) {
                    this.i(0);
                }
            } else {
                bl2 = true;
            }
            if (n2 != -1674843007) {
                lk.a(50, -101, 127, 94, false, 20, 66);
            }
            if (bl2) {
                if (0 != this.Ab && ~(n & 0x10) == -1) {
                    bl2 = false;
                } else if (this.lk_e > 2) {
                    if (!this.y && -1 > ~this.Ab && ~this.lk_g == ~this.lk_e && this.o(32) == this.M && null != this.lk_rb) {
                        this.H += 5;
                        he.he_ab += 5;
                        fb.fb_e += 5;
                    }
                    this.lk_e = 2;
                }
            }
            if (-1 <= ~this.lk_e) break block24;
            this.c(30000, -1 + this.lk_e, 0);
        }
    }

    final rf b(int n) {
        boolean bl = client.A;
        this.c(0);
        int n2 = 0;
        while (~this.lk_t < ~n2 && this.X[n2].rf_e != 0) {
            ++n2;
        }
        if (~this.lk_t >= ~n2) {
            throw new IllegalStateException();
        }
        if (n != -19939) {
            return null;
        }
        rf rf2 = this.X[n2];
        ++rf2.rf_e;
        return rf2;
    }

    final void a(int n, int n2, int n3, boolean bl, int n4, int n5) {
        boolean bl2 = client.A;
        this.L = n5;
        this.lk_q = n4;
        n3 = n & -this.lk_ab + n3;
        while (-1 > ~n3) {
            int[] nArray = this.B;
            int[] nArray2 = this.B;
            if (nArray == null || ~(this.zb * this.C) < ~nArray.length) {
                this.B = nArray2 = new int[this.C * this.zb];
            }
            int n6 = 0;
            for (int i = 0; this.zb > i; ++i) {
                int n7 = -1 + this.zb - i;
                for (int j = 0; this.C > j; ++j) {
                    this.B[n7] = this.T[n6++];
                    n7 += this.zb;
                }
            }
            n6 = this.C;
            this.C = this.zb;
            this.B = this.T;
            this.zb = n6;
            this.T = nArray2;
            --n3;
        }
        this.a(n2, (byte)126, bl);
    }

    final void a(int n, int n2, rf rf2) {
        int n3;
        boolean bl = client.A;
        this.zb = rf2.rf_n;
        ++this.U;
        this.C = rf2.rf_b;
        this.lk_b = new int[this.C * this.zb];
        this.T = new int[this.C * this.zb];
        if (n <= 73) {
            this.a(false);
        }
        this.lk_tb = new int[this.C * this.zb];
        for (n3 = 0; this.zb * this.C > n3; ++n3) {
            this.T[n3] = lb.a(255, rf2.rf_c[n3]);
        }
        for (n3 = 0; this.C * this.zb > n3; ++n3) {
            this.lk_b[n3] = 8;
        }
        this.lk_o = 0;
        this.lk_db = 0;
        if (-1 != ~(1 & (this.C ^ this.zb))) {
            int n4;
            n3 = 0;
            int n5 = 0;
            int n6 = 0;
            int n7 = 0;
            int n8 = 0;
            while (~n8 > ~this.zb) {
                for (n4 = 0; n4 < this.C; ++n4) {
                    if (0 != this.T[n7]) {
                        n5 += n8;
                        ++n6;
                        n3 += n4;
                    }
                    ++n7;
                }
                ++n8;
            }
            n4 = n6 * (this.zb - 1) >> 847858401;
            n8 = (-1 + this.C) * n6 >> 1653217089;
            if (-n4 + n5 <= n3 + -n8 || n5 - n4 <= n8 + -n3) {
                if (~(n5 - n4) > ~(-n8 + n3) && -n4 + n5 < -n3 + n8) {
                    this.lk_o = -1;
                } else {
                    this.lk_db = n3 >= n8 ? 1 : -1;
                }
            } else {
                this.lk_o = 1;
            }
        }
        this.Cb = 0;
        this.lk_q = -this.C + this.O >> -433015551;
        this.A = 0;
        this.L = -this.zb + 1 + this.z;
        this.yb = n2;
        this.lk_ab = 0;
        this.lk_e = -3 < ~this.lk_g ? 2 : this.lk_g;
        this.y = false;
        this.Ab = this.l(123);
        this.M = this.o(32);
    }

    final void a(rf rf2, byte by) {
        boolean bl = client.A;
        if (this.lk_t >= this.X.length) {
            rf[] rfArray;
            rf[] rfArray2 = rfArray = new rf[2 * this.X.length];
            int n = 0;
            while (~n > ~this.X.length) {
                rfArray[n] = this.X[n];
                ++n;
            }
            this.X = rfArray2;
        }
        if (by > -116) {
            this.lk_o = 45;
        }
        rf2.rf_l = this.lk_wb;
        this.lk_wb += 3;
        this.X[this.lk_t++] = rf2;
    }

    private final boolean c(int n, int n2) {
        boolean bl = client.A;
        if (n != 5) {
            return false;
        }
        if (n2 != -15303) {
            this.Bb = false;
        }
        int n3 = 0;
        while (-6 < ~n3) {
            block11: {
                int n4 = this.lk_w[n3];
                int n5 = n4 % this.O;
                int n6 = n4 / this.O;
                int n7 = 15;
                for (int i = 0; 5 > i; ++i) {
                    if (i == n3) continue;
                    int n8 = this.lk_w[i];
                    int n9 = n8 % this.O;
                    int n10 = n8 / this.O;
                    if (-1 == ~(n10 -= n6) && (0 == ~(n9 -= n5) || n9 == 1)) {
                        n7 &= 3;
                        continue;
                    }
                    if (~n9 == -1 && (n10 == -1 || ~n10 == -2)) {
                        n7 &= 0xC;
                        continue;
                    }
                    if (-1 == n9 && ~n10 == 0) {
                        n7 &= 5;
                        continue;
                    }
                    if (-2 == ~n9 && n10 == -1) {
                        n7 &= 9;
                        continue;
                    }
                    if (0 == ~n9 && -2 == ~n10) {
                        n7 &= 6;
                        continue;
                    }
                    if (~n9 == -2 && ~n10 == -2) {
                        n7 &= 0xA;
                        continue;
                    }
                    break block11;
                }
                if (-1 != ~n7) {
                    return true;
                }
            }
            ++n3;
        }
        return false;
    }

    final void k(int n) {
        if (n != -9897) {
            this.V = 92;
        }
        if (-1 > ~this.C && !this.S) {
            this.V = this.C;
            this.E = this.L;
            this.lk_mb = 1;
            this.lk_h = this.zb;
            this.lk_ob = this.lk_q;
            this.N = this.T;
            ge.a(this.lk_lb, this.lk_k / 2, (byte)127, ul.ul_i);
            this.S = true;
            this.K = 0;
            this.lk_p = 0;
            this.Bb = false;
            this.lk_nb = 0;
        }
        this.C = 0;
    }

    private final void b(boolean bl2) {
        block0: {
            int n = -300 + ka.a((byte)122, 601, tf.tf_cb);
            n = n * (n * n) / 90000;
            a.a(n, this.J / 4, ak.ak_b, this.lk_sb, 256);
            if (!bl2) break block0;
            this.M = -21;
        }
    }

    private final void i(int n) {
        block2: {
            if (this.q(21200)) {
                return;
            }
            if ((this.lk_db | this.lk_o) == n) break block2;
            this.lk_o = -this.lk_o;
            this.lk_db = -this.lk_db;
            if (this.q(n ^ 0x52D0)) {
                return;
            }
            this.lk_o = -this.lk_o;
            this.lk_db = -this.lk_db;
        }
    }

    private final int a(byte by) {
        boolean bl2 = client.A;
        int n = this.C * this.zb;
        int n2 = 0;
        while (~n < ~n2) {
            int n3 = this.T[n2];
            if (0 != n3) {
                return (n3 & 0x18) >> 1983512195;
            }
            ++n2;
        }
        if (by < 35) {
            this.T = null;
        }
        return 0;
    }

    final boolean n(int n) {
        boolean bl2 = client.A;
        int n2 = this.O * this.lk_a;
        int n3 = 0;
        while (~n2 < ~n3) {
            int n4 = this.P[n3];
            if ((0x18 & n4) == 24 && 1 != (n4 &= 7) && -4 != ~n4) {
                return true;
            }
            ++n3;
        }
        if (n != -22477) {
            lk lk2 = null;
            this.a(null, 112, true, lk2);
        }
        return false;
    }

    static final boolean a(int n, int n2, int n3, int n4, boolean bl2, int n5, int n6) {
        int n7 = -122 / ((n2 - -36) / 55);
        if (ea.d((byte)69)) {
            im.a(-93, n6, bl2, n5);
            if (w.H != null && w.H.a(bl2, n4, n, 0, n5)) {
                bl2 = false;
                tf.i((byte)-78);
            }
            ll.a(bl2, 0, n5);
            ji.a(n3, 0, bl2);
            bl2 = false;
        }
        return bl2;
    }

    final void a(boolean bl2) {
        if (bl2) {
            return;
        }
        this.lk_nb = 0;
        this.lk_p = 0;
        this.S = true;
        this.K = 0;
    }

    final void a(oi oi2, int n, boolean bl2, lk lk2) {
        block99: {
            int n2;
            int n3;
            int n4;
            boolean bl3 = client.A;
            mk.mk_e = 0;
            if (n <= 124) {
                return;
            }
            dn.dn_i = false;
            fk.H = 0;
            bj.bj_a = false;
            pn.pn_db = false;
            boolean bl4 = false;
            if (1 == this.lk_ib) {
                n4 = 1;
                for (n3 = 0; this.lk_a * this.O > n3; ++n3) {
                    n2 = this.P[n3];
                    if (-33 < ~n2) continue;
                    if (~(n2 += 32) <= -417) {
                        n2 = 0;
                    } else {
                        n4 = 0;
                    }
                    bl4 = true;
                    this.P[n3] = n2;
                }
                if (n4 != 0) {
                    this.lk_ib = 0;
                }
            } else if (-1 == ~this.lk_ib) {
                ud ud2;
                int n5;
                n4 = 0;
                n3 = 0;
                n2 = -1 + this.lk_a * this.O;
                int n6 = this.lk_a + -1;
                while (-1 >= ~n6) {
                    n5 = -1 + this.O;
                    while (-1 >= ~n5) {
                        int n7 = this.P[n2];
                        if (~n7 != -1) {
                            if (bl2 || 16 != (n7 & 0x18) && -25 != ~(n7 & 0x18) || ~n6 <= ~(-1 + this.lk_a) || this.P[n2 - -this.O] != 0) {
                                if (!(bl2 || ~(n7 & 0x18) != -17 && (0x18 & n7) != 24 || this.lk_a + -1 <= n6 || n5 - -this.lk_l < 0 || ~(n5 + this.lk_l) <= ~this.O || ~this.P[this.lk_l + n2] != -1 || ~this.P[this.O + n2 + this.lk_l] != -1)) {
                                    this.P[this.lk_l + n2] = de.b(lb.a(31, n7), 32);
                                    this.P[n2] = 0;
                                    bl4 = true;
                                    ++n4;
                                } else if (!(bl2 || ~(n7 & 0x18) != -17 && ~(n7 & 0x18) != -25 || ~(this.lk_a + -1) >= ~n6 || ~(-this.lk_l + n5) > -1 || ~this.O >= ~(-this.lk_l + n5) || ~this.P[-this.lk_l + n2] != -1 || -1 != ~this.P[-this.lk_l + (n2 + this.O)])) {
                                    this.P[-this.lk_l + n2] = de.b(lb.a(31, n7), 32);
                                    bl4 = true;
                                    this.P[n2] = 0;
                                    ++n4;
                                } else if (32 <= n7) {
                                    if (!bl2 || n7 >= 64) {
                                        if (n7 < 64) {
                                            ++n3;
                                        }
                                        if (-449 >= ~(n7 += 32)) {
                                            n7 &= 0x1F;
                                        }
                                    } else {
                                        n7 &= 0x1F;
                                    }
                                    this.P[n2] = n7;
                                    bl4 = true;
                                }
                            } else {
                                this.P[n2 + this.O] = de.b(lb.a(n7, 31), 32);
                                this.P[n2] = 0;
                                ++n4;
                                bl4 = true;
                            }
                        }
                        --n2;
                        --n5;
                    }
                    --n6;
                }
                ud ud3 = ud2 = ~this.lk_l == -1 ? bf.bf_u : rc.rc_i;
                if (~n4 >= -1) {
                    ei ei2 = wf.wf_l[this.Q];
                    if (ei2 != null) {
                        ei2.g(en.en_o / 50);
                        wf.wf_l[this.Q] = null;
                    }
                } else {
                    ei ei3;
                    pg.pg_a[this.Q] = true;
                    n5 = (int)(0.5 + (double)this.lk_k * Math.sqrt(n4));
                    if (~(4 * this.lk_k) > ~n5) {
                        n5 = 4 * this.lk_k;
                    }
                    if (null != (ei3 = wf.wf_l[this.Q])) {
                        ei3.f(-1);
                    }
                    if (null == ei3 || !ei3.a((byte)93) || ei3.ol_q != ud2) {
                        if (null != ei3) {
                            ei3.g(en.en_o / 50);
                        }
                        ei3 = ei.c(ud2, 100, n5 * pb.pb_d, this.lk_lb << -273244250);
                        ei3.f(-1);
                        dg.dg_c.a(ei3);
                        wf.wf_l[this.Q] = ei3;
                    } else {
                        ei3.b(en.en_o / 50, n5 * pb.pb_d, this.lk_lb << 522231430);
                    }
                }
                if (0 < n3) {
                    int n8 = (2 + (int)((double)this.lk_k * Math.sqrt(n3))) / 4;
                    if (this.lk_k < n8) {
                        n8 = this.lk_k;
                    }
                    ge.a(this.lk_lb, n8, (byte)127, bj.bj_e);
                }
                if (bl4) {
                    this.lk_l = -this.lk_l;
                } else {
                    this.lk_ib = 2;
                    this.lk_l = 0;
                }
            }
            if (!(bl4 || this.lk_s || bl2)) {
                gg.B = Integer.MAX_VALUE;
                gi.gi_a = 0;
                n4 = 0;
                n3 = 0;
                while (~n3 > ~(this.lk_a * this.O)) {
                    n2 = this.a(true, 2, 4, lk2, true, -1, n3, 1, oi2, false, (byte)71);
                    if (n2 > 0) {
                        if (this.lk_kb) {
                            if (this.a(-101, n2)) {
                                bj.bj_a = true;
                            }
                            if (this.c(n2, -15303)) {
                                dn.dn_i = true;
                            }
                            if (this.b(n2, -1)) {
                                pn.pn_db = true;
                            }
                        }
                        ++n4;
                    }
                    ++n3;
                }
                this.a(-99, false, 1);
                if (n4 <= 0) {
                    this.lk_s = true;
                } else {
                    this.K += n4;
                    if (-3 >= ~n4) {
                        n3 = ((int)((double)this.lk_k * Math.sqrt(n4)) + 1) / 2;
                        if (this.lk_k < n3) {
                            n3 = this.lk_k;
                        }
                        ge.a(this.lk_lb, n3, (byte)127, bf.bf_w);
                    }
                    ++this.lk_nb;
                    if (-3 >= ~this.lk_nb) {
                        n3 = (this.lk_nb + -1) % 4;
                        n2 = (-1 + this.lk_nb) / 4 * 3;
                        if (n3 == 3) {
                            ++n2;
                        }
                        ai.a(62, n2, jm.jm_v[n3], this.lk_lb, this.lk_k);
                    }
                    if (null != this.lk_rb) {
                        n2 = n3 = ik.a((byte)126, n4);
                        fb.fb_e += n2;
                        he.he_ab += n2;
                        this.lk_ub += n3;
                        if (0 < n3) {
                            this.lk_rb.a(new sa(true, this.O * 128, -384 + gg.B-- * 256, n3, jg.jg_f, -2 + n4, 0, new String[]{cm.a((byte)85, on.on_h, new String[]{Integer.toString(n4)}), " = <b>", Integer.toString(n3)}), 2777);
                        }
                        n2 = le.b(32085, this.lk_nb);
                        if (0 < n2) {
                            this.W = new sa(true, 128 * this.O, -384 + gg.B-- * 256, n2, nf.nf_f, this.lk_nb + -2, 0, new String[]{cm.a((byte)115, e.e_d, new String[]{Integer.toString(this.lk_nb)}), " = <b>", Integer.toString(n2)});
                        }
                    }
                    bl4 = true;
                }
            }
            if (!bl4 && !bl2) {
                ei ei4;
                int n9;
                n4 = 1;
                for (n3 = 0; n3 < this.lk_a * this.O; ++n3) {
                    n2 = this.P[n3];
                    if (~n2 > -33 || ~(n2 & 0x1F) == -26 || ~(n2 & 0x1F) == -28) continue;
                    if ((n2 += 32) >= 416) {
                        n2 = 0;
                    } else {
                        n4 = 0;
                    }
                    this.P[n3] = n2;
                    bl4 = true;
                }
                n3 = -1 + (-1 + this.lk_a) * this.O;
                for (n2 = this.lk_a - 2; n2 >= 0; --n2) {
                    for (int i = -1 + this.O; i >= 0; --i) {
                        int n10 = this.P[n3];
                        if (~n10 == -26) {
                            this.a(false, 2, 1, lk2, false, -2, this.O + n3, 3, oi2, false, (byte)109);
                            this.b(-1, this.O + n3, false);
                        }
                        if (27 == n10) {
                            this.a(true, 2, 1, lk2, true, -2, this.O + n3, 3, oi2, false, (byte)-99);
                            this.b(-1, n3 - -this.O, false);
                        }
                        --n3;
                    }
                }
                n3 = this.O * (-1 + this.lk_a) - 1;
                n2 = -2 + this.lk_a;
                while (~n2 <= -1) {
                    int n11 = -1 + this.O;
                    while (-1 >= ~n11) {
                        int n12 = this.P[n3];
                        if (~n12 == -26 && -1 == ~(this.P[n3 + this.O] & 0x70000000)) {
                            this.a(false, 1, 1, lk2, false, -1, n3 - -this.O, 3, oi2, false, (byte)123);
                        }
                        if (~n12 == -28 && 0 == (this.P[this.O + n3] & 0x70000000)) {
                            this.a(false, 1, 1, lk2, true, -1, this.O + n3, 3, oi2, false, (byte)72);
                        }
                        --n3;
                        --n11;
                    }
                    --n2;
                }
                this.a(-121, false, 2);
                n2 = 0;
                n3 = -1 + this.O * this.lk_a;
                int n13 = 0;
                int n14 = -1 + this.lk_a;
                while (-1 >= ~n14) {
                    for (int i = this.O + -1; i >= 0; --i) {
                        n9 = this.P[n3];
                        if (~(0x1F & n9) == -26 || 27 == (n9 & 0x1F)) {
                            bl4 = true;
                            if (32 <= n9) {
                                if (~(n9 += 32) <= -417) {
                                    n9 = 0;
                                } else {
                                    n4 = 0;
                                }
                                this.P[n3] = n9;
                            } else {
                                if (-1 + this.lk_a > n14) {
                                    this.P[n3 + this.O] = n9;
                                }
                                this.P[n3] = n9 - -32;
                                n4 = 0;
                                if (~(7 & n9) != -4) {
                                    ++n2;
                                } else {
                                    ++n13;
                                }
                            }
                        }
                        --n3;
                    }
                    --n14;
                }
                if (0 < n2) {
                    n14 = kd.kd_s[0][this.Q];
                    ei[] eiArray = sk.sk_a[0];
                    n9 = (1 + (int)((double)this.lk_k * Math.sqrt(n2))) / 2;
                    if (n9 > this.lk_k) {
                        n9 = this.lk_k;
                    }
                    if (n9 < n14) {
                        n9 = n14;
                    }
                    kd.kd_s[0][this.Q] = n9;
                    ei4 = eiArray[this.Q];
                    if (ei4 != null) {
                        ei4.b(en.en_o / 50, n9 * pb.pb_d, this.lk_lb << -432303322);
                    } else {
                        ei4 = ei.c(ob.ob_n, 100, pb.pb_d * n9, this.lk_lb << -1195698778);
                        ei4.f(-1);
                        dg.dg_c.a(ei4);
                        eiArray[this.Q] = ei4;
                    }
                }
                if (0 < n13) {
                    n14 = kd.kd_s[1][this.Q];
                    ei[] eiArray = sk.sk_a[1];
                    n9 = (1 + (int)((double)this.lk_k * Math.sqrt(n13))) / 2;
                    if (~this.lk_k > ~n9) {
                        n9 = this.lk_k;
                    }
                    if (n9 < n14) {
                        n9 = n14;
                    }
                    kd.kd_s[1][this.Q] = n9;
                    ei4 = eiArray[this.Q];
                    if (ei4 != null) {
                        ei4.b(en.en_o / 50, pb.pb_d * n9, this.lk_lb << -59157402);
                    } else {
                        ei4 = ei.c(ob.ob_n, 120, n9 * pb.pb_d, this.lk_lb << -297612698);
                        ei4.f(-1);
                        dg.dg_c.a(ei4);
                        eiArray[this.Q] = ei4;
                    }
                }
                if (bl4 && n4 != 0) {
                    this.lk_ib = 0;
                    this.lk_s = false;
                }
            }
            if (!bl2 && this.G != 0) {
                n4 = this.G;
                this.G = 0;
                n3 = 0;
                for (n2 = 0; this.lk_a * this.O > n2; ++n2) {
                    int n15;
                    int n16 = this.P[n2];
                    int n17 = n16 >> -465067389;
                    if (2 != n17 && ~n17 != -2 || 0 == (n4 & (n15 = 1 << (7 & n16)))) continue;
                    n3 += this.a(true, n17, 1, lk2, false, -1, n2, 3, oi2, true, (byte)-72);
                }
                this.a(-107, true, this.lk_ib);
                if (~n3 < -1) {
                    bl4 = true;
                    if (null != this.lk_rb) {
                        int n18 = n2 = gg.b(n3, 27935);
                        he.he_ab += n18;
                        fb.fb_e += n18;
                        this.lk_hb += n2;
                        this.lk_rb.a(new sa(true, this.O * 128, this.O * -32, n2, oh.oh_c, -1 + h.a(n4, 63), 26, new String[]{" = <b>", Integer.toString(n2)}), 2777);
                    }
                }
            }
            if (!bl2 && (this.lk_r || this.Y)) {
                n4 = 0;
                while (~(this.O * this.lk_a) < ~n4) {
                    n3 = this.P[n4];
                    if (-24 != ~n3 && (this.lk_r && n3 >> 1910143171 == 1 || this.Y && ~(n3 >> 585718723) == -3)) {
                        this.P[n4] = qm.b(24, n3);
                    }
                    ++n4;
                }
                if (this.lk_r) {
                    this.lk_v = true;
                    ge.a(this.lk_lb, this.lk_k, (byte)127, fj.fj_k);
                }
                if (this.Y) {
                    ge.a(this.lk_lb, this.lk_k, (byte)127, w.Eb);
                }
                this.Y = false;
                this.lk_r = false;
            }
            if (this.N != null) {
                ++this.lk_mb;
                if (13 == this.lk_mb) {
                    this.N = null;
                }
            }
            if (!bl2 && !bl4 && null == this.N && this.lk_jb > 0 && this.Z != this.z) {
                ge.a(this.lk_lb, this.lk_k, (byte)127, qa.qa_s);
                n4 = this.z;
                while (~n4 > ~this.Z) {
                    for (n3 = 0; n3 < this.O; ++n3) {
                        n2 = this.P[n4 * this.O + n3];
                        if (-1 == ~n2) continue;
                        this.P[n4 * this.O - -n3] = 32 + n2;
                        this.lk_ib = 1;
                    }
                    ++n4;
                }
                this.L += this.Z - this.z;
                bl4 = true;
                this.z = this.Z;
            }
            if (bl4 || this.N != null || bl2) break block99;
            this.S = false;
            this.lk_s = false;
            this.lk_ib = 0;
            this.lk_v = false;
            if (this.lk_rb != null && this.W != null) {
                this.lk_j += this.W.sa_t;
                n4 = this.W.sa_t;
                fb.fb_e += n4;
                he.he_ab += n4;
                this.lk_rb.a(this.W, 2777);
                this.W = null;
            }
            if (this.c((byte)-117)) {
                --this.L;
            }
            this.M = this.o(32);
        }
    }

    public static void g(int n) {
        if (n < 35) {
            mm mm2 = null;
            lk.a(null, true, mm2, -73);
        }
        lk_i = null;
    }

    private final void b(byte by) {
        block2: {
            --this.lk_q;
            if (this.c((byte)-117)) {
                ++this.lk_q;
            } else {
                this.h(by + 115);
                ge.a(this.lk_lb, this.lk_k / 4, (byte)127, hm.hm_d);
            }
            if (by == -116) break block2;
            this.lk_j = 63;
        }
    }

    private final void c(int n) {
        if (n != 0) {
            this.lk_pb = -32;
        }
        ge.a(this.lk_sb, this.J / 8, (byte)127, ul.ul_i);
    }

    private final rf p(int n) {
        boolean bl2 = client.A;
        if (this.lk_t <= 0) {
            throw new IllegalStateException();
        }
        rf rf2 = this.X[0];
        int n2 = 1;
        while (~this.lk_t < ~n2) {
            this.X[-1 + n2] = this.X[n2];
            ++n2;
        }
        ++this.lk_m;
        if (n <= 121) {
            return null;
        }
        --this.lk_t;
        return rf2;
    }

    final void a(boolean bl2, wl wl2, byte by) {
        int n;
        boolean bl3 = client.A;
        int n2 = wl2.e(3);
        this.S = -1 != ~(n2 & 0x100);
        this.lk_ab = (0x650 & n2) >> 2050439561;
        this.lk_o = (0xC0000000 & n2 << -818043813) >> 627226110;
        this.y = 0 != (0x40 & n2);
        this.lk_ib = (0x20 & n2) != 0 ? 0 : 1;
        this.lk_db = (0xC0000000 & n2 << 2113050941) >> 1576984158;
        this.lk_jb = wl2.d((byte)-74);
        if (bl2) {
            for (n = this.lk_jb; 3 > n; ++n) {
                rk.rk_cb += 30000;
                fh.fh_h += 30000;
            }
        }
        n = 0;
        while (~(this.lk_a * this.O) < ~n) {
            int n3 = wl2.d((byte)-40);
            if (-129 >= ~n3) {
                int n4 = wl2.d((byte)-102);
                n3 = 0x7F & n3 | n4 << 1559143495;
            }
            this.P[n] = n3;
            ++n;
        }
        this.U = wl2.d((byte)-71);
        this.C = wl2.d((byte)-38);
        this.zb = wl2.d((byte)-39);
        this.T = new int[this.C * this.zb];
        this.lk_b = new int[this.C * this.zb];
        this.lk_tb = new int[this.zb * this.C];
        n = 0;
        while (~n > ~(this.C * this.zb)) {
            this.T[n] = wl2.d((byte)-42);
            ++n;
        }
        for (n = 0; this.C * this.zb > n; ++n) {
            this.lk_b[n] = 8;
        }
        this.lk_q = wl2.g((byte)-123);
        this.L = wl2.g((byte)-84);
        this.lk_e = wl2.d((byte)-45);
        this.Ab = wl2.e(3);
        this.A = wl2.d((byte)-104);
        this.Cb = wl2.g((byte)-122);
        this.yb = wl2.d((byte)-102);
        if (by < 116) {
            this.a(84, false, 99);
        }
        this.K = wl2.d((byte)-52);
        this.z = wl2.d((byte)-100);
        this.Bb = false;
    }

    private final int o(int n) {
        block0: {
            if (n == 32) break block0;
            lk_i = null;
        }
        return this.lk_o + this.zb + 2 * this.L;
    }

    private final void d(int n) {
        block1: {
            int n2 = this.o(32);
            if (this.M < n2) {
                this.M = n2;
            }
            if (n == 30968) break block1;
            lk lk2 = null;
            this.a(null, -76, false, lk2);
        }
    }

    private final int a(int n, int n2, int n3, int n4, int n5) {
        block1: {
            int n6;
            if (n2 <= 123) {
                this.lk_pb = -105;
            }
            if (~(0x8FFFFFFF & (n6 = this.P[n])) != ~n5 && (n6 & 0x8FFFFFFF) != n3) break block1;
            this.lk_w[n4++] = n;
            this.P[n] = n6 + Integer.MIN_VALUE;
        }
        return n4;
    }

    private final void b(int n, int n2, boolean bl2) {
        block12: {
            block11: {
                int n3 = this.P[n2];
                if (bl2) {
                    return;
                }
                if (24 != (0x8FFFFFF8 & n3)) break block11;
                if (1 == (7 & n3)) break block12;
                if (~(7 & n3) == -4) {
                    return;
                }
                if ((n3 & 0x8FFFFFFF) == 24 && 0 == this.lk_l) {
                    this.lk_l = 1;
                    ge.a(this.lk_lb, this.lk_k / 2, (byte)127, pk.pk_q);
                }
                if ((n3 & 0x8FFFFFFF) == 29) {
                    this.Y = true;
                }
                if ((n3 & 0x8FFFFFFF) == 26 && n >= 0) {
                    this.G |= 1 << n;
                }
                if (~(0x8FFFFFFF & n3) == -29) {
                    this.lk_r = true;
                }
                if ((0x70000000 & n3) == 0) {
                    this.P[n2] = 0x10000000 + n3;
                    if (this.lk_rb != null) {
                        he.he_ab += 2000;
                        fb.fb_e += 2000;
                        this.lk_bb += 2000;
                        this.lk_rb.a(new sa(true, 128 - -(256 * (n2 % this.O)), n2 / this.O * 256 + 128, 2000, null, 0xD0D0D0, n3, new String[]{" = <b>", Integer.toString(2000)}), 2777);
                    }
                }
            }
            return;
        }
    }

    private final boolean t(int n) {
        int n2;
        int n3;
        int n4;
        boolean bl2 = client.A;
        int[] nArray = this.B;
        int[] nArray2 = this.B;
        if (nArray == null || ~nArray.length > ~(this.C * this.zb)) {
            this.B = nArray2 = new int[this.C * this.zb];
        }
        int n5 = n;
        for (n4 = 0; this.zb > n4; ++n4) {
            n3 = (-1 + this.C) * this.zb + n4;
            n2 = 0;
            while (~n2 > ~this.C) {
                this.B[n3] = this.T[n5++];
                n3 -= this.zb;
                ++n2;
            }
        }
        n4 = -this.lk_o + -this.zb + (this.C - -this.lk_db) >> -1674843007;
        this.lk_q += n4;
        n3 = this.lk_o + this.lk_db + (-this.C + this.zb) >> -212989087;
        this.L += n3;
        n5 = this.C;
        this.C = this.zb;
        this.zb = n5;
        this.B = this.T;
        this.T = nArray2;
        if (!this.c((byte)-117)) {
            --this.lk_ab;
            n5 = this.lk_db;
            this.lk_db = this.lk_o;
            this.lk_o = -n5;
            this.d(30968);
            n5 = 0;
            this.h(~n);
            for (n2 = 0; this.zb > n2; ++n2) {
                for (int j = 0; j < this.C; ++j) {
                    this.lk_tb[n5] = 0;
                    this.lk_b[n5] = 8 * (-1 + -(j * 2) + this.lk_db + this.C) / this.C;
                    ++n5;
                }
            }
            ge.a(this.lk_lb, this.lk_k / 4, (byte)127, ib.ib_ob);
            return true;
        }
        this.T = this.B;
        this.zb = this.C;
        this.B = nArray2;
        this.L -= n3;
        this.lk_q -= n4;
        this.C = n5;
        return false;
    }

    final int a(int n, byte by, int n2) {
        int n3;
        if (0 != this.C && !this.S) {
            n3 = n2 + -this.lk_q;
            int n4 = -this.L + n;
            if (-1 >= ~n3 && -1 >= ~n4 && ~this.C < ~n3) {
                if (~n4 <= ~this.zb) {
                    n3 = 119 / ((45 - by) / 37);
                    return 0;
                }
                int n5 = n4 * this.C + n3;
                if (this.T[n5] != 0) {
                    return this.lk_tb[n5];
                }
            }
        }
        n3 = 119 / ((45 - by) / 37);
        return 0;
    }

    private final int b(int n, int n2, int n3) {
        int n4;
        block1: {
            boolean bl2 = client.A;
            n4 = 0;
            for (int j = n; j < n2; ++j) {
                int n5 = this.lk_w[j];
                n4 += n5 % this.O;
            }
            if (n3 > 49) break block1;
            this.a((byte)-117);
        }
        return 128 + n4 * 256 / (-n + n2);
    }

    final int r(int n) {
        if (n != 3837) {
            return -4;
        }
        if (0 > this.L) {
            return this.L;
        }
        return 0;
    }

    private final boolean a(byte by, boolean bl2) {
        int n;
        int n2;
        boolean bl3 = client.A;
        ++this.L;
        if (this.c((byte)-117)) {
            --this.L;
            return true;
        }
        this.d(30968);
        if (bl2) {
            n2 = this.a((byte)103);
            if (n2 != 1) {
                ge.a(this.lk_lb, this.lk_k / 4, (byte)127, pg.pg_d);
            } else {
                ge.a(this.lk_lb, this.lk_k / 8, (byte)127, client.F);
            }
        }
        n2 = n = 0;
        while (this.zb * this.C > n) {
            this.lk_tb[n] = 0;
            this.lk_b[n] = 8;
            ++n;
        }
        if (by >= -27) {
            this.a(-71, (byte)28, false);
        }
        return false;
    }

    private final boolean c(byte by) {
        boolean bl2 = client.A;
        int n = 0;
        int n2 = this.lk_q + this.L * this.O;
        int n3 = 0;
        while (~n3 > ~this.zb) {
            int n4 = 0;
            while (~this.C < ~n4) {
                if (this.T[n] != 0) {
                    if (~(this.lk_q - -n4) > -1 || ~this.O >= ~(this.lk_q + n4)) {
                        return true;
                    }
                    if (this.L + n3 >= this.lk_a) {
                        return true;
                    }
                    if (~(n3 + this.L) <= -1 && -1 != ~this.P[n2]) {
                        return true;
                    }
                }
                ++n;
                ++n2;
                ++n4;
            }
            n2 += this.O - this.C;
            ++n3;
        }
        return by != -117;
    }

    final int b(int n, byte by, int n2) {
        int n3 = 0;
        if (by <= 102) {
            return -33;
        }
        if (this.N != null) {
            int n4;
            int n5 = -this.lk_ob + n;
            int n6 = -this.E + n2;
            if (~n5 <= -1 && ~n6 <= -1 && n5 < this.V && n6 < this.lk_h && -1 != ~(n4 = this.N[n6 * this.V + n5])) {
                n3 = this.lk_mb;
            }
        }
        return n3;
    }

    final void a(int n, byte by, boolean bl2) {
        boolean bl3 = client.A;
        int n2 = 0;
        int n3 = -97 % ((83 - by) / 37);
        while (~(this.C * this.zb) < ~n2) {
            if (-1 != ~this.T[n2]) {
                ++this.lk_qb;
            }
            ++n2;
        }
        this.Z = n;
        if (this.z > this.L) {
            --this.lk_jb;
            if (bl2) {
                fh.fh_h += 30000;
                rk.rk_cb += 30000;
            }
            if (this.lk_jb <= 0) {
                this.k(-9897);
                return;
            }
            this.E = this.L;
            this.V = this.C;
            this.lk_ob = this.lk_q;
            this.lk_h = this.zb;
            n2 = this.V * this.lk_h;
            this.N = new int[n2];
            n3 = n2;
            for (int j = -1 + (this.L + this.zb); this.L <= j; --j) {
                int n4 = -1 + (this.lk_q - -this.C);
                while (~this.lk_q >= ~n4) {
                    int n5;
                    if ((0x18 & (n5 = this.T[--n3])) != 16 && 24 != (n5 & 0x18)) {
                        this.N[n3] = n5;
                    } else {
                        int n6 = j;
                        if (n6 < this.z) {
                            n6 = this.z;
                        }
                        if (~this.lk_a < ~n6 && -1 == ~this.P[n4 + this.O * n6]) {
                            this.P[n4 + this.O * n6] = 32 + n5;
                            if (16 == (n5 & 0x18) && this.lk_rb != null) {
                                fb.fb_e += 25;
                                he.he_ab += 25;
                                this.x += 25;
                            }
                        } else {
                            this.N[n3] = n5;
                        }
                    }
                    --n4;
                }
            }
            this.lk_mb = 1;
            ge.a(this.lk_lb, this.lk_k / 2, (byte)127, ul.ul_i);
        } else {
            n2 = 0;
            n3 = this.L * this.O + this.lk_q;
            int n7 = 0;
            int n8 = 0;
            while (~n8 > ~this.zb) {
                int n9 = 0;
                while (~n9 > ~this.C) {
                    int n10 = this.T[n2];
                    if (-1 != ~n10) {
                        if ((0x18 & n10) == 16 || ~n8 == -1 || -1 == ~this.T[-this.C + n2]) {
                            n10 |= 0x20;
                        }
                        this.P[n3] = n10;
                        if ((0x18 & n10) == 16 && this.lk_rb != null) {
                            this.x += 25;
                            fb.fb_e += 25;
                            he.he_ab += 25;
                        }
                        if (8 == (0x18 & n10)) {
                            ++n7;
                        }
                    }
                    ++n3;
                    ++n2;
                    ++n9;
                }
                n3 += this.O - this.C;
                ++n8;
            }
            if (0 < n7) {
                n8 = ((int)((double)this.lk_k * Math.sqrt(n7)) + 4) / 8;
                if (~n8 < ~this.lk_k) {
                    n8 = this.lk_k;
                }
                ge.a(this.lk_lb, n8, (byte)127, fh.fh_c);
            }
        }
        this.lk_p = 0;
        this.S = true;
        this.Bb = false;
        this.lk_nb = 0;
        this.K = 0;
        this.C = 0;
    }

    static final void a(mm mm2, boolean bl2, mm mm3, int n) {
        block0: {
            rk.R = mm3;
            om.om_a = n;
            bg.bg_g = mm2;
            pj.a(31004, hk.hk_j / 2, hk.hk_i / 2);
            s.a(mm3.C, mm2.K + mm2.C, (byte)-91, mm2.C, mm3.C + mm3.K);
            if (bl2) break block0;
            lk_i = null;
        }
    }

    private final boolean b(int n, int n2) {
        boolean bl2 = client.A;
        boolean bl3 = false;
        boolean bl4 = false;
        for (int j = 0; j < n; ++j) {
            int n3 = this.lk_w[j];
            if (~n3 > ~this.O) {
                bl3 = true;
            }
            if (~(this.O * (this.lk_a - 1)) < ~n3) continue;
            bl4 = true;
        }
        if (n2 != -1) {
            return true;
        }
        return bl3 && bl4;
    }

    private final void c(int n, int n2, int n3) {
        block5: {
            boolean bl2 = client.A;
            if (n != 30000) {
                this.O = -79;
            }
            this.lk_e = n2;
            while (~n2 == -1) {
                if (!this.y) {
                    if (!this.a((byte)-126, 0 == n3)) {
                        ++n3;
                        this.lk_e = n2 = this.lk_g;
                        continue;
                    }
                    this.lk_e = 20;
                    this.y = true;
                    break;
                }
                this.Bb = true;
                break;
            }
            if (~this.lk_g != -1 || -1 <= ~n3) break block5;
            int n4 = ((int)((double)this.lk_k * Math.sqrt((double)(this.lk_a - -n3) / ((double)this.lk_a * 2.0))) + 4) / 8;
            if (n4 > this.lk_k) {
                n4 = this.lk_k;
            }
            ge.a(this.lk_lb, n4, (byte)127, fh.fh_c);
        }
    }

    final boolean e(int n) {
        int n2 = -106 % ((n - -22) / 51);
        if (this.lk_t > 0 && -1 == ~this.X[0].rf_l) {
            return true;
        }
        return this.lk_pb >= 18;
    }

    private final boolean a(int n, int n2) {
        boolean bl2 = client.A;
        if (4 != n2) {
            return false;
        }
        if (n >= -45) {
            this.a(-31, -66, (byte)71, -102);
        }
        int n3 = 0;
        while (~n3 > -5) {
            block5: {
                int n4 = this.lk_w[n3];
                int n5 = n4 % this.O;
                int n6 = n4 / this.O;
                for (int j = 0; 4 > j; ++j) {
                    if (~n3 == ~j) continue;
                    int n7 = this.lk_w[j];
                    int n8 = n7 % this.O;
                    int n9 = n7 / this.O;
                    if (0 == (n8 -= n5) && ((n9 -= n6) == -1 || n9 == 1) || 0 == n9 && (n8 == -1 || -2 == ~n8)) {
                        continue;
                    }
                    break block5;
                }
                return true;
            }
            ++n3;
        }
        return false;
    }

    private final void a(lk lk2, oi oi2, int n, int n2, int n3) {
        block10: {
            int n4;
            int n5;
            int n6;
            int n7;
            int n8;
            boolean bl2 = client.A;
            if (null == lk2 && null == oi2) {
                return;
            }
            int n9 = -1 + this.O;
            int n10 = -1 + this.lk_a;
            int n11 = n2;
            int n12 = 0;
            for (n8 = 0; n3 > n8; ++n8) {
                n7 = this.lk_w[n8];
                n6 = n7 % this.O;
                n5 = n7 / this.O;
                if (n6 < n9) {
                    n9 = n6;
                }
                if (~n6 < ~n11) {
                    n11 = n6;
                }
                if (n12 < n5) {
                    n12 = n5;
                }
                if (n5 >= n10) continue;
                n10 = n5;
            }
            n8 = -n9 + 1 + n11;
            n7 = n12 - -1 - n10;
            n6 = n8 * n7;
            n5 = this.lk_fb++;
            rf rf2 = null;
            if (null != oi2) {
                rf2 = oi2.a(false, n5);
            }
            if (rf2 == null) {
                rf2 = new rf(n5);
                rf2.rf_m = this.lk_p++;
                if (null != oi2) {
                    oi2.a(rf2, 0);
                }
            }
            rf2.rf_b = n8;
            rf2.rf_c = new byte[n6];
            rf2.rf_n = n7;
            int n13 = 0;
            while (~n13 > ~n6) {
                rf2.rf_c[n13] = 0;
                ++n13;
            }
            n13 = n4 = 0;
            while (n4 < n3) {
                int n14 = this.lk_w[n4];
                int n15 = -n9 + n14 % this.O;
                int n16 = n14 / this.O - n10;
                rf2.rf_c[n15 + n16 * n8] = (byte)n;
                ++n4;
            }
            if (lk2 == null) break block10;
            lk2.a(rf2, (byte)-128);
        }
    }

    final void a(int n, int n2, boolean bl2) {
        if (n2 != 2113050941) {
            this.a(80, 86, (byte)-26, -11);
        }
        this.lk_g = !bl2 ? mn.mn_b[n] : pn.pn_eb[n];
    }

    private final void c(boolean bl2) {
        block3: {
            if (this.t(0)) {
                return;
            }
            if (bl2) {
                this.c(61, 75);
            }
            if (-1 == ~(this.lk_db | this.lk_o)) break block3;
            this.lk_db = -this.lk_db;
            this.lk_o = -this.lk_o;
            if (this.t(0)) {
                return;
            }
            this.lk_db = -this.lk_db;
            this.lk_o = -this.lk_o;
        }
    }

    private final int a(int n, int n2, byte by, int n3) {
        block3: {
            int n4 = this.P[n2];
            if (~n3 != ~(0x8FFFFFFF & n4)) {
                this.b(7 & n3, n2, false);
            } else {
                if (-1879048193 < ~(n4 & 0x70000000)) {
                    n4 += 0x10000000;
                }
                this.lk_w[n++] = n2;
                this.P[n2] = n4 + Integer.MIN_VALUE;
            }
            if (by == -44) break block3;
            oi oi2 = null;
            this.a(true, 26, -7, null, true, 84, -39, 24, oi2, false, (byte)-94);
        }
        return n;
    }

    private final void j(int n) {
        block2: {
            ++this.lk_q;
            if (!this.c((byte)-117)) {
                this.h(-1);
                ge.a(this.lk_lb, this.lk_k / 4, (byte)127, hm.hm_d);
            } else {
                --this.lk_q;
            }
            if (n == 4) break block2;
            this.lk_mb = -42;
        }
    }

    private final int a(boolean bl2, int n, int n2) {
        boolean bl3 = client.A;
        int n3 = 0;
        int n4 = n2;
        if (!bl2) {
            this.N = null;
        }
        while (~n4 > ~n) {
            int n5 = this.lk_w[n4];
            int n6 = n5 / this.O;
            if (~gg.B < ~n6) {
                gg.B = n6;
            }
            if (gi.gi_a < n6) {
                gi.gi_a = n6;
            }
            n3 += n6;
            ++n4;
        }
        return 128 - -(n3 * 256 / (n + -n2));
    }

    final int a(int n) {
        block0: {
            if (n == 0) break block0;
            this.A = -70;
        }
        return this.lk_j + (this.lk_ub + this.lk_hb) + (this.H + this.x) - (-this.lk_bb - this.lk_f);
    }

    final int m(int n) {
        int n2 = 0;
        if (1 <= this.lk_c) {
            ++n2;
        }
        int n3 = this.lk_u.a(79, n2 + this.lk_d);
        int n4 = this.lk_u.a(107, this.lk_d - -n2);
        if (n != 26580) {
            return -69;
        }
        if (this.lk_d == n3) {
            n3 = 7;
        }
        if (this.lk_d == n4) {
            n4 = 7;
        }
        return n4 + (n3 << -793988540);
    }

    final void s(int n) {
        block36: {
            int n2;
            int n3;
            int n4;
            int n5;
            boolean bl2 = client.A;
            if (!this.S) {
                int n6;
                int n7;
                n5 = 0;
                n4 = 0;
                while (~this.zb < ~n4) {
                    for (n7 = 0; this.C > n7; ++n7) {
                        n3 = this.lk_tb[n5];
                        n6 = this.lk_b[n5];
                        n6 = ~n3 <= -1 ? (n6 += -n3 >> 1589558273) : (n6 -= n3 >> -2057940319);
                        n3 = 0 > (n3 += n6) ? (n3 -= n3 >> -1962291932) : (n3 += -n3 >> 521635204);
                        this.lk_tb[n5] = n3;
                        this.lk_b[n5] = n6;
                        ++n5;
                    }
                    ++n4;
                }
                n4 = 0;
                while (~n4 > ~this.C) {
                    int n8;
                    n7 = -1073741824;
                    n3 = 0;
                    while (~n3 > ~this.zb) {
                        n5 = n4 + n3 * this.C;
                        n6 = this.lk_q + n4;
                        if (~n6 <= -1 && ~this.O < ~n6) {
                            n2 = this.L - (-n3 + 1);
                            for (n8 = 0; -1 >= ~n2 && n7 < n8; n8 -= 80) {
                                if (n2 < this.lk_a && 0 != this.P[n6 + n2 * this.O]) {
                                    n7 = n8;
                                    break;
                                }
                                --n2;
                            }
                        }
                        n2 = this.lk_tb[n5];
                        n8 = this.lk_b[n5];
                        if (~n2 > ~n7) {
                            n2 = n7;
                            if (0 > n8) {
                                n8 = -n8;
                            }
                        }
                        this.lk_tb[n5] = n2;
                        this.lk_b[n5] = n8;
                        if (-1 != ~this.T[n5] && ~(n7 -= 80) > ~n2) {
                            n7 = n2;
                        }
                        ++n3;
                    }
                    n3 = 0x3FFFFFFF;
                    for (n6 = -1 + this.zb; 0 <= n6; --n6) {
                        int n9;
                        n5 = this.C * n6 - -n4;
                        n2 = n4 + this.lk_q;
                        if (n2 >= 0 && ~this.O < ~n2) {
                            n8 = this.L - -n6 - -1;
                            n9 = 0;
                            while (~n3 < ~n9) {
                                if (~n8 <= ~this.lk_a || -1 >= ~n8 && this.P[n2 + this.O * n8] != 0) {
                                    n3 = n9;
                                    break;
                                }
                                n9 += 80;
                                ++n8;
                            }
                        }
                        n8 = this.lk_tb[n5];
                        n9 = this.lk_b[n5];
                        if (~n8 < ~n3) {
                            if (-1 > ~n9) {
                                n9 = -n9;
                            }
                            n8 = n3;
                        }
                        this.lk_tb[n5] = n8;
                        this.lk_b[n5] = n9;
                        if (~this.T[n5] == -1 || (n3 += 80) <= n8) continue;
                        n3 = n8;
                    }
                    ++n4;
                }
            }
            if (this.lk_vb != null) {
                ++this.R;
                if (100 <= this.R) {
                    this.lk_vb = null;
                }
            }
            n5 = 1;
            n4 = 0;
            while (~this.lk_t < ~n4) {
                rf rf2 = this.X[n4];
                if (null == rf2.rf_c && rf2.rf_l <= 18) {
                    n5 = 0;
                }
                if (n5 != 0 && 0 < rf2.rf_l) {
                    if (18 == rf2.rf_l) {
                        this.b(false);
                    }
                    --rf2.rf_l;
                    n3 = rf2.rf_m - -1;
                    if (rf2.rf_l == 12 && -6 >= ~n3) {
                        this.lk_vb = cm.a((byte)105, uj.uj_b, new String[]{Integer.toString(n3)});
                        this.lk_eb = ka.a((byte)62, 7, tf.tf_cb) - 3;
                        this.lk_n = ka.a((byte)126, 7, tf.tf_cb) - 3;
                        this.R = 0;
                        int[] nArray = vl.G;
                        n2 = n3 / 10;
                        if (~nArray.length >= ~n2) {
                            n2 = nArray.length + -1;
                        }
                        this.xb = nArray[n2];
                    }
                }
                if (~rf2.rf_e < -1) {
                    ++rf2.rf_e;
                }
                ++n4;
            }
            if (n != -21142) {
                this.h(13);
            }
            n4 = this.e(-124) ? 1 : 0;
            while (this.lk_t > 0 && -14 >= ~this.X[0].rf_e) {
                this.p(127);
            }
            if (this.lk_cb != null && this.lk_cb.c((byte)70) != null) {
                if (-1 == ~this.lk_pb) {
                    this.b(false);
                }
                if (-323 == ~this.lk_pb) {
                    this.c(0);
                }
                ++this.lk_pb;
                if (335 == this.lk_pb) {
                    this.lk_pb = 0;
                    this.lk_cb.a(n + 21146);
                }
            }
            boolean bl3 = this.e(n ^ 0x52C6);
            if (n5 != 0 && 18 < this.lk_wb) {
                --this.lk_wb;
            }
            if (n4 != 0 && !bl3) {
                ge.a(this.lk_sb, this.J / 8, (byte)127, ig.ig_ac);
            }
            if (!bl3) break block36;
            ah.ah_b[this.Q] = true;
            ei ei2 = ik.ik_c[this.Q];
            if (ei2 != null) {
                ei2.b(en.en_o / 50, pb.pb_d * this.J, this.lk_sb << -2127177498);
            } else {
                ei ei3;
                int n10 = 100 + rd.a((byte)16, 4, this.Q);
                ei2 = ei3 = ei.c(kf.P, n10, pb.pb_d * this.J, this.lk_sb << 1719062758);
                ei2.f(-1);
                dg.dg_c.a(ei3);
                ik.ik_c[this.Q] = ei3;
            }
        }
    }

    lk(boolean bl2, int n, int n2, int n3, int n4) {
        if (bl2) {
            this.O = 12;
            this.lk_a = 27;
        } else {
            this.lk_a = 18;
            this.O = 8;
        }
        this.lk_d = n3;
        this.lk_w = new int[this.O * this.lk_a];
        this.D = n2;
        this.lk_c = n4;
        this.P = new int[this.O * this.lk_a];
        this.a(n, 2113050941, false);
        this.lk_t = 0;
        this.lk_m = 0;
    }

    static {
        I = 3;
        lk_i = "There are no valid types of game that match your preferences.";
    }
}
