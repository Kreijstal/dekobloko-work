/*
 * Decompiled with CFR 0.152.
 */
final class ih {
    private static int[] ih_i;
    private static float[] ih_c;
    private static boolean[] ih_e;
    private int[] ih_b;
    private int[] ih_a;
    private static int[] ih_h;
    private int[][] ih_k;
    private int[] ih_d;
    private int[] ih_f;
    private int ih_j;
    private int[] ih_l;
    private static int[] ih_g;

    private final void a(int n, int n2) {
        if (n >= n2) {
            return;
        }
        int n3 = n;
        int n4 = ih_h[n3];
        int n5 = ih_i[n3];
        boolean bl = ih_e[n3];
        for (int i = n + 1; i <= n2; ++i) {
            int n6 = ih_h[i];
            if (n6 >= n4) continue;
            ih.ih_h[n3] = n6;
            ih.ih_i[n3] = ih_i[i];
            ih.ih_e[n3] = ih_e[i];
            ih.ih_h[i] = ih_h[++n3];
            ih.ih_i[i] = ih_i[n3];
            ih.ih_e[i] = ih_e[n3];
        }
        ih.ih_h[n3] = n4;
        ih.ih_i[n3] = n5;
        ih.ih_e[n3] = bl;
        this.a(n, n3 - 1);
        this.a(n3 + 1, n2);
    }

    private static final int a(int[] nArray, int n) {
        int n2 = nArray[n];
        int n3 = -1;
        int n4 = Integer.MAX_VALUE;
        for (int i = 0; i < n; ++i) {
            int n5 = nArray[i];
            if (n5 <= n2 || n5 >= n4) continue;
            n3 = i;
            n4 = n5;
        }
        return n3;
    }

    final boolean a() {
        boolean bl;
        boolean bl2 = bl = va.b() != 0;
        if (!bl) {
            return false;
        }
        int n = this.ih_f.length;
        System.arraycopy(this.ih_f, 0, ih_h, 0, n);
        int n2 = ih_g[this.ih_j - 1];
        int n3 = s.b((byte)6, n2 - 1);
        ih.ih_i[0] = va.c(n3);
        ih.ih_i[1] = va.c(n3);
        int n4 = 2;
        for (int i = 0; i < this.ih_a.length; ++i) {
            int n5 = this.ih_a[i];
            int n6 = this.ih_l[n5];
            int n7 = this.ih_b[n5];
            int n8 = (1 << n7) - 1;
            int n9 = 0;
            if (n7 > 0) {
                n9 = va.S[this.ih_d[n5]].a();
            }
            for (int j = 0; j < n6; ++j) {
                int n10 = this.ih_k[n5][n9 & n8];
                n9 >>>= n7;
                ih.ih_i[n4++] = n10 >= 0 ? va.S[n10].a() : 0;
            }
        }
        return true;
    }

    private final int a(int n, int n2, int n3, int n4, int n5) {
        int n6 = n4 - n2;
        int n7 = n3 - n;
        int n8 = n6 < 0 ? -n6 : n6;
        int n9 = n8 * (n5 - n);
        int n10 = n9 / n7;
        return n6 < 0 ? n2 - n10 : n2 + n10;
    }

    private static final int b(int[] nArray, int n) {
        int n2 = nArray[n];
        int n3 = -1;
        int n4 = Integer.MIN_VALUE;
        for (int i = 0; i < n; ++i) {
            int n5 = nArray[i];
            if (n5 >= n2 || n5 <= n4) continue;
            n3 = i;
            n4 = n5;
        }
        return n3;
    }

    public static void b() {
        ih_g = null;
        ih_c = null;
        ih_h = null;
        ih_i = null;
        ih_e = null;
    }

    private final void a(int n, int n2, int n3, int n4, float[] fArray, int n5) {
        int n6 = n4 - n2;
        int n7 = n3 - n;
        int n8 = n6 < 0 ? -n6 : n6;
        int n9 = n6 / n7;
        int n10 = n2;
        int n11 = 0;
        int n12 = n6 < 0 ? n9 - 1 : n9 + 1;
        n8 -= (n9 < 0 ? -n9 : n9) * n7;
        int n13 = n;
        fArray[n13] = fArray[n13] * ih_c[n10];
        if (n3 > n5) {
            n3 = n5;
        }
        int n14 = n + 1;
        while (n14 < n3) {
            if ((n11 += n8) >= n7) {
                n11 -= n7;
                n10 += n12;
            } else {
                n10 += n9;
            }
            int n15 = n14++;
            fArray[n15] = fArray[n15] * ih_c[n10];
        }
    }

    final void a(float[] fArray, int n) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8 = this.ih_f.length;
        int n9 = ih_g[this.ih_j - 1];
        boolean[] blArray = ih_e;
        ih.ih_e[1] = true;
        blArray[0] = true;
        for (n7 = 2; n7 < n8; ++n7) {
            n6 = ih.b(ih_h, n7);
            n5 = ih.a(ih_h, n7);
            n4 = this.a(ih_h[n6], ih_i[n6], ih_h[n5], ih_i[n5], ih_h[n7]);
            n3 = ih_i[n7];
            int n10 = n9 - n4;
            int n11 = n4;
            int n12 = (n10 < n11 ? n10 : n11) << 1;
            if (n3 != 0) {
                boolean[] blArray2 = ih_e;
                int n13 = n6;
                ih.ih_e[n5] = true;
                blArray2[n13] = true;
                ih.ih_e[n7] = true;
                if (n3 >= n12) {
                    ih.ih_i[n7] = n10 > n11 ? n3 - n11 + n4 : n4 - n3 + n10 - 1;
                    continue;
                }
                ih.ih_i[n7] = (n3 & 1) != 0 ? n4 - (n3 + 1) / 2 : n4 + n3 / 2;
                continue;
            }
            ih.ih_e[n7] = false;
            ih.ih_i[n7] = n4;
        }
        this.a(0, n8 - 1);
        n7 = 0;
        n6 = ih_i[0] * this.ih_j;
        n5 = n2 = 1;
        while (n2 < n8) {
            if (ih_e[n2]) {
                n4 = ih_h[n2];
                n3 = ih_i[n2] * this.ih_j;
                this.a(n7, n6, n4, n3, fArray, n);
                if (n4 >= n) {
                    return;
                }
                n7 = n4;
                n6 = n3;
            }
            ++n2;
        }
        float f = ih_c[n6];
        n4 = n7;
        while (n4 < n) {
            int n14 = n4++;
            fArray[n14] = fArray[n14] * f;
        }
    }

    ih() {
        int n;
        int n2;
        int n3;
        int n4;
        int n5 = va.c(16);
        if (n5 != 1) {
            throw new RuntimeException();
        }
        int n6 = va.c(5);
        int n7 = 0;
        this.ih_a = new int[n6];
        for (n4 = 0; n4 < n6; ++n4) {
            this.ih_a[n4] = n3 = va.c(4);
            if (n3 < n7) continue;
            n7 = n3 + 1;
        }
        this.ih_l = new int[n7];
        this.ih_b = new int[n7];
        this.ih_d = new int[n7];
        this.ih_k = new int[n7][];
        for (n4 = 0; n4 < n7; ++n4) {
            this.ih_l[n4] = va.c(3) + 1;
            this.ih_b[n4] = va.c(2);
            n3 = this.ih_b[n4];
            if (n3 != 0) {
                this.ih_d[n4] = va.c(8);
            }
            n3 = 1 << n3;
            int[] nArray = new int[n3];
            this.ih_k[n4] = nArray;
            for (n2 = 0; n2 < n3; ++n2) {
                nArray[n2] = va.c(8) - 1;
            }
        }
        this.ih_j = va.c(2) + 1;
        n4 = va.c(4);
        n3 = 2;
        for (n = 0; n < n6; ++n) {
            n3 += this.ih_l[this.ih_a[n]];
        }
        this.ih_f = new int[n3];
        this.ih_f[0] = 0;
        this.ih_f[1] = 1 << n4;
        n3 = 2;
        for (n = 0; n < n6; ++n) {
            n2 = this.ih_a[n];
            for (int i = 0; i < this.ih_l[n2]; ++i) {
                this.ih_f[n3++] = va.c(n4);
            }
        }
        if (ih_h == null || ih_h.length < n3) {
            ih_h = new int[n3];
            ih_i = new int[n3];
            ih_e = new boolean[n3];
            return;
        }
    }

    static {
        ih_c = new float[]{1.0649863E-7f, 1.1341951E-7f, 1.2079015E-7f, 1.2863978E-7f, 1.369995E-7f, 1.459025E-7f, 1.5538409E-7f, 1.6548181E-7f, 1.7623574E-7f, 1.8768856E-7f, 1.998856E-7f, 2.128753E-7f, 2.2670913E-7f, 2.4144197E-7f, 2.5713223E-7f, 2.7384212E-7f, 2.9163792E-7f, 3.1059022E-7f, 3.307741E-7f, 3.5226967E-7f, 3.7516213E-7f, 3.995423E-7f, 4.255068E-7f, 4.5315863E-7f, 4.8260745E-7f, 5.1397E-7f, 5.4737063E-7f, 5.829419E-7f, 6.208247E-7f, 6.611694E-7f, 7.041359E-7f, 7.4989464E-7f, 7.98627E-7f, 8.505263E-7f, 9.057983E-7f, 9.646621E-7f, 1.0273513E-6f, 1.0941144E-6f, 1.1652161E-6f, 1.2409384E-6f, 1.3215816E-6f, 1.4074654E-6f, 1.4989305E-6f, 1.5963394E-6f, 1.7000785E-6f, 1.8105592E-6f, 1.9282195E-6f, 2.053526E-6f, 2.1869757E-6f, 2.3290977E-6f, 2.4804558E-6f, 2.6416496E-6f, 2.813319E-6f, 2.9961443E-6f, 3.1908505E-6f, 3.39821E-6f, 3.619045E-6f, 3.8542307E-6f, 4.1047006E-6f, 4.371447E-6f, 4.6555283E-6f, 4.958071E-6f, 5.280274E-6f, 5.623416E-6f, 5.988857E-6f, 6.3780467E-6f, 6.7925284E-6f, 7.2339453E-6f, 7.704048E-6f, 8.2047E-6f, 8.737888E-6f, 9.305725E-6f, 9.910464E-6f, 1.0554501E-5f, 1.1240392E-5f, 1.1970856E-5f, 1.2748789E-5f, 1.3577278E-5f, 1.4459606E-5f, 1.5399271E-5f, 1.6400005E-5f, 1.7465769E-5f, 1.8600793E-5f, 1.9809577E-5f, 2.1096914E-5f, 2.2467912E-5f, 2.3928002E-5f, 2.5482977E-5f, 2.7139005E-5f, 2.890265E-5f, 3.078091E-5f, 3.2781227E-5f, 3.4911533E-5f, 3.718028E-5f, 3.9596467E-5f, 4.2169668E-5f, 4.491009E-5f, 4.7828602E-5f, 5.0936775E-5f, 5.424693E-5f, 5.7772202E-5f, 6.152657E-5f, 6.552491E-5f, 6.9783084E-5f, 7.4317984E-5f, 7.914758E-5f, 8.429104E-5f, 8.976875E-5f, 9.560242E-5f, 1.0181521E-4f, 1.0843174E-4f, 1.1547824E-4f, 1.2298267E-4f, 1.3097477E-4f, 1.3948625E-4f, 1.4855085E-4f, 1.5820454E-4f, 1.6848555E-4f, 1.7943469E-4f, 1.9109536E-4f, 2.0351382E-4f, 2.167393E-4f, 2.3082423E-4f, 2.4582449E-4f, 2.6179955E-4f, 2.7881275E-4f, 2.9693157E-4f, 3.1622787E-4f, 3.3677815E-4f, 3.5866388E-4f, 3.8197188E-4f, 4.0679457E-4f, 4.3323037E-4f, 4.613841E-4f, 4.913675E-4f, 5.2329927E-4f, 5.573062E-4f, 5.935231E-4f, 6.320936E-4f, 6.731706E-4f, 7.16917E-4f, 7.635063E-4f, 8.1312325E-4f, 8.6596457E-4f, 9.2223985E-4f, 9.821722E-4f, 0.0010459992f, 0.0011139743f, 0.0011863665f, 0.0012634633f, 0.0013455702f, 0.0014330129f, 0.0015261382f, 0.0016253153f, 0.0017309374f, 0.0018434235f, 0.0019632196f, 0.0020908006f, 0.0022266726f, 0.0023713743f, 0.0025254795f, 0.0026895993f, 0.0028643848f, 0.0030505287f, 0.003248769f, 0.0034598925f, 0.0036847359f, 0.0039241905f, 0.0041792067f, 0.004450795f, 0.004740033f, 0.005048067f, 0.0053761187f, 0.005725489f, 0.0060975635f, 0.0064938175f, 0.0069158226f, 0.0073652514f, 0.007843887f, 0.008353627f, 0.008896492f, 0.009474637f, 0.010090352f, 0.01074608f, 0.011444421f, 0.012188144f, 0.012980198f, 0.013823725f, 0.014722068f, 0.015678791f, 0.016697686f, 0.017782796f, 0.018938422f, 0.020169148f, 0.021479854f, 0.022875736f, 0.02436233f, 0.025945531f, 0.027631618f, 0.029427277f, 0.031339627f, 0.03337625f, 0.035545226f, 0.037855156f, 0.0403152f, 0.042935107f, 0.045725275f, 0.048696756f, 0.05186135f, 0.05523159f, 0.05882085f, 0.062643364f, 0.06671428f, 0.07104975f, 0.075666964f, 0.08058423f, 0.08582105f, 0.09139818f, 0.097337745f, 0.1036633f, 0.11039993f, 0.11757434f, 0.12521498f, 0.13335215f, 0.14201812f, 0.15124726f, 0.16107617f, 0.1715438f, 0.18269168f, 0.19456401f, 0.20720787f, 0.22067343f, 0.23501402f, 0.25028655f, 0.26655158f, 0.28387362f, 0.3023213f, 0.32196787f, 0.34289113f, 0.36517414f, 0.3889052f, 0.41417846f, 0.44109413f, 0.4697589f, 0.50028646f, 0.53279793f, 0.5674221f, 0.6042964f, 0.64356697f, 0.6853896f, 0.72993004f, 0.777365f, 0.8278826f, 0.88168305f, 0.9389798f, 1.0f};
        ih_g = new int[]{256, 128, 86, 64};
    }
}
