/*
 * Decompiled with CFR 0.152.
 */
final class dj
extends kf
implements vn {
    private String Z;
    private gk W;
    static StringBuilder dj_ab;
    private ek[] V;
    static int[][] T;
    private int U = 0;
    private mm X;
    static nh dj_cb;
    private int[] S;
    static ck dj_eb;
    static int Y;
    static String dj_db;
    static String dj_bb;

    dj(gk gk2, mm mm2, String string) {
        super(0, 0, 288, 0, null);
        this.X = mm2;
        this.Z = string;
        this.W = gk2;
        int n = null == this.Z ? 0 : this.X.b(this.Z, 260, this.X.R);
        this.b(n + 22, 288, 0, 0, -16555);
    }

    static final int a(int n) {
        block0: {
            if (n >= 106) break block0;
            dj.b(false);
        }
        return ig.ig_dc;
    }

    public static void b(boolean bl) {
        dj_ab = null;
        if (!bl) {
            return;
        }
        dj_eb = null;
        T = null;
        dj_bb = null;
        dj_db = null;
        dj_cb = null;
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        block0: {
            super.a(n, -104, n3, n4);
            this.X.a(this.Z, n - (-this.ce_u - 14), this.D + (n4 + 10), this.ce_t - 28, this.y, 0xFFFFFF, -1, 0, 0, this.X.R);
            if (n2 <= -103) break block0;
            this.a(67, 1, 70, -22);
        }
    }

    private final void b(int n, int n2) {
        int n3;
        ek[] ekArray;
        boolean bl = client.A;
        if (this.U >= n) {
            return;
        }
        ek[] ekArray2 = ekArray = new ek[n];
        int[] nArray = new int[n];
        for (n3 = 0; n3 < this.U; ++n3) {
            ekArray[n3] = this.V[n3];
            nArray[n3] = this.S[n3];
        }
        this.U = n;
        n3 = -117 % ((50 - n2) / 51);
        this.S = nArray;
        this.V = ekArray2;
    }

    final ek a(int n, String string, kg kg2) {
        ek ek2 = new ek(string, kg2);
        ek2.ce_p = new fk();
        int n2 = -2 + this.y;
        if (n <= 95) {
            return null;
        }
        this.b(this.y + 34, this.ce_t, 0, 0, -16555);
        ek2.b(30, -14 + this.ce_t, 7, n2, -16555);
        this.b(ek2, (byte)-55);
        return ek2;
    }

    final void a(String string, int n, int n2) {
        if (n2 != 14) {
            this.Z = null;
        }
        int n3 = this.U;
        this.b(1 + n3, -104);
        this.V[n3] = this.a(103, string, this);
        this.S[n3] = n;
    }

    static final void a(ud ud2, int n) {
        block0: {
            ai.a(98, 0, ud2, 128, 128);
            if (n == 22) break block0;
            ud ud3 = null;
            dj.a(ud3, 24);
        }
    }

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        boolean bl2 = client.A;
        if (by != 67) {
            dj_db = null;
        }
        for (int i = 0; i < this.U; ++i) {
            if (this.V[i] != ek2) continue;
            int n4 = this.S[i];
            if (~n4 == 0) {
                this.W.n(-123);
                break;
            }
            hm.a(this.S[i], (byte)-109);
            break;
        }
    }

    static {
        T = null;
        dj_ab = new StringBuilder(80);
        dj_bb = "Show lobby chat from my friends";
        dj_db = "Show all game chat";
    }
}
