/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

final class fc {
    static w fc_f;
    static int[] fc_d;
    static w fc_c;
    static int[] fc_b;
    static long fc_h;
    static int fc_a;
    static String fc_g;
    static int fc_e;

    static final void a(int n, byte by, boolean bl, int n2) {
        block1: {
            fl.a(n - -20, 256, 0xFFFFFF, ug.ug_n, n2 - -4, w.w_kb);
            fl.a(12 + (n += 26), 256, 0xFFFFFF, vk.vk_b[0], 4 + n2, se.S);
            ph.yb[0].c(122 + n2, n);
            fl.a(12 + (n += 16), by ^ 0x105, 0xFFFFFF, vk.vk_b[1], n2 - -4, se.S);
            ph.yb[1].c(n2 + 122, n);
            n += 23;
            if (by != 5) {
                String string = null;
                fc.a((byte)7, string);
            }
            fl.a(12 + n, 256, 0xFFFFFF, vk.vk_b[2], 4 + n2, se.S);
            ph.yb[3].c(122 + n2, n);
            fl.a((n += 16) - -12, 256, 0xFFFFFF, vk.vk_b[3], 4 + n2, se.S);
            ph.yb[2].c(n2 + 100, n);
            ed.a(0xFFFFFF, 119 + n2, "/", 12 + n, (byte)75, se.S);
            ph.yb[4].c(122 + n2, n);
            fl.a((n += 23) + 12, 256, 0xFFFFFF, vk.vk_b[5], n2 - -4, se.S);
            ph.yb[5].c(122 + n2, n);
            n += 23;
            if (!bl) break block1;
            fl.a(12 + n, 256, 0xFFFFFF, vk.vk_b[6], 4 + n2, se.S);
            ph.yb[6].c(n2 + 122, n);
        }
    }

    static final void a(int n, boolean bl) {
        block1: {
            if (ea.d((byte)80)) {
                bl = false;
            }
            cg.b(bl, 1);
            ub.a((byte)54);
            if (n == 5) break block1;
            fc_g = null;
        }
    }

    public static void a(int n) {
        if (n < 26) {
            return;
        }
        fc_d = null;
        fc_g = null;
        fc_c = null;
        fc_f = null;
        fc_b = null;
    }

    static final ck[] a(int n, ck ck2, int n2) {
        boolean bl = client.A;
        ck[] ckArray = new ck[n];
        int[] nArray = ck2.D;
        int n3 = ck2.K / n;
        if (n2 != -10241) {
            return null;
        }
        int n4 = ck2.I - n3;
        for (int i = 0; i < n; ++i) {
            ck ck3 = ckArray[i] = new ck(n3, ck2.H);
            int[] nArray2 = ck3.D;
            int n5 = i * n3 + ck2.F;
            int n6 = ck2.z;
            int n7 = n6 * n3 + n5;
            int n8 = 0;
            int n9 = -ck2.H;
            while (~n9 > -1) {
                int n10 = -n3;
                while (-1 < ~n10) {
                    nArray2[n8++] = nArray[n7++];
                    ++n10;
                }
                n7 += n4;
                ++n9;
            }
        }
        return ckArray;
    }

    static final boolean a(byte by, String string) {
        boolean bl = client.A;
        try {
            if (!fd.fd_d.startsWith("win")) {
                return false;
            }
            if (!string.startsWith("http://") && !string.startsWith("https://")) {
                return false;
            }
            String string2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789?&=,.%+-_#:/*";
            for (int i = 0; i < string.length(); ++i) {
                if (0 != ~string2.indexOf(string.charAt(i))) continue;
                return false;
            }
            Runtime.getRuntime().exec("cmd /c start \"j\" \"" + string + "\"");
            return by == -19;
        }
        catch (Exception exception) {
            return false;
        }
    }

    static final void a(byte by) {
        boolean bl = client.A;
        if (ta.ta_k != null) {
            ta.ta_k.d((byte)117);
        }
        if (qb.qb_r != null) {
            qb.qb_r.a((byte)-98);
        }
        if (null != mk.mk_d) {
            try {
                mk.mk_d.c((byte)124);
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        int n = -32 % ((by - -41) / 50);
        if (null != ig.ig_cc) {
            for (int i = 0; ig.ig_cc.length > i; ++i) {
                if (ig.ig_cc[i] == null) continue;
                try {
                    ig.ig_cc[i].c((byte)125);
                    continue;
                }
                catch (IOException iOException) {
                    // empty catch block
                }
            }
        }
    }

    static {
        fc_d = new int[8192];
        fc_g = "Cancel";
        fc_b = new int[]{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    }
}
