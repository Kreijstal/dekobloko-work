/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import netscape.javascript.JSObject;

final class nc {
    static final void a(byte by, Applet applet, String string) throws Throwable {
        JSObject.getWindow(applet).eval(string);
        if (by != -51) {
            return;
        }
    }

    static final Object a(String string, int n, Applet applet, Object[] objectArray) throws Throwable {
        if (n != -14541) {
            return null;
        }
        return JSObject.getWindow(applet).call(string, objectArray);
    }

    static final Object a(boolean bl, String string, Applet applet) throws Throwable {
        if (!bl) {
            return null;
        }
        return JSObject.getWindow(applet).call(string, null);
    }
}
