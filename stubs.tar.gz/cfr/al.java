/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;

final class al
implements gl {
    static String al_a = "Friends";
    private int al_i;
    private int al_f;
    static String al_j = "Updates will sent to the email address you've given";
    private int al_d;
    private mm al_g;
    private int al_c;
    private int al_b;
    private int al_e;
    static ha al_h;
    private int al_k;

    public static void a(byte by) {
        al_a = null;
        if (by != -100) {
            al_j = null;
        }
        al_h = null;
        al_j = null;
    }

    static final void a(int n, Component component) {
        if (n != -2204) {
            al.a((byte)21);
        }
        component.addMouseListener(ik.ik_f);
        component.addMouseMotionListener(ik.ik_f);
        component.addFocusListener(ik.ik_f);
    }

    @Override
    public final void a(boolean bl, int n, int n2, byte by, ce ce2) {
        block3: {
            int n3;
            int n4;
            double d;
            ai ai2 = (ai)(ce2 instanceof ai ? ce2 : null);
            if (ai2 != null) {
                // empty if block
            }
            hk.a(n + ce2.ce_u, n2 + ce2.D, ce2.ce_t, ce2.y, this.al_d);
            int n5 = n - (-ce2.ce_u + -ai2.O);
            int n6 = n2 - -ce2.D - -ai2.V;
            hk.e(n5, n6, ai2.K, this.al_f);
            if (~ai2.S != 0) {
                d = Math.PI * (double)ai2.S * 2.0 / (double)ai2.Q;
                n4 = (int)(-Math.sin(d) * (double)ai2.K);
                n3 = (int)(Math.cos(d) * (double)ai2.K);
                hk.e(n4 + n5, n6 - -n3, 1, this.al_e);
            }
            hk.e(n5, n6, 2, 1);
            d = Math.PI * (double)ai2.R * 2.0 / (double)ai2.Q;
            n4 = (int)(-Math.sin(d) * (double)ai2.K);
            n3 = (int)(Math.cos(d) * (double)ai2.K);
            hk.b(n5, n6, n4 + n5, n6 - -n3, 1);
            if (this.al_g != null) {
                int n7 = this.al_k + (ai2.K + ai2.O);
                this.al_g.a(ce2.E, n - (-ce2.ce_u - n7), ce2.D + (n2 + this.al_b), -this.al_k - (n7 - ce2.ce_t), ce2.y + -(this.al_k << -1217244063), this.al_c, this.al_i, 1, 1, 0);
            }
            if (by <= -60) break block3;
            al_j = null;
        }
    }

    static final int a(int n, int n2) {
        boolean bl = client.A;
        d.d_f = null;
        hd.hd_n = n;
        rk.L = null;
        int n3 = cb.cb_c;
        cb.cb_c = gm.H;
        ta.ta_k.dd_o = 51 == n2 ? 2 : (~n2 == -51 ? 5 : 1);
        ++ta.ta_k.dd_j;
        gm.H = n3;
        if (-3 >= ~ta.ta_k.dd_j && 51 == n2) {
            return 2;
        }
        if (2 <= ta.ta_k.dd_j && -51 == ~n2) {
            return 5;
        }
        if (~ta.ta_k.dd_j <= -5) {
            return 1;
        }
        return -1;
    }

    al(mm mm2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        this.al_g = mm2;
        this.al_i = n4;
        this.al_c = n3;
        this.al_e = n6;
        this.al_d = n7;
        this.al_f = n5;
        this.al_b = n2;
        this.al_k = n;
    }
}
