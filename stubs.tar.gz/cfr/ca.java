/*
 * Decompiled with CFR 0.152.
 */
abstract class ca
extends t {
    private ef ca_ub;
    private int ca_nb;
    private int ca_tb;
    static int ca_vb;
    static ke ca_wb;
    private int ca_lb;
    private ce ca_sb;
    private i ca_pb;
    private int ca_rb;
    private int ca_mb;
    static ck ca_qb;
    static int ca_kb;
    static String ca_ob;

    @Override
    final void j(byte by) {
        if (this.ca_pb == da.da_b) {
            return;
        }
        int n = -119 % ((by - 30) / 39);
        this.ca_rb = 0;
        this.ca_pb = rb.rb_c;
        this.a(this.ca_sb, -29870);
        this.ca_ub.Q = 0;
        this.ca_sb = null;
    }

    private final void a(ce ce2, int n) {
        block3: {
            if (this.ca_ub != null) {
                this.ca_ub.b((byte)111);
            }
            if (null == ce2) {
                this.ca_ub = new ef();
            } else {
                ce2.b(ce2.y, ce2.ce_t, 6, this.ca_nb + 6, -16555);
                this.ca_ub = new ef(ce2);
            }
            this.b(this.ca_ub, (byte)-55);
            this.ca_sb = null;
            if (n == -29870) break block3;
            ce ce3 = null;
            this.c(ce3, (byte)-56);
        }
    }

    static final void a(String string, String string2, String string3, byte by, int n, int n2) {
        hl hl2 = new hl(n, string, n2, string2, string3);
        rb.a(hl2, -3);
        int n3 = 121 % ((20 - by) / 42);
    }

    static final ck[] a(int n, int n2, int n3, int n4, int n5, boolean bl2, int n6, int n7, int n8) {
        int n9;
        int n10;
        ck[] ckArray;
        boolean bl3 = client.A;
        int n11 = n2 + (n4 + n5);
        ck[] ckArray2 = ckArray = new ck[]{new ck(n11, n11), new ck(n8, n11), new ck(n11, n11), new ck(n11, n8), new ck(64, 64), new ck(n11, n8), new ck(n11, n11), new ck(n8, n11), new ck(n11, n11)};
        if (bl2) {
            ca_kb = -21;
        }
        for (n10 = 0; ckArray2.length > n10; ++n10) {
            ck ck2 = ckArray2[n10];
            for (int j = 0; j < ck2.D.length; ++j) {
                ck2.D[j] = n;
            }
        }
        for (n9 = 0; n9 < n4; ++n9) {
            for (n10 = 0; n11 > n10; ++n10) {
                ckArray[6].D[n10 + (n11 + -n9 - 1) * n11] = n3;
                ckArray[8].D[(-1 + (n11 + -n9)) * n11 + n10] = n3;
                ckArray[2].D[-n9 - 1 - -n11 + n10 * n11] = n3;
                ckArray[8].D[n10 * n11 + (-n9 + (-1 + n11))] = n3;
            }
        }
        for (n9 = 0; n9 < n4; ++n9) {
            for (n10 = 0; n11 > n10; ++n10) {
                ckArray[0].D[n10 - -(n11 * n9)] = n7;
                ckArray[0].D[n11 * n10 + n9] = n7;
                if (~(-n9 + n11) >= ~n10) continue;
                ckArray[2].D[n10 - -(n9 * n11)] = n7;
                ckArray[6].D[n10 * n11 + n9] = n7;
            }
        }
        n9 = 0;
        while (~n8 < ~n9) {
            n10 = 0;
            while (~n10 > ~n4) {
                ckArray[7].D[(-1 + n11 - n10) * n8 + n9] = n3;
                ckArray[5].D[-n10 - (1 + -n11 - n9 * n11)] = n3;
                ckArray[1].D[n10 * n8 + n9] = n7;
                ckArray[3].D[n11 * n9 - -n10] = n7;
                ++n10;
            }
            ++n9;
        }
        for (n9 = 0; n8 >> 949160769 > n9; ++n9) {
            n10 = 0;
            while (~n10 > ~n5) {
                ckArray[1].D[n9 + n8 * (-1 + -n10 + n11)] = n6;
                ckArray[3].D[-n10 - (1 + -n11 - n11 * n9)] = n6;
                ckArray[7].D[n10 * n8 - -n9] = n6;
                ckArray[5].D[n10 + n11 * n9] = n6;
                ++n10;
            }
        }
        return ckArray;
    }

    void c(ce ce2, byte by) {
        block2: {
            block1: {
                if (by < 10) {
                    ca_kb = -79;
                }
                this.ca_sb = ce2;
                if (fh.fh_e != this.ca_pb) break block1;
                this.b(this.ca_sb.ce_t + 12, this.ca_tb, this.ca_sb.y + this.ca_nb + 12, 194);
                this.ca_rb = 0;
                break block2;
            }
            if (da.da_b == this.ca_pb) break block2;
            this.ca_pb = da.da_b;
            this.ca_rb = 0;
        }
    }

    static final ck[] m(int n) {
        boolean bl2 = client.A;
        ck[] ckArray = new ck[ec.ec_g];
        for (int j = n; j < ec.ec_g; ++j) {
            int n2 = hc.hc_c[j] * tm.tm_a[j];
            byte[] byArray = tc.Nb[j];
            if (!da.da_d[j]) {
                int[] nArray = new int[n2];
                for (int k = 0; n2 > k; ++k) {
                    nArray[k] = mb.mb_d[lb.a(255, byArray[k])];
                }
                ckArray[j] = new ck(ed.ed_f, i.i_d, sg.sg_d[j], fh.fh_a[j], tm.tm_a[j], hc.hc_c[j], nArray);
                continue;
            }
            byte[] byArray2 = pd.pd_e[j];
            int[] nArray = new int[n2];
            for (int k = 0; n2 > k; ++k) {
                nArray[k] = de.b(lb.a(byArray2[k], 255) << -1019066312, mb.mb_d[lb.a(byArray[k], 255)]);
            }
            ckArray[j] = new ld(ed.ed_f, i.i_d, sg.sg_d[j], fh.fh_a[j], tm.tm_a[j], hc.hc_c[j], nArray);
        }
        oa.a(126);
        return ckArray;
    }

    public static void l(int n) {
        if (n <= 72) {
            return;
        }
        ca_wb = null;
        ca_ob = null;
        ca_qb = null;
    }

    @Override
    boolean a(int n, int n2, ce ce2, char c) {
        if (super.a(82, n2, ce2, c)) {
            return true;
        }
        int n3 = 54 % ((n - -22) / 49);
        if (this.ca_ub != null) {
            if (98 == n2) {
                this.ca_ub.a(false, ce2);
            }
            if (~n2 != -100) {
                return false;
            }
            this.ca_ub.a(false, ce2);
        }
        return false;
    }

    @Override
    final void j(int n) {
        if (null != this.ca_pb) {
            if (this.ca_pb != rb.rb_c) {
                this.a(108, this.ca_sb.ce_t + 12, this.ca_nb + 12 - -this.ca_sb.y);
                this.a(this.ca_sb, -29870);
            }
            this.ca_ub.Q = 256;
            this.ca_pb = null;
        }
        super.j(92);
        int n2 = 11 % ((-15 - n) / 49);
    }

    @Override
    boolean h(byte by) {
        block5: {
            block6: {
                boolean bl2 = client.A;
                if (by <= 15) {
                    ca_kb = -126;
                }
                if (this.ca_pb == null) break block5;
                if (da.da_b == this.ca_pb) break block6;
                if (this.ca_pb != rb.rb_c) break block5;
                if (++this.ca_rb != this.ca_mb) {
                    this.ca_ub.Q = (this.ca_rb << -1699061016) / this.ca_mb;
                } else {
                    this.ca_ub.Q = 256;
                    this.ca_pb = null;
                }
                break block5;
            }
            if (~(++this.ca_rb) != ~this.ca_lb) {
                this.ca_ub.Q = -((this.ca_rb << 1615067112) / this.ca_lb) + 256;
            } else {
                this.ca_pb = fh.fh_e;
                this.b(12 + this.ca_sb.ce_t, this.ca_tb, this.ca_nb + 12 - -this.ca_sb.y, 194);
                this.ca_ub.Q = 0;
                this.ca_rb = 0;
            }
        }
        return super.h((byte)47);
    }

    ca(ka ka2, ce ce2, int n, int n2, int n3) {
        super(ka2, ce2.ce_t + 12, 12 + (n - -ce2.y));
        this.ca_lb = this.ca_mb = n2;
        this.ca_nb = n;
        this.ca_tb = n3;
        this.a(ce2, -29870);
    }

    @Override
    final boolean f(byte by) {
        if (by <= 77) {
            this.ca_pb = null;
        }
        this.j(-109);
        return super.f((byte)116);
    }

    static {
        ca_ob = "Your ignore list is full. Max of 100 hit.";
    }
}
