/*
 * Decompiled with CFR 0.152.
 */
final class vf {
    static String vf_c;
    static boolean vf_a;
    static String vf_e;
    static int vf_b;
    static String vf_d;

    public static void a(int n) {
        if (n != 27067) {
            vf_a = false;
        }
        vf_e = null;
        vf_d = null;
        vf_c = null;
    }

    static final StringBuilder a(StringBuilder stringBuilder, int n, int n2, char c) {
        boolean bl = client.A;
        int n3 = stringBuilder.length();
        stringBuilder.setLength(n2);
        if (n != -23510) {
            vf_c = null;
        }
        int n4 = n3;
        while (~n2 < ~n4) {
            stringBuilder.setCharAt(n4, c);
            ++n4;
        }
        return stringBuilder;
    }

    static {
        vf_e = "Please enter your date of birth to enable chat:";
        vf_c = "Fruit";
        vf_d = "This private message is prefixed with \"<col=9090FF>To <%1>:</col>\" on your screen.<br>On <%1>'s screen, it will be prefixed with \"<col=FF6060>From <%0>:</col>\", which is<br>a different length and may leave less room for the message itself.<br><br>This shading covers the area which is not available on <%1>'s screen.<br>Provided your message fits to the left of the shaded area,<br><%1> should be able to see it in full.<br><br>(Note: this may be inaccurate if <%1> is playing in a different<br>language from you.)";
    }
}
