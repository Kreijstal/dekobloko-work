/*
 * Decompiled with CFR 0.152.
 */
final class fh {
    static String fh_b = "<%0> WINS!";
    static int[] fh_a;
    static int fh_h;
    static i fh_e;
    static int fh_f;
    static w fh_g;
    static ud fh_c;
    static w fh_d;

    static final void a(int n, int n2, boolean bl, int n3) {
        boolean bl2 = client.A;
        if (!bl) {
            return;
        }
        int n4 = 320;
        int n5 = 490;
        int n6 = 0;
        while (~n6 > ~rb.rb_n.length) {
            int n7 = rb.rb_n[n6] >> 1058191496 & 0xFF;
            int n8 = 0xFF & rb.rb_n[n6] >> -496612168;
            int n9 = (2048 * n7 >> -208576440) - -(bb.bb_f * (1 + n8) >> -1499643386);
            int n10 = rb.rb_n[n6] >> -226715728 & 0xFF;
            int n11 = 0xFF & rb.rb_n[n6];
            int n12 = ke.a(2047, n9) >> -200783770;
            int n13 = h.a(n9, (byte)-122) >> -1071707034;
            int n14 = ke.a(2047, n11 + n9) >> -1246657338;
            int n15 = h.a(n9 + n11, (byte)-122) >> -1683979834;
            int[] nArray = new int[]{n4 + n3, n - -n5, n12 + n3, n + n13, n3 - -n14, n15 + n};
            if (256 != n2) {
                ok.a(nArray, 0xFFFFFF, n10 * 256 >> 431644137);
            } else {
                ok.a(nArray, 0xFFFFFF, n10);
            }
            ++n6;
        }
    }

    static final void b(byte by) {
        block0: {
            s.g((byte)-115);
            if (by <= -122) break block0;
            fh.a(-67);
        }
    }

    static final void a(byte by, cl cl2, int n) {
        uf uf2 = we.we_b;
        int n2 = -58 / ((by - 59) / 33);
        uf2.f(n, -4);
        uf2.a(true, cl2.cl_q);
        uf2.a(true, cl2.z);
    }

    static final boolean a(byte by) {
        int n = 114 % ((by - 70) / 46);
        if (0 == ~sm.sm_e) {
            if (!pe.b(25973, 1)) {
                return false;
            }
            sm.sm_e = de.V.d((byte)-64);
            de.V.wl_n = 0;
        }
        if (sm.sm_e == -2) {
            if (!pe.b(25973, 2)) {
                return false;
            }
            sm.sm_e = de.V.e(3);
            de.V.wl_n = 0;
        }
        return pe.b(25973, sm.sm_e);
    }

    public static void b(int n) {
        fh_c = null;
        fh_d = null;
        fh_e = null;
        fh_b = null;
        fh_a = null;
        if (n != 0) {
            return;
        }
        fh_g = null;
    }

    static final void a(int n) {
        boolean bl2 = client.A;
        if (!uk.a(-22802)) {
            if (cl.cl_v != null) {
                if (cl.cl_v.ql_e) {
                    sn.a(false);
                    u.u_i.a((byte)-105, (ce)new ib(u.u_i, kl.kl_p));
                }
                return;
            }
        } else {
            int n2 = -26 % ((n - 37) / 58);
            u.u_i.a(jd.Yb, true, ab.ab_f, 29166);
            u.u_i.g(0);
            while (ab.c((byte)50)) {
                u.u_i.a(wh.wh_c, el.G, (byte)121);
            }
            return;
        }
    }

    static {
        fh_e = new i();
    }
}
