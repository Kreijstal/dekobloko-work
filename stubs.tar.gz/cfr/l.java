/*
 * Decompiled with CFR 0.152.
 */
final class l {
    static int l_c;
    static ck[] l_d;
    static int l_f;
    static ck l_b;
    static String l_e;
    static dh[] l_i;
    static ck l_j;
    static w l_a;
    static long l_h;
    static int[] l_g;

    static final w a(int n) {
        if (n > -72) {
            return null;
        }
        return wf.c(-122);
    }

    static final int[] c(int n) {
        int[] nArray;
        boolean bl = client.A;
        if (n != 4) {
            l.a(64);
        }
        int[] nArray2 = nArray = new int[4];
        for (int i = 0; i < 4; ++i) {
            nArray[i] = bf.y.nextInt();
        }
        return nArray;
    }

    public static void b(int n) {
        l_a = null;
        l_e = null;
        l_j = null;
        if (n < 118) {
            l_h = -47L;
        }
        l_i = null;
        l_b = null;
        l_d = null;
        l_g = null;
    }

    static {
        l_d = new ck[64];
        l_f = 0;
        l_e = "City";
        for (int i = 0; i < 64; ++i) {
            l.l_d[i] = new ck(9, 9);
        }
        l_h = 0L;
        l_g = new int[8];
    }
}
