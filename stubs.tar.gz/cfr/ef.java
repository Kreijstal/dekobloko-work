/*
 * Decompiled with CFR 0.152.
 */
final class ef
extends ma {
    int Q;
    static vj S = new vj();
    static wl R;
    static ck[] O;
    static int[] T;
    static int N;
    static String[] M;
    static String U;
    static int P;

    public static void g(int n) {
        M = null;
        U = null;
        T = null;
        S = null;
        if (n != 0) {
            return;
        }
        O = null;
        R = null;
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        if (n2 > -103) {
            ef.f((byte)-51);
        }
        if (0 != n3) {
            return;
        }
        if (null == this.L) {
            return;
        }
        if (~this.Q == -1) {
            return;
        }
        if (-257 == ~this.Q) {
            this.L.a(n + this.ce_u, -128, n3, this.D + n4);
            return;
        }
        ck ck2 = new ck(this.L.ce_t, this.L.y);
        tb.a(true, ck2);
        this.L.a(0, -107, n3, 0);
        mk.a((byte)-5);
        ck2.c(n - -this.ce_u, n4 - -this.D, this.Q);
    }

    ef(ce ce2) {
        super(ce2.ce_u, ce2.D, ce2.ce_t, ce2.y, null, null);
        ce2.b(this.y, this.ce_t, 0, 0, -16555);
        this.Q = 256;
        this.L = ce2;
    }

    public ef() {
        super(0, 0, 0, 0, null, null);
        this.Q = 256;
    }

    static final void f(byte by) {
        block3: {
            if (~ac.B != ~le.le_m.eh_i) {
                qc.Y += le.le_m.eh_i + -ac.B;
                ac.B = le.le_m.eh_i;
            }
            if (0 < bl.T) {
                --bl.T;
            }
            if (-1 > ~bl.T) {
                on.b((byte)-100);
            }
            if (by >= 51) break block3;
            ef.g(-58);
        }
    }
}
