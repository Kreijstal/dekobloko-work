/*
 * Decompiled with CFR 0.152.
 */
abstract class vb
extends kf
implements jl {
    private qf W;
    static ji S;
    static boolean Z;
    static int[] X;
    static String[] U;
    static int V;
    static String Y;
    static String T;

    abstract int i(int var1);

    public static void j(int n) {
        X = null;
        U = null;
        S = null;
        if (n > -17) {
            vb.j(-12);
        }
        Y = null;
        T = null;
    }

    abstract boolean k(int var1);

    static final void g(byte by) {
        if (by != 105) {
            Z = true;
        }
        qf.a("", -99, null);
    }

    @Override
    public final nb a(int n) {
        block0: {
            if (n <= -86) break block0;
            vb.j(-30);
        }
        return this.W;
    }

    abstract int f(byte var1);

    void a(byte by, qf qf2) {
        if (by < 74) {
            S = null;
        }
        this.W = qf2;
        this.W.qf_g = this;
    }

    static final void a(boolean bl, int n) {
        int n2;
        boolean bl2 = client.A;
        wj.Lb = hk.hk_j;
        vk.vk_f = hk.hk_i;
        qf.a(bl ? bf.bf_r : tg.tg_e, 97);
        je.je_f.a(-42 + ee.ee_i.N, ee.ee_i.w_mb, 0, n + 117, 0);
        he.he_jb.a(in.in_o.w_mb, n ^ 0xFFFFFFFE, 0, kf.O, 0);
        kl.kl_r.a(in.in_o.w_mb - (pd.pd_a ? 2 + (40 + vh.vh_e - -2) : 0), 0, 2 + kf.O, 18, 0);
        ea.A.a(42 - -vh.vh_e, 0, kf.O - n, 18, -40 + (-2 + in.in_o.w_mb - vh.vh_e));
        tb.tb_b.a(6, kf.O + 22, vh.vh_e, 0, -2 + (-kf.O + in.in_o.N) - 20, in.in_o.w_mb, 2);
        ma.G.a(ee.ee_i.w_mb, 0, -40 + ee.ee_i.N, 40, 0);
        fl.fl_b.a(oh.oh_d.w_mb, 0, 0, 30, 0);
        qm.qm_a.a(oh.oh_d.w_mb, 0, 30, -2 + oh.oh_d.N + -70, 0);
        int n3 = j.j_b - -3;
        if (~b.P.length > -3) {
            --n3;
        }
        if (bl) {
            --n3;
        }
        if (~(n2 = (-10 + (-5 + (qm.qm_a.N - 5) - -2 + (n3 - -1) / 2)) / (1 + n3) - 2) < -31) {
            n2 = 30;
        }
        int n4 = -((2 + n2) * n3) + -5 + qm.qm_a.N - 5;
        if (-41 > ~n4) {
            n4 = 40;
        }
        li.li_d.a(-5 + qm.qm_a.w_mb - 5, 0, 5, n4, 5);
        int n5 = n4 + 5 - -2;
        for (int i = 0; i < 4 + j.j_b; ++i) {
            int n6;
            if (1 == i && ~b.P.length > -3 || 3 == i && mg.Vb <= 1) continue;
            if (bl || i != 3) {
                int n7;
                boolean bl3;
                if (bl && i == 0) {
                    w w2 = um.um_c[i];
                    um.um_c[i].N = 0;
                    w2.w_mb = 0;
                    n6 = 0;
                    while (~qa.qa_v[i].length < ~n6) {
                        if (qa.qa_v[i][n6] != null) {
                            qd qd2 = qa.qa_v[i][n6];
                            qa.qa_v[i][n6].N = 0;
                            qd2.w_mb = 0;
                        }
                        ++n6;
                    }
                    continue;
                }
                boolean bl4 = bl3 = bl && i >= 4 && null != bn.bn_f && bn.bn_f[-4 + i];
                if (bl3) {
                    w w3 = um.um_c[i];
                    um.um_c[i].N = 0;
                    w3.w_mb = 0;
                    for (n7 = 0; qa.qa_v[i].length > n7; ++n7) {
                        if (qa.qa_v[i][n7] == null) continue;
                        qd qd3 = qa.qa_v[i][n7];
                        qa.qa_v[i][n7].N = 0;
                        qd3.w_mb = 0;
                    }
                    continue;
                }
                um.um_c[i].a(103, 0, n5, n2, 5);
                n6 = 110;
                if (bl) {
                    qa.qa_v[i][0].a(n2, 2, n6, n5, 38, j.j_c, 500);
                    n6 += 40;
                } else if (qa.qa_v[i][0] != null) {
                    qd qd4 = qa.qa_v[i][0];
                    qa.qa_v[i][0].N = 0;
                    qd4.w_mb = 0;
                }
                n7 = 2 + (-n6 + -5) + oh.oh_d.w_mb;
                int n8 = qa.qa_v[i].length - 1;
                for (int k = 0; n8 > k; ++k) {
                    int n9 = n7 * k / n8;
                    qa.qa_v[i][k - -1].a(n2, 2, n6 + n9, n5, -n9 + ((1 + k) * n7 / n8 + -2), j.j_c, n + 502);
                }
                n5 += 2 + n2;
                continue;
            }
            w w4 = um.um_c[i];
            um.um_c[i].N = 0;
            w4.w_mb = 0;
            for (n6 = 0; qa.qa_v[i].length > n6; ++n6) {
                if (qa.qa_v[i][n6] == null) continue;
                qd qd5 = qa.qa_v[i][n6];
                qa.qa_v[i][n6].N = 0;
                qd5.w_mb = 0;
            }
        }
        mn.mn_e.a(360, n ^ 0xFFFFFFFE, 10, -10 + (-120 + hk.hk_i + -14), hk.hk_j + -360 >> 1115655457);
        ie.ie_a.a(mn.mn_e.w_mb, 0, 0, 24, 0);
        cl.C.a(mn.mn_e.w_mb, 0, 24, mn.mn_e.N - 24, 0);
        cl.C.w_lb = ea.a(1, -20982, 3, cl.C.N, 0x808080, 0xB0B0B0);
        gg.y.a(-10 + cl.C.w_mb, 0, 5, -10 + cl.C.N + -24 - 2, 5);
        qc.qc_q.a(80, 0, -29 + cl.C.N, 24, (-80 + cl.C.w_mb) / 2);
        bf.c((byte)-81);
    }

    vb(int n, int n2, int n3, int n4, gl gl2) {
        super(n, n2, n3, n4, gl2);
    }

    static final int a(int n, int n2, boolean bl) {
        boolean bl2 = client.A;
        int n3 = 1;
        if (bl) {
            X = null;
        }
        while (n2 > 1) {
            if ((1 & n2) != 0) {
                n3 *= n;
            }
            n *= n;
            n2 >>= 1;
        }
        if (-2 == ~n2) {
            return n * n3;
        }
        return n3;
    }

    static final String a(char c2, int n, int n2) {
        char[] cArray;
        boolean bl = client.A;
        char[] cArray2 = cArray = new char[n];
        if (n2 != -12681) {
            X = null;
        }
        for (int i = 0; i < n; ++i) {
            cArray[i] = c2;
        }
        return new String(cArray);
    }

    abstract int b(boolean var1);

    static {
        T = "Show tutorial again";
        Y = "To Customer Support";
        X = new int[]{2, 1, 2, 3, 2, 10, 2, 10, 3, 5, 5, 1, 1, 2, 5, 2, 3, 10, 1, 2, 5, 3, 5, 5, 1, 1, 1, 1, 2, 2, 3};
    }
}
