/*
 * Decompiled with CFR 0.152.
 */
final class he
extends kf
implements qh,
vn {
    private ek X;
    static int he_gb;
    private ek he_ib;
    static int[] V;
    static boolean he_db;
    private rk he_bb;
    private boolean Z;
    private boolean W;
    private boolean he_eb;
    static int he_ab;
    private rk he_cb;
    static String he_fb;
    static w he_jb;
    static int S;
    private String T;
    static String Y;
    private ek U;
    static String he_hb;

    he(String string, String string2, boolean bl2, boolean bl3, boolean bl4) {
        super(0, 0, 310, 190, null);
        this.T = string2;
        this.Z = bl2;
        this.W = bl4;
        this.he_eb = bl3;
        if (this.Z && (this.he_eb || this.W)) {
            throw new IllegalStateException();
        }
        this.he_bb = new og(string, this, 100);
        this.he_cb = new og("", this, 20);
        if (!this.Z) {
            this.U = new ek(jh.jh_a, null);
            this.X = new ek(this.W ? ic.ic_b : bl.X, null);
            if (this.he_eb) {
                this.he_ib = new ek(i.i_f, this);
            }
        } else {
            this.U = new ek(sh.sh_c, null);
            this.X = new ek(ig.Tb, null);
            this.he_bb.I = false;
        }
        this.he_bb.ce_p = new di(0x989898);
        this.he_cb.ce_p = new gm(0x989898);
        fk fk2 = new fk();
        this.U.ce_p = fk2;
        if (this.X != null) {
            this.X.ce_p = fk2;
        }
        this.he_bb.B = f.f_v;
        if (this.he_ib != null) {
            this.he_ib.ce_p = fk2;
        }
        if (null != this.he_ib) {
            this.he_ib.B = tm.tm_h;
        }
        if (this.Z) {
            this.X.B = gi.gi_d;
        } else if (!this.W) {
            this.X.ce_p = new on();
        } else {
            this.X.B = kh.kh_c;
            this.X.ce_p = new on();
        }
        this.D = 15;
        mm mm2 = hh.hh_e;
        if (this.T != null) {
            this.D += 5 + mm2.b(this.T, this.ce_t + -40, mm2.R);
        }
        String string3 = ua.G;
        ij ij2 = jb.a(se.h(25144), -10314);
        if (ij2 == ah.ah_f) {
            string3 = v.v_g;
        } else if (ij2 == ge.ge_g) {
            string3 = sl.sl_a;
        }
        de de2 = new de(10, this.D, this.ce_t - 20, 25, this.he_bb, false, 80, 3, mm2, 0xFFFFFF, string3);
        this.b(de2, (byte)-55);
        this.D += de2.y + 5;
        de2 = new de(10, this.D, -20 + this.ce_t, 25, this.he_cb, false, 80, 3, mm2, 0xFFFFFF, ch.ch_d);
        this.b(de2, (byte)-55);
        this.U.ce_v = this;
        this.D += 5 + de2.y;
        if (this.he_ib != null) {
            this.he_ib.ce_v = this;
        }
        if (this.X != null) {
            this.X.ce_v = this;
        }
        if (null != this.he_ib) {
            this.U.b(30, this.ce_t + -95, 85, this.D, -16555);
            this.D += 60;
        } else {
            this.U.b(30, this.ce_t - 16, 8, this.D, -16555);
            this.D += 35;
        }
        if (null != this.he_ib) {
            this.he_ib.b(30, -10 + (-6 + this.ce_t), 8, this.D, -16555);
            this.D += 35;
        }
        if (this.X != null) {
            if (this.Z || this.W) {
                this.X.b(30, -10 + (-6 + this.ce_t), 8, this.D, -16555);
                this.D += 35;
            } else {
                this.X.b(20, 40, 8, this.D, -16555);
                this.D += 25;
            }
        }
        this.b(this.D + 3, this.ce_t, 0, 0, -16555);
        this.b(this.U, (byte)-55);
        if (null != this.he_ib) {
            this.b(this.he_ib, (byte)-55);
        }
        if (this.X != null) {
            this.b(this.X, (byte)-55);
        }
    }

    @Override
    public final void b(int n2, rk rk2) {
        block2: {
            if (this.he_bb == rk2) {
                this.he_cb.a(false, this);
            }
            if (rk2 == this.he_cb) {
                this.f((byte)-29);
            }
            if (n2 == -2569) break block2;
            he_fb = null;
        }
    }

    static final byte[] a(byte by, byte[] byArray, int n2, uf uf2) {
        boolean bl2 = client.A;
        int n3 = uf2.a(n2, (byte)81);
        if (~n3 == -1) {
            return null;
        }
        if (null == byArray || ~byArray.length != ~n3) {
            byArray = new byte[n3];
        }
        int n4 = uf2.a(3, (byte)52);
        if (by != 5) {
            return null;
        }
        byte by2 = (byte)uf2.a(8, (byte)58);
        if (n4 > 0) {
            for (int j = 0; n3 > j; ++j) {
                byArray[j] = (byte)(by2 + uf2.a(n4, (byte)117));
            }
        } else {
            for (int j = 0; j < n3; ++j) {
                byArray[j] = by2;
            }
        }
        return byArray;
    }

    private final void f(byte by) {
        block1: {
            if (ri.a(71) || ~this.he_bb.E.length() < -1 && ~this.he_cb.E.length() < -1) {
                da.a((byte)-109, this.he_bb.E, this.he_cb.E);
            }
            if (by <= -26) break block1;
            he_hb = null;
        }
    }

    final String j(int n2) {
        if (n2 != 80) {
            he.a(false, false, -20);
        }
        if (this.he_bb.E == null) {
            return "";
        }
        return this.he_bb.E;
    }

    static final void a(boolean bl2, boolean bl3, int n2) {
        block14: {
            boolean bl4 = client.A;
            boolean bl5 = ge.ge_f.Rb.a(2 + kf.O, n2 * ((kf.O - -2) * 3), -15230, ki.ki_w == ge.ge_f.Rb, 2, bl3);
            vj vj2 = ge.ge_f.Sb.M;
            if (-3 != ~jj.jj_b && -2 != ~jj.jj_b) {
                ge.ge_f.Hb = false;
                ge.ge_f.Rb.Rb.Y = wf.wf_m;
                gk.a(ge.ge_f.Sb, true);
            } else {
                ge.ge_f.Rb.Rb.Y = null;
                ge.ge_f.Hb = true;
                wb wb2 = null;
                wb wb3 = (wb)vj2.c((byte)95);
                while (wb3 != null) {
                    boolean bl6 = false;
                    if (null == wb3.M) {
                        wb3.Sb = new w(0L, gg.G);
                        wb3.a(wb3.Sb, -16834);
                        wb3.Wb = new w(0L, gg.G);
                        wb3.a(wb3.Wb, -16834);
                        wb3.d(-36);
                        bl6 = true;
                    }
                    wb3.w_mb = ge.ge_f.Sb.w_mb;
                    wb3.Sb.a(wb3.w_mb, 0, 0, kf.O, 0);
                    boolean bl7 = false;
                    if (wb3.Tb != null && !wb3.Tb.equals("")) {
                        wb3.Wb.I = a.a_p;
                        wb3.Wb.Bb = 0xFF6666;
                        wb3.Wb.a(3 + a.a_p.K, 0, 0, kf.O, 0);
                        bl7 = true;
                    }
                    int n3 = 0;
                    int n4 = wb3.w_mb;
                    if (bl7) {
                        n3 = 3 + a.a_p.K;
                        n4 -= n3;
                    }
                    wb3.Sb.Y = n4 > 0 ? mm.a(wb3.Sb.J, wb3.Ob, n4) : wb3.Ob;
                    boolean bl8 = !wb3.Sb.Y.equals(wb3.Ob);
                    wb3.Sb.a(n4, 0, 0, kf.O, n3);
                    if (!bl5) {
                        wb3.F = kf.O - wb3.N;
                    }
                    if (bl6) {
                        ge.ge_f.Sb.a(wb2, wb3, 2, 0);
                    }
                    if (null != wb3.Wb && wb3.Wb.w_jb) {
                        sl.sl_g = wb3.Tb;
                    } else if (wb3.Sb.w_jb && bl8) {
                        sl.sl_g = wb3.Ob;
                    }
                    wb2 = wb3;
                    if (~wb3.w_ob != -1) {
                        sl.a(wb3.Pb, null, (byte)112, ge.ge_f.Rb, wb3, wb3.Ob, 0L, -1, -1);
                        pf pf2 = w.H;
                        String string = wk.wk_o;
                        pf2.pf_h.a(string, 7, 72);
                        pf pf3 = w.H;
                        int n5 = S;
                        int n6 = nf.nf_h;
                        pf3.pf_h.b(n6, n5, 89, 0, 0);
                    }
                    wb3 = (wb)vj2.d(bl2);
                }
                if (ge.ge_f.Ob.w_ob != 0) {
                    vh.vh_h = new hb(ge.ge_f.Ob.E, ge.ge_f.Ob.w_pb, ge.ge_f.Ob.w_mb, ge.ge_f.Ob.N, pj.L, ah.ah_h, ua.H, ua.H);
                    of.of_d = 2;
                }
                if (ge.ge_f.Nb.w_ob != 0) {
                    vh.vh_h = new hb(ge.ge_f.Nb.E, ge.ge_f.Nb.w_pb, ge.ge_f.Nb.w_mb, ge.ge_f.Nb.N, bn.bn_b, ah.ah_h, ua.H, ua.H);
                    of.of_d = 3;
                }
            }
            if (bl2) break block14;
            he_jb = null;
        }
    }

    static final boolean a(int n2, char c) {
        block6: {
            block5: {
                block4: {
                    boolean bl2 = client.A;
                    if (n2 >= -5) {
                        he.a(true, true, -20);
                    }
                    if (c > '\u0000' && '\u0080' > c) break block4;
                    if (c < '\u00a0') break block5;
                    if ('\u00ff' >= c) break block4;
                    if (c == '\u0000') break block6;
                    char[] cArray = nh.nh_l;
                    char[] cArray2 = nh.nh_l;
                    for (int j = 0; j < cArray.length; ++j) {
                        char c2 = cArray[j];
                        if (c != c2) continue;
                        return true;
                    }
                    break block6;
                }
                return true;
            }
            if (c != '\u0000') {
                char[] cArray = nh.nh_l;
                char[] cArray3 = nh.nh_l;
                for (int j = 0; j < cArray.length; ++j) {
                    char c3 = cArray[j];
                    if (c != c3) continue;
                    return true;
                }
            }
        }
        return false;
    }

    static final boolean a(String string, byte by, String string2) {
        string = jm.a('_', string, "", -1);
        String string3 = oa.a(string, -1);
        int n2 = -17 % ((58 - by) / 55);
        return ~string2.indexOf(string) != 0 || 0 != ~string2.indexOf(string3);
    }

    final void a(String string, int n2) {
        rk rk2 = this.he_bb;
        String string2 = string;
        rk2.a(string2, (byte)114, false);
        if (n2 != 30534) {
            this.a(127, 108, (ce)null, '\uffab');
        }
        this.he_cb.m(0);
    }

    @Override
    final boolean a(int n2, int n3, ce ce2, char c) {
        if (super.a(65, n3, ce2, c)) {
            return true;
        }
        int n4 = 56 / ((-22 - n2) / 49);
        if (-99 == ~n3) {
            return this.a(ce2, (byte)-45);
        }
        if (99 != n3) {
            return false;
        }
        return this.a(32, ce2);
    }

    @Override
    public final void a(int n2, rk rk2) {
        block0: {
            if (n2 == 0xFF6666) break block0;
            this.W = true;
        }
    }

    final void a(int n2) {
        if (n2 <= 28) {
            this.X = null;
        }
        this.he_bb.m(0);
        this.he_cb.m(0);
    }

    @Override
    final void a(int n2, int n3, int n4, int n5) {
        if (this.T != null) {
            hh.hh_e.a(this.T, n2 + (this.ce_u - -20), n5 + (this.D + 15), this.ce_t - 40, this.y, 0xFFFFFF, -1, 1, 0, hh.hh_e.R);
        }
        if (n3 > -103) {
            he_jb = null;
        }
        if (this.he_ib != null) {
            hk.a(10 + n2, 134 + n5, -20 + this.ce_t, 0x404040);
        }
        super.a(n2, -119, n4, n5);
    }

    @Override
    public final void a(byte by, int n2, ek ek2, int n3, int n4) {
        block9: {
            boolean bl2 = client.A;
            if (ek2 == this.U) {
                this.f((byte)-37);
            } else if (ek2 != this.he_ib) {
                if (ek2 == this.X) {
                    if (!this.Z) {
                        if (!this.W) {
                            lg.a(8927);
                        } else {
                            t.k((byte)-73);
                        }
                    } else {
                        qi.h(17);
                    }
                }
            } else {
                ha.e(0);
            }
            if (by == 67) break block9;
            this.j(-21);
        }
    }

    static final void a(boolean bl2, int n2) {
        block0: {
            tf.tf_gb.a(1141039778, bl2);
            if (n2 <= -73) break block0;
            he_fb = null;
        }
    }

    public static void i(int n2) {
        he_hb = null;
        Y = null;
        V = null;
        if (n2 != 0) {
            he_hb = null;
        }
        he_fb = null;
        he_jb = null;
    }

    static {
        V = new int[4];
        he_gb = 250;
        he_fb = "Loading sound effects";
        S = 0;
    }
}
