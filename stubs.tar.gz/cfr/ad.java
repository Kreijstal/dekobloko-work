/*
 * Decompiled with CFR 0.152.
 */
final class ad {
    private int ad_w;
    byte[][] ad_l;
    static int ad_a;
    int[][] ad_v;
    oc ad_e;
    oc[] ad_o;
    static ck ad_d;
    int[] ad_k;
    int ad_m;
    int[] y;
    int ad_n;
    int ad_s;
    int[] ad_f;
    static String ad_b;
    private int[][] ad_r;
    private int[] ad_p;
    private byte[] ad_h;
    static String A;
    int[] ad_c;
    static w ad_q;
    static ck[][] ad_j;
    int[] B;
    static ck ad_g;
    static String ad_t;
    static int ad_u;
    static int[] ad_i;
    static String x;
    static String z;

    public static void a(byte by) {
        block0: {
            ad_b = null;
            ad_d = null;
            ad_j = null;
            ad_i = null;
            A = null;
            z = null;
            x = null;
            ad_q = null;
            ad_g = null;
            ad_t = null;
            if (by == -67) break block0;
            ad_g = null;
        }
    }

    static final void a(int n, int n2) {
        if (n != -1) {
            ad_q = null;
        }
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        uf2.a(true, 1);
        uf2.a(true, 0);
    }

    static final String a(ji ji2, String string, boolean bl, String string2) {
        if (!ji2.a((byte)121)) {
            return string;
        }
        if (!bl) {
            ad.a(null, -41, true, 8, -58, true);
        }
        return string2 + " - " + ji2.b((byte)-89) + "%";
    }

    static final void a(byte[] byArray, int n, boolean bl, int n2, int n3, boolean bl2) {
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n4 = uf2.wl_n;
        uf2.a(bl, 4);
        uf2.a(bl, n2);
        int n5 = n3;
        if (bl2) {
            n5 += 128;
        }
        uf2.a(bl, n5);
        uf2.a(false, byArray.length, byArray, 0);
        uf2.b(-n4 + uf2.wl_n, bl);
    }

    private final void a(byte[] byArray, int n) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        boolean bl = client.A;
        wl wl2 = new wl(i.a(byArray, -89));
        wl wl3 = wl2;
        int n7 = wl3.d((byte)-114);
        if (~n7 > -6 || -8 > ~n7) {
            throw new RuntimeException();
        }
        this.ad_m = -7 < ~n7 ? 0 : wl3.i(n ^ 0x1D81);
        int n8 = wl3.d((byte)-46);
        boolean bl2 = ~(n8 & 1) != -1;
        boolean bl3 = (n8 & 2) != 0;
        this.ad_w = 7 > n7 ? wl3.e(n + 3) : wl3.f(21663);
        int n9 = 0;
        int n10 = -1;
        this.ad_f = new int[this.ad_w];
        if (-8 >= ~n7) {
            for (n6 = 0; this.ad_w > n6; ++n6) {
                this.ad_f[n6] = n9 += wl2.f(21663);
                if (~this.ad_f[n6] >= ~n10) continue;
                n10 = this.ad_f[n6];
            }
        } else {
            for (n6 = 0; this.ad_w > n6; ++n6) {
                this.ad_f[n6] = n9 += wl3.e(qm.b(n, 3));
                if (this.ad_f[n6] <= n10) continue;
                n10 = this.ad_f[n6];
            }
        }
        this.ad_n = n10 - -1;
        this.y = new int[this.ad_n];
        if (bl3) {
            this.ad_l = new byte[this.ad_n][];
        }
        this.ad_c = new int[this.ad_n];
        this.ad_v = new int[this.ad_n][];
        this.B = new int[this.ad_n];
        this.ad_k = new int[this.ad_n];
        if (bl2) {
            this.ad_p = new int[this.ad_n];
            for (n6 = 0; this.ad_n > n6; ++n6) {
                this.ad_p[n6] = -1;
            }
            n6 = 0;
            while (~this.ad_w < ~n6) {
                this.ad_p[this.ad_f[n6]] = wl2.i(n + 7553);
                ++n6;
            }
            this.ad_e = new oc(this.ad_p);
        }
        for (n6 = n; this.ad_w > n6; ++n6) {
            this.ad_c[this.ad_f[n6]] = wl2.i(7553);
        }
        if (bl3) {
            for (n6 = 0; n6 < this.ad_w; ++n6) {
                byte[] byArray2 = new byte[64];
                wl3.a(byArray2, 0, (byte)125, 64);
                this.ad_l[this.ad_f[n6]] = byArray2;
            }
        }
        for (n6 = 0; this.ad_w > n6; ++n6) {
            this.y[this.ad_f[n6]] = wl2.i(7553);
        }
        if (-8 < ~n7) {
            for (n6 = 0; n6 < this.ad_w; ++n6) {
                this.B[this.ad_f[n6]] = wl2.e(3);
            }
            for (n6 = 0; this.ad_w > n6; ++n6) {
                int n11 = this.ad_f[n6];
                n5 = this.B[n11];
                n9 = 0;
                n4 = -1;
                this.ad_v[n11] = new int[n5];
                n3 = 0;
                while (~n3 > ~n5) {
                    this.ad_v[n11][n3] = n9 += wl2.e(3);
                    n2 = n9;
                    if (~n2 < ~n4) {
                        n4 = n2;
                    }
                    ++n3;
                }
                this.ad_k[n11] = 1 + n4;
                if (~(1 + n4) != ~n5) continue;
                this.ad_v[n11] = null;
            }
        } else {
            for (n6 = 0; this.ad_w > n6; ++n6) {
                this.B[this.ad_f[n6]] = wl2.f(21663);
            }
            for (n6 = 0; this.ad_w > n6; ++n6) {
                int n12 = this.ad_f[n6];
                n5 = this.B[n12];
                n9 = 0;
                this.ad_v[n12] = new int[n5];
                n4 = -1;
                n3 = 0;
                while (~n3 > ~n5) {
                    this.ad_v[n12][n3] = n9 += wl2.f(21663);
                    n2 = n9;
                    if (n2 > n4) {
                        n4 = n2;
                    }
                    ++n3;
                }
                this.ad_k[n12] = 1 + n4;
                if (n4 - -1 != n5) continue;
                this.ad_v[n12] = null;
            }
        }
        if (bl2) {
            this.ad_o = new oc[n10 + 1];
            this.ad_r = new int[n10 + 1][];
            n6 = 0;
            while (~this.ad_w < ~n6) {
                int n13 = this.ad_f[n6];
                n5 = this.B[n13];
                this.ad_r[n13] = new int[this.ad_k[n13]];
                for (n4 = 0; this.ad_k[n13] > n4; ++n4) {
                    this.ad_r[n13][n4] = -1;
                }
                n4 = 0;
                while (~n4 > ~n5) {
                    n3 = null == this.ad_v[n13] ? n4 : this.ad_v[n13][n4];
                    this.ad_r[n13][n3] = wl2.i(qm.b(n, 7553));
                    ++n4;
                }
                this.ad_o[n13] = new oc(this.ad_r[n13]);
                ++n6;
            }
        }
    }

    ad(byte[] byArray, int n, byte[] byArray2) {
        this.ad_s = tj.a(byArray.length, 0, byArray);
        if (this.ad_s != n) {
            throw new RuntimeException();
        }
        if (null != byArray2) {
            if (byArray2.length != 64) {
                throw new RuntimeException();
            }
            this.ad_h = um.a(0, byArray, 0, byArray.length);
            int n2 = 0;
            while (~n2 > -65) {
                if (~byArray2[n2] != ~this.ad_h[n2]) {
                    throw new RuntimeException();
                }
                ++n2;
            }
        }
        this.a(byArray, 0);
    }

    static {
        ad_b = "Please enter a year between <%0> and <%1>";
        ad_d = new ck(18, 18);
        ad_j = new ck[8][];
        A = "<%0> wants to join";
        ad_t = "Your email address is used to identify this account";
        ad_u = 0;
        z = "Achievements This Session";
    }
}
