/*
 * Decompiled with CFR 0.152.
 */
final class q {
    int q_c;
    int[] q_a;
    int q_b;
    int[] q_d;

    q() {
        va.c(16);
        int n = this.q_b = va.b() != 0 ? va.c(4) + 1 : 1;
        if (va.b() != 0) {
            va.c(8);
        }
        va.c(2);
        if (this.q_b > 1) {
            this.q_c = va.c(4);
        }
        this.q_a = new int[this.q_b];
        this.q_d = new int[this.q_b];
        for (int i = 0; i < this.q_b; ++i) {
            va.c(8);
            this.q_a[i] = va.c(8);
            this.q_d[i] = va.c(8);
        }
    }
}
