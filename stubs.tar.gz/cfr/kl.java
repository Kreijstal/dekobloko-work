/*
 * Decompiled with CFR 0.152.
 */
final class kl
extends bh {
    int C;
    mh[] kl_t;
    int[] A;
    mh[] y;
    int kl_o;
    static um B = new um();
    int[] kl_q;
    static af z;
    byte[][][] kl_s;
    static ck kl_v;
    static int[] kl_n;
    static String x;
    int[] kl_u;
    static ln kl_p;
    static w kl_r;
    static String kl_w;

    public static void a(boolean bl) {
        if (!bl) {
            return;
        }
        B = null;
        kl_r = null;
        x = null;
        kl_p = null;
        z = null;
        kl_n = null;
        kl_w = null;
        kl_v = null;
    }

    static final void a(int n, int n2, int n3) {
        if (n != 11024) {
            kl.a(-96, 40, 17);
        }
        u.u_e = n3;
        sa.sa_p = n2;
    }

    kl() {
    }

    static {
        x = "Unable to delete friend - system busy";
        kl_n = new int[8192];
        z = new af();
        kl_p = new ln();
        kl_w = "Bugs";
    }
}
