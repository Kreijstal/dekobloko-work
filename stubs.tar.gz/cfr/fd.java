/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.Transferable;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;

final class fd
implements Runnable {
    static String fd_k;
    EventQueue fd_w;
    private ae fd_r;
    private static int fd_n;
    private mh fd_h = null;
    private Object x;
    private static volatile long fd_t;
    boolean fd_a = false;
    hf fd_i = null;
    private static String fd_b;
    static String fd_c;
    hf[] fd_o;
    private Thread fd_s;
    private mh fd_p = null;
    private boolean fd_j = false;
    private boolean fd_m = false;
    static String fd_d;
    static Method fd_f;
    private Object fd_q;
    private static String fd_u;
    hf fd_v = null;
    private static String fd_g;
    private fg fd_e;
    hf fd_l = null;

    final mh a(byte by, int n, int n2, int n3, int n4) {
        block0: {
            if (by > 39) break block0;
            this.fd_r = null;
        }
        return this.a(n4 + (n2 << 75254128), 1, null, 6, (n3 << 261205040) + n);
    }

    final mh a(int n, String string, int n2) {
        block0: {
            if (n > 98) break block0;
            String string2 = null;
            this.a(12, true, -60, string2);
        }
        return this.a(n2, false, -10742, string);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final void a(int n) {
        block19: {
            fd fd2 = this;
            synchronized (fd2) {
                this.fd_m = true;
                this.notifyAll();
            }
            try {
                this.fd_s.join();
                if (n != 0) {
                    this.a(-106);
                }
            }
            catch (InterruptedException interruptedException) {
                // empty catch block
            }
            if (this.fd_i != null) {
                try {
                    this.fd_i.a(-72);
                }
                catch (IOException iOException) {
                    // empty catch block
                }
            }
            if (null != this.fd_l) {
                try {
                    this.fd_l.a(n + -55);
                }
                catch (IOException iOException) {
                    // empty catch block
                }
            }
            if (null != this.fd_o) {
                int n2 = 0;
                while (~n2 > ~this.fd_o.length) {
                    if (null != this.fd_o[n2]) {
                        try {
                            this.fd_o[n2].a(n ^ 0xFFFFFFB9);
                        }
                        catch (IOException iOException) {
                            // empty catch block
                        }
                    }
                    ++n2;
                }
            }
            if (this.fd_v == null) break block19;
            try {
                this.fd_v.a(-72);
            }
            catch (IOException iOException) {}
        }
    }

    final mh a(boolean bl, String string, Class clazz) {
        if (bl) {
            return null;
        }
        return this.a(0, 1, new Object[]{clazz, string}, 9, 0);
    }

    private final mh a(int n, boolean bl, int n2, String string) {
        if (n2 != -10742) {
            this.fd_h = null;
        }
        return this.a(0, 1, string, bl ? 22 : 1, n);
    }

    final boolean b(int n) {
        if (n != -86) {
            return false;
        }
        if (!this.fd_a) {
            return false;
        }
        if (this.fd_j) {
            return null != this.fd_e;
        }
        return this.x != null;
    }

    final mh a(int n, String string, Class clazz, Class[] classArray) {
        if (n != -10962) {
            fd_f = null;
        }
        return this.a(0, n ^ 0xFFFFD52F, new Object[]{clazz, string, classArray}, 8, 0);
    }

    private static final hf a(byte by, String string, String string2, int n) {
        String string3 = 33 != n ? (~n != -35 ? "jagex_" + string + "_preferences" + string2 + ".dat" : "jagex_" + string + "_preferences" + string2 + "_wip.dat") : "jagex_" + string + "_preferences" + string2 + "_rc.dat";
        String[] stringArray = new String[]{"c:/rscache/", "/rscache/", fd_u, "c:/windows/", "c:/winnt/", "c:/", "/tmp/", ""};
        if (by != -32) {
            return null;
        }
        int n2 = 0;
        while (~stringArray.length < ~n2) {
            String string4 = stringArray[n2];
            if (-1 <= ~string4.length() || new File(string4).exists()) {
                try {
                    hf hf2 = new hf(new File(string4, string3), "rw", 10000L);
                    return hf2;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            ++n2;
        }
        return null;
    }

    final mh a(int n, Frame frame) {
        if (n != 75254128) {
            return null;
        }
        return this.a(0, 1, frame, 7, 0);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final void run() {
        while (true) {
            mh mh2;
            Object object = this;
            synchronized (object) {
                while (true) {
                    if (this.fd_m) {
                        return;
                    }
                    if (this.fd_h != null) {
                        mh2 = this.fd_h;
                        this.fd_h = this.fd_h.mh_f;
                        if (null != this.fd_h) break;
                        this.fd_p = null;
                        break;
                    }
                    try {
                        this.wait();
                    }
                    catch (InterruptedException interruptedException) {}
                }
            }
            try {
                int n = mh2.mh_d;
                if (-2 != ~n) {
                    if (-23 == ~n) {
                        if ((ik.a(4) ^ 0xFFFFFFFFFFFFFFFFL) > (fd_t ^ 0xFFFFFFFFFFFFFFFFL)) {
                            throw new IOException();
                        }
                        try {
                            mh2.mh_b = pn.a((String)mh2.mh_e, mh2.mh_g, 23155).a(-7);
                        }
                        catch (db db2) {
                            mh2.mh_b = db2.getMessage();
                            throw db2;
                        }
                    } else if (~n != -3) {
                        if (4 != n) {
                            if (-9 == ~n) {
                                Object[] objectArray = (Object[])mh2.mh_e;
                                if (this.fd_a && ((Class)objectArray[0]).getClassLoader() == null) {
                                    throw new SecurityException();
                                }
                                mh2.mh_b = ((Class)objectArray[0]).getDeclaredMethod((String)objectArray[1], (Class[])objectArray[2]);
                            } else if (-10 == ~n) {
                                Object[] objectArray = (Object[])mh2.mh_e;
                                if (this.fd_a && null == ((Class)objectArray[0]).getClassLoader()) {
                                    throw new SecurityException();
                                }
                                mh2.mh_b = ((Class)objectArray[0]).getDeclaredField((String)objectArray[1]);
                            } else if (-19 == ~n) {
                                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                                mh2.mh_b = clipboard.getContents(null);
                            } else if (~n == -20) {
                                Transferable transferable = (Transferable)mh2.mh_e;
                                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                                clipboard.setContents(transferable, null);
                            } else {
                                if (!this.fd_a) throw new Exception("");
                                if (~n == -4) {
                                    if ((fd_t ^ 0xFFFFFFFFFFFFFFFFL) < (ik.a(4) ^ 0xFFFFFFFFFFFFFFFFL)) {
                                        throw new IOException();
                                    }
                                    String string = (mh2.mh_g >> -1649452392 & 0xFF) + "." + (0xFF & mh2.mh_g >> -1316320240) + "." + ((mh2.mh_g & 0xFFDE) >> -1967676120) + "." + (0xFF & mh2.mh_g);
                                    mh2.mh_b = InetAddress.getByName(string).getHostName();
                                } else if (~n != -22) {
                                    if (-6 == ~n) {
                                        mh2.mh_b = this.fd_j ? (Object)this.fd_e.a(0) : Class.forName("vc").getMethod("listmodes", new Class[0]).invoke(this.x, new Object[0]);
                                    } else if (6 == n) {
                                        Frame frame = new Frame("Jagex Full Screen");
                                        mh2.mh_b = frame;
                                        frame.setResizable(false);
                                        if (this.fd_j) {
                                            this.fd_e.a(mh2.mh_a >> -339845072, false, mh2.mh_g >>> 615328656, mh2.mh_g & 0xFFFF, mh2.mh_a & 0xFFFF, frame);
                                        } else {
                                            Class.forName("vc").getMethod("enter", Frame.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE).invoke(this.x, frame, new Integer(mh2.mh_g >>> 1399377360), new Integer(mh2.mh_g & 0xFFFF), new Integer(mh2.mh_a >> 692951952), new Integer(mh2.mh_a & 0xFFFF));
                                        }
                                    } else if (~n == -8) {
                                        if (!this.fd_j) {
                                            Class.forName("vc").getMethod("exit", new Class[0]).invoke(this.x, new Object[0]);
                                        } else {
                                            this.fd_e.a((Frame)mh2.mh_e, (byte)122);
                                        }
                                    } else if (12 != n) {
                                        if (-14 == ~n) {
                                            hf hf2 = fd.a((byte)-32, "", (String)mh2.mh_e, fd_n);
                                            mh2.mh_b = hf2;
                                        } else if (!this.fd_a || ~n != -15) {
                                            if (!this.fd_a || 15 != n) {
                                                if (!this.fd_j && -18 == ~n) {
                                                    Object[] objectArray = (Object[])mh2.mh_e;
                                                    Class.forName("il").getDeclaredMethod("setcustomcursor", Component.class, int[].class, Integer.TYPE, Integer.TYPE, Point.class).invoke(this.fd_q, objectArray[0], objectArray[1], new Integer(mh2.mh_g), new Integer(mh2.mh_a), objectArray[2]);
                                                } else {
                                                    if (16 != n) {
                                                        throw new Exception("");
                                                    }
                                                    try {
                                                        if (!fd_d.startsWith("win")) {
                                                            throw new Exception();
                                                        }
                                                        String string = (String)mh2.mh_e;
                                                        if (!string.startsWith("http://") && !string.startsWith("https://")) {
                                                            throw new Exception();
                                                        }
                                                        String string2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789?&=,.%+-_#:/*";
                                                        int n2 = 0;
                                                        while (~string.length() < ~n2) {
                                                            if (0 == ~string2.indexOf(string.charAt(n2))) {
                                                                throw new Exception();
                                                            }
                                                            ++n2;
                                                        }
                                                        Runtime.getRuntime().exec("cmd /c start \"j\" \"" + string + "\"");
                                                        mh2.mh_b = null;
                                                    }
                                                    catch (Exception exception) {
                                                        mh2.mh_b = exception;
                                                        throw exception;
                                                    }
                                                }
                                            } else {
                                                boolean bl = mh2.mh_g != 0;
                                                Component component = (Component)mh2.mh_e;
                                                if (!this.fd_j) {
                                                    Class.forName("il").getDeclaredMethod("showcursor", Component.class, Boolean.TYPE).invoke(this.fd_q, component, new Boolean(bl));
                                                } else {
                                                    this.fd_r.a(bl, component, (byte)111);
                                                }
                                            }
                                        } else {
                                            int n3 = mh2.mh_g;
                                            int n4 = mh2.mh_a;
                                            if (!this.fd_j) {
                                                Class.forName("il").getDeclaredMethod("movemouse", Integer.TYPE, Integer.TYPE).invoke(this.fd_q, new Integer(n3), new Integer(n4));
                                            } else {
                                                this.fd_r.a(n3, n4, (byte)-98);
                                            }
                                        }
                                    } else {
                                        hf hf3 = fd.a((byte)-32, fd_g, (String)mh2.mh_e, fd_n);
                                        mh2.mh_b = hf3;
                                    }
                                } else {
                                    if (fd_t > ik.a(4)) {
                                        throw new IOException();
                                    }
                                    mh2.mh_b = InetAddress.getByName((String)mh2.mh_e).getAddress();
                                }
                            }
                        } else {
                            if (fd_t > ik.a(4)) {
                                throw new IOException();
                            }
                            mh2.mh_b = new DataInputStream(((URL)mh2.mh_e).openStream());
                        }
                    } else {
                        Thread thread = new Thread((Runnable)mh2.mh_e);
                        thread.setDaemon(true);
                        thread.start();
                        thread.setPriority(mh2.mh_g);
                        mh2.mh_b = thread;
                    }
                } else {
                    if (ik.a(4) < fd_t) {
                        throw new IOException();
                    }
                    mh2.mh_b = new Socket(InetAddress.getByName((String)mh2.mh_e), mh2.mh_g);
                }
                mh2.mh_c = 1;
            }
            catch (ThreadDeath threadDeath) {
                throw threadDeath;
            }
            catch (Throwable throwable) {
                mh2.mh_c = 2;
            }
            object = mh2;
            synchronized (object) {
                mh2.notify();
            }
        }
    }

    final mh a(URL uRL, byte by) {
        int n = -74 % ((-9 - by) / 45);
        return this.a(0, 1, uRL, 4, 0);
    }

    final mh a(byte by) {
        if (by <= 121) {
            return null;
        }
        return this.a(0, 1, null, 5, 0);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final mh a(int n, int n2, Object object, int n3, int n4) {
        mh mh2 = new mh();
        mh2.mh_g = n4;
        mh2.mh_a = n;
        mh2.mh_d = n3;
        mh2.mh_e = object;
        fd fd2 = this;
        synchronized (fd2) {
            if (null == this.fd_p) {
                this.fd_p = this.fd_h = mh2;
            } else {
                this.fd_p.mh_f = mh2;
                this.fd_p = mh2;
            }
            this.notify();
            if (n2 != 1) {
                fd_t = -68L;
            }
        }
        return mh2;
    }

    final mh a(byte by, int n, Runnable runnable) {
        int n2 = -20 / ((by - 80) / 41);
        return this.a(0, 1, runnable, 2, n);
    }

    fd(int n, String string, int n2, boolean bl) throws Exception {
        this.fd_a = bl;
        fd_n = n;
        fd_c = "1.1";
        fd_g = string;
        fd_k = "Unknown";
        try {
            fd_k = System.getProperty("java.vendor");
            fd_c = System.getProperty("java.version");
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (~fd_k.toLowerCase().indexOf("microsoft") != 0) {
            this.fd_j = true;
        }
        try {
            fd_b = System.getProperty("os.name");
        }
        catch (Exception exception) {
            fd_b = "Unknown";
        }
        fd_d = fd_b.toLowerCase();
        try {
            System.getProperty("os.arch").toLowerCase();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            System.getProperty("os.version").toLowerCase();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            fd_u = System.getProperty("user.home");
            if (fd_u != null) {
                fd_u = fd_u + "/";
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (fd_u == null) {
            fd_u = "~/";
        }
        try {
            this.fd_w = Toolkit.getDefaultToolkit().getSystemEventQueue();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (!this.fd_j) {
            try {
                Class.forName("java.awt.Component").getDeclaredMethod("setFocusTraversalKeysEnabled", Boolean.TYPE);
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                fd_f = Class.forName("java.awt.Container").getDeclaredMethod("setFocusCycleRoot", Boolean.TYPE);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        od.a(fd_n, fd_g, 7154);
        if (this.fd_a) {
            this.fd_v = new hf(od.a(null, 30869, "random.dat", fd_n), "rw", 25L);
            this.fd_i = new hf(od.a(0, "main_file_cache.dat2"), "rw", 314572800L);
            this.fd_l = new hf(od.a(0, "main_file_cache.idx255"), "rw", 0x100000L);
            this.fd_o = new hf[n2];
            for (int i = 0; n2 > i; ++i) {
                this.fd_o[i] = new hf(od.a(0, "main_file_cache.idx" + i), "rw", 0x100000L);
            }
            if (this.fd_j) {
                try {
                    Class.forName("hi").newInstance();
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            try {
                if (this.fd_j) {
                    fg fg2;
                    this.fd_e = fg2 = new fg();
                } else {
                    this.x = Class.forName("vc").newInstance();
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            try {
                if (this.fd_j) {
                    this.fd_r = new ae();
                } else {
                    this.fd_q = Class.forName("il").newInstance();
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        this.fd_m = false;
        this.fd_s = new Thread(this);
        this.fd_s.setPriority(10);
        this.fd_s.setDaemon(true);
        this.fd_s.start();
    }

    static {
        fd_t = 0L;
    }
}
