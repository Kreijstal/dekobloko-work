/*
 * Decompiled with CFR 0.152.
 */
final class dl
extends ek {
    static int M = 20;
    static int N;
    static String[] K;
    static String L;

    dl(String string, kg kg2, boolean bl) {
        this(string, kg2);
        this.H = bl;
    }

    private dl(String string, kg kg2) {
        this(string, bf.x.c_b, kg2);
        this.ce_p = bf.x.c_a;
    }

    static final void a(byte by, boolean bl, ck ck2, int n, int n2) {
        block5: {
            boolean bl2 = client.A;
            if (ck2 == tc.Tb) {
                lj.a(n2, n, 0, true);
            } else if (null == ck2) {
                hk.a(0, 0, 640, 480, 0);
            } else {
                ck2.e(0, n, n2);
            }
            if (bl) {
                fj.a(0, n2, -26, n);
            }
            if (by >= 40) break block5;
            L = null;
        }
    }

    public static void b(boolean bl) {
        if (bl) {
            return;
        }
        K = null;
        L = null;
    }

    static final void b(int n, int n2) {
        block1: {
            cl cl2;
            boolean bl = client.A;
            cl cl3 = cl2 = (cl)oe.I.c((byte)113);
            while (null != cl2) {
                fh.a((byte)104, cl2, n2);
                cl3 = (cl)oe.I.d(true);
            }
            if (n == 640) break block1;
            ck ck2 = null;
            dl.a((byte)62, true, ck2, -96, 15);
        }
    }

    private dl(String string, gl gl2, kg kg2) {
        super(string, gl2, kg2);
        this.ce_p = bf.x.c_a;
    }

    @Override
    final void b(int n, int n2, int n3, int n4) {
        this.H = !this.H;
        super.b(n, n2, n3, n4);
    }

    static final boolean a(int n) {
        if (n != 480) {
            return true;
        }
        return 250 < gd.gd_e;
    }

    static {
        L = "Stage <%0>";
        N = -1;
    }
}
