/*
 * Decompiled with CFR 0.152.
 */
final class hd
extends bh {
    static String hd_t;
    static String hd_o;
    static String hd_v;
    static String hd_p;
    static int hd_s;
    static w hd_q;
    static int hd_u;
    static c hd_r;
    static int hd_n;

    private hd() throws Throwable {
        throw new Error();
    }

    static final void a(int n, boolean bl, ve ve2, String string) {
        String string2;
        sl.a(null, null, (byte)105, gf.gf_c, ve2, null, 0L, -1, ve2.e(-88));
        if (ve2.ve_lc && (2 == ve2.ve_qc || te.te_p >= 2)) {
            pf pf2 = w.H;
            string2 = cm.a((byte)86, ec.ec_a, new String[]{string});
            pf2.pf_h.a(string2, 10, 126);
        }
        w.H.b(-119);
        if (bl) {
            if (w.H.pf_f == ta.ta_b) {
                pf pf3 = w.H;
                string2 = cm.a((byte)94, fb.fb_d, new String[]{string});
                pf3.pf_h.a(string2, 16, n + 87);
            } else {
                pf pf4 = w.H;
                string2 = cm.a((byte)86, sb.sb_p, new String[]{string});
                pf4.pf_h.a(string2, 15, n ^ 0x5B);
            }
        }
        pf pf5 = w.H;
        int n2 = he.S;
        int n3 = nf.nf_h;
        pf5.pf_h.b(n3, n2, 123, n, 0);
    }

    public static void a(int n) {
        if (n != 22771) {
            hd_u = -48;
        }
        hd_o = null;
        hd_q = null;
        hd_v = null;
        hd_p = null;
        hd_t = null;
        hd_r = null;
    }

    static {
        hd_o = "Won";
        hd_t = "Don't mind";
        hd_p = "Similar rating";
        hd_v = "Real-life threats";
    }
}
