/*
 * Decompiled with CFR 0.152.
 */
final class oi {
    private rf[] oi_c;
    static String oi_e = "Winner!";
    static qm oi_d = new qm(7, 0, 1, 1);
    static em oi_a;
    static String oi_b;

    static final int a(int n, int n2, int n3) {
        int n4;
        block0: {
            n4 = n + -1 & n3 >> -1286094081;
            if (n2 >= 76) break block0;
            sb sb2 = null;
            oi.a(106, 18, sb2);
        }
        return n4 + (n3 - -(n3 >>> -520357569)) % n;
    }

    private final void a(byte by) {
        rf[] rfArray;
        boolean bl = client.A;
        rf[] rfArray2 = rfArray = new rf[this.oi_c.length * 2];
        if (by <= 103) {
            return;
        }
        int n = 0;
        while (~this.oi_c.length < ~n) {
            rf rf2 = this.oi_c[n];
            if (rf2 != null) {
                rfArray[rf2.rf_j % rfArray.length] = rf2;
            }
            ++n;
        }
        this.oi_c = rfArray2;
    }

    final rf a(boolean bl, boolean bl2, uf uf2) {
        rf rf2;
        int n;
        rf rf3;
        boolean bl3 = client.A;
        if (!bl) {
            oi_a = null;
        }
        if ((rf3 = this.oi_c[(n = uf2.a(118)) % this.oi_c.length]) != null && n == rf3.rf_j) {
            if (!bl2) {
                this.oi_c[n % this.oi_c.length] = null;
            }
            return rf3;
        }
        while (bl2 && this.oi_c[n % this.oi_c.length] != null) {
            this.a((byte)115);
        }
        rf3 = rf2 = new rf(n);
        rf3.rf_b = uf2.d((byte)-102);
        rf3.rf_n = uf2.d((byte)-79);
        rf3.rf_c = new byte[rf3.rf_b * rf3.rf_n];
        uf2.j((byte)-108);
        for (int i = 0; rf3.rf_c.length > i; ++i) {
            rf3.rf_c[i] = (byte)uf2.a(5, (byte)75);
        }
        uf2.k((byte)-128);
        if (bl2) {
            this.oi_c[n % this.oi_c.length] = rf2;
        }
        return rf3;
    }

    final rf a(boolean bl, int n) {
        rf rf2;
        if (bl) {
            rf rf3 = null;
            this.a(rf3, (byte)-73);
        }
        if ((rf2 = this.oi_c[n % this.oi_c.length]) == null) {
            return null;
        }
        if (~rf2.rf_j != ~n) {
            return null;
        }
        return rf2;
    }

    final void a(rf rf2, byte by) {
        int n = rf2.rf_j;
        if (rf2 != this.oi_c[n % this.oi_c.length]) {
            throw new IllegalArgumentException();
        }
        if (by < 24) {
            return;
        }
        this.oi_c[n % this.oi_c.length] = null;
    }

    oi(int n) {
        this.oi_c = new rf[n];
    }

    public static void a(int n) {
        block0: {
            oi_d = null;
            oi_a = null;
            oi_b = null;
            oi_e = null;
            if (n == 2) break block0;
            oi_e = null;
        }
    }

    final void a(rf rf2, int n) {
        boolean bl = client.A;
        int n2 = rf2.rf_j;
        if (this.oi_c[n2 % this.oi_c.length] != null && rf2.rf_j == this.oi_c[n2 % this.oi_c.length].rf_j) {
            throw new IllegalArgumentException();
        }
        while (null != this.oi_c[n2 % this.oi_c.length]) {
            this.a((byte)116);
        }
        if (n != 0) {
            oi.a(93, 98, -46);
        }
        this.oi_c[n2 % this.oi_c.length] = rf2;
    }

    static final void a(int n, int n2, sb sb2) {
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        uf2.a(true, 2);
        uf2.a(true, 0);
        if (n > -57) {
            oi.a(-93, 111, -125);
        }
        uf2.a(true, sb2.sb_r);
    }

    static {
        oi_b = "Drawn";
    }
}
