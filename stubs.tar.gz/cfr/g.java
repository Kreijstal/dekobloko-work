/*
 * Decompiled with CFR 0.152.
 */
final class g
extends ek {
    static w R;
    static int L;
    static ck[] O;
    private nb P;
    static String K;
    private int M;
    static ve N;
    static int Q;

    @Override
    final void a(int n, int n2, int n3, int n4) {
        block6: {
            int n5;
            int n6;
            block4: {
                tb tb2;
                block5: {
                    boolean bl = client.A;
                    super.a(n, -105, n3, n4);
                    if (n3 != 0) {
                        return;
                    }
                    n6 = (this.ce_t >> -1680970431) + (this.ce_u + n);
                    n5 = n4 - (-this.D - (this.y >> 2059120769));
                    if (n2 > -103) {
                        this.c((byte)-60);
                    }
                    if (le.le_o == (tb2 = this.P.a(20350)) || jb.jb_j == tb2) break block4;
                    if (tb2 != vm.vm_u) break block5;
                    ck ck2 = tl.tl_u[2];
                    ck2.f(n6 - (ck2.I >> -993975615), n5 + -(ck2.H >> -1066974111), 256);
                    break block6;
                }
                if (tb2 != dc.dc_b) break block6;
                ck ck3 = tl.tl_u[1];
                ck3.f(-(ck3.I >> 1795837889) + n6, n5 + -(ck3.H >> -2125021919), 256);
                break block6;
            }
            ck ck4 = tl.tl_u[0];
            int n7 = ck4.K << 431319489;
            int n8 = ck4.C << -1730393887;
            if (kl.kl_v != null && ~n7 >= ~kl.kl_v.I && n8 <= kl.kl_v.H) {
                tb.a(true, kl.kl_v);
                hk.b();
            } else {
                kl.kl_v = new ck(n7, n8);
                tb.a(true, kl.kl_v);
            }
            ck4.a(112, 144, ck4.K << -1519146172, ck4.C << 2128115844, -this.M << 1537513130, 4096);
            mk.a((byte)-5);
            kl.kl_v.f(n6 + -ck4.K, -ck4.C + n5, 256);
        }
    }

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        if (n <= 38) {
            g.a(100);
        }
        ++this.M;
        super.a(ce2, 89, n2, n3);
    }

    static final wb a(int n, String string) {
        boolean bl = client.A;
        if (null == hg.hg_e) {
            return null;
        }
        String string2 = kf.a(string, (byte)2);
        if (null == string2) {
            string2 = string;
        }
        if (n != -3805) {
            g.a(106);
        }
        wb wb2 = (wb)hg.hg_e.a(24710, string2.hashCode());
        while (wb2 != null) {
            String string3 = kf.a(wb2.Ob, (byte)2);
            if (null == string3) {
                string3 = wb2.Ob;
            }
            if (string3.equals(string2)) {
                return wb2;
            }
            wb2 = (wb)hg.hg_e.d(-17713);
        }
        return null;
    }

    @Override
    final String c(byte by) {
        if (this.ce_q) {
            return this.P.b((byte)69);
        }
        if (by == 113) {
            return null;
        }
        return null;
    }

    @Override
    final boolean a(boolean bl, ce ce2) {
        if (bl) {
            Q = -39;
        }
        return false;
    }

    public static void a(int n) {
        block0: {
            N = null;
            R = null;
            O = null;
            K = null;
            if (n < -91) break block0;
            K = null;
        }
    }

    g(nb nb2) {
        this.P = nb2;
    }

    static {
        L = 2;
        K = "Suggested names: ";
    }
}
