/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;

class en {
    private long en_a = ik.a(4);
    private int en_n = 32;
    int[] en_k;
    static int en_o;
    private ol en_b;
    static boolean en_u;
    private boolean en_f = false;
    private static rc en_r;
    private boolean en_i = true;
    private ol[] en_p;
    private ol[] en_h = new ol[8];
    private int en_l = 0;
    private int en_j = 0;
    private int en_q = 0;
    private long en_g = 0L;
    private static int en_s;
    private int en_t;
    private long en_m = 0L;
    private int en_c;
    private int en_e = 0;
    private int en_d;

    void b() throws Exception {
    }

    final synchronized void g() {
        if (this.en_f) {
            return;
        }
        long l = ik.a(4);
        try {
            if (l > this.en_a + 6000L) {
                this.en_a = l - 6000L;
            }
            while (l > this.en_a + 5000L) {
                this.b(256);
                this.en_a += (long)(256000 / en_o);
                l = ik.a(4);
            }
        }
        catch (Exception exception) {
            this.en_a = l;
        }
        if (this.en_k == null) {
            return;
        }
        try {
            int n;
            int n2;
            if (this.en_m != 0L) {
                if (l < this.en_m) {
                    return;
                }
                this.a(this.en_c);
                this.en_m = 0L;
                this.en_i = true;
            }
            if (this.en_e - (n2 = this.c()) > this.en_q) {
                this.en_q = this.en_e - n2;
            }
            if ((n = this.en_t + this.en_d) + 256 > 16384) {
                n = 16128;
            }
            if (n + 256 > this.en_c) {
                this.en_c += 1024;
                if (this.en_c > 16384) {
                    this.en_c = 16384;
                }
                this.d();
                this.a(this.en_c);
                n2 = 0;
                this.en_i = true;
                if (n + 256 > this.en_c) {
                    n = this.en_c - 256;
                    this.en_d = n - this.en_t;
                }
            }
            while (n2 < n) {
                this.a(this.en_k, 256);
                this.b();
                n2 += 256;
            }
            if (l > this.en_g) {
                if (!this.en_i) {
                    if (this.en_q == 0 && this.en_j == 0) {
                        this.d();
                        this.en_m = l + 2000L;
                        return;
                    }
                    this.en_d = Math.min(this.en_j, this.en_q);
                    this.en_j = this.en_q;
                } else {
                    this.en_i = false;
                }
                this.en_q = 0;
                this.en_g = l + 2000L;
            }
            this.en_e = n2;
        }
        catch (Exception exception) {
            this.d();
            this.en_m = l + 2000L;
        }
    }

    void h() throws Exception {
    }

    void a(int n) throws Exception {
    }

    static final en a(fd fd2, Component component, int n, int n2) {
        if (en_o == 0) {
            throw new IllegalStateException();
        }
        if (n < 0 || n >= 2) {
            throw new IllegalArgumentException();
        }
        if (n2 < 256) {
            n2 = 256;
        }
        try {
            jn jn2;
            jn jn3 = jn2 = new jn();
            jn3.en_k = new int[256 * (en_u ? 2 : 1)];
            ((en)jn3).en_t = n2;
            ((en)jn3).a(component);
            ((en)jn3).en_c = (n2 & 0xFFFFFC00) + 1024;
            if (((en)jn3).en_c > 16384) {
                ((en)jn3).en_c = 16384;
            }
            ((en)jn3).a(((en)jn3).en_c);
            if (en_s > 0 && en_r == null) {
                en_r = new rc();
                en.en_r.rc_f = fd2;
                fd2.a((byte)122, en_s, en_r);
            }
            if (en_r != null) {
                if (en.en_r.rc_l[n] != null) {
                    throw new IllegalArgumentException();
                }
                en.en_r.rc_l[n] = jn2;
            }
            return jn3;
        }
        catch (Throwable throwable) {
            return new en();
        }
    }

    public static void f() {
        en_r = null;
    }

    final synchronized void b(ol ol2) {
        this.en_b = ol2;
    }

    void a(Component component) throws Exception {
    }

    final synchronized void a() {
        this.en_i = true;
        try {
            this.h();
        }
        catch (Exception exception) {
            this.d();
            this.en_m = ik.a(4) + 2000L;
        }
    }

    static final void a(int n, boolean bl, int n2) {
        if (n < 8000 || n > 48000) {
            throw new IllegalArgumentException();
        }
        en_o = n;
        en_u = bl;
        en_s = n2;
    }

    private final void a(ol ol2, int n) {
        int n2 = n >> 5;
        ol ol3 = this.en_h[n2];
        if (ol3 == null) {
            this.en_p[n2] = ol2;
        } else {
            ol3.ol_o = ol2;
        }
        this.en_h[n2] = ol2;
        ol2.ol_n = n;
    }

    void d() {
    }

    private final void a(int[] nArray, int n) {
        int n2 = n;
        if (en_u) {
            n2 <<= 1;
        }
        an.a(nArray, 0, n2);
        this.en_l -= n;
        if (this.en_b != null && this.en_l <= 0) {
            ol ol2;
            int n3;
            this.en_l += en_o >> 4;
            en.a(this.en_b);
            this.a(this.en_b, this.en_b.b());
            int n4 = 0;
            int n5 = 255;
            int n6 = 7;
            block0: while (n5 != 0) {
                int n7;
                int n8;
                if (n6 < 0) {
                    n8 = n6 & 3;
                    n7 = -(n6 >> 2);
                } else {
                    n8 = n6;
                    n7 = 0;
                }
                for (n3 = n5 >>> n8 & 0x11111111; n3 != 0; n3 >>>= 4) {
                    if ((n3 & 1) != 0) {
                        n5 &= ~(1 << n8);
                        ol2 = null;
                        ol ol3 = this.en_p[n8];
                        while (ol3 != null) {
                            ti ti2 = ol3.ol_q;
                            if (ti2 != null && ti2.ti_n > n7) {
                                n5 |= 1 << n8;
                                ol2 = ol3;
                                ol3 = ol3.ol_o;
                                continue;
                            }
                            ol3.ol_p = true;
                            int n9 = ol3.a();
                            n4 += n9;
                            if (ti2 != null) {
                                ti2.ti_n += n9;
                            }
                            if (n4 >= this.en_n) break block0;
                            ol ol4 = ol3.d();
                            if (ol4 != null) {
                                int n10 = ol3.ol_n;
                                while (ol4 != null) {
                                    this.a(ol4, n10 * ol4.b() >> 8);
                                    ol4 = ol3.c();
                                }
                            }
                            ol ol5 = ol3.ol_o;
                            ol3.ol_o = null;
                            if (ol2 == null) {
                                this.en_p[n8] = ol5;
                            } else {
                                ol2.ol_o = ol5;
                            }
                            if (ol5 == null) {
                                this.en_h[n8] = ol2;
                            }
                            ol3 = ol5;
                        }
                    }
                    n8 += 4;
                    ++n7;
                }
                --n6;
            }
            for (n6 = 0; n6 < 8; ++n6) {
                ol ol6 = this.en_p[n6];
                ol[] olArray = this.en_p;
                n3 = n6;
                this.en_h[n6] = null;
                olArray[n3] = null;
                while (ol6 != null) {
                    ol2 = ol6.ol_o;
                    ol6.ol_o = null;
                    ol6 = ol2;
                }
            }
        }
        if (this.en_l < 0) {
            this.en_l = 0;
        }
        if (this.en_b != null) {
            this.en_b.b(nArray, 0, n);
        }
        this.en_a = ik.a(4);
    }

    private final void b(int n) {
        this.en_l -= n;
        if (this.en_l < 0) {
            this.en_l = 0;
        }
        if (this.en_b != null) {
            this.en_b.a(n);
            return;
        }
    }

    private static final void a(ol ol2) {
        ol2.ol_p = false;
        if (ol2.ol_q != null) {
            ol2.ol_q.ti_n = 0;
        }
        ol ol3 = ol2.d();
        while (ol3 != null) {
            en.a(ol3);
            ol3 = ol2.c();
        }
    }

    int c() throws Exception {
        return this.en_c;
    }

    final synchronized void e() {
        if (en_r != null) {
            boolean bl = true;
            for (int i = 0; i < 2; ++i) {
                if (en.en_r.rc_l[i] == this) {
                    en.en_r.rc_l[i] = null;
                }
                if (en.en_r.rc_l[i] == null) continue;
                bl = false;
            }
            if (bl) {
                en.en_r.rc_j = true;
                while (en.en_r.rc_b) {
                    ua.a(50L, -128);
                }
                en_r = null;
            }
        }
        this.d();
        this.en_k = null;
        this.en_f = true;
    }

    en() {
        this.en_p = new ol[8];
    }
}
