/*
 * Decompiled with CFR 0.152.
 */
interface gj
extends kg {
    public void a(boolean var1, ce var2, boolean var3);
}
