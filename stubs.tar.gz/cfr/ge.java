/*
 * Decompiled with CFR 0.152.
 */
final class ge {
    static int ge_e;
    static s ge_f;
    static String ge_d;
    static boolean ge_j;
    static ck ge_h;
    static ij ge_g;
    static int ge_b;
    static volatile int ge_a;
    static volatile boolean ge_i;
    static boolean ge_c;

    static final int a(lk lk2, int n) {
        boolean bl = client.A;
        if (null == lk2) {
            return 0;
        }
        int n2 = 0;
        int n3 = 10000 / lk2.O;
        if (n <= 14) {
            lk lk3 = null;
            ge.a(lk3, 96);
        }
        int n4 = lk2.z;
        while (~lk2.lk_a < ~n4) {
            for (int i = 0; lk2.O > i; ++i) {
                if (-1 == ~lk2.P[n4 * lk2.O - -i]) continue;
                n2 += n3;
            }
            n3 = n3 * 3 / 4;
            ++n4;
        }
        n4 = 0;
        if (-5001 >= ~(n2 += n3 * lk2.O)) {
            n4 = 1;
        }
        if (-20001 >= ~n2) {
            n4 = 2;
        }
        return n4;
    }

    static final jg b(byte by) {
        String string = aa.a(by + 35);
        if (string != null && -1 >= ~string.indexOf(64)) {
            string = "";
        }
        if (by != -89) {
            ge_b = 0;
        }
        return new jg(aa.a(-65), uk.c((byte)-17));
    }

    public static void a(boolean bl) {
        ge_d = null;
        if (!bl) {
            return;
        }
        ge_f = null;
        ge_h = null;
        ge_g = null;
    }

    static final ni a(byte by, int n, int n2, pi[] piArray, byte[] byArray, int n3) {
        int[] nArray;
        boolean bl = client.A;
        if (256 != piArray.length) {
            throw new IllegalArgumentException();
        }
        int[] nArray2 = nArray = new int[256];
        int[] nArray3 = new int[256];
        int[] nArray4 = new int[256];
        int[] nArray5 = new int[256];
        int n4 = -2 / ((48 - by) / 43);
        int[] nArray6 = new int[]{0, n, n3};
        byte[][] byArrayArray = new byte[256][];
        int[] nArray7 = hk.hk_l;
        int n5 = hk.hk_j;
        int n6 = hk.hk_i;
        int[] nArray8 = new int[4];
        hk.b(nArray8);
        int n7 = 0;
        while (-257 < ~n7) {
            int n8;
            int n9;
            nArray[n7] = piArray[n7].lc_d + -n2;
            nArray3[n7] = piArray[n7].lc_c + -n2;
            nArray4[n7] = (n2 << 435946913) + piArray[n7].lc_b;
            nArray5[n7] = piArray[n7].lc_i + (n2 << -894393727);
            byArrayArray[n7] = new byte[nArray4[n7] * nArray5[n7]];
            byte[] byArray2 = byArrayArray[n7];
            byte[] byArray3 = piArray[n7].pi_k;
            int n10 = piArray[n7].lc_b;
            int n11 = piArray[n7].lc_i;
            int n12 = nArray4[n7];
            int n13 = n12 + -n10;
            hk.a(new int[nArray5[n7] * nArray4[n7]], nArray4[n7], nArray5[n7]);
            int n14 = 0;
            for (n9 = 0; n9 < n11; ++n9) {
                for (n8 = 0; n10 > n8; ++n8) {
                    if (0 == byArray3[n14++]) continue;
                    hk.a(n8, n9, (n2 << 1731923329) + 1, (n2 << -1375208415) + 1, 2);
                }
            }
            n14 = 0;
            n9 = 0;
            while (~byArray2.length < ~n9) {
                byArray2[n9] = (byte)hk.hk_l[n9];
                ++n9;
            }
            n9 = (1 + nArray4[n7]) * n2;
            for (n8 = 0; n8 < n11; ++n8) {
                int n15 = 0;
                while (~n10 < ~n15) {
                    if (byArray3[n14++] == 0) {
                        ++n9;
                    } else {
                        byArray2[n9++] = 1;
                    }
                    ++n15;
                }
                n9 += n13;
            }
            ++n7;
        }
        ni ni2 = new ni(byArray, nArray, nArray3, nArray4, nArray5, nArray6, byArrayArray);
        ni2.C -= n2;
        ni2.K -= n2;
        ni2.R -= n2;
        hk.a(nArray7, n5, n6);
        hk.a(nArray8);
        return ni2;
    }

    static final void a(int n, int n2, byte by, ud ud2) {
        block0: {
            ai.a(80, 0, ud2, n, n2);
            if (by == 127) break block0;
            ge.a((byte)73);
        }
    }

    static final void a(byte by) {
        pn.pn_bb = new String[qb.qb_u];
        pn.pn_bb[18] = gg.E;
        pn.pn_bb[17] = ue.ue_d;
        pn.pn_bb[5] = cc.cc_b;
        pn.pn_bb[4] = im.im_d;
        pn.pn_bb[9] = gb.Tb;
        pn.pn_bb[15] = ml.ml_d;
        pn.pn_bb[21] = cb.cb_d;
        pn.pn_bb[11] = km.y;
        pn.pn_bb[7] = gh.gh_d;
        pn.pn_bb[20] = hd.hd_v;
        pn.pn_bb[19] = wk.wk_k;
        pn.pn_bb[6] = jd.Zb;
        pn.pn_bb[13] = vh.vh_c;
        if (by != 123) {
            ge_e = 114;
        }
        pn.pn_bb[16] = uj.uj_e;
    }

    static final void a(byte by, jk jk2) {
        if (by > -65) {
            ge.a((byte)-116, -89, -66, null, null, 119);
        }
        me.z = jk2;
    }

    static {
        ge_j = false;
        ge_d = "Invalid name";
        ge_g = new ij("usename");
        ge_a = 0;
        ge_i = true;
    }
}
