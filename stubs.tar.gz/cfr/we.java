/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import java.net.Socket;

abstract class we {
    int we_f;
    static String we_c;
    static String we_g;
    static String we_e;
    static uf we_b;
    String we_d;
    static String we_a;

    static final void a(byte by) {
        block1: {
            if (gd.gd_f) {
                bb.b(true);
                jd.g(74);
                d.a(true);
                gd.gd_f = false;
            }
            if (by > 46) break block1;
            we.a(true);
        }
    }

    static final ck[] a(ji ji2, int n, int n2, int n3) {
        block1: {
            if (!gb.a(n3, ji2, n2, 115)) {
                return null;
            }
            if (n < -123) break block1;
            we.a((byte)55);
        }
        return de.c(false);
    }

    final Socket b(int n) throws IOException {
        if (n != 2) {
            return null;
        }
        return new Socket(this.we_d, this.we_f);
    }

    abstract Socket a(int var1) throws IOException;

    we() {
    }

    public static void b(byte by) {
        we_g = null;
        we_e = null;
        if (by != -37) {
            return;
        }
        we_b = null;
        we_a = null;
        we_c = null;
    }

    static final int a(boolean bl) {
        boolean bl2 = client.A;
        boolean bl3 = bl;
        while (ab.c((byte)114)) {
            wj.Jb.a(-38);
            if (!wj.Jb.b((byte)114)) continue;
            bl3 = true;
        }
        wj.Jb.a(pm.a(pm.pm_f, -2141435999, bh.bh_g), -20563, pm.a(nf.nf_h, -2141435999, he.S));
        if (wj.Jb.b((byte)114)) {
            bl3 = true;
        }
        int n = 0;
        if (bl3 && ~wj.Jb.sk_h <= -1 && (n = ef.T[wj.Jb.sk_h]) == 2) {
            ek.g(-1209);
        }
        return n;
    }

    static {
        we_e = "<%0> players want to draw. Hold 'F1' for details.";
        we_c = "achievements to collect";
        we_g = "Rematch!";
        we_a = "EXCLUSIVE";
    }
}
