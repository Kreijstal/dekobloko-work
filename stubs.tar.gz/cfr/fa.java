/*
 * Decompiled with CFR 0.152.
 */
final class fa
extends bh {
    static boolean fa_n;
    static String fa_o;
    static int[] fa_q;
    static String fa_r;
    int fa_s;
    byte[] fa_p;

    public static void c(byte by) {
        fa_o = null;
        if (by != -74) {
            fa.c((byte)-12);
        }
        fa_r = null;
        fa_q = null;
    }

    private fa() throws Throwable {
        throw new Error();
    }

    static {
        fa_o = "Continue";
    }
}
