/*
 * Decompiled with CFR 0.152.
 */
interface nl {
    public cf a(ce var1, byte var2);

    public int a(boolean var1, ce var2);

    public void a(ce var1, int var2, int var3, int var4, int var5);

    public int a(ce var1, int var2);

    public int a(byte var1, ce var2, int var3);

    public int a(int var1, int var2, ce var3);

    public int a(byte var1);

    public int b(ce var1, int var2);

    public int a(int var1, int var2, ce var3, int var4, int var5, int var6);

    public void a(int var1, int var2, int var3, int var4, int var5, ce var6);
}
