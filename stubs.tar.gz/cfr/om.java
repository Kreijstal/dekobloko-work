/*
 * Decompiled with CFR 0.152.
 */
final class om {
    static String om_b;
    static String om_g;
    static int om_a;
    static String om_c;
    static boolean om_f;
    static String om_e;
    static volatile int om_d;
    private static final String z;

    public static void a(boolean bl) {
        om_c = null;
        om_g = null;
        om_e = null;
        if (bl) {
            om_a = -81;
        }
        om_b = null;
    }

    static {
        z = "om.A(";
        om_b = "Return to lobby";
        om_c = "Played";
        om_g = "Friends";
        om_d = 0;
        om_e = "Show private chat from my friends and opponents";
    }
}
