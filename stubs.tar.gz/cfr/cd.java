/*
 * Decompiled with CFR 0.152.
 */
final class cd {
    String cd_f;
    boolean cd_e;
    int cd_h;
    static vj cd_c = new vj();
    boolean cd_n;
    static int[] cd_b = new int[8192];
    static ck cd_k;
    static ve cd_m;
    String[] cd_d;
    static String cd_j;
    static boolean cd_i;
    static int cd_a;
    static String cd_l;
    static volatile boolean cd_g;

    static final lm a(String string, ji ji2, ji ji3, byte by, String string2) {
        if (by <= 86) {
            cd_b = null;
        }
        int n = ji3.b(-1, string2);
        int n2 = ji3.a(n, 13030, string);
        return ql.a(ji3, (byte)41, n2, n, ji2);
    }

    static final boolean a(int n) {
        if (n != 8192) {
            cd_c = null;
        }
        return cl.cl_v != null ? true : qc.N;
    }

    static final void a(boolean bl) {
        block0: {
            am.am_a = null;
            nk.nk_k = false;
            h.h_d = null;
            f.f_s = null;
            pd.pd_d = null;
            ca.ca_wb = null;
            kf.G = null;
            cl.B = null;
            if (bl) break block0;
            cd_m = null;
        }
    }

    public static void a(byte by) {
        cd_l = null;
        cd_c = null;
        cd_m = null;
        cd_k = null;
        if (by < 119) {
            return;
        }
        cd_b = null;
        cd_j = null;
    }

    cd(boolean bl) {
        this.cd_n = bl;
    }

    static {
        cd_i = false;
        cd_j = "<%0> wants to draw.";
        cd_g = true;
        cd_l = "Full";
    }
}
