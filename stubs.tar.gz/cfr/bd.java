/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.net.URL;

abstract class bd
extends hn {
    private boolean bd_t;
    private int bd_u;
    private int bd_v;
    private int bd_n;
    private int bd_w;
    private int bd_q;
    private boolean bd_r;
    private int bd_o;
    private long bd_s;
    String bd_m;
    private boolean bd_p;

    private final void c(byte by) {
        block0: {
            te.te_v[5] = true;
            if (by > 62) break block0;
            this.bd_s = -10L;
        }
    }

    private final void h(int n) {
        block0: {
            te.te_v[6] = true;
            if (n == -1) break block0;
            this.i(-42);
        }
    }

    private final int a(boolean bl, int n2, boolean bl2) {
        int n3;
        boolean bl3 = client.A;
        int n4 = -3 % ((6 - n2) / 36);
        int n5 = ne.a(255, kd.kd_p, bl, jk.jk_c);
        if (n5 == 0) {
            throw new IllegalStateException();
        }
        if (-2 == ~n5) {
            n3 = sm.a(ge.b((byte)-89), ob.b((byte)-117), 125);
            if (-1 != n3) {
                qf.a(rk.Y, ph.Eb, n3, -677);
                rk.Y = null;
                ph.Eb = null;
            }
            Boolean bl4 = pg.a(24994);
            if (bl4 != null) {
                pk.a(bl4, false);
            }
        }
        if (-3 == ~n5 && 0 != ~(n3 = rd.a(pc.a(2), sm.a((byte)-97), f.a(116), aa.a(-48), 0, this.bd_v, sm.b(1)))) {
            jc.a(ph.Eb, n3, rk.Y, 0);
            rk.Y = null;
            ph.Eb = null;
        }
        if (3 == n5) {
            if (~s.Pb != 0 && s.Pb != 0) {
                s.Pb = -1;
                sn.c((byte)-115);
            }
            if (bl2) {
                of.of_h = false;
            } else {
                n3 = sn.a(aa.a(-48), this.bd_r, pc.a(2), (byte)55, this.bd_v, false);
                if (-1 != n3) {
                    if (-1 == ~n3) {
                        ua.B = sh.sh_f;
                        n.a(1);
                        v.v_d = false;
                        hc.hc_d = 10;
                    } else {
                        dd.a(rk.Y, 0, n3);
                        rk.Y = null;
                    }
                }
            }
        }
        if (~n5 == -5) {
            if (ce.ce_w) {
                be.a(se.h(25144), (byte)-57);
            } else {
                v.v_d = true;
                hc.hc_d = 10;
            }
        }
        if (~n5 == -6) {
            pk.me_a_applet((byte)-17, se.h(25144));
        }
        if (n5 == 6 && qi.M) {
            hc.hc_d = 10;
        }
        if (n5 == 7) {
            ki.me_a_applet((byte)96, se.h(25144));
        }
        if (8 == n5) {
            be.a(se.h(25144), (byte)-57);
        }
        if (9 == n5) {
            bh.a(-114, se.h(25144));
        }
        if (10 == n5) {
            we.we_b.f(17, -4);
        }
        if (-12 == ~n5) {
            wb.a(se.h(25144), 30307);
        }
        if (-13 == ~n5) {
            aj.a(vm.c(-30185), -88, se.h(25144));
        }
        if (13 == n5) {
            try {
                if (vg.E == null) {
                    vg.E = new oh(lf.lf_e, new URL(this.getCodeBase(), "countrylist.ws"), 5000);
                }
                if (vg.E.a(-125)) {
                    wl wl2 = vg.E.a(false);
                    if (null == wl2) {
                        jb.jb_a_string(null, (byte)45);
                    } else {
                        String string = un.a(wl2.wl_r, 0, 0, wl2.wl_n);
                        jb.jb_a_string(string, (byte)45);
                    }
                    vg.E = null;
                }
            }
            catch (Exception exception) {
                qb.a(exception, 16408, "S1");
                jb.jb_a_string(null, (byte)45);
                vg.E = null;
            }
        }
        if (~n5 == -16) {
            hc.hc_d = 10;
        }
        if (-17 == ~n5) {
            return 1;
        }
        if (17 == n5) {
            return 2;
        }
        return 0;
    }

    private final void i(int n2) {
        block0: {
            String string = ui.a(n2 ^ 0xFFFFD0F8);
            oa.a(se.h(25144), -1, string);
            if (n2 == 0) break block0;
            this.f((byte)100);
        }
    }

    final void g(int n2) {
        block6: {
            block5: {
                boolean bl2 = client.A;
                if (n2 != 10) {
                    return;
                }
                if (t.i((byte)124)) break block5;
                if (ca.ca_vb < 10) break block6;
                if (dl.a(480)) {
                    if (-1 != ~hc.hc_d) {
                        ql.a(jk.jk_c, (byte)-101);
                    } else {
                        this.a(false, -104, false);
                    }
                } else {
                    ua.h((byte)-70);
                }
                break block6;
            }
            this.a(null != cl.cl_v, -41, false);
        }
    }

    private final void e(byte by) {
        block0: {
            te.te_v[13] = true;
            te.te_v[12] = true;
            te.te_v[11] = true;
            if (by == 13) break block0;
            this.bd_v = -26;
        }
    }

    final void b(boolean bl2, int n2) {
        block55: {
            boolean bl3 = client.A;
            if (li.li_b != null) {
                if (null == cl.cl_v) {
                    Container container = wm.f((byte)126);
                    Dimension dimension = container.getSize();
                    li.li_b.a(dimension.width, false, dimension.height);
                }
                li.li_b.a(false);
            }
            wf.b(19012);
            ql.c(-2);
            if (!ta.a((byte)-35) && ~hc.hc_d != -12) {
                fh.a(-52);
            }
            if (null != uc.uc_e) {
                jk.jk_c = uc.uc_e.a(60);
            }
            if (si.c(-12851)) {
                int n3 = n.a((byte)-74) * 1200;
                if (this.bd_p || ~n3 > ~fl.a((byte)-108) && ~n3 > ~ne.b((byte)-40)) {
                    this.bd_p = false;
                    si.a(79);
                    gh.a(false);
                    dd.a(am.am_d, n2 ^ 0xFFFFFFF5, 2);
                    jc.b((byte)84);
                    of.of_h = true;
                    lb.lb_d = ik.a(n2 + 15) + 15000L;
                }
            }
            if (~s.Pb == 0 || -1 == ~s.Pb) {
                boolean bl4 = ~s.Pb == 0;
                s.Pb = ib.l(102);
                if (bl4 && ~s.Pb == -1 && -12 == ~hc.hc_d && !ea.c((byte)-57)) {
                    n.a(1);
                }
                if (-1 != s.Pb && s.Pb != 0) {
                    lb.lb_d = ik.a(4) - -15000L;
                }
            }
            if (s.Pb != -1 && s.Pb != 0) {
                if (~ca.ca_vb <= -11) {
                    if (-11 >= ~hc.hc_d) {
                        gh.a(false);
                        if (-4 != ~s.Pb) {
                            if (4 != s.Pb) {
                                if (2 != s.Pb) {
                                    if (s.Pb == 5) {
                                        dd.a(ah.ah_a, n2 + 11, 5);
                                    } else {
                                        dd.a(kf.N, 0, 256);
                                    }
                                } else {
                                    dd.a(kb.kb_f, 0, 256);
                                }
                            } else {
                                dd.a(ub.ub_f, n2 + 11, 256);
                            }
                        } else {
                            dd.a(ic.ic_d, 0, 256);
                        }
                        of.of_h = true;
                    }
                } else if (~s.Pb != -4) {
                    if (4 != s.Pb) {
                        if (s.Pb == 2) {
                            this.a(true, "js5connect_full");
                        } else if (-6 != ~s.Pb) {
                            this.a(true, "js5connect");
                        } else {
                            this.a(true, "outofdate");
                        }
                    } else {
                        this.a(true, "js5io");
                    }
                } else {
                    this.a(true, "js5crc");
                }
            }
            if ((s.Pb != -1 && ~s.Pb != -1 || ea.c((byte)-112)) && (ik.a(4) ^ 0xFFFFFFFFFFFFFFFFL) <= (lb.lb_d ^ 0xFFFFFFFFFFFFFFFFL)) {
                of.of_h = false;
                if (~s.Pb != 0 && 0 != s.Pb) {
                    s.Pb = -1;
                    sn.c((byte)-116);
                }
            }
            if (s.Pb == 0 && !ea.c((byte)-112)) {
                tf.tf_bb = false;
            }
            if (-1 == ~ca.ca_vb && nf.c(48)) {
                ca.ca_vb = 1;
            }
            if (~ca.ca_vb == -2) {
                if (0 != kd.kd_p) {
                    vj.vj_a = vg.a(vh.vh_d, 34);
                }
                sk.sk_f = tf.a(1, n2 + 131, false, true, cg.cg_a);
                rc.rc_k = tf.a(1, 127, false, true, a.a_h);
                ph.Fb = tf.a(1, 113, false, true, rf.rf_d);
                ah.ah_i = sk.sk_f;
                ca.ca_vb = 2;
                qc.qc_vb = rc.rc_k;
            }
            if (~ca.ca_vb == -3) {
                if (vj.vj_a != null && vj.vj_a.a((byte)121)) {
                    if (!vj.vj_a.a("", n2 ^ 0xFFFFFFF5)) {
                        vj.vj_a = null;
                    } else if (vj.vj_a.a("", (byte)-94)) {
                        ml.a(vj.vj_a, (byte)117);
                        vj.vj_a = null;
                        vj.a(true);
                    }
                }
                if (vj.vj_a == null) {
                    ca.ca_vb = 3;
                }
            }
            if (3 == ca.ca_vb && ta.a(sk.sk_f, rc.rc_k, -21, ph.Fb) && ba.a(ph.Fb, Integer.MIN_VALUE)) {
                e.b(-8621);
                nm.h((byte)112);
                qi.M = false;
                he.he_hb = wf.wf_m;
                se.a(sk.sk_f, ph.Fb, (byte)76, ce.ce_w, rc.rc_k);
                if (ge.ge_j || null != vd.vd_q) {
                    rb.a(!ge.ge_j, (byte)-86, vd.vd_q, !ge.ge_j);
                }
                if (om.om_f) {
                    rk.c(false);
                }
                if (null == hm.hm_c) {
                    hm.hm_c = pk.a(15000);
                    ea.ea_r = i.a(1);
                }
                ed.a(ph.Fb, ea.ea_r, hm.hm_c, 20350);
                sk.sk_f = null;
                rc.rc_k = null;
                ph.Fb = null;
                rd.a(this, false);
                vj.a(true);
                ca.ca_vb = 10;
            }
            if (~ca.ca_vb == n2) {
                if (0 != kd.kd_p) {
                    wk.wk_q = vg.a(gi.gi_e, 112);
                }
                ca.ca_vb = 11;
            }
            if (~ca.ca_vb == -12) {
                if (null == wk.wk_q || wk.wk_q.a((byte)121) && wk.wk_q.a(false)) {
                    ca.ca_vb = 12;
                    of.of_c = true;
                } else {
                    qi.a(0.0f, -78, ad.a(wk.wk_q, fe.fe_a, true, eb.eb_n));
                }
            }
            if (12 == ca.ca_vb && !of.of_c) {
                ca.ca_vb = 13;
            }
            if (~ca.ca_vb == -14) {
                boolean bl5 = true;
                if (sh.sh_g != null) {
                    bl5 = sh.sh_g.a(-57);
                    qi.a(sh.sh_g.cb_l, n2 + 82, sh.sh_g.cb_a);
                }
                if (bl5) {
                    ca.ca_vb = 20;
                }
            }
            if (!bl2 && jg.jg_e) {
                tj.a(false, jh.jh_b);
                this.b((byte)-91);
                hl.a(jh.jh_b, (byte)-97);
            }
            if (!te.te_v[8]) break block55;
            ec.a(n2 + -82);
        }
    }

    final int a(boolean bl2, byte by) {
        block0: {
            if (by == 102) break block0;
            this.bd_t = false;
        }
        return this.a(bl2, by ^ 0xFFFFFF84, true);
    }

    final void f(byte by) {
        int n2;
        boolean bl2 = client.A;
        if (by < 115) {
            this.g(-60);
        }
        if ((n2 = bh.bh_k) >= 64 || !te.te_v[n2]) {
            qb.a(null, 16408, "MGS2: " + qk.d((byte)127));
            si.a(119);
            return;
        }
        if (n2 == 0) {
            return;
        }
        if (-2 == ~n2) {
            ua.i((byte)-21);
        } else if (2 == n2) {
            ke.e((byte)48);
        } else if (n2 != 3) {
            if (n2 == 4) {
                cm.a((byte)53);
            } else if (5 != n2) {
                if (~n2 == -7) {
                    ul.a((byte)112);
                } else if (7 != n2) {
                    if (~n2 != -9) {
                        if (-17 != ~n2) {
                            if (n2 != 11 && -13 != ~n2) {
                                if (13 == n2) {
                                    oe.c(false);
                                } else if (17 == n2) {
                                    this.l(-33);
                                } else if (-19 != ~n2) {
                                    qb.a(null, 16408, "MGS1: " + qk.d((byte)52));
                                    si.a(65);
                                } else {
                                    ne.c(27721);
                                }
                            } else {
                                hl hl2 = ki.a(0, n2 == 12);
                                cl.a(hl2, true);
                            }
                        } else {
                            wm.d(140);
                        }
                    } else {
                        qn.a(sm.sm_e, lf.lf_e, 0x404040, de.V);
                    }
                } else {
                    this.i(0);
                }
            } else {
                pe.b(14750);
            }
        } else {
            dk.a(69);
        }
    }

    private final void h(byte by) {
        block0: {
            te.te_v[4] = true;
            if (by == -25) break block0;
            this.bd_q = 127;
        }
    }

    final void a(int n2, int n3, String string) {
        if (n2 != -2990) {
            this.bd_m = null;
        }
        this.a(n3, false, 480, 640, string);
    }

    private final void a(int n2, boolean bl2) {
        if (n2 < 70) {
            this.bd_m = null;
        }
        te.te_v[0] = true;
        te.te_v[17] = true;
        te.te_v[16] = true;
        te.te_v[7] = true;
        te.te_v[8] = bl2;
        te.te_v[18] = true;
        te.te_v[3] = true;
    }

    private final int j(int n2) {
        if (this.hn_f) {
            return -1;
        }
        if (!ea.c((byte)-38)) {
            return -1;
        }
        if (of.of_h) {
            return -1;
        }
        int n3 = sn.a(aa.a(n2 + -68), this.bd_r, pc.a(2), (byte)55, this.bd_v, true);
        if (-1 == n3) {
            return -1;
        }
        if (0 == n3 || -2 == ~n3) {
            if (-12 == ~hc.hc_d && -1 == ~s.Pb) {
                n.a(1);
            }
            return n3;
        }
        if (!lf.lf_g) {
            this.a(true, "reconnect");
        }
        gh.a(false);
        dd.a(rk.Y, n2 ^ n2, n3);
        of.of_h = true;
        lb.lb_d = 15000L + ik.a(4);
        return n3;
    }

    static final void a(int n2, int n3) {
        if (n3 != -27096) {
            return;
        }
        ul.ul_g = 1000000000L / (long)n2;
    }

    final void a(int n2, int n3, int n4, int n5, int n6, int n7, int n8, boolean bl2) {
        Frame frame = new Frame("Jagex");
        frame.pack();
        frame.dispose();
        this.setBackground(Color.black);
        if (n3 <= 2) {
            return;
        }
        kd.kd_p = this.bd_o;
        lc.a(kd.kd_p, true);
        j.a(n4, this.bd_u, lf.lf_e, 5000, 5000, this.bd_s, kd.kd_p, bl2, this.bd_q, this.bd_w, this.bd_t, true, this.bd_n, this.bd_m);
        ce.a(this.bd_w, this.bd_u, kd.kd_p, n4, this.bd_n, this.bd_m, lf.lf_e, 0, this.bd_q);
        eb.c(120);
        uc.uc_e = t.k(-22);
        hl.a(jh.jh_b, (byte)-71);
        gi.gi_e = n2;
        a.a_h = n8;
        vh.vh_d = n5;
        cg.cg_a = n6;
        rf.rf_d = n7;
        this.c(true);
        oh.a((byte)13);
    }

    private final void m(int n2) {
        block0: {
            te.te_v[1] = true;
            if (n2 == -1) break block0;
            this.bd_o = 49;
        }
    }

    final void a(boolean bl2, boolean bl3, boolean bl4, boolean bl5, boolean bl6, boolean bl7, boolean bl8) {
        block6: {
            this.a(77, true);
            if (bl2) {
                this.m(-1);
            }
            if (bl4) {
                this.k(7);
            }
            if (bl5) {
                return;
            }
            if (bl7) {
                this.h((byte)-25);
            }
            if (bl8) {
                this.c((byte)87);
            }
            if (bl6) {
                this.h(-1);
            }
            if (!bl3) break block6;
            this.e((byte)13);
        }
    }

    private final void a(int n2, boolean bl2, int n3, int n4, String string) {
        try {
            if (!this.a((byte)-29)) {
                return;
            }
            this.bd_m = this.getCodeBase().getHost();
            String string2 = this.bd_m.toLowerCase();
            this.bd_r = string2.equals("jagex.com") || string2.endsWith(".jagex.com");
            this.bd_n = Integer.parseInt(this.getParameter("gameport1"));
            this.bd_w = Integer.parseInt(this.getParameter("gameport2"));
            String string3 = this.getParameter("servernum");
            if (null != string3) {
                this.bd_q = Integer.parseInt(string3);
            }
            this.bd_u = Integer.parseInt(this.getParameter("gamecrc"));
            this.bd_s = Long.parseLong(this.getParameter("instanceid"));
            this.bd_t = this.getParameter("member").equals("yes");
            String string4 = this.getParameter("lang");
            if (null != string4) {
                this.bd_o = Integer.parseInt(string4);
            }
            if (5 <= this.bd_o) {
                this.bd_o = 0;
            }
            String string5 = this.getParameter("affid");
            if (string5 != null) {
                this.bd_v = Integer.parseInt(string5);
            }
            om.om_f = Boolean.valueOf(this.getParameter("simplemode"));
            if (bl2) {
                return;
            }
            this.a(string, 32, n2, !bl2, n3, n4, this.bd_u);
        }
        catch (Exception exception) {
            qb.a(exception, 16408, null);
            this.a(!bl2, "crash");
        }
    }

    static final boolean d(byte by) {
        int n2 = -5 % ((by - -47) / 44);
        return true;
    }

    private final void l(int n2) {
        int n3 = 105 / ((n2 - 27) / 38);
        int n4 = de.V.d((byte)-124);
        boolean bl2 = (n4 & 1) != 0;
        int n5 = sm.sm_e - 1;
        byte[] byArray = new byte[n5];
        de.V.a(-67, byArray, n5, 0);
        c.a((byte)84, qj.a(byArray, 2), bl2, se.h(25144));
    }

    private final void k(int n2) {
        if (n2 != 7) {
            return;
        }
        te.te_v[2] = true;
    }

    final int g(byte by) {
        int n2 = this.j(-1);
        if (by <= 122) {
            this.bd_w = -122;
        }
        if (0 == n2 || n2 == 1) {
            if (te.te_v[1]) {
                qn.c(-20494, 2);
            }
            if (te.te_v[2]) {
                dg.a(-111, 3);
            }
            if (te.te_v[3]) {
                of.a(false, 4);
            }
            if (te.te_v[4]) {
                wa.a(3, 5);
            }
            if (te.te_v[5]) {
                bh.a(6, -120);
            }
            if (te.te_v[6]) {
                dl.b(640, 7);
            }
            if (te.te_v[8]) {
                ga.b((byte)-112);
            }
        }
        return n2;
    }

    private final void c(boolean bl2) {
        mk.mk_c[18] = 1;
        mk.mk_c[4] = -1;
        mk.mk_c[13] = -1;
        mk.mk_c[8] = -2;
        mk.mk_c[2] = -2;
        mk.mk_c[1] = 16;
        if (!bl2) {
            return;
        }
        mk.mk_c[11] = -1;
        mk.mk_c[7] = -1;
        mk.mk_c[3] = -1;
        mk.mk_c[6] = -2;
        mk.mk_c[9] = -1;
        mk.mk_c[5] = -1;
        mk.mk_c[17] = -1;
        mk.mk_c[12] = -1;
        mk.mk_c[10] = -1;
        mk.mk_c[16] = -1;
    }

    protected bd() {
    }
}
