/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

final class ql
extends Canvas
implements FocusListener {
    Frame ql_g;
    static String ql_a = "Month";
    static cc ql_b;
    volatile boolean ql_e;
    static int ql_c;
    static String ql_f;
    static int[] ql_d;

    @Override
    public final void focusLost(FocusEvent focusEvent) {
        this.ql_e = true;
    }

    @Override
    public final void focusGained(FocusEvent focusEvent) {
    }

    static final lm a(ji ji2, byte by, int n, int n2, ji ji3) {
        if (by != 41) {
            ql_a = null;
        }
        if (!gb.a(n2, ji2, n, 56)) {
            return null;
        }
        return w.a(ji3.a(n, -117, n2), (byte)-5);
    }

    ql() {
    }

    @Override
    public final void update(Graphics graphics) {
    }

    static final void a(int n, byte by) {
        int n2 = -50 % ((by - -51) / 49);
        qm.a((byte)57);
    }

    static final boolean a(int n) {
        if (n != 2) {
            return false;
        }
        return !wl.wl_p;
    }

    static final void a(vj vj2, int n, int n2) {
        bh bh2;
        boolean bl = client.A;
        if (~n2 >= -2) {
            return;
        }
        bh bh3 = vj2.vj_c.bh_b;
        if (n >= -114) {
            return;
        }
        for (int i = 0; n2 > i; i += 2) {
            bh3 = bh3.bh_b;
        }
        vj vj3 = new vj();
        vj2.a(-128, bh3, vj3);
        ql.a(vj2, -117, (1 + n2) / 2);
        ql.a(vj3, -127, n2 / 2);
        bh bh4 = vj2.vj_c.bh_b;
        while (vj3.vj_c != (bh2 = vj3.vj_c.bh_b)) {
            uk uk2 = (uk)bh2;
            while (vj2.vj_c != bh4 && uk2.uk_o > ((uk)bh4).uk_o) {
                bh4 = bh4.bh_b;
            }
            fm.a((byte)113, uk2, bh4);
        }
    }

    public static void b(int n) {
        ql_f = null;
        if (n > -70) {
            return;
        }
        ql_b = null;
        ql_d = null;
        ql_a = null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final void c(int n) {
        wg wg2 = ik.ik_f;
        synchronized (wg2) {
            ++pf.pf_g;
            be.be_n = pa.pa_bb;
            bh.bh_g = lc.lc_f;
            if (n != -2) {
                ql.c(-55);
            }
            pm.pm_f = te.te_r;
            pm.pm_b = ml.ml_b;
            ml.ml_b = false;
            ig.Yb = nk.nk_l;
            he.S = ge.ge_a;
            nf.nf_h = qa.qa_t;
            nk.nk_l = 0;
        }
    }

    final void a(fd fd2, int n) {
        if (n <= 4) {
            fd fd3 = null;
            this.a(fd3, 55);
        }
        wj.a(true, this.ql_g, fd2);
    }

    @Override
    public final void paint(Graphics graphics) {
    }

    static {
        ql_f = "Reject";
    }
}
