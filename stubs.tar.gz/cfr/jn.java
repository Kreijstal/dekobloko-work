/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.SourceDataLine;

final class jn
extends en {
    private int z;
    private boolean x = false;
    private SourceDataLine jn_w;
    private AudioFormat jn_v;
    private byte[] y;
    private static final String A = "soundmax";

    @Override
    final void d() {
        if (this.jn_w != null) {
            this.jn_w.close();
            this.jn_w = null;
            return;
        }
    }

    @Override
    final void b() {
        int n = 256;
        if (en_u) {
            n <<= 1;
        }
        for (int i = 0; i < n; ++i) {
            int n2 = this.en_k[i];
            if ((n2 + 0x800000 & 0xFF000000) != 0) {
                n2 = 0x7FFFFF ^ n2 >> 31;
            }
            this.y[i * 2] = (byte)(n2 >> 8);
            this.y[i * 2 + 1] = (byte)(n2 >> 16);
        }
        this.jn_w.write(this.y, 0, n << 1);
    }

    @Override
    final int c() {
        return this.z - (this.jn_w.available() >> (en_u ? 2 : 1));
    }

    jn() {
    }

    @Override
    final void a(int n) throws LineUnavailableException {
        try {
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, this.jn_v, n << (en_u ? 2 : 1));
            this.jn_w = (SourceDataLine)AudioSystem.getLine(info);
            this.jn_w.open();
            this.jn_w.start();
            this.z = n;
        }
        catch (LineUnavailableException lineUnavailableException) {
            if (h.a(n, 101) != 1) {
                this.a(oe.b(-10498, n));
                return;
            }
            this.jn_w = null;
            throw lineUnavailableException;
        }
    }

    @Override
    final void h() throws LineUnavailableException {
        this.jn_w.flush();
        if (this.x) {
            this.jn_w.close();
            this.jn_w = null;
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, this.jn_v, this.z << (en_u ? 2 : 1));
            this.jn_w = (SourceDataLine)AudioSystem.getLine(info);
            this.jn_w.open();
            this.jn_w.start();
            return;
        }
    }

    @Override
    final void a(Component component) {
        Mixer.Info[] infoArray = AudioSystem.getMixerInfo();
        if (infoArray != null) {
            Mixer.Info[] infoArray2 = infoArray;
            for (int i = 0; i < infoArray2.length; ++i) {
                String string;
                Mixer.Info info = infoArray2[i];
                if (info == null || (string = info.getName()) == null || string.toLowerCase().indexOf(A) < 0) continue;
                this.x = true;
            }
        }
        this.jn_v = new AudioFormat(en_o, 16, en_u ? 2 : 1, true, false);
        this.y = new byte[256 << (en_u ? 2 : 1)];
    }
}
