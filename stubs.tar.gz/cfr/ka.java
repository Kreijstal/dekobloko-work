/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

final class ka
extends ma {
    static String M = "CHALLENGE!";
    private vj Q = new vj();
    static String O = "Members' Benefits";
    static af P;
    static pl N;

    final bl g(byte by) {
        boolean bl2 = client.A;
        rd rd2 = new rd(this.Q);
        bl bl3 = (bl)rd2.a((byte)71);
        if (by > -73) {
            ka.h((byte)44);
        }
        while (null != bl3) {
            if (bl3.S) {
                return bl3;
            }
            bl bl4 = (bl)rd2.a(-93);
        }
        return null;
    }

    final void c(boolean bl2) {
        boolean bl3 = client.A;
        if (!bl2) {
            O = null;
        }
        rd rd2 = new rd(this.Q);
        bl bl4 = (bl)rd2.a((byte)71);
        while (null != bl4) {
            bl4.S = false;
            bl bl5 = (bl)rd2.a(-48);
        }
        this.L = null;
    }

    static final int a(byte by, int n, Random random) {
        int n2;
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
        if (pe.a(922790152, n)) {
            return (int)(((long)random.nextInt() & 0xFFFFFFFFL) * (long)n >> -627379424);
        }
        if (by < 42) {
            N = null;
        }
        int n3 = -((int)(0x100000000L % (long)n)) + Integer.MIN_VALUE;
        while (~n3 >= ~(n2 = random.nextInt())) {
        }
        return oi.a(n, 105, n2);
    }

    public ka() {
        super(0, 0, cf.cf_f, vd.vd_n, null, null);
    }

    static final void a(boolean bl2, int n) {
        block5: {
            sb.c((byte)123);
            if (hh.hh_a != tc.Tb) {
                boolean bl3 = cd.cd_m != null && km.b(cd.cd_m.ve_rc, -8222);
                boolean bl4 = hh.hh_a != null;
                lk.a(0, true, 14, 11, 13, jk.jk_c, fm.fm_b || fa.fa_n || bl4, 15, bl2, true, bl3, 50 < pm.pm_g);
            } else {
                gn.b(n + -26499);
            }
            if (n != -3051) {
                return;
            }
            if (sn.sn_g) {
                jb.a((byte)126, uj.uj_g);
                sn.sn_g = false;
            }
            if (gm.I) {
                we.we_b.f(58, -4);
                gm.I = false;
            }
            if (!nh.nh_a) break block5;
            we.we_b.f(10, -4);
            nh.nh_a = false;
        }
    }

    final void g(int n) {
        boolean bl2 = client.A;
        if (n != 0) {
            O = null;
        }
        rd rd2 = new rd(this.Q);
        bl bl3 = (bl)rd2.a((byte)71);
        while (bl3 != null) {
            if (bl3.h((byte)39)) {
                bl3.b((byte)124);
            }
            bl bl4 = (bl)rd2.a(n + -70);
        }
        this.L = this.g((byte)-87);
    }

    public static void h(byte by) {
        N = null;
        O = null;
        M = null;
        P = null;
        int n = 99 % ((-85 - by) / 40);
    }

    @Override
    final ce a(int n) {
        boolean bl2 = client.A;
        rd rd2 = new rd(this.Q);
        if (n != 14) {
            return null;
        }
        bl bl3 = (bl)rd2.a((byte)71);
        while (bl3 != null) {
            if (bl3.S) {
                return bl3.e((byte)-74);
            }
            bl bl4 = (bl)rd2.a(-93);
        }
        return null;
    }

    final void f(byte by) {
        boolean bl2 = client.A;
        if (by != -66) {
            P = null;
        }
        rd rd2 = new rd(this.Q);
        bl bl3 = (bl)rd2.a((byte)71);
        while (null != bl3) {
            if (bl3.f((byte)110)) {
                bl3.b((byte)120);
            }
            bl bl4 = (bl)rd2.a(by ^ 8);
        }
    }

    final void a(byte by, ce ce2) {
        if (!(ce2 instanceof bl)) {
            throw new IllegalArgumentException();
        }
        if (by > -104) {
            ce ce3 = null;
            this.a((byte)-72, ce3);
        }
        bl bl2 = (bl)ce2;
        this.Q.b(bl2, 7143);
        bl2.S = true;
        bl2.a(false, (ce)this);
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        boolean bl2 = client.A;
        if (null != this.ce_p) {
            this.ce_p.a(true, n, n4, (byte)-100, this);
        }
        rd rd2 = new rd(this.Q);
        if (n2 > -103) {
            return;
        }
        ce ce2 = (ce)rd2.a(true);
        while (null != ce2) {
            ce2.a(n + this.ce_u, -116, n3, this.D + n4);
            ce ce3 = (ce)rd2.d(2078965185);
        }
    }
}
