/*
 * Decompiled with CFR 0.152.
 */
import java.math.BigInteger;
import java.security.SecureRandom;

final class ri {
    private int ri_p;
    static int ri_i;
    private int ri_g;
    private int ri_j;
    private int ri_n;
    static String[] ri_f;
    private float ri_d;
    private tk ri_t;
    private int ri_m;
    private int ri_l;
    static String ri_k;
    private boolean ri_q;
    private int ri_r;
    private int ri_c;
    private int ri_e;
    private int ri_o;
    private int ri_a;
    private int ri_h;
    private int ri_s;
    private int ri_u;
    private int ri_b;

    static final boolean a(int n) {
        int n2 = -44 / ((-56 - n) / 32);
        return vb.Z;
    }

    static final String a(int n, boolean bl, boolean bl2, boolean bl3) {
        int n2;
        block2: {
            n2 = n;
            if (bl3) {
                n2 += 4;
            }
            if (bl2) {
                n2 += 2;
            }
            if (!bl) break block2;
            ++n2;
        }
        return ik.ik_d[n2];
    }

    static final void a(int n, byte by, int n2, BigInteger bigInteger, BigInteger bigInteger2, wl wl2, byte[] byArray) {
        int n3;
        int n4;
        boolean bl = client.A;
        int n5 = ha.a(n2, (byte)-126);
        if (rk.K == null) {
            rk.K = new SecureRandom();
        }
        int[] nArray = new int[4];
        for (n4 = 0; 4 > n4; ++n4) {
            nArray[n4] = rk.K.nextInt();
        }
        if (null == ef.R || ~n5 < ~ef.R.wl_r.length) {
            ef.R = new wl(n5);
        }
        ef.R.wl_n = 0;
        if (by < 101) {
            return;
        }
        ef.R.a(false, n2, byArray, n);
        ef.R.e(102, n5);
        ef.R.a((byte)-105, nArray);
        if (ba.ba_b == null || 100 > ba.ba_b.wl_r.length) {
            ba.ba_b = new wl(100);
        }
        ba.ba_b.wl_n = 0;
        ba.ba_b.a(true, 10);
        n4 = n3 = 0;
        while (4 > n3) {
            ba.ba_b.a(nArray[n3], false);
            ++n3;
        }
        ba.ba_b.d(-1, n2);
        ba.ba_b.a(bigInteger2, bigInteger, true);
        wl2.a(false, ba.ba_b.wl_n, ba.ba_b.wl_r, 0);
        wl2.a(false, ef.R.wl_n, ef.R.wl_r, 0);
    }

    final ql c(int n) {
        if (n != 27134) {
            ri.a(-14);
        }
        this.ri_g = ob.ob_g;
        this.ri_j = de.M;
        this.ri_t.a(-4328, this.ri_o, this.ri_p);
        jg.jg_e = false;
        ql ql2 = sg.a(this.ri_p, lf.lf_e, 0, 0, 67, this.ri_o);
        if (null == ql2) {
            this.b((byte)-60);
        }
        return ql2;
    }

    final void a(boolean bl) {
        if (null != cl.cl_v) {
            return;
        }
        if (eh.eh_a <= 0) {
            this.ri_q = false;
        }
        if (!this.ri_q) {
            if (de.M >= this.ri_m) {
                if (this.ri_m > 0) {
                    qd.Rb = 0;
                }
            } else {
                qd.Rb = (this.ri_m + -de.M) / 2;
            }
            if (~this.ri_n != ~de.M || ob.ob_g != this.ri_r) {
                this.ri_t.a(-4328, this.ri_r, this.ri_n);
                return;
            }
        } else {
            if (--this.ri_u > 0) {
                return;
            }
            this.ri_u = this.ri_s;
            if (this.ri_e > ab.ab_e) {
                this.ri_q = false;
                return;
            }
            this.d(60);
            if (bl) {
                ri.a(-99, -30, 116, 96, -46, -122);
            }
            return;
        }
    }

    private final void d(int n) {
        block13: {
            boolean bl = client.A;
            int n2 = this.ri_m;
            int n3 = this.ri_h;
            if (!this.b(n + -60)) {
                this.ri_q = false;
                return;
            }
            if (~n2 >= ~this.ri_a) {
                if (~n2 > ~this.ri_l) {
                    n2 = this.ri_l;
                }
            } else {
                n2 = this.ri_a;
            }
            if (~n3 >= ~this.ri_c) {
                if (~this.ri_b < ~n3) {
                    n3 = this.ri_b;
                }
            } else {
                n3 = this.ri_c;
            }
            if (0.0f < this.ri_d) {
                int n4 = (int)((float)n3 * this.ri_d + 0.5f);
                if (n4 > n2) {
                    n3 = (int)((float)n2 / this.ri_d);
                } else if (n2 > n4) {
                    n2 = n4;
                }
            }
            if (~de.M != ~n2 || ~ob.ob_g != ~n3) {
                this.ri_t.a(-4328, n3, n2);
            }
            if (n != 60) {
                ri.a((byte)59);
            }
            if (~this.ri_m >= -1) break block13;
            qd.Rb = (this.ri_m + -de.M) / 2;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        boolean bl = client.A;
        int n8 = 80 > n2 ? n2 / 20 * 18 : 54;
        int n9 = 0;
        if (n2 < 60) {
            n8 += vl.a(23841, 80, n3 * 18 + 40);
        } else if (n2 >= 80) {
            if (~n2 > -94) {
                n9 = vl.a(23841, 80, 40 + ve.ve_ic[1 + n2 - 80] * 18);
            } else {
                hk.a(-30 + n5, 54 + n + -2, 60, 40, 4, 65280, 100);
            }
        } else {
            n8 += vl.a(23841, 80, 40 + n6 * 18);
        }
        if (n4 >= -57) {
            ri_i = -11;
        }
        int n10 = 0;
        while (-4 < ~n10) {
            fb.fb_c[n7][1].c(n10 * 18 + -27 + n5, 72 + n, 18, 18);
            ++n10;
        }
        fb.fb_c[n7][1].c(n5 - 27 + 36, n9 + n8 + n, 18, -n9 + 18);
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        block3: {
            int n7;
            db.db_b[og.og_eb] = n;
            ch.ch_a[og.og_eb] = og.og_eb;
            ad.ad_i[og.og_eb] = n4;
            if (~ge.ge_b < ~n4) {
                mf.Q = n4;
            }
            if (~n4 < ~bg.bg_d) {
                rf.rf_g = n4;
            }
            oa.oa_e[og.og_eb] = n2;
            ln.ln_a[og.og_eb] = n5;
            mk.mk_b[og.og_eb] = n6;
            int n8 = n6 + (n5 + n2);
            cc.cc_h[og.og_eb] = n7 = ~n8 != n3 ? n2 * 1000 / n8 : 0;
            ++og.og_eb;
            if (rf.rf_g < n7) {
                rf.rf_g = n7;
            }
            if (~mf.Q >= ~n7) break block3;
            mf.Q = n7;
        }
    }

    final boolean b(int n) {
        if (n != 0) {
            this.ri_t = null;
        }
        return ab.ab_e >= this.ri_e && 0 < eh.eh_a;
    }

    final void a(int n, boolean bl, int n2) {
        block0: {
            this.ri_h = n2;
            this.ri_m = n;
            if (!bl) break block0;
            this.c(-56);
        }
    }

    final void b(byte by) {
        if (by > -49) {
            this.ri_s = -34;
        }
        this.ri_t.a(-4328, this.ri_g, this.ri_j);
    }

    public static void a(byte by) {
        block0: {
            ri_f = null;
            ri_k = null;
            if (by == -91) break block0;
            ri.a(-34, (byte)-93, 92, null, null, null, null);
        }
    }

    private ri() throws Throwable {
        throw new Error();
    }

    static {
        ri_k = "DRAW!";
        ri_f = new String[8];
        ri.ri_f[0] = "fruit";
        ri.ri_f[3] = "bugs";
        ri.ri_f[5] = "undersea";
        ri.ri_f[4] = "flowers";
        ri.ri_f[1] = "animals";
        ri.ri_f[7] = "eightbit";
        ri.ri_f[6] = "city";
        ri.ri_f[2] = "breakfast";
    }
}
