/*
 * Decompiled with CFR 0.152.
 */
final class d {
    static ck[] d_h;
    static w d_g;
    static int d_b;
    static mh d_f;
    static w d_a;
    static int[] d_d;
    static pi d_e;
    static int d_c;

    public static void a(int n) {
        d_d = null;
        d_g = null;
        d_a = null;
        d_f = null;
        d_e = null;
        if (n != 36) {
            d.a(false);
        }
        d_h = null;
    }

    static final void a(boolean bl) {
        boolean bl2 = client.A;
        md.Z = 0;
        f.f_w = null;
        ed.ed_g = 0;
        qi.S.c(111);
        uf.z.c(117);
        if (!bl) {
            d.a(true);
        }
        be be2 = mc.mc_a.c(-9443);
        while (null != be2) {
            be2.e((byte)105);
            be2 = mc.mc_a.b(-112);
        }
        be2 = hg.hg_e.c(-9443);
        while (null != be2) {
            be2.e((byte)100);
            be2 = hg.hg_e.b(104);
        }
        jj.jj_b = 0;
    }

    static {
        d_d = new int[8192];
        d_c = 0;
        d_e = new pi(36, 36, 0);
    }
}
