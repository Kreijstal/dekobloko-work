/*
 * Decompiled with CFR 0.152.
 */
final class gi {
    static boolean gi_b;
    static int gi_e;
    static int gi_a;
    static int gi_c;
    static String gi_d;

    static final boolean a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        if (n != 17) {
            gi_c = -63;
        }
        return ~n7 >= ~n3 && ~(n4 + n7) < ~n3 && n2 >= n5 && ~(n5 - -n6) < ~n2;
    }

    public static void a(int n) {
        int n2 = -114 % ((n - -21) / 55);
        gi_d = null;
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, byte by) {
        block1: {
            ie.ie_c.a(n3, 0, n5, n, n6);
            if (null != mg.mg_bc) {
                mg.mg_bc.a(n4, -l.l_f + n4, n, n2, (byte)-18, n);
            }
            if (by < -83) break block1;
            gi_e = -12;
        }
    }

    static final void a(int n, int n2, int n3, wl wl2, int n4) {
        wl2.a(true, 12);
        wl2.d(-1, n3);
        wl2.d(-1, n4);
        wl2.d(-1, n);
        wl2.a(true, n2);
    }

    static {
        gi_d = "Warning: if you quit, you will lose any game you are in the middle of!";
    }
}
