/*
 * Decompiled with CFR 0.152.
 */
final class bc
extends a {
    static mf E;
    static String F;
    private sn C;
    private sn[] A = new sn[6];
    static int[][] D;
    static String G;
    static int[] J;
    static int[] I;
    static int B;
    static String K;

    private final void a(byte by, bc bc2, boolean bl) {
        int n;
        boolean bl2 = client.A;
        super.a(-12253, bc2);
        if (!bl) {
            an.a(this.A, 0, bc2.A, 0, 6);
        } else {
            n = 0;
            while (~n > -7) {
                sn sn2 = this.A[n];
                if (sn2 == null) {
                    bc2.A[n] = null;
                } else {
                    sn sn3 = bc2.A[n];
                    sn2.a(sn3 != null ? sn3 : new sn(), 1);
                }
                ++n;
            }
        }
        n = -82 % ((-68 - by) / 44);
    }

    final void a(int n, ck[] ckArray, int n2) {
        int n3;
        if (n <= 97) {
            ce ce2 = null;
            this.a(true, -54, 87, (byte)-121, ce2);
        }
        if (this.A[n3 = n2] == null) {
            this.A[n3] = new sn();
        }
        this.A[n2].sn_a = ckArray;
    }

    bc(bc bc2, boolean bl) {
        this();
        bc2.a((byte)-117, this, bl);
    }

    public bc() {
        this.C = new sn();
        sn sn2 = this.A[0] = new sn();
        sn2.b((byte)68);
    }

    final sn a(int n, int n2) {
        if (n2 <= 0) {
            E = null;
        }
        this.A[n] = new sn();
        return this.A[n];
    }

    static final String a(CharSequence charSequence, int n) {
        int n2;
        boolean bl = client.A;
        if (n != 65) {
            K = null;
        }
        if (-21 > ~(n2 = charSequence.length())) {
            n2 = 20;
        }
        char[] cArray = new char[n2];
        for (int i = 0; i < n2; ++i) {
            char c = charSequence.charAt(i);
            cArray[i] = 'A' <= c && c <= 'Z' ? (char)(-65 + (c + 97)) : (c >= 'a' && c <= 'z' || c >= '0' && c <= '9' ? (char)c : (char)95);
        }
        return new String(cArray);
    }

    @Override
    public final void a(boolean bl, int n, int n2, byte by, ce ce2) {
        block9: {
            sn sn2;
            ek ek2;
            ek ek3 = ek2 = (ek)(!(ce2 instanceof ek) ? null : ce2);
            gg.a(ce2.D + n2, 20763, ce2.ce_t + ce2.ce_u + n, n - -ce2.ce_u, ce2.D + n2 + ce2.y);
            if (null != ek3) {
                bl &= ek2.I;
            }
            sn sn3 = this.A[0];
            this.C.b((byte)80);
            sn3.a(this.C, this, 122, n2, n, ce2);
            if (null != ek3) {
                if (ek3.H && null != (sn2 = this.A[1])) {
                    sn2.a(this.C, this, 127, n2, n, ce2);
                }
                if (ek3.ce_q) {
                    sn2 = this.A[3];
                    if (~ek3.ce_o == -1 || sn2 == null) {
                        sn sn4 = this.A[2];
                        if (null != sn4) {
                            sn4.a(this.C, this, 126, n2, n, ce2);
                        }
                    } else {
                        sn2.a(this.C, this, 122, n2, n, ce2);
                    }
                }
            }
            if (ce2.a(true) && (sn2 = this.A[5]) != null) {
                sn2.a(this.C, this, 126, n2, n, ce2);
            }
            if (!bl && null != (sn2 = this.A[4])) {
                sn2.a(this.C, this, 124, n2, n, ce2);
            }
            this.C.a(-2, ce2, n, this, n2);
            mk.a((byte)-5);
            if (by <= -60) break block9;
            ce ce3 = null;
            this.a(true, -61, 21, (byte)-12, ce3);
        }
    }

    final void a(ck ck2, int n) {
        boolean bl = client.A;
        sn[] snArray = this.A;
        sn[] snArray2 = this.A;
        if (n != 2) {
            F = null;
        }
        int n2 = 0;
        while (~n2 > ~snArray.length) {
            sn sn2 = snArray[n2];
            if (null != sn2) {
                sn2.sn_b = ck2;
            }
            ++n2;
        }
    }

    final void a(ck[] ckArray, boolean bl) {
        boolean bl2 = client.A;
        sn[] snArray = this.A;
        sn[] snArray2 = this.A;
        if (bl) {
            return;
        }
        for (int i = 0; i < snArray.length; ++i) {
            sn sn2 = snArray[i];
            if (null == sn2) continue;
            sn2.sn_a = ckArray;
        }
    }

    public static void b(byte by) {
        F = null;
        J = null;
        D = null;
        K = null;
        if (by >= -101) {
            K = null;
        }
        I = null;
        G = null;
        E = null;
    }

    static {
        F = "No spectators";
        I = new int[8192];
        G = "Allow spectators?";
        K = "To play a multiplayer game, please log in or create a free account.";
    }
}
