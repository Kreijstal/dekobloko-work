/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;
import java.awt.Frame;

final class jh {
    static String[] jh_c = new String[]{"Form a Deko and a Bloko at precisely the same time", "Eliminate a wildcard as part of 2 shapes at the same time", "Eliminate a wildcard as part of 3 shapes at the same time", "Eliminate a wildcard as part of 7 shapes at the same time", "Double-eliminate a solid shape by completing 2 touching loose shapes at the same time", "Triple-eliminate a solid shape by completing 3 touching loose shapes at the same time", "Set off a chain of 5 explosions", "Set off a chain of 10 explosions", "Make a solid shape as tall as the bucket", "Bombard your victim with 100 shapes in one go in a multiplayer game", "Completely clear a quarter-full bucket in a Rated game", "Have over 30 shapes in your machine in a Rated game", "Unlock the Flowers theme in the Master Challenge (Theme 5)", "Unlock the City theme in the Master Challenge (Theme 7)", "Unlock the Eight-bit theme in the Master Challenge (Theme 8)", "Get at least 50,000 points in the Master Challenge", "Get at least 100,000 points in the Master Challenge", "Get at least 200,000 points in the Master Challenge", "Win a Rated game", "Win 3 Rated games in a row, in one session", "Win 5 Rated games in a row, in one session, starting with a Rating of at least 1500", "Win an 8-player Rated game", "Win an 8-player Rated game, defeating all opponents yourself", "Earn 50,000 points within the first two levels of the Master Challenge", "Win a Rated game without the glass breaking at all", "Defeat a FunOrb Moderator or someone who has this Achievement", "Send 500 shapes to other players in Rated games", "Send 1,000 shapes to other players in Rated games", "Send 2,500 shapes to other players in Rated games", "Send 5,000 shapes to other players in Rated games", "Send 10,000 shapes to other players in Rated games"};
    static Canvas jh_b;
    static int jh_e;
    static String jh_g;
    static String jh_f;
    static ck jh_d;
    static String jh_a;
    static boolean jh_h;

    public static void a(boolean bl) {
        jh_a = null;
        jh_b = null;
        jh_g = null;
        jh_f = null;
        if (bl) {
            jh_d = null;
        }
        jh_c = null;
        jh_d = null;
    }

    static final Frame a(int n, fd fd2, int n2, int n3, boolean bl2, int n4) {
        boolean bl3 = client.A;
        if (!fd2.b(-86)) {
            return null;
        }
        if (n3 == 0) {
            dc[] dcArray = ak.a((byte)-109, fd2);
            dc[] dcArray2 = dcArray;
            if (null == dcArray2) {
                return null;
            }
            boolean bl4 = false;
            for (int i = 0; i < dcArray.length; ++i) {
                if (~n2 != ~dcArray[i].dc_f || ~n != ~dcArray[i].dc_j || -1 != ~n4 && dcArray[i].dc_a != n4 || bl4 && ~dcArray[i].dc_h >= ~n3) continue;
                bl4 = true;
                n3 = dcArray[i].dc_h;
            }
            if (!bl4) {
                return null;
            }
        }
        if (bl2) {
            jh_h = true;
        }
        mh mh2 = fd2.a((byte)107, n, n3, n2, n4);
        while (0 == mh2.mh_c) {
            ua.a(10L, -128);
        }
        Frame frame = (Frame)mh2.mh_b;
        if (frame == null) {
            return null;
        }
        if (~mh2.mh_c == -3) {
            wj.a(true, frame, fd2);
            return null;
        }
        return frame;
    }

    static final void a(byte by, mm mm2, ji ji2) {
        boolean bl2 = client.A;
        int n = kd.kd_p;
        ie.ie_c = new w(0L, null);
        if (ji2 == null) {
            qb.a(null, 16408, "QC1");
            return;
        }
        ji2.ji_b = false;
        ji2.ji_g = 0;
        oi.oi_a = new em(n, ji2, ji2);
        wj.Qb = new sm(n, ji2, ji2, new ga());
        ac ac2 = dn.b((byte)124);
        if (null == ac2) {
            qb.a(null, 16408, "QC2");
            return;
        }
        jc.a(ac2, -1);
        fj.fj_d = wa.a(2245737, 0x171717, 0, 0x888888, 5138823, 1127256, 65793, 65793, 4020342, 0x171717, 65793, -24447, null);
        rd.rd_e = wa.a(0, 0, 0xFFCC66, 0, 0, 0, 0, 0, 0, 0, 0, -24447, mm2);
        ad.ad_q = wa.a(0, 0, 0xFFFFFF, 0, 0, 0, 0, 0, 0, 0, 0, -24447, mm2);
        int n2 = hk.hk_j;
        int n3 = hk.hk_i;
        int[] nArray = hk.hk_l;
        qb.qb_q = new ck(10, 14);
        qb.qb_q.a();
        int n4 = 2;
        while (-8 < ~n4) {
            hk.g(n4, n4 - -1, 14 - (n4 << -810284479), 0xFFFFFF);
            ++n4;
        }
        hk.a(nArray, n2, n3);
        vk.vk_a = ll.a(ad.ad_q, rd.rd_e, ac2, fj.fj_d, 0);
        if (by <= 61) {
            return;
        }
        ie.ie_c.M = new vj();
    }

    static final int a(int[] nArray, int n) {
        int n2;
        block1: {
            boolean bl2 = client.A;
            n2 = 0;
            for (int i = 0; nArray.length > i; ++i) {
                n2 += h.a(nArray[i], -127);
            }
            if (n >= 94) break block1;
            jh.a(null, 120);
        }
        return n2;
    }

    static {
        jh_a = "Log in";
        jh_g = "Accept <%0> into this game";
        jh_f = "No";
        jh_h = false;
        jh_e = 0;
    }
}
