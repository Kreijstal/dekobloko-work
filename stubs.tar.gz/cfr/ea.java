/*
 * Decompiled with CFR 0.152.
 */
import java.math.BigInteger;

final class ea
extends cf {
    private boolean ea_w;
    private int B;
    static int ea_p;
    private int ea_s;
    static w A;
    static String ea_u;
    private int ea_v;
    private String ea_m;
    static int ea_n;
    static BigInteger ea_k;
    static int ea_r;
    static ck ea_l;
    static w D;
    private mm ea_o;
    static int ea_t;
    private int z;
    private int ea_q;
    static String y;
    static String C;
    static cd x;

    final void a(int n, int n2, String string, byte by, mm mm2) {
        if (null == string) {
            this.cf_a = null;
            return;
        }
        if (mm2 == this.ea_o && this.ea_w && ~this.ea_s == -2 && null != this.ea_m && this.ea_m.equals(string)) {
            return;
        }
        this.ea_o = mm2;
        this.ea_s = 1;
        if (by != 8) {
            ea.a(54, 119, -124, -51, 32, 28);
        }
        this.ea_w = true;
        nf nf2 = this.a(-95, n, mm2, string);
        int n3 = mm2.a(string);
        nf2.nf_a[0] = n2 - (n3 >> -385423935);
        nf2.nf_a[string.length()] = n2 - -(n3 >> -862867359);
        hm.a(nf2, mm2, 0, string, by ^ 0xFFFFFFF7);
    }

    static final boolean c(byte by) {
        if (by >= -23) {
            return false;
        }
        return hc.hc_d >= 10 && !v.v_d && !si.c(-12851);
    }

    static final ck[] a(int n, int n2, int n3, int n4, int n5, int n6) {
        int[] nArray = hk.hk_l;
        int n7 = hk.hk_j;
        int n8 = hk.hk_i;
        ck ck2 = new ck(n3, n4 - n3 * 2);
        ck2.a();
        hk.d(0, 0, n3, n4 + -(2 * n3), n6, n5);
        ck ck3 = new ck(n3, n3);
        ck3.a();
        hk.a(0, 0, n3, n3, n6);
        ck ck4 = new ck(16, n3);
        if (n2 != -20982) {
            return null;
        }
        ck4.a();
        hk.a(0, 0, 16, n3, n6);
        ck ck5 = new ck(n3, n3);
        ck5.a();
        hk.a(0, 0, n3, n3, n5);
        ck ck6 = new ck(16, n3);
        ck6.a();
        hk.a(0, 0, 16, n3, n5);
        ck ck7 = null;
        if (n > 0) {
            ck7 = new ck(16, 16);
            ck7.a();
            hk.a(0, 0, 16, 16, n);
        }
        hk.a(nArray, n7, n8);
        return new ck[]{ck3, ck4, ck3, ck2, ck7, ck2, ck5, ck6, ck5};
    }

    final void a(int n, mm mm2, String string, int n2, int n3) {
        nf nf2;
        if (string == null) {
            this.cf_a = null;
            return;
        }
        if (n3 <= 11) {
            ea_r = -109;
        }
        if (mm2 == this.ea_o && this.ea_w && ~this.ea_s == -1 && null != this.ea_m && this.ea_m.equals(string)) {
            return;
        }
        this.ea_w = true;
        this.ea_o = mm2;
        this.ea_m = string;
        this.ea_s = 0;
        nf nf3 = nf2 = this.a(-27, n2, mm2, string);
        nf2.nf_a[0] = n;
        nf3.nf_a[string.length()] = mm2.a(string) + n;
        hm.a(nf3, mm2, 0, string, -1);
    }

    final void a(String string, int n, mm mm2, int n2, int n3, int n4, int n5, int n6) {
        int n7;
        int n8;
        String[] stringArray;
        boolean bl = client.A;
        if (n6 == 0) {
            n6 = mm2.S;
        }
        if (string == null) {
            this.cf_a = null;
            return;
        }
        if (this.ea_o == mm2 && !this.ea_w && this.ea_s == n4 && ~this.ea_q == ~n && n6 == this.B && ~this.ea_v == ~n3 && n2 == this.z && null != this.ea_m && this.ea_m.equals(string)) {
            return;
        }
        this.B = n6;
        this.ea_m = string;
        this.ea_q = n;
        this.z = n2;
        this.ea_o = mm2;
        this.ea_v = n3;
        this.ea_w = false;
        this.ea_s = n4;
        String[] stringArray2 = stringArray = new String[mm2.a(string, n2) + 1];
        int n9 = Math.max(1, mm2.a(string, new int[]{n2}, stringArray2));
        if (~this.ea_q == -4 && -2 == ~n9) {
            this.ea_q = 1;
        }
        if (n5 < 8) {
            ea.b(true);
        }
        this.cf_a = new nf[n9];
        if (~this.ea_q == -1) {
            n8 = mm2.R;
        } else if (this.ea_q != 1) {
            if (this.ea_q != 2) {
                n7 = (-(n9 * this.B) + this.ea_v) / (1 + n9);
                if (-1 < ~n7) {
                    n7 = 0;
                }
                n8 = n7 + mm2.R;
                this.B += n7;
            } else {
                n8 = -(this.B * n9) + -mm2.K + this.ea_v;
            }
        } else {
            n8 = (-(n9 * this.B) + this.ea_v >> -531200703) + mm2.R;
        }
        n7 = 0;
        while (~n9 < ~n7) {
            String string2 = stringArray[n7];
            nf nf2 = new nf(-mm2.R + n8, mm2.K + n8, null == string2 ? 0 : string2.length());
            nf2.nf_a[0] = 0;
            if (string2 != null) {
                nf2.nf_a[string2.length()] = mm2.a(string2);
                hm.a(nf2, mm2, ~n4 != -4 ? 0 : this.a((byte)64, mm2.a(string2), string2, n2), string2, -1);
            }
            this.cf_a[n7] = nf2;
            n8 += n6;
            ++n7;
        }
    }

    static final String b(boolean bl) {
        if (!wd.wd_d && ~jc.jc_g <= ~o.o_b && he.he_gb + o.o_b > jc.jc_g) {
            return k.k_e;
        }
        if (bl) {
            return null;
        }
        ea.b(true);
        return null;
    }

    final void a(int n, mm mm2, int n2, int n3, String string) {
        nf nf2;
        if (null == string) {
            this.cf_a = null;
            return;
        }
        if (this.ea_o == mm2 && this.ea_w && ~this.ea_s == -3 && this.ea_m != null && this.ea_m.equals(string)) {
            return;
        }
        this.ea_m = string;
        this.ea_o = mm2;
        this.ea_w = true;
        this.ea_s = 2;
        nf nf3 = nf2 = this.a(88, n3, mm2, string);
        nf3.nf_a[n] = -mm2.a(string) + n2;
        nf2.nf_a[string.length()] = n2;
        hm.a(nf3, mm2, 0, string, -1);
    }

    public static void b(byte by) {
        if (by != -37) {
            return;
        }
        y = null;
        x = null;
        ea_u = null;
        ea_k = null;
        A = null;
        ea_l = null;
        D = null;
        C = null;
    }

    private final nf a(int n, int n2, mm mm2, String string) {
        nf nf2;
        nf nf3 = nf2 = new nf(n2 + -mm2.R, n2 - -mm2.K, string.length());
        int n3 = -31 / ((27 - n) / 34);
        this.cf_a = new nf[]{nf2};
        return nf3;
    }

    static final boolean d(byte by) {
        if (by <= 34) {
            y = null;
        }
        return w.H != null || qd.e(-6) || pd.pd_f != null || ab.c(48);
    }

    static {
        ea_n = 0;
        ea_u = "Invite players";
        y = "Under the Sea";
        ea_t = 0;
        ea_p = 360;
        C = "Enter the name you'd prefer. This is the name displayed to other players.";
        ea_k = new BigInteger("65537");
    }
}
