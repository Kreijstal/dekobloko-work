/*
 * Decompiled with CFR 0.152.
 */
final class cj {
    static int cj_a;
    static en cj_b;
    static int cj_c;
    private static final String z;

    public static void a(int n) {
        int n2 = 110 % ((-1 - n) / 35);
        cj_b = null;
    }

    static {
        z = "cj.A(";
    }
}
