/*
 * Decompiled with CFR 0.152.
 */
final class pb {
    static String[] pb_f = new String[]{"Play Stamina Mode to unlock themes for the multiplayer game!", "<%0> of <%1> themes unlocked for multiplayer - play Stamina Mode to unlock up to 4!", "<%0> of <%1> themes unlocked for multiplayer - play the Master Challenge to unlock the rest!", "All themes unlocked for multiplayer! Can you beat your Stamina and Master Challenge highscores?"};
    ji pb_g;
    String pb_b;
    String pb_j;
    int pb_h;
    String pb_a;
    static vj pb_c;
    static String pb_k;
    static int pb_d;
    static String pb_e;
    static gh pb_i;

    public static void a(byte by) {
        if (by != 78) {
            pb.a((byte)-103);
        }
        pb_f = null;
        pb_i = null;
        pb_k = null;
        pb_e = null;
        pb_c = null;
    }

    static final void a(boolean bl) {
        boolean bl2 = client.A;
        int n = -(45 * (kf.G.ke_o * kf.G.ke_o) / 400) + 45;
        hk.a(0, n + 435, 640, 28, 0xFFCC00, 100);
        hk.a(0, n + 435, 640, 0);
        hk.a(0, n + 462, 640, 0);
        if (!bl) {
            pb.a(true);
        }
        String string = id.P != 0 ? (id.P < 3 ? cm.a((byte)85, pb_f[1], new String[]{Integer.toString(id.P + 1), Integer.toString(8)}) : (~id.P <= -8 ? pb_f[3] : cm.a((byte)83, pb_f[2], new String[]{Integer.toString(id.P - -1), Integer.toString(8)}))) : pb_f[0];
        fl.a(n + 454, 256, 0xFFFFFF, string, -(0x3FF & bb.bb_f) + -382, w.w_kb);
        fl.a(n + 454, 256, 0xFFFFFF, string, -(bb.bb_f & 0x3FF) + 642, w.w_kb);
    }

    static final void a(int n2) {
        block22: {
            block19: {
                int n3;
                int n4;
                block20: {
                    block21: {
                        int n5;
                        int n6;
                        int n7;
                        Object object;
                        Object object2;
                        int n8;
                        Object object3;
                        boolean bl2 = client.A;
                        if (le.E != null && le.E.a((byte)121) && le.E.a("benefits", (byte)-119) && eb.eb_k != null && eb.eb_k.a((byte)121) && eb.eb_k.a("benefits", (byte)102)) {
                            dj.dj_eb = id.a(le.E, "headline", "benefits", n2 + 7802);
                            hg.hg_a = id.a(le.E, "blurbpane", "benefits", 8192);
                            ea.ea_l = id.a(le.E, "button", "benefits", 8192);
                            pj.I = id.a(le.E, "signup_text", "benefits", 8192);
                            lf.lf_i = id.a(le.E, "menu_text", "benefits", 8192);
                            c.c_i = id.a(le.E, "button_frame", "benefits", n2 ^ 0x2186);
                            ge.ge_h = id.a(le.E, "arrow", "benefits", 8192);
                            aj.aj_e = cd.a("large_font", eb.eb_k, le.E, (byte)114, "benefits");
                            bn.bn_g = cd.a("small_font", eb.eb_k, le.E, (byte)112, "benefits");
                            object3 = hk.hk_l;
                            n4 = hk.hk_j;
                            n8 = hk.hk_i;
                            hk.b(he.V);
                            object2 = new ck(4 + ge.ge_h.I, ge.ge_h.H - -4);
                            ((ck)object2).a();
                            ge.ge_h.b(2, 2, o.o_d);
                            re.a(2, 1, 0, 2, (ck)object2, 0, ((ck)object2).I, ((ck)object2).H);
                            ge.ge_h = (ck)object2;
                            l.l_b = ge.ge_h.e();
                            object = new ck(195, 221);
                            n7 = ((ck)object).I / 2;
                            ((ck)object).a();
                            aj.aj_e.b(cm.a((byte)84, af.af_g, new String[]{wf.wf_n}), n7, 40, 0xFFFFFF, -1);
                            bn.bn_g.b(cm.a((byte)90, qi.N, new String[]{wf.wf_n}), n7, 60, 0xFFFFFF, -1);
                            aj.aj_e.b(cm.a((byte)126, sa.sa_n, new String[]{jm.jm_u}), n7, 110, 0xFFFFFF, -1);
                            bn.bn_g.b(cm.a((byte)94, we.we_c, new String[]{jm.jm_u}), n7, 130, 0xFFFFFF, -1);
                            aj.aj_e.b(we.we_a, n7, 180, 0xFFFFFF, -1);
                            bn.bn_g.b(sa.A, n7, 200, 0xFFFFFF, -1);
                            re.a(3, 1, 0, n2 ^ 0x184, (ck)object, 0, ((ck)object).I, ((ck)object).H);
                            hg.hg_a.a();
                            ((ck)object).c(18 - hg.hg_a.F, 241 - hg.hg_a.z);
                            n6 = 0;
                            while (~n6 > ~dl.K.length) {
                                vi.z[n6].a();
                                bn.bn_g.a(dl.K[n6], 3, 3, -6 + vi.z[n6].I, -6 + vi.z[n6].H, o.o_d, -1, 1, 1, bn.bn_g.R - -bn.bn_g.K);
                                re.a(3, 1, 0, 2, vi.z[n6], 0, vi.z[n6].I, vi.z[n6].H);
                                ++n6;
                            }
                            dl.K = null;
                            oh.oh_e = pj.I.c();
                            oh.oh_e.a();
                            wb.a(31, 0, 2 * hk.hk_i / 3, 0, 64, hk.hk_j);
                            hk.a((int[])object3, n4, n8);
                            hk.a(he.V);
                            le.E = null;
                            sk.sk_e = 434 - -((-c.c_i.I + ea.ea_l.I) / 2);
                            dm.dm_a = (ea.ea_l.I - c.c_i.I) / 2 + 231;
                            dg.dg_b = 390 - -((-c.c_i.H + ea.ea_l.H) / 2);
                            sk.sk_k = 390 - -((-c.c_i.H + ea.ea_l.H) / 2);
                        }
                        if (lb.lb_h == null) {
                            return;
                        }
                        if (wg.wg_b != null && null != aj.aj_e) {
                            int n9;
                            object3 = hk.hk_l;
                            n4 = hk.hk_j;
                            n8 = hk.hk_i;
                            hk.b(he.V);
                            object2 = cm.a((byte)120, pd.pd_b, new String[]{ma.H[rb.rb_m]});
                            int n10 = aj.aj_e.b((String)object2, ce.ce_r);
                            n7 = aj.aj_e.b((String)object2, ce.ce_r, aj.aj_e.R + aj.aj_e.K);
                            n6 = pm.pm_d + (-n10 + ce.ce_r) / 2;
                            n10 += 6;
                            n5 = qk.qk_k - -((nk.nk_g - n7) / 2);
                            if (0 > (n6 -= 3)) {
                                n9 = -n6;
                                n10 += n9 * 2;
                                le.y -= n9;
                                pm.pm_d += n9;
                                n6 += n9;
                                wg.wg_b.F += n9;
                                wg.wg_b.K += 2 * n9;
                            }
                            n5 -= 3;
                            n7 += 6;
                            if (wg.wg_b.K < n10 + n6) {
                                n9 = n10 + (n6 - wg.wg_b.K);
                                le.y -= n9;
                                n6 += n9;
                                pm.pm_d += n9;
                                n10 += 2 * n9;
                                wg.wg_b.K += n9 * 2;
                                wg.wg_b.F += n9;
                            }
                            if (~n5 > -1) {
                                n9 = -n5;
                                g.Q -= n9;
                                n5 += n9;
                                n7 += n9 * 2;
                                qk.qk_k += n9;
                                wg.wg_b.C += 2 * n9;
                                wg.wg_b.z += n9;
                            }
                            if (wg.wg_b.C < n7 + n5) {
                                n9 = n5 + (n7 + -wg.wg_b.C);
                                wg.wg_b.z += n9;
                                n7 += n9 * 2;
                                wg.wg_b.C += 2 * n9;
                                n5 += n9;
                                g.Q -= n9;
                                qk.qk_k += n9;
                            }
                            wg.wg_b.b();
                            ck ck2 = new ck(wg.wg_b.K, wg.wg_b.C);
                            ck2.a();
                            aj.aj_e.a((String)object2, pm.pm_d, qk.qk_k, ce.ce_r, nk.nk_g, 0xFFFFFF, -1, 1, 1, aj.aj_e.R - -aj.aj_e.K);
                            re.a(3, 1, 0, 2, ck2, 0, ck2.K, ck2.C);
                            wg.wg_b.a();
                            ck2.c(0, 0);
                            w.w_qb = new ck(640, 480);
                            w.w_qb.a();
                            wg.wg_b.d((wg.wg_b.K >> 1059375233) - -le.y, (wg.wg_b.C >> -491134559) - -g.Q, db.db_a, 4096);
                            wg.wg_b = null;
                            w.w_qb.f();
                            hk.a((int[])object3, n4, n8);
                            hk.a(he.V);
                        }
                        if (n.n_b != null && null != bn.bn_g) {
                            object3 = hk.hk_l;
                            n4 = hk.hk_j;
                            n8 = hk.hk_i;
                            hk.b(he.V);
                            object2 = new ck(412, 43);
                            object = cm.a((byte)122, df.Z, new String[]{n.n_b});
                            n.n_b = null;
                            ((ck)object2).a();
                            bn.bn_g.a((String)object, 3, 3, ((ck)object2).I - 6, ((ck)object2).H - 6, 0xFFFFFF, -1, 0, 1, bn.bn_g.R + bn.bn_g.K);
                            re.a(3, 1, 0, 2, (ck)object2, 0, ((ck)object2).I, ((ck)object2).H);
                            lb.lb_h.a();
                            ((ck)object2).c(-lb.lb_h.F + 199, -lb.lb_h.z + 83);
                            hk.a((int[])object3, n4, n8);
                            hk.a(he.V);
                        }
                        if (pe.pe_d != null && bn.bn_g != null) {
                            object3 = hk.hk_l;
                            n4 = hk.hk_j;
                            n8 = hk.hk_i;
                            hk.b(he.V);
                            int n11 = 6 + bn.bn_g.b(ka.O, 640);
                            int n12 = 20 + (n11 - -pe.pe_d.K);
                            n7 = -(n12 / 2) + 427;
                            n6 = 20 + (n7 - -pe.pe_d.K);
                            lb.lb_h.a();
                            bn.bn_g.a(ka.O, n6 - lb.lb_h.F, bn.bn_g.K + (bn.bn_g.R + (-lb.lb_h.z + 155)), 0xFFFFFF, -1);
                            re.a(3, 1, -lb.lb_h.F + (n6 + -4), n2 ^ 0x184, lb.lb_h, -lb.lb_h.z + 155, n11, 50);
                            n5 = -lb.lb_h.z + 155 - (-bn.bn_g.R + -3 + pe.pe_d.C + -bn.bn_g.K) / 2;
                            pe.pe_d.c(n7 - lb.lb_h.F, n5);
                            hk.a((int[])object3, n4, n8);
                            hk.a(he.V);
                            pe.pe_d = null;
                        }
                        hk.b(he.V);
                        if (n2 != 390) {
                            pb.a((byte)100);
                        }
                        hk.a(16, 16, 608, 112, 15, qn.qn_lb, w.Fb);
                        hk.a(231, 144, 393, 232, 15, qn.qn_lb, w.Fb);
                        if (null != dj.dj_eb) {
                            dj.dj_eb.c(0, 0);
                        }
                        if (null != hg.hg_a) {
                            hg.hg_a.c(0, 0);
                        }
                        lb.lb_h.c(0, 0);
                        if (null != w.w_qb) {
                            w.w_qb.c(0, 0);
                        }
                        if (ea.ea_l != null && null != c.c_i) {
                            ea.ea_l.c(231, 390);
                            object3 = pj.I;
                            if (~rg.rg_a.sk_h == -1) {
                                object3 = oh.oh_e;
                            }
                            ((ck)object3).c(0, 0);
                            n4 = (h.a(rb.rb_b << (0 != rg.rg_a.sk_h ? 3 : 4), (byte)-122) * 40 >> -551624784) + 40;
                            if (-1 > ~n4) {
                                ea.ea_l.f(230, 389, n4);
                                ea.ea_l.f(232, 389, n4);
                                ea.ea_l.f(232, 391, n4);
                                ea.ea_l.f(230, 391, n4);
                                ((ck)object3).f(1, 1, n4);
                                ((ck)object3).f(-1, 1, n4);
                                ((ck)object3).f(1, -1, n4);
                                ((ck)object3).f(-1, -1, n4);
                            }
                            ak.a(dm.dm_a, sk.sk_k, -1 == ~rg.rg_a.sk_h, 40);
                        }
                        if (null != ea.ea_l && c.c_i != null) {
                            ea.ea_l.c(434, 390);
                            lf.lf_i.c(0, 0);
                            if (~rg.rg_a.sk_h == -2) {
                                wb.a(31, 436, 7 * ea.ea_l.H / 12, 392, 64, -4 + ea.ea_l.I);
                            }
                            ak.a(sk.sk_e, dg.dg_b, ~rg.rg_a.sk_h == -2, 40);
                        }
                        if (null == ge.ge_h) break block19;
                        n3 = -(ge.ge_h.C / 2) + 357;
                        ge.ge_h.c(-ge.ge_h.K + 269, n3);
                        l.l_b.c(586, n3);
                        if (n3 >= pm.pm_f || n3 - -ge.ge_h.H <= pm.pm_f || 0 >= (n4 = (40 * h.a(rb.rb_b << -919985340, (byte)-122) >> -605044784) + 40)) break block19;
                        if (bh.bh_g > 269 + -ge.ge_h.I && bh.bh_g < 269) break block20;
                        if (586 >= bh.bh_g) break block19;
                        if (586 - -ge.ge_h.I > bh.bh_g) break block21;
                        hc.a(73);
                        vi.z[wh.wh_a].c(269, 340);
                        break block22;
                    }
                    l.l_b.f(585, -1 + n3, n4);
                    l.l_b.f(587, -1 + n3, n4);
                    l.l_b.f(585, 1 + n3, n4);
                    l.l_b.f(587, 1 + n3, n4);
                    break block19;
                }
                ge.ge_h.f(-ge.ge_h.K + 269 + -1, n3 + -1, n4);
                ge.ge_h.f(1 + (269 - ge.ge_h.K), -1 + n3, n4);
                ge.ge_h.f(-ge.ge_h.K + 269 + -1, 1 + n3, n4);
                ge.ge_h.f(-ge.ge_h.K + 269 - -1, n3 - -1, n4);
            }
            hc.a(73);
            vi.z[wh.wh_a].c(269, 340);
        }
    }

    static final void a(ji ji2, int n2) {
        int n3;
        int n4;
        uf uf2;
        boolean bl2 = client.A;
        uf uf3 = uf2 = new uf(ji2.a(0, "", "logo.fo3d"));
        int n5 = uf3.d((byte)-124);
        uf3.j((byte)-108);
        l.l_i = rf.a(122, uf3);
        df.U = new int[n5][];
        jb.jb_g = new vg[n5];
        for (n4 = 0; n4 < n5; ++n4) {
            jb.jb_g[n4] = un.a(-128, uf2);
        }
        uf3.k((byte)-124);
        if (n2 >= -1) {
            pb_e = null;
        }
        n4 = n3 = 0;
        while (n5 > n3) {
            vg vg2 = jb.jb_g[n3];
            vg2.a(6, 6, (byte)31, 6, 1);
            vg2.a(-14200);
            int[] nArray = new int[]{vg2.H - -vg2.vg_f >> 2089083617, vg2.vg_b + vg2.vg_n >> -1064477215, vg2.vg_a + vg2.vg_i >> 1145728961};
            df.U[n3] = nArray;
            vg2.a((byte)-111, -nArray[0], -nArray[1], -nArray[2]);
            ++n3;
        }
    }

    pb() {
    }

    static {
        pb_k = "Try changing the following settings:  ";
        pb_c = new vj();
        pb_d = 128;
        pb_e = "Reload game";
        pb_i = new gh(3);
    }
}
