/*
 * Decompiled with CFR 0.152.
 */
final class ud
extends ti {
    int ud_p;
    byte[] ud_o;
    int ud_q;
    boolean ud_r;
    int ud_s;

    final ud a(je je2) {
        this.ud_o = je2.a(14, this.ud_o);
        this.ud_p = je2.a(false, this.ud_p);
        if (this.ud_q == this.ud_s) {
            this.ud_q = this.ud_s = je2.b(this.ud_q, 114);
        } else {
            this.ud_q = je2.b(this.ud_q, 86);
            this.ud_s = je2.b(this.ud_s, 36);
            if (this.ud_q == this.ud_s) {
                --this.ud_q;
            }
        }
        return this;
    }

    ud(int n, byte[] byArray, int n2, int n3) {
        this.ud_p = n;
        this.ud_o = byArray;
        this.ud_q = n2;
        this.ud_s = n3;
    }

    ud(int n, byte[] byArray, int n2, int n3, boolean bl) {
        this.ud_p = n;
        this.ud_o = byArray;
        this.ud_q = n2;
        this.ud_s = n3;
        this.ud_r = bl;
    }
}
