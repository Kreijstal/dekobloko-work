/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;

final class va
extends bh {
    private static int[] x;
    private static int y;
    private static float[] A;
    private int C;
    private static float[] M;
    private static int va_u;
    private static float[] U;
    private static int T;
    private boolean G;
    private int P;
    private int F;
    private byte[][] va_t;
    private static float[] va_v;
    private static ih[] R;
    private static bm[] va_o;
    private static boolean[] K;
    static ja[] S;
    private int N;
    private static float[] va_p;
    private byte[] E;
    private static int[] D;
    private static q[] va_r;
    private static boolean va_n;
    private static byte[] va_w;
    private static float[] J;
    private float[] z;
    private static float[] H;
    private int va_s;
    private int O;
    private int L;
    private int I;
    private static int B;
    private static int[] Q;
    private boolean va_q;

    static final float a(int n) {
        int n2 = n & 0x1FFFFF;
        int n3 = n & Integer.MIN_VALUE;
        int n4 = (n & 0x7FE00000) >> 21;
        if (n3 != 0) {
            n2 = -n2;
        }
        return (float)((double)n2 * Math.pow(2.0, n4 - 788));
    }

    static final void b(byte[] byArray) {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        va.a(byArray, 0);
        y = 1 << va.c(4);
        B = 1 << va.c(4);
        H = new float[B];
        for (n5 = 0; n5 < 2; ++n5) {
            n4 = n5 != 0 ? B : y;
            n3 = n4 >> 1;
            n2 = n4 >> 2;
            n = n4 >> 3;
            float[] fArray = new float[n3];
            for (int i = 0; i < n2; ++i) {
                fArray[2 * i] = (float)Math.cos((double)(4 * i) * Math.PI / (double)n4);
                fArray[2 * i + 1] = -((float)Math.sin((double)(4 * i) * Math.PI / (double)n4));
            }
            float[] fArray2 = new float[n3];
            for (int i = 0; i < n2; ++i) {
                fArray2[2 * i] = (float)Math.cos((double)(2 * i + 1) * Math.PI / (double)(2 * n4));
                fArray2[2 * i + 1] = (float)Math.sin((double)(2 * i + 1) * Math.PI / (double)(2 * n4));
            }
            float[] fArray3 = new float[n2];
            for (int i = 0; i < n; ++i) {
                fArray3[2 * i] = (float)Math.cos((double)(4 * i + 2) * Math.PI / (double)n4);
                fArray3[2 * i + 1] = -((float)Math.sin((double)(4 * i + 2) * Math.PI / (double)n4));
            }
            int[] nArray = new int[n];
            int n6 = s.b((byte)-57, n - 1);
            for (int i = 0; i < n; ++i) {
                nArray[i] = rd.a((byte)16, n6, i);
            }
            if (n5 != 0) {
                U = fArray;
                J = fArray2;
                M = fArray3;
                D = nArray;
                continue;
            }
            va_v = fArray;
            va_p = fArray2;
            A = fArray3;
            Q = nArray;
        }
        n5 = va.c(8) + 1;
        S = new ja[n5];
        for (n4 = 0; n4 < n5; ++n4) {
            va.S[n4] = new ja();
        }
        n4 = va.c(6) + 1;
        for (n3 = 0; n3 < n4; ++n3) {
            va.c(16);
        }
        n4 = va.c(6) + 1;
        R = new ih[n4];
        for (n3 = 0; n3 < n4; ++n3) {
            va.R[n3] = new ih();
        }
        n3 = va.c(6) + 1;
        va_o = new bm[n3];
        for (n2 = 0; n2 < n3; ++n2) {
            va.va_o[n2] = new bm();
        }
        n2 = va.c(6) + 1;
        va_r = new q[n2];
        for (n = 0; n < n2; ++n) {
            va.va_r[n] = new q();
        }
        n = va.c(6) + 1;
        K = new boolean[n];
        x = new int[n];
        for (int i = 0; i < n; ++i) {
            va.K[i] = va.b() != 0;
            va.c(16);
            va.c(16);
            va.x[i] = va.c(8);
        }
        va_n = true;
    }

    static final int b() {
        int n = va_w[T] >> va_u & 1;
        T += ++va_u >> 3;
        va_u &= 7;
        return n;
    }

    private final void a(byte[] byArray) throws IOException {
        int n;
        wl wl2 = new wl(byArray);
        this.O = wl2.i(7553);
        this.I = wl2.i(7553);
        this.P = wl2.i(7553);
        this.L = wl2.i(7553);
        if (this.L < 0) {
            this.L ^= 0xFFFFFFFF;
            this.va_q = true;
        }
        if ((n = wl2.i(7553)) < 0) {
            throw new IOException();
        }
        this.va_t = new byte[n][];
        for (int i = 0; i < n; ++i) {
            int n2;
            int n3 = 0;
            do {
                n2 = wl2.d((byte)-64);
                n3 += n2;
            } while (n2 >= 255);
            byte[] byArray2 = new byte[n3];
            wl2.a(byArray2, 0, (byte)125, n3);
            this.va_t[i] = byArray2;
        }
    }

    final ud a(int[] nArray) {
        if (nArray != null && nArray[0] <= 0) {
            return null;
        }
        if (this.E == null) {
            this.va_s = 0;
            this.z = new float[B];
            this.E = new byte[this.I];
            this.F = 0;
            this.N = 0;
        }
        while (this.N < this.va_t.length) {
            if (nArray != null && nArray[0] <= 0) {
                return null;
            }
            float[] fArray = this.d(this.N);
            if (fArray != null) {
                int n = fArray.length;
                int n2 = this.F;
                if (n > this.I - n2) {
                    n = this.I - n2;
                }
                for (int i = 0; i < n; ++i) {
                    int n3 = (int)(128.0f + fArray[i] * 128.0f);
                    if ((n3 & 0xFFFFFF00) != 0) {
                        n3 = ~n3 >> 31;
                    }
                    this.E[n2++] = (byte)(n3 - 128);
                }
                if (nArray != null) {
                    nArray[0] = nArray[0] - (n2 - this.F);
                }
                this.F = n2;
            }
            ++this.N;
        }
        this.z = null;
        byte[] byArray = this.E;
        this.E = null;
        return new ud(this.O, byArray, this.P, this.L, this.va_q);
    }

    final ud a() {
        this.va_s = 0;
        this.z = new float[B];
        byte[] byArray = new byte[this.I];
        int n = 0;
        for (int i = 0; i < this.va_t.length; ++i) {
            float[] fArray = this.d(i);
            if (fArray == null) continue;
            int n2 = fArray.length;
            if (n2 > this.I - n) {
                n2 = this.I - n;
            }
            for (int j = 0; j < n2; ++j) {
                int n3 = (int)(128.0f + fArray[j] * 128.0f);
                if ((n3 & 0xFFFFFF00) != 0) {
                    n3 = ~n3 >> 31;
                }
                byArray[n++] = (byte)(n3 - 128);
            }
        }
        this.z = null;
        return new ud(this.O, byArray, this.P, this.L, this.va_q);
    }

    private final float[] d(int n) {
        boolean bl;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        va.a(this.va_t[n], 0);
        va.b();
        int n8 = va.c(s.b((byte)-26, x.length - 1));
        boolean bl2 = K[n8];
        int n9 = bl2 ? B : y;
        boolean bl3 = false;
        boolean bl4 = false;
        if (bl2) {
            bl3 = va.b() != 0;
            bl4 = va.b() != 0;
        }
        int n10 = n9 >> 1;
        if (bl2 && !bl3) {
            n7 = (n9 >> 2) - (y >> 2);
            n6 = (n9 >> 2) + (y >> 2);
            n5 = y >> 1;
        } else {
            n7 = 0;
            n6 = n10;
            n5 = n9 >> 1;
        }
        if (bl2 && !bl4) {
            n4 = n9 - (n9 >> 2) - (y >> 2);
            n3 = n9 - (n9 >> 2) + (y >> 2);
            n2 = y >> 1;
        } else {
            n4 = n10;
            n3 = n9;
            n2 = n9 >> 1;
        }
        q q2 = va_r[x[n8]];
        int bl5 = q2.q_c;
        int fArray = q2.q_a[bl5];
        boolean bl6 = bl = !R[fArray].a();
        for (fArray = 0; fArray < q2.q_b; ++fArray) {
            bm n12 = va_o[q2.q_d[fArray]];
            float[] n17 = H;
            n12.a(n17, n9 >> 1, bl6);
        }
        if (!bl) {
            fArray = q2.q_c;
            int n16 = q2.q_a[fArray];
            R[n16].a(H, n9 >> 1);
        }
        if (bl) {
            for (fArray = n9 >> 1; fArray < n9; ++fArray) {
                va.H[fArray] = 0.0f;
            }
        } else {
            int n11;
            float i;
            float n21;
            float n20;
            float n13;
            int n12;
            int n14;
            fArray = n9 >> 1;
            int n30 = n9 >> 2;
            int n31 = n9 >> 3;
            float[] n32 = H;
            int fArray2 = 0;
            while (fArray2 < fArray) {
                int n15 = fArray2++;
                n32[n15] = n32[n15] * 0.5f;
            }
            fArray2 = n14 = fArray;
            while (n14 < n9) {
                n32[n14] = -n32[n9 - n14 - 1];
                ++n14;
            }
            float[] fArray3 = bl2 ? U : va_v;
            float[] fArray4 = bl2 ? J : va_p;
            float[] fArray5 = bl2 ? M : A;
            int[] nArray = bl2 ? D : Q;
            for (n12 = 0; n12 < n30; ++n12) {
                n13 = n32[4 * n12] - n32[n9 - 4 * n12 - 1];
                n20 = n32[4 * n12 + 2] - n32[n9 - 4 * n12 - 3];
                n21 = fArray3[2 * n12];
                i = fArray3[2 * n12 + 1];
                n32[n9 - 4 * n12 - 1] = n13 * n21 - n20 * i;
                n32[n9 - 4 * n12 - 3] = n13 * i + n20 * n21;
            }
            for (n12 = 0; n12 < n31; ++n12) {
                n13 = n32[fArray + 3 + 4 * n12];
                n20 = n32[fArray + 1 + 4 * n12];
                n21 = n32[4 * n12 + 3];
                i = n32[4 * n12 + 1];
                n32[fArray + 3 + 4 * n12] = n13 + n21;
                n32[fArray + 1 + 4 * n12] = n20 + i;
                float n22 = fArray3[fArray - 4 - 4 * n12];
                float n23 = fArray3[fArray - 3 - 4 * n12];
                n32[4 * n12 + 3] = (n13 - n21) * n22 - (n20 - i) * n23;
                n32[4 * n12 + 1] = (n20 - i) * n22 + (n13 - n21) * n23;
            }
            n12 = s.b((byte)-63, n9 - 1);
            for (n11 = 0; n11 < n12 - 3; ++n11) {
                int n25 = n9 >> n11 + 2;
                int n26 = 8 << n11;
                for (int n27 = 0; n27 < 2 << n11; ++n27) {
                    int f13 = n9 - n25 * 2 * n27;
                    int f18 = n9 - n25 * (2 * n27 + 1);
                    for (int j = 0; j < n9 >> n11 + 4; ++j) {
                        int f20 = 4 * j;
                        float f = n32[f13 - 1 - f20];
                        float f2 = n32[f13 - 3 - f20];
                        float f3 = n32[f18 - 1 - f20];
                        float f4 = n32[f18 - 3 - f20];
                        n32[f13 - 1 - f20] = f + f3;
                        n32[f13 - 3 - f20] = f2 + f4;
                        float f5 = fArray3[j * n26];
                        float f6 = fArray3[j * n26 + 1];
                        n32[f18 - 1 - f20] = (f - f3) * f5 - (f2 - f4) * f6;
                        n32[f18 - 3 - f20] = (f2 - f4) * f5 + (f - f3) * f6;
                    }
                }
            }
            for (n11 = 1; n11 < n31 - 1; ++n11) {
                int f14 = nArray[n11];
                if (n11 >= f14) continue;
                int f15 = 8 * n11;
                int f16 = 8 * f14;
                float f17 = n32[f15 + 1];
                n32[f15 + 1] = n32[f16 + 1];
                n32[f16 + 1] = f17;
                f17 = n32[f15 + 3];
                n32[f15 + 3] = n32[f16 + 3];
                n32[f16 + 3] = f17;
                f17 = n32[f15 + 5];
                n32[f15 + 5] = n32[f16 + 5];
                n32[f16 + 5] = f17;
                f17 = n32[f15 + 7];
                n32[f15 + 7] = n32[f16 + 7];
                n32[f16 + 7] = f17;
            }
            for (n11 = 0; n11 < fArray; ++n11) {
                n32[n11] = n32[2 * n11 + 1];
            }
            for (n11 = 0; n11 < n31; ++n11) {
                n32[n9 - 1 - 2 * n11] = n32[4 * n11];
                n32[n9 - 2 - 2 * n11] = n32[4 * n11 + 1];
                n32[n9 - n30 - 1 - 2 * n11] = n32[4 * n11 + 2];
                n32[n9 - n30 - 2 - 2 * n11] = n32[4 * n11 + 3];
            }
            for (n11 = 0; n11 < n31; ++n11) {
                float f21 = fArray5[2 * n11];
                float f = fArray5[2 * n11 + 1];
                float f7 = n32[fArray + 2 * n11];
                float f8 = n32[fArray + 2 * n11 + 1];
                float f9 = n32[n9 - 2 - 2 * n11];
                float f10 = n32[n9 - 1 - 2 * n11];
                float f11 = f * (f7 - f9) + f21 * (f8 + f10);
                n32[fArray + 2 * n11] = (f7 + f9 + f11) * 0.5f;
                n32[n9 - 2 - 2 * n11] = (f7 + f9 - f11) * 0.5f;
                f11 = f * (f8 + f10) - f21 * (f7 - f9);
                n32[fArray + 2 * n11 + 1] = (f8 - f10 + f11) * 0.5f;
                n32[n9 - 1 - 2 * n11] = (-f8 + f10 + f11) * 0.5f;
            }
            for (n11 = 0; n11 < n30; ++n11) {
                n32[n11] = n32[2 * n11 + fArray] * fArray4[2 * n11] + n32[2 * n11 + 1 + fArray] * fArray4[2 * n11 + 1];
                n32[fArray - 1 - n11] = n32[2 * n11 + fArray] * fArray4[2 * n11 + 1] - n32[2 * n11 + 1 + fArray] * fArray4[2 * n11];
            }
            for (n11 = 0; n11 < n30; ++n11) {
                n32[n9 - n30 + n11] = -n32[n11];
            }
            for (n11 = 0; n11 < n30; ++n11) {
                n32[n11] = n32[n30 + n11];
            }
            for (n11 = 0; n11 < n30; ++n11) {
                n32[n30 + n11] = -n32[n30 - n11 - 1];
            }
            for (n11 = 0; n11 < n30; ++n11) {
                n32[fArray + n11] = n32[n9 - n11 - 1];
            }
            n11 = n7;
            while (n11 < n6) {
                float f22 = (float)Math.sin(((double)(n11 - n7) + 0.5) / (double)n5 * 0.5 * Math.PI);
                int n16 = n11++;
                H[n16] = H[n16] * (float)Math.sin(1.5707963267948966 * (double)f22 * (double)f22);
            }
            n11 = n4;
            while (n11 < n3) {
                float f = (float)Math.sin(((double)(n11 - n4) + 0.5) / (double)n2 * 0.5 * Math.PI + 1.5707963267948966);
                int n17 = n11++;
                H[n17] = H[n17] * (float)Math.sin(1.5707963267948966 * (double)f * (double)f);
            }
        }
        float[] fArray6 = null;
        if (this.va_s > 0) {
            float[] fArray7;
            int fArray62 = this.va_s + n9 >> 2;
            fArray6 = fArray7 = new float[fArray62];
            if (!this.G) {
                int i = 0;
                while (i < this.C) {
                    int n34 = (this.va_s >> 1) + i;
                    int n18 = i++;
                    fArray7[n18] = fArray7[n18] + this.z[n34];
                }
            }
            if (!bl) {
                for (int i = n7; i < n9 >> 1; ++i) {
                    int n19;
                    int n20 = n19 = fArray7.length - (n9 >> 1) + i;
                    fArray7[n20] = fArray7[n20] + H[i];
                }
            }
        }
        float[] fArray8 = this.z;
        this.z = H;
        H = fArray8;
        this.va_s = n9;
        this.C = n3 - (n9 >> 1);
        this.G = bl;
        return fArray6;
    }

    static final int c(int n) {
        int n2;
        int n3 = 0;
        int n4 = 0;
        while (n >= 8 - va_u) {
            n2 = 8 - va_u;
            int n5 = (1 << n2) - 1;
            n3 += (va_w[T] >> va_u & n5) << n4;
            va_u = 0;
            ++T;
            n4 += n2;
            n -= n2;
        }
        if (n > 0) {
            n2 = (1 << n) - 1;
            n3 += (va_w[T] >> va_u & n2) << n4;
            va_u += n;
        }
        return n3;
    }

    static final va a(ji ji2, int n, int n2) {
        if (!va.a(ji2)) {
            ji2.a((byte)-83, n2, n);
            return null;
        }
        byte[] byArray = ji2.a(n2, -124, n);
        if (byArray == null) {
            return null;
        }
        va va2 = null;
        try {
            va2 = new va(byArray);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        return va2;
    }

    private static final boolean a(ji ji2) {
        if (!va_n) {
            byte[] byArray = ji2.a(0, -121, 0);
            if (byArray == null) {
                return false;
            }
            va.b(byArray);
        }
        return true;
    }

    public static void c() {
        va_w = null;
        S = null;
        R = null;
        va_o = null;
        va_r = null;
        K = null;
        x = null;
        H = null;
        va_v = null;
        va_p = null;
        A = null;
        U = null;
        J = null;
        M = null;
        Q = null;
        D = null;
    }

    private static final void a(byte[] byArray, int n) {
        va_w = byArray;
        T = n;
        va_u = 0;
    }

    static final va a(ji ji2, String string, String string2) {
        if (!va.a(ji2)) {
            ji2.a(string2, true, string);
            return null;
        }
        byte[] byArray = ji2.a(0, string2, string);
        if (byArray == null) {
            return null;
        }
        va va2 = null;
        try {
            va2 = new va(byArray);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        return va2;
    }

    private va(byte[] byArray) throws IOException {
        this.a(byArray);
    }

    static {
        va_n = false;
    }
}
