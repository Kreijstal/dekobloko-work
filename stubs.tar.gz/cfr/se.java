/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.util.Hashtable;

final class se
extends ma {
    private int N;
    static lm S;
    static String V;
    static String Q;
    private int R;
    private boolean P;
    private int O = Integer.MAX_VALUE;
    static w U;
    private int M = Integer.MAX_VALUE;
    private boolean T;

    public static void g(int n) {
        if (n != 11344) {
            se.i(-102);
        }
        Q = null;
        V = null;
        S = null;
        U = null;
    }

    @Override
    final boolean a(int n, int n2, ce ce2, int n3, int n4, int n5, byte by) {
        boolean bl = super.a(n, n2, ce2, n3, n4, n5, by);
        if (bl && this.P) {
            return true;
        }
        if (!this.a(n2, (byte)-39, n4, n, n5)) {
            return bl;
        }
        this.ce_o = n3;
        if (~n3 != -2) {
            return true;
        }
        this.N = -n5 + (n2 - this.ce_u);
        lg.Y = this;
        this.R = n + -this.D + -n4;
        return true;
    }

    static final Applet h(int n) {
        if (n != 25144) {
            se.i(-107);
        }
        if (kb.kb_h != null) {
            return kb.kb_h;
        }
        return ta.ta_i;
    }

    static final boolean i(int n) {
        if (n != -1) {
            se.i(107);
        }
        return nm.Qb && qj.qj_k || ph.n(n + -30145);
    }

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        block7: {
            if (this.L instanceof ek && !((ek)this.L).I || 1 != this.ce_o) {
                if (this.T) {
                    int n4;
                    if (~this.M != ~this.ce_u) {
                        n4 = -this.ce_u + this.M;
                        this.ce_u += Math.abs(n4) > 2 ? n4 >> 1623977313 : (-1 > ~n4 ? 1 : -1);
                    }
                    if (this.D != this.O) {
                        n4 = this.O + -this.D;
                        this.D += ~Math.abs(n4) >= -3 ? (~n4 >= -1 ? -1 : 1) : n4 >> -553011135;
                    }
                }
            } else {
                int n5 = bh.bh_g - (this.N - -n3);
                int n6 = pm.pm_f - this.R - n2;
                if (~this.ce_u != ~n5 || ~n6 != ~this.D) {
                    this.D = n6;
                    this.ce_u = n5;
                    if (this.ce_v instanceof mj) {
                        ((mj)this.ce_v).a(n3, this, -24076, n2);
                    }
                }
            }
            super.a(ce2, 113, n2, n3);
            if (n >= 38) break block7;
            se.g(86);
        }
    }

    static final void a(ji ji2, ji ji3, byte by, boolean bl2, ji ji4) {
        jj.jj_f = ui.a(0, "");
        jj.jj_f.a(-21, false);
        fn.a(ji2, ji3, ji4, 0);
        bl.g((byte)-121);
        sh.sh_d = uc.uc_c;
        if (by != 76) {
            ji ji5 = null;
            se.a(null, null, (byte)-98, true, ji5);
        }
        ka.P = uc.uc_c;
    }

    @Override
    final StringBuilder a(Hashtable hashtable, int n, StringBuilder stringBuilder, boolean bl2) {
        if (!bl2) {
            ce ce2 = null;
            this.a(-91, 66, ce2, 112, 104, 72, (byte)-16);
        }
        if (this.a(0, n, hashtable, stringBuilder)) {
            this.a((byte)72, stringBuilder, hashtable, n);
            this.a((byte)-105, n, stringBuilder, hashtable);
            stringBuilder.append(" revert=").append(this.T);
            if (Integer.MIN_VALUE != ~this.M && ~this.O != Integer.MIN_VALUE) {
                stringBuilder.append(" to ").append(this.M).append(',').append(this.O);
            }
        }
        return stringBuilder;
    }

    @Override
    final void b(boolean bl2) {
        super.b(bl2);
        this.L.b(this.y, this.ce_t, 0, 0, -16555);
        this.O = this.D;
        this.M = this.ce_u;
    }

    @Override
    final void a(int n, int n2, int n3, ce ce2, int n4, int n5) {
        block0: {
            super.a(n, n2 ^ 0, n3, ce2, n4, n5);
            this.ce_o = 0;
            if (n2 == 64) break block0;
            S = null;
        }
    }

    private se(int n, int n2, int n3, int n4, gl gl2, kg kg2, ce ce2, boolean bl2, boolean bl3) {
        super(n, n2, n3, n4, gl2, kg2);
        this.T = bl2;
        this.P = bl3;
        this.L = ce2;
    }

    static {
        Q = "Create";
        V = "You cannot chat to <%0> because <%0> is not in your friend list.";
    }
}
