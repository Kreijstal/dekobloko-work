/*
 * Decompiled with CFR 0.152.
 */
import java.net.URL;

final class pl {
    private ng pl_a = new ng(256);
    static String pl_c = "New Game";
    private ji pl_g;
    static String pl_e;
    static String pl_f;
    private ji pl_d;
    private ng pl_b = new ng(256);

    final ud a(String string, String string2, int n) {
        block0: {
            if (n == 0) break block0;
            this.pl_a = null;
        }
        return this.a(string, null, string2, true);
    }

    static final void a(int n) {
        if (n != 3970) {
            pl_c = null;
        }
        jc.a((byte)103);
    }

    final ud a(int n, int n2, int n3) {
        int n4 = -17 % ((-2 - n) / 57);
        return this.a(121, n3, null, n2);
    }

    static final URL a(String string, String string2, boolean bl, URL uRL, int n) {
        boolean bl2 = client.A;
        String string3 = uRL.getFile();
        int n2 = 0;
        while (true) {
            int n3;
            if (string3.regionMatches(n2, "/l=", 0, 3) && -1 >= ~(n3 = string3.indexOf(47, 1 + n2))) {
                if (0 > n) {
                    n2 = n3;
                    continue;
                }
                string3 = string3.substring(0, n2) + string3.substring(n3);
                continue;
            }
            if (string3.regionMatches(n2, "/a=", 0, 3) && -1 >= ~(n3 = string3.indexOf(47, n2 - -1))) {
                n2 = n3;
                continue;
            }
            if (string3.regionMatches(n2, "/p=", 0, 3) && 0 <= (n3 = string3.indexOf(47, 1 + n2))) {
                if (string2 == null) {
                    n2 = n3;
                    continue;
                }
                string3 = string3.substring(0, n2) + string3.substring(n3);
                continue;
            }
            if (!string3.regionMatches(n2, "/s=", 0, 3) && !string3.regionMatches(n2, "/c=", 0, 3) || 0 > (n3 = string3.indexOf(47, n2 + 1))) break;
            if (null != string) {
                string3 = string3.substring(0, n2) + string3.substring(n3);
                continue;
            }
            n2 = n3;
        }
        StringBuilder stringBuilder = new StringBuilder(n2);
        if (bl) {
            return null;
        }
        stringBuilder.append(string3.substring(0, n2));
        if (-1 > ~n) {
            stringBuilder.append("/l=");
            stringBuilder.append(Integer.toString(n));
        }
        if (null != string2 && ~string2.length() < -1) {
            stringBuilder.append("/p=");
            stringBuilder.append(string2);
        }
        if (string != null && 0 < string.length()) {
            stringBuilder.append("/s=");
            stringBuilder.append(string);
        }
        if (~n2 > ~string3.length()) {
            stringBuilder.append(string3.substring(n2, string3.length()));
        } else {
            stringBuilder.append('/');
        }
        try {
            return new URL(uRL, stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return uRL;
        }
    }

    private final ud a(String string, int[] nArray, String string2, byte by) {
        int n;
        if (by > -17) {
            String string3 = null;
            this.a(null, string3, 126);
        }
        if (0 > (n = this.pl_d.b(-1, string2))) {
            return null;
        }
        int n2 = this.pl_d.a(n, 13030, string);
        if (~n2 > -1) {
            return null;
        }
        return this.a(n2, nArray, n, -15027);
    }

    final ud a(byte by, String string, String string2) {
        if (by != 101) {
            return null;
        }
        return this.a(string2, null, string, (byte)-75);
    }

    public static void b(int n) {
        pl_e = null;
        pl_c = null;
        int n2 = 81 % ((n - -78) / 33);
        pl_f = null;
    }

    private final ud a(String string, int[] nArray, String string2, boolean bl) {
        int n = this.pl_g.b(-1, string);
        if (!bl) {
            this.pl_a = null;
        }
        if (0 > n) {
            return null;
        }
        int n2 = this.pl_g.a(n, 13030, string2);
        if (n2 < 0) {
            return null;
        }
        return this.a(119, n, nArray, n2);
    }

    private final ud a(int n, int[] nArray, int n2, int n3) {
        va va2;
        int n4 = n ^ (0xFFFC & n2 << 58549220 | n2 >>> 391646732);
        long l = 0x100000000L ^ (long)(n4 |= n2 << 13351536);
        ud ud2 = (ud)this.pl_b.a(l, 126);
        if (null != ud2) {
            return ud2;
        }
        if (nArray != null && ~nArray[0] >= -1) {
            return null;
        }
        va va3 = va2 = (va)this.pl_a.a(l, 55);
        if (va2 == null) {
            va3 = va.a(this.pl_d, n2, n);
            if (va3 == null) {
                return null;
            }
            this.pl_a.a(l, n3 ^ 0x3AB2, va3);
        }
        if (n3 != -15027) {
            return null;
        }
        ud2 = va3.a(nArray);
        if (null == ud2) {
            return null;
        }
        va3.b((byte)101);
        this.pl_b.a(l, -1, ud2);
        return ud2;
    }

    private final ud a(int n, int n2, int[] nArray, int n3) {
        ud ud2;
        long l;
        ud ud3;
        int n4 = n3 ^ (n2 << 1515294692 & 0xFFFB | n2 >>> -487058036);
        n4 |= n2 << 1656051856;
        if (n < 113) {
            pl_f = null;
        }
        if (null != (ud3 = (ud)this.pl_b.a(l = (long)n4, 106))) {
            return ud3;
        }
        if (null != nArray && ~nArray[0] >= -1) {
            return null;
        }
        bi bi2 = bi.a(this.pl_g, n2, n3);
        if (bi2 == null) {
            return null;
        }
        ud3 = ud2 = bi2.b();
        this.pl_b.a(l, -1, ud3);
        if (null != nArray) {
            nArray[0] = nArray[0] - ud2.ud_o.length;
        }
        return ud3;
    }

    final ud b(int n, int n2, int n3) {
        if (n3 != -1) {
            return null;
        }
        return this.a(n, null, n2, -15027);
    }

    pl(ji ji2, ji ji3) {
        this.pl_d = ji3;
        this.pl_g = ji2;
    }

    static {
        pl_f = "You need to play 1 more rated game to unlock this option.";
        pl_e = "Add <%0> to friend list";
    }
}
