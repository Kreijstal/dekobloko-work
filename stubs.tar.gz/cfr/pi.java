/*
 * Decompiled with CFR 0.152.
 */
final class pi
extends lc {
    byte[] pi_k;
    int[] pi_l;

    private static final void a(int[] nArray, byte[] byArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = 256 - n7;
        for (int i = -n4; i < 0; ++i) {
            for (int j = -n3; j < 0; ++j) {
                int n9;
                if ((n9 = byArray[n++]) != 0) {
                    n9 = nArray2[n9 & 0xFF];
                    int n10 = nArray[n2];
                    nArray[n2++] = ((n9 & 0xFF00FF) * n7 + (n10 & 0xFF00FF) * n8 & 0xFF00FF00) + ((n9 & 0xFF00) * n7 + (n10 & 0xFF00) * n8 & 0xFF0000) >> 8;
                    continue;
                }
                ++n2;
            }
            n2 += n5;
            n += n6;
        }
    }

    @Override
    final void a(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.lc_d) + (n2 += this.lc_c) * hk.hk_j;
        int n6 = 0;
        int n7 = this.lc_i;
        int n8 = this.lc_b;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            pi.a(hk.hk_l, this.pi_k, this.pi_l, n6, n5, n8, n7, n9, n10, n3);
            return;
        }
    }

    private static final void b(int[] nArray, byte[] byArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = -(n4 >> 2);
        n4 = -(n4 & 3);
        for (int i = -n5; i < 0; ++i) {
            int n9;
            for (n9 = n8; n9 < 0; ++n9) {
                if ((n = byArray[n2++]) != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                } else {
                    ++n3;
                }
                n = byArray[n2++];
                if (n != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                } else {
                    ++n3;
                }
                n = byArray[n2++];
                if (n != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                } else {
                    ++n3;
                }
                n = byArray[n2++];
                if (n != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                    continue;
                }
                ++n3;
            }
            for (n9 = n4; n9 < 0; ++n9) {
                if ((n = byArray[n2++]) != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    pi(int n, int n2, int n3, int n4, int n5, int n6, byte[] byArray, int[] nArray) {
        this.lc_a = n;
        this.lc_g = n2;
        this.lc_d = n3;
        this.lc_c = n4;
        this.lc_b = n5;
        this.lc_i = n6;
        this.pi_k = byArray;
        this.pi_l = nArray;
    }

    @Override
    final void a(int n, int n2) {
        int n3;
        int n4 = (n += this.lc_d) + (n2 += this.lc_c) * hk.hk_j;
        int n5 = 0;
        int n6 = this.lc_i;
        int n7 = this.lc_b;
        int n8 = hk.hk_j - n7;
        int n9 = 0;
        if (n2 < hk.hk_h) {
            n3 = hk.hk_h - n2;
            n6 -= n3;
            n2 = hk.hk_h;
            n5 += n3 * n7;
            n4 += n3 * hk.hk_j;
        }
        if (n2 + n6 > hk.hk_b) {
            n6 -= n2 + n6 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n3 = hk.hk_c - n;
            n7 -= n3;
            n = hk.hk_c;
            n5 += n3;
            n4 += n3;
            n9 += n3;
            n8 += n3;
        }
        if (n + n7 > hk.hk_g) {
            n3 = n + n7 - hk.hk_g;
            n7 -= n3;
            n9 += n3;
            n8 += n3;
        }
        if (n7 > 0) {
            if (n6 <= 0) {
                return;
            }
            pi.b(hk.hk_l, this.pi_k, this.pi_l, 0, n5, n4, n7, n6, n8, n9);
            return;
        }
    }

    final void a() {
        if (this.lc_b == this.lc_a && this.lc_i == this.lc_g) {
            return;
        }
        byte[] byArray = new byte[this.lc_a * this.lc_g];
        int n = 0;
        for (int i = 0; i < this.lc_i; ++i) {
            for (int j = 0; j < this.lc_b; ++j) {
                byArray[j + this.lc_d + (i + this.lc_c) * this.lc_a] = this.pi_k[n++];
            }
        }
        this.pi_k = byArray;
        this.lc_b = this.lc_a;
        this.lc_i = this.lc_g;
        this.lc_d = 0;
        this.lc_c = 0;
    }

    pi(int n, int n2, int n3) {
        this.lc_a = this.lc_b = n;
        this.lc_g = this.lc_i = n2;
        this.lc_c = 0;
        this.lc_d = 0;
        this.pi_k = new byte[n * n2];
        this.pi_l = new int[n3];
    }

    final pi b() {
        pi pi2 = new pi(this.lc_b, this.lc_i, this.pi_l.length);
        pi2.lc_a = this.lc_a;
        pi2.lc_g = this.lc_g;
        pi2.lc_d = this.lc_d;
        pi2.lc_c = this.lc_c;
        int n = this.pi_k.length;
        System.arraycopy(this.pi_k, 0, pi2.pi_k, 0, n);
        n = this.pi_l.length;
        System.arraycopy(this.pi_l, 0, pi2.pi_l, 0, n);
        return pi2;
    }
}
