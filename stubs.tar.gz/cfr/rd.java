/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class rd {
    private bh rd_d;
    private vj rd_b;
    static boolean[] rd_c;
    static w rd_e;
    static w rd_a;

    static final w b(int n) {
        block0: {
            if (n <= -26) break block0;
            rd.a((byte)-21, 73, 124);
        }
        return df.i(119);
    }

    final bh a(bh bh2, boolean bl) {
        if (bl) {
            return null;
        }
        bh bh3 = bh2 != null ? bh2 : this.rd_b.vj_c.bh_b;
        if (bh3 == this.rd_b.vj_c) {
            this.rd_d = null;
            return null;
        }
        this.rd_d = bh3.bh_b;
        return bh3;
    }

    public static void b(byte by) {
        rd_c = null;
        rd_a = null;
        if (by != -119) {
            rd_c = null;
        }
        rd_e = null;
    }

    final bh a(int n) {
        bh bh2 = this.rd_d;
        if (n >= -40) {
            rd_c = null;
        }
        if (this.rd_b.vj_c == bh2) {
            this.rd_d = null;
            return null;
        }
        this.rd_d = bh2.bh_b;
        return bh2;
    }

    static final int a(String string, int n, String string2, String string3, int n2, int n3, boolean bl) {
        jg jg2 = new jg(string3);
        if (n2 != 0) {
            return -75;
        }
        jg jg3 = new jg(string2);
        return qb.a(bl, n, jg2, -109, n3, jg3, string);
    }

    final bh a(boolean bl) {
        bh bh2 = this.rd_b.vj_c.bh_a;
        if (!bl) {
            String string = null;
            rd.a(null, 14, null, string, -52, 96, false);
        }
        if (bh2 == this.rd_b.vj_c) {
            this.rd_d = null;
            return null;
        }
        this.rd_d = bh2.bh_a;
        return bh2;
    }

    final bh a(bh bh2, byte by) {
        bh bh3 = bh2 != null ? bh2 : this.rd_b.vj_c.bh_a;
        if (this.rd_b.vj_c == bh3) {
            this.rd_d = null;
            return null;
        }
        this.rd_d = bh3.bh_a;
        if (by != -88) {
            return null;
        }
        return bh3;
    }

    rd(vj vj2) {
        this.rd_b = vj2;
    }

    final bh d(int n) {
        bh bh2 = this.rd_d;
        if (bh2 == this.rd_b.vj_c) {
            this.rd_d = null;
            return null;
        }
        if (n != 2078965185) {
            rd.b(-96);
        }
        this.rd_d = bh2.bh_a;
        return bh2;
    }

    final bh a(byte by) {
        bh bh2 = this.rd_b.vj_c.bh_b;
        if (by != 71) {
            String string = null;
            rd.a(null, -87, null, string, -5, -114, false);
        }
        if (bh2 == this.rd_b.vj_c) {
            this.rd_d = null;
            return null;
        }
        this.rd_d = bh2.bh_b;
        return bh2;
    }

    static final void a(Applet applet, boolean bl) {
        String string;
        if (bl) {
            rd.c(-42);
        }
        if (null != (string = applet.getParameter("username")) && (ab.a(120, string) ^ 0xFFFFFFFFFFFFFFFFL) == -1L) {
            return;
        }
    }

    static final int a(byte by, int n, int n2) {
        boolean bl = client.A;
        if (by != 16) {
            rd.b(15);
        }
        int n3 = 0;
        while (0 < n) {
            n3 = n3 << 2078965185 | n2 & 1;
            n2 >>>= 1;
            --n;
        }
        return n3;
    }

    static final boolean a(CharSequence charSequence, int n) {
        if (n != -27454) {
            return false;
        }
        return ug.a(charSequence, false, 100);
    }

    static final void c(int n) {
        boolean bl = client.A;
        int[] nArray = a.a_r;
        int[] nArray2 = a.a_r;
        int n2 = n;
        int n3 = nArray.length;
        while (n2 < n3) {
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
            nArray[n2++] = 0;
        }
    }
}
