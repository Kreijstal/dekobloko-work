/*
 * Decompiled with CFR 0.152.
 */
import java.util.Iterator;

final class dg
implements Iterator {
    static vj dg_e;
    private be dg_g = null;
    static ck[][] dg_d;
    private uh dg_a;
    private be dg_f;
    static mi dg_c;
    static int dg_b;

    public final Object next() {
        be be2 = this.dg_f;
        if (this.dg_a.uh_a != be2) {
            this.dg_f = be2.be_p;
        } else {
            be2 = null;
            this.dg_f = null;
        }
        this.dg_g = be2;
        return be2;
    }

    @Override
    public final void remove() {
        if (this.dg_g == null) {
            throw new IllegalStateException();
        }
        this.dg_g.e((byte)81);
        this.dg_g = null;
    }

    public static void a(int n) {
        dg_e = null;
        dg_d = null;
        if (n != 8) {
            dg_d = null;
        }
        dg_c = null;
    }

    static final void a(int n, w w2, w w3) {
        if (w3.M == null) {
            w3.M = new vj();
        }
        if (null == w2.M) {
            w2.M = new vj();
        }
        if (null == mc.mc_a) {
            mc.mc_a = new nk(64);
        }
        if (null == hg.hg_e) {
            hg.hg_e = new nk(64);
        }
        uf.z = w2.M;
        if (n != 21014) {
            dg_c = null;
        }
        qi.S = w3.M;
        d.a(true);
    }

    static final void a(int n, int n2) {
        kn kn2;
        boolean bl = client.A;
        bh bh2 = kn2 = (kn)pb.pb_c.c((byte)-80);
        while (kn2 != null) {
            fm.a((byte)-125, n2, kn2);
            bh2 = (kn)pb.pb_c.d(true);
        }
        if (n > -47) {
            dg_b = 100;
        }
        kc kc2 = (kc)dg_e.c((byte)-121);
        bh2 = kc2;
        while (kc2 != null) {
            wb.a(kc2, n2, 60);
            bh2 = (kc)dg_e.d(true);
        }
    }

    @Override
    public final boolean hasNext() {
        return this.dg_f != this.dg_a.uh_a;
    }

    static final boolean b(int n) {
        if (n >= -34) {
            return false;
        }
        return rg.a(se.h(25144), (byte)-78);
    }

    dg(uh uh2) {
        this.dg_a = uh2;
        this.dg_f = this.dg_a.uh_a.be_p;
        this.dg_g = null;
    }

    static {
        dg_d = new ck[8][];
        dg_e = new vj();
    }
}
