/*
 * Decompiled with CFR 0.152.
 */
final class ac
extends be {
    int[] C;
    String H;
    static String[] z = new String[]{"Master Challenge: prove your prowess", "Unlock 4 more vibrant and varied themes", "Large bucket: grow shapes to the limit", "Use special items in multiplayer...", "...to turn things around spectacularly!", "Loads of extra Achievements", null, null};
    char[] G;
    static int B = 480;
    boolean D = false;
    int[] E;
    static int A;
    char[] y;
    static int F;

    static final void f(byte by) {
        if (by > -68) {
            ac.f((byte)55);
        }
        kk.kk_n = 0;
        cg.a(true);
    }

    static final ck[] a(int n, String string, String string2, ji ji2) {
        int n2;
        int n3;
        block0: {
            n3 = ji2.b(-1, string);
            n2 = ji2.a(n3, 13030, string2);
            if (n == 0) break block0;
            ac.g((byte)24);
        }
        return si.a(n2, n3, ji2, (byte)-46);
    }

    final void me_a_wl(byte by, wl wl2) {
        int n;
        boolean bl = client.A;
        if (by != -4) {
            this.H = null;
        }
        while (~(n = wl2.d((byte)-60)) != -1) {
            this.a(n, wl2, -127);
        }
    }

    public static void g(byte by) {
        if (by != -17) {
            ac.g((byte)-64);
        }
        z = null;
    }

    private final void a(int n, wl wl2, int n2) {
        int n3;
        boolean bl = client.A;
        if (n != 1) {
            if (-3 == ~n) {
                n3 = wl2.d((byte)-47);
                this.G = new char[n3];
                this.C = new int[n3];
                int n4 = 0;
                while (~n4 > ~n3) {
                    this.C[n4] = wl2.e(3);
                    byte by = wl2.g((byte)-99);
                    this.G[n4] = 0 != by ? jb.a(by, (byte)78) : (char)0;
                    ++n4;
                }
            } else if (3 != n) {
                if (-5 == ~n) {
                    this.D = true;
                }
            } else {
                n3 = wl2.d((byte)-37);
                this.E = new int[n3];
                this.y = new char[n3];
                for (int i = 0; n3 > i; ++i) {
                    this.E[i] = wl2.e(3);
                    byte by = wl2.g((byte)-107);
                    this.y[i] = -1 != ~by ? jb.a(by, (byte)88) : (char)0;
                }
            }
        } else {
            this.H = wl2.c((byte)-38);
        }
        n3 = 8 % ((2 - n2) / 44);
    }

    final void c(int n) {
        int n2;
        boolean bl = client.A;
        if (n != -1) {
            return;
        }
        if (this.E != null) {
            for (n2 = 0; n2 < this.E.length; ++n2) {
                this.E[n2] = de.b(this.E[n2], 32768);
            }
        }
        if (this.C != null) {
            int n3;
            n2 = n3 = 0;
            while (~n3 > ~this.C.length) {
                this.C[n3] = de.b(this.C[n3], 32768);
                ++n3;
            }
        }
    }

    ac() {
    }
}
