/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.alterorb.launcher.Hook
 */
import java.io.File;
import java.util.Hashtable;
import net.alterorb.launcher.Hook;

public class od {
    private static int od_d;
    private static String od_c;
    private static Hashtable od_b;
    private static boolean od_e;
    private static String od_a;

    private od() throws Throwable {
        throw new Error();
    }

    public static File a(int n, String string) {
        block0: {
            if (n == 0) break block0;
            od_c = null;
        }
        return od.a(od_c, 30869, string, od_d);
    }

    public static File a(String string, int n, String string2, int n2) {
        return Hook.cacheRedirect((String)string, (String)string2);
    }

    public static void a(int n, String string, int n2) {
        block4: {
            od_c = string;
            od_d = n;
            try {
                od_a = System.getProperty("user.home");
                if (null != od_a) {
                    od_a = od_a + "/";
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            od_e = true;
            if (n2 != 7154) {
                return;
            }
            if (null != od_a) break block4;
            od_a = "~/";
        }
    }

    static {
        od_e = false;
        od_b = new Hashtable(16);
    }
}
