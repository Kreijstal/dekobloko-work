/*
 * Decompiled with CFR 0.152.
 */
final class hj {
    private static float hj_c;
    private int[][][] hj_b = new int[2][2][4];
    private int[] hj_f = new int[2];
    private int[][][] hj_e = new int[2][2][4];
    static int hj_d;
    int[] hj_g = new int[2];
    private static float[][] hj_h;
    static int[][] hj_a;

    private final float b(int n, int n2, float f) {
        float f2 = (float)this.hj_b[n][0][n2] + f * (float)(this.hj_b[n][1][n2] - this.hj_b[n][0][n2]);
        return 1.0f - (float)Math.pow(10.0, -(f2 *= 0.0015258789f) / 20.0f);
    }

    final void a(wl wl2, sd sd2) {
        int n = wl2.d((byte)-53);
        this.hj_g[0] = n >> 4;
        this.hj_g[1] = n & 0xF;
        if (n != 0) {
            int n2;
            int n3;
            this.hj_f[0] = wl2.e(3);
            this.hj_f[1] = wl2.e(3);
            int n4 = wl2.d((byte)-21);
            for (n3 = 0; n3 < 2; ++n3) {
                for (n2 = 0; n2 < this.hj_g[n3]; ++n2) {
                    this.hj_e[n3][0][n2] = wl2.e(3);
                    this.hj_b[n3][0][n2] = wl2.e(3);
                }
            }
            for (n3 = 0; n3 < 2; ++n3) {
                int n5;
                n2 = n5 = 0;
                while (n5 < this.hj_g[n3]) {
                    if ((n4 & 1 << n3 * 4 << n5) != 0) {
                        this.hj_e[n3][1][n5] = wl2.e(3);
                        this.hj_b[n3][1][n5] = wl2.e(3);
                    } else {
                        this.hj_e[n3][1][n5] = this.hj_e[n3][0][n5];
                        this.hj_b[n3][1][n5] = this.hj_b[n3][0][n5];
                    }
                    ++n5;
                }
            }
            if (n4 != 0 || this.hj_f[1] != this.hj_f[0]) {
                sd2.a(wl2);
            }
        } else {
            int[] nArray = this.hj_f;
            this.hj_f[1] = 0;
            nArray[0] = 0;
        }
    }

    final int a(int n, float f) {
        int n2;
        float f2;
        if (n == 0) {
            f2 = (float)this.hj_f[0] + (float)(this.hj_f[1] - this.hj_f[0]) * f;
            hj_c = (float)Math.pow(0.1, (f2 *= 0.0030517578f) / 20.0f);
            hj_d = (int)(hj_c * 65536.0f);
        }
        if (this.hj_g[n] == 0) {
            return 0;
        }
        f2 = this.b(n, 0, f);
        hj.hj_h[n][0] = -2.0f * f2 * (float)Math.cos(this.a(n, 0, f));
        hj.hj_h[n][1] = f2 * f2;
        for (n2 = 1; n2 < this.hj_g[n]; ++n2) {
            f2 = this.b(n, n2, f);
            float f3 = -2.0f * f2 * (float)Math.cos(this.a(n, n2, f));
            float f4 = f2 * f2;
            hj.hj_h[n][n2 * 2 + 1] = hj_h[n][n2 * 2 - 1] * f4;
            hj.hj_h[n][n2 * 2] = hj_h[n][n2 * 2 - 1] * f3 + hj_h[n][n2 * 2 - 2] * f4;
            for (int i = n2 * 2 - 1; i >= 2; --i) {
                float[] fArray = hj_h[n];
                int n3 = i;
                fArray[n3] = fArray[n3] + (hj_h[n][i - 1] * f3 + hj_h[n][i - 2] * f4);
            }
            float[] fArray = hj_h[n];
            fArray[1] = fArray[1] + (hj_h[n][0] * f3 + f4);
            float[] fArray2 = hj_h[n];
            fArray2[0] = fArray2[0] + f3;
        }
        if (n == 0) {
            n2 = 0;
            while (n2 < this.hj_g[0] * 2) {
                float[] fArray = hj_h[0];
                int n4 = n2++;
                fArray[n4] = fArray[n4] * hj_c;
            }
        }
        for (n2 = 0; n2 < this.hj_g[n] * 2; ++n2) {
            hj.hj_a[n][n2] = (int)(hj_h[n][n2] * 65536.0f);
        }
        return this.hj_g[n] * 2;
    }

    private static final float a(float f) {
        float f2 = 32.703197f * (float)Math.pow(2.0, f);
        return f2 * (float)Math.PI / 11025.0f;
    }

    public static void a() {
        hj_h = null;
        hj_a = null;
    }

    private final float a(int n, int n2, float f) {
        float f2 = (float)this.hj_e[n][0][n2] + f * (float)(this.hj_e[n][1][n2] - this.hj_e[n][0][n2]);
        return hj.a(f2 *= 1.2207031E-4f);
    }

    hj() {
    }

    static {
        hj_h = new float[2][8];
        hj_a = new int[2][8];
    }
}
