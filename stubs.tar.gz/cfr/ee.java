/*
 * Decompiled with CFR 0.152.
 */
final class ee {
    static w ee_i;
    private int[] ee_f = new int[256];
    static ui[] ee_a;
    private int ee_c;
    static ud ee_g;
    private int ee_j;
    private int ee_e;
    private int ee_h;
    static int[] ee_b;
    private int[] ee_d = new int[256];

    public static void a(byte by) {
        block0: {
            ee_b = null;
            ee_g = null;
            ee_a = null;
            ee_i = null;
            if (by == -78) break block0;
            ee_a = null;
        }
    }

    final int a(boolean bl) {
        if (0 == this.ee_e) {
            this.b(-1);
            this.ee_e = 256;
        }
        if (bl) {
            return 55;
        }
        return this.ee_d[--this.ee_e];
    }

    private final void b(int n) {
        boolean bl = client.A;
        if (n != -1) {
            this.ee_f = null;
        }
        this.ee_j += ++this.ee_h;
        for (int i = 0; 256 > i; ++i) {
            int n2;
            int n3 = this.ee_f[i];
            this.ee_c = 0 != (i & 2) ? (~(i & 1) != -1 ? (this.ee_c ^= this.ee_c >>> 29915184) : (this.ee_c ^= this.ee_c << -1034970558)) : ((i & 1) == 0 ? (this.ee_c ^= this.ee_c << 499832653) : (this.ee_c ^= this.ee_c >>> 1482730214));
            this.ee_c += this.ee_f[128 + i & 0xFF];
            this.ee_f[i] = n2 = this.ee_j + this.ee_c + this.ee_f[lb.a(1020, n3) >> 346011810];
            this.ee_d[i] = this.ee_j = n3 + this.ee_f[lb.a(255, n2 >> 1542245672 >> 212130562)];
        }
    }

    final int a(int n, int n2) {
        int n3;
        if (0 >= n2) {
            throw new IllegalArgumentException();
        }
        int n4 = -((int)(0x100000000L % (long)n2)) + Integer.MAX_VALUE;
        if (n < 71) {
            ee_a = null;
        }
        while ((n3 = this.a(false)) > n4) {
        }
        return oi.a(n2, 83, n3);
    }

    private final void a(int n) {
        int n2;
        boolean bl = client.A;
        int n3 = -1640531527;
        int n4 = -1640531527;
        int n5 = -1640531527;
        int n6 = -1640531527;
        if (n != 0x7FFFFF) {
            this.ee_j = -27;
        }
        int n7 = -1640531527;
        int n8 = -1640531527;
        int n9 = -1640531527;
        int n10 = -1640531527;
        for (n2 = 0; 4 > n2; ++n2) {
            n8 ^= n5 << 182743371;
            n5 += n6;
            n4 += (n5 ^= n6 >>> -623949854);
            n6 += (n3 += n8);
            n9 += (n6 ^= n3 << -1392054424);
            n3 += n4;
            n10 += (n3 ^= n4 >>> 475147376);
            n4 += n9;
            n7 += (n4 ^= n9 << 1588146762);
            n9 += n10;
            n8 += (n9 ^= n10 >>> 1290212708);
            n10 += n7;
            n5 += (n10 ^= n7 << -996545496);
            n7 += n8;
            n6 += (n7 ^= n8 >>> -1633094391);
            n8 += n5;
        }
        for (n2 = 0; n2 < 256; n2 += 8) {
            n7 += this.ee_d[7 + n2];
            n3 += this.ee_d[3 + n2];
            n10 += this.ee_d[6 + n2];
            n4 += this.ee_d[4 + n2];
            n9 += this.ee_d[5 + n2];
            n8 += this.ee_d[n2];
            n5 += (n6 += this.ee_d[2 + n2]);
            n4 += (n5 ^= n6 >>> -125735902);
            n6 += (n3 += (n8 ^= (n5 += this.ee_d[n2 - -1]) << -816264853));
            n6 ^= n3 << -938954040;
            n3 += n4;
            n10 += (n3 ^= n4 >>> -922820208);
            n4 += (n9 += n6);
            n7 += (n4 ^= n9 << -1991636022);
            n9 += n10;
            n8 += (n9 ^= n10 >>> 1365830244);
            n10 += n7;
            n5 += (n10 ^= n7 << -1429514072);
            n7 += n8;
            n7 ^= n8 >>> -1116988567;
            this.ee_f[n2] = n8 += n5;
            this.ee_f[n2 + 1] = n5;
            this.ee_f[n2 + 2] = n6 += n7;
            this.ee_f[3 + n2] = n3;
            this.ee_f[4 + n2] = n4;
            this.ee_f[5 + n2] = n9;
            this.ee_f[n2 - -6] = n10;
            this.ee_f[n2 - -7] = n7;
        }
        for (n2 = 0; n2 < 256; n2 += 8) {
            n7 += this.ee_f[n2 + 7];
            n3 += this.ee_f[3 + n2];
            n8 += this.ee_f[n2];
            n9 += this.ee_f[5 + n2];
            n10 += this.ee_f[6 + n2];
            n4 += this.ee_f[4 + n2];
            n5 += (n6 += this.ee_f[n2 + 2]);
            n4 += (n5 ^= n6 >>> 1651212194);
            n6 += (n3 += (n8 ^= (n5 += this.ee_f[1 + n2]) << 641295979));
            n6 ^= n3 << -366006168;
            n3 += n4;
            n3 ^= n4 >>> -191059248;
            n4 += (n9 += n6);
            n7 += (n4 ^= n9 << -587601654);
            n9 += (n10 += n3);
            n9 ^= n10 >>> -469009724;
            n10 += n7;
            n10 ^= n7 << 1547957672;
            n7 += (n8 += n9);
            n7 ^= n8 >>> -1641952215;
            this.ee_f[n2] = n8 += (n5 += n10);
            this.ee_f[1 + n2] = n5;
            this.ee_f[n2 + 2] = n6 += n7;
            this.ee_f[3 + n2] = n3;
            this.ee_f[n2 - -4] = n4;
            this.ee_f[5 + n2] = n9;
            this.ee_f[6 + n2] = n10;
            this.ee_f[7 + n2] = n7;
        }
        this.b(-1);
        this.ee_e = 256;
    }

    static final boolean a(byte by, boolean bl, int n, int n2) {
        int n3;
        int n4;
        if (!bl) {
            if (cc.cc_h[n2] < cc.cc_h[n]) {
                return true;
            }
            if (cc.cc_h[n2] > cc.cc_h[n]) {
                return false;
            }
            if (ad.ad_i[n2] < ad.ad_i[n]) {
                return true;
            }
            if (ad.ad_i[n2] > ad.ad_i[n]) {
                return false;
            }
        } else {
            if (~ad.ad_i[n2] > ~ad.ad_i[n]) {
                return true;
            }
            if (~ad.ad_i[n] > ~ad.ad_i[n2]) {
                return false;
            }
            if (cc.cc_h[n2] < cc.cc_h[n]) {
                return true;
            }
            if (~cc.cc_h[n2] < ~cc.cc_h[n]) {
                return false;
            }
        }
        if (~(n4 = mk.mk_b[n] + ln.ln_a[n] + oa.oa_e[n]) < ~(n3 = ln.ln_a[n2] + (oa.oa_e[n2] - -mk.mk_b[n2]))) {
            return true;
        }
        if (~n3 < ~n4) {
            return false;
        }
        if (by <= 97) {
            return false;
        }
        return ~n2 > ~n;
    }

    ee(int[] nArray) {
        int n = 0;
        while (~n > ~nArray.length) {
            this.ee_d[n] = nArray[n];
            ++n;
        }
        this.a(0x7FFFFF);
    }

    static {
        ee_a = new ui[4];
        ee_b = new int[]{0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, Short.MAX_VALUE, 65535, 131071, 262143, 524287, 1048575, 0x1FFFFF, 0x3FFFFF, 0x7FFFFF, 0xFFFFFF, 0x1FFFFFF, 0x3FFFFFF, 0x7FFFFFF, 0xFFFFFFF, 0x1FFFFFFF, 0x3FFFFFFF, Integer.MAX_VALUE, -1};
    }
}
