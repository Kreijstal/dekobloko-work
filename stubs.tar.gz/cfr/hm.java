/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;

abstract class hm {
    static mi hm_c;
    static ud hm_d;
    static jc hm_a;
    static w hm_b;
    static int[][] hm_e;

    abstract int a(int var1);

    static final void a(nf nf2, mm mm2, int n, String string, int n2) {
        boolean bl = client.A;
        int n3 = 0;
        int n4 = n2;
        int n5 = 1;
        while (~string.length() < ~n5) {
            char c = string.charAt(n5);
            if (c == '<') {
                n4 = nf2.nf_a[0] + ((n3 >> 1028880040) - -mm2.a(string.substring(0, n5)));
            }
            if (-1 == n4) {
                if (' ' == c) {
                    n3 += n;
                }
                nf2.nf_a[n5] = (n3 >> 685930120) - -nf2.nf_a[0] - (-mm2.a(string.substring(0, n5 + 1)) + mm2.a(c));
            } else {
                nf2.nf_a[n5] = n4;
            }
            if (c == '>') {
                n4 = -1;
            }
            ++n5;
        }
    }

    public static void b(int n) {
        hm_c = null;
        hm_d = null;
        hm_b = null;
        int n2 = -36 / ((n - -11) / 52);
        hm_a = null;
        hm_e = null;
    }

    abstract void a(int var1, Component var2);

    static final void a(int n, byte by) {
        if (by >= -101) {
            return;
        }
        ai.P = n;
    }

    static final fm a(boolean bl, String string, String string2, int n) {
        if (n != 9507) {
            hm_d = null;
        }
        long l = 0L;
        String string3 = null;
        if (string2.indexOf(64) == -1) {
            l = ab.a(121, string2);
        } else {
            string3 = string2;
        }
        return sb.a(l, string, bl, string3, 0);
    }

    hm() {
    }

    abstract void a(Component var1, int var2);

    static final void a(int n, boolean bl) {
        if (null != sl.sl_g) {
            qd.a(sl.sl_g, -2);
        }
        if (w.H != null) {
            w.H.a((byte)39, bl);
        }
        r.a(bl, 4028);
        if (n != -1) {
            hm_d = null;
        }
        if (null != pd.pd_f) {
            pd.pd_f.a(1141039778, bl);
        }
        lg.a(bl, -123);
    }

    static {
        hm_a = new jc();
        hm_e = null;
    }
}
