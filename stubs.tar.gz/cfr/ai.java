/*
 * Decompiled with CFR 0.152.
 */
final class ai
extends ek {
    int O;
    static byte[] N;
    static String T;
    int R;
    static int P;
    int K;
    static String L;
    static String M;
    int S;
    int V;
    static String U;
    int Q;

    @Override
    final boolean a(int n, int n2, ce ce2, int n3, int n4, int n5, byte by) {
        boolean bl = client.A;
        if (!super.a(n, n2, ce2, n3, n4, n5, by)) {
            return false;
        }
        int n6 = -this.O - (n5 - -this.ce_u) + n2;
        int n7 = n - this.V - (n4 - -this.D);
        if (~(n6 * n6 + n7 * n7) > ~(this.K * this.K)) {
            double d = Math.atan2(n7, n6) - hc.hc_b;
            if (0.0 > d) {
                d -= Math.PI / (double)this.Q;
            } else if (0.0 < d) {
                d += Math.PI / (double)this.Q;
            }
            this.R = (int)((double)this.Q * d / (Math.PI * 2));
            while (~this.Q >= ~this.R) {
                this.R -= this.Q;
            }
            while (this.R < 0) {
                this.R += this.Q;
            }
        }
        return true;
    }

    public static void a(int n) {
        if (n > -7) {
            ai.e((byte)-48);
        }
        M = null;
        N = null;
        L = null;
        T = null;
        U = null;
    }

    static final void a(int n, int n2, ud ud2, int n3, int n4) {
        if (n <= 56) {
            P = -82;
        }
        int n5 = (int)(0.5 + (double)(ud2.ud_p * 256) * Math.pow(2.0, (double)n2 * 0.08333333333333333) / (double)en.en_o);
        dg.dg_c.a(ud2, n5, n4 * pb.pb_d, n3 << 911025766);
    }

    static final void e(byte by) {
        int n;
        boolean bl;
        ck ck2;
        boolean bl2;
        ck ck3;
        if (db.db_d) {
            ck3 = hh.hh_a;
            bl2 = wg.wg_f;
            ck2 = ue.ue_b;
            bl = qd.Nb;
            n = 320 + -(vf.vf_b * vf.vf_b * 320 / 900);
        } else {
            ck3 = ue.ue_b;
            n = 320 * (vf.vf_b * vf.vf_b) / 900;
            bl2 = qd.Nb;
            bl = wg.wg_f;
            ck2 = hh.hh_a;
        }
        if (bl && bl2) {
            bl2 = false;
            bl = false;
        }
        hk.b(0, 0, 640, 160 + -n);
        int n2 = 128 * n / 320 + 128;
        dl.a((byte)93, bl2, ck2, -n, 256);
        hk.b(0, 160 - n, 213, 320 - n);
        dl.a((byte)123, bl2, ck2, -n, 256);
        hk.b(427, 160 - n, 640, 320 + -n);
        dl.a((byte)121, bl2, ck2, -n, 256);
        hk.b(0, -n + 320, 213, 320 + n);
        dl.a((byte)92, bl, ck3, 0, n2);
        hk.b(213, 160 - n, 427, n + 160);
        dl.a((byte)91, bl, ck3, 0, n2);
        hk.b(427, 320 - n, 640, 320 + n);
        dl.a((byte)91, bl, ck3, 0, n2);
        if (by != 84) {
            U = null;
        }
        hk.b(213, 160 + n, 427, 320 - -n);
        dl.a((byte)43, bl2, ck2, n, 256);
        hk.b(0, n + 320, 640, 480);
        dl.a((byte)121, bl2, ck2, n, 256);
        hk.d();
    }

    static final boolean f(byte by) {
        int n = -28 % ((by - -57) / 39);
        return fj.fj_e;
    }

    static final void h(int n) {
        block0: {
            qf.a(te.te_q, -128, null);
            if (n < -6) break block0;
            ud ud2 = null;
            ai.a(-10, 44, ud2, 29, -93);
        }
    }

    private ai() throws Throwable {
        throw new Error();
    }

    static final cl a(int n, int n2, byte by, int n3) {
        cl cl2;
        boolean bl = client.A;
        cl cl3 = cl2 = (cl)oe.I.c((byte)19);
        while (null != cl2) {
            if (n3 == cl2.cl_q) {
                return cl2;
            }
            cl3 = (cl)oe.I.d(true);
        }
        if (by != -111) {
            M = null;
        }
        cl3 = new cl();
        cl3.z = n2;
        cl3.cl_q = n3;
        oe.I.a(cl3, by + 2888);
        fh.a((byte)8, cl3, n);
        return cl3;
    }

    static {
        T = "This option cannot be combined with the current '<%0>' setting.";
        P = -1;
        M = "Send private message to <%0>";
        L = "Only show game chat from my friends";
        U = "Play free version";
    }
}
