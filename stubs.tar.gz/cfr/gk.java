/*
 * Decompiled with CFR 0.152.
 */
class gk
extends ca
implements vn {
    static String Db = "Options";
    static boolean Ib;
    private boolean Fb;
    private boolean Ab;
    private mm Bb;
    private r xb;
    static byte[][] yb;
    static int[] Cb;
    static w Hb;
    static String Gb;
    private boolean Eb;
    private boolean zb;

    final void n(int n) {
        block2: {
            block1: {
                if (!this.S) {
                    return;
                }
                this.S = false;
                int n2 = 6 % ((-68 - n) / 51);
                if (this.Ab) break block1;
                if (!this.Eb) break block2;
                ai.h(-73);
                break block2;
            }
            qf.a(true);
        }
    }

    final void o(int n) {
        this.xb.a(n, 4088, 2121792);
        dj dj2 = new dj(this, this.Bb, fm.fm_a);
        dj2.a(mn.mn_a, 15, n ^ 0x40404E);
        this.c(dj2, (byte)51);
    }

    static final int c(int n, int n2, int n3) {
        if (n2 == n3 && ll.a(n, (byte)-96)) {
            return 29;
        }
        return fc.fc_b[n3];
    }

    gk(ka ka2, mm mm2, String string, boolean bl2, boolean bl3) {
        super(ka2, new dj(null, mm2, string), 77, 10, 10);
        this.Bb = mm2;
        this.Ab = bl2;
        this.zb = false;
        this.Fb = false;
        this.Eb = bl3;
        this.xb = new r(13, 50, 274, 30, 15, 2113632, 0x404040);
        this.xb.L = true;
        this.b(this.xb, (byte)-55);
    }

    static final void a(w w2, boolean bl2) {
        w w3;
        boolean bl3 = client.A;
        w w4 = w3 = (w)w2.M.c((byte)-76);
        while (null != w3) {
            w3.Ib = 0;
            w3.Mb = 0;
            w3.F = 0;
            w3.N = 0;
            w4 = (w)w2.M.d(true);
        }
        if (!bl2) {
            yb = null;
        }
        w2.Mb = 0;
        w2.Ib = 0;
        w2.F = 0;
        w2.N = 0;
    }

    final void a(byte by, String string, int n) {
        boolean bl2 = client.A;
        if (by != 48) {
            return;
        }
        if (this.Fb) {
            return;
        }
        this.zb = 256 == n;
        this.Fb = true;
        this.xb.a(0x404040, 4088, 8405024);
        dj dj2 = new dj(this, this.Bb, string);
        if (-6 == ~n) {
            dj2.a(pb.pb_e, 11, 14);
            dj2.a(ig.Tb, 17, by ^ 0x3E);
        } else if (-257 == ~n) {
            dj2.a(116, sh.sh_c, this);
        } else {
            dj2.a(this.Ab ? sh.sh_c : bl.X, -1, 14);
        }
        if (3 == n) {
            dj2.a(ce.z, 7, 14);
        } else if (~n == -5) {
            dj2.a(ai.U, 8, 14);
        } else if (6 == n) {
            dj2.a(vb.Y, 9, 14);
        } else if (-10 == ~n) {
            dj2.a(127, pc.pc_e, this);
        }
        this.c(dj2, (byte)84);
    }

    static final void a(int n, int n2, byte by, cc cc2) {
        int n3 = -111 % ((by - 41) / 38);
    }

    @Override
    final boolean a(int n, int n2, ce ce2, char c) {
        if (n2 == 13) {
            this.n(63);
            return true;
        }
        int n3 = -15 / ((n - -22) / 49);
        return super.a(123, n2, ce2, c);
    }

    @Override
    public void a(byte by, int n, ek ek2, int n2, int n3) {
        if (by != 67) {
            this.Eb = true;
        }
        if (this.zb) {
            hm.a(3, (byte)-124);
            this.n(-9);
        } else {
            aj.a("tochangedisplayname.ws", by ^ 0xFFFFFFB1, se.h(by ^ 0x627B));
        }
    }

    public static void p(int n) {
        Gb = null;
        yb = null;
        int n2 = 107 % ((-66 - n) / 34);
        Db = null;
        Cb = null;
        Hb = null;
    }

    static {
        yb = new byte[50][];
        Cb = new int[4];
        Gb = "Quick Chat Help";
    }
}
