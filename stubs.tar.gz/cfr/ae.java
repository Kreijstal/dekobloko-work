/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.ms.awt.WComponentPeer
 *  com.ms.dll.Callback
 *  com.ms.dll.Root
 *  com.ms.win32.User32
 */
import com.ms.awt.WComponentPeer;
import com.ms.dll.Callback;
import com.ms.dll.Root;
import com.ms.win32.User32;
import java.awt.Component;

final class ae
extends Callback {
    private volatile int ae_a;
    private volatile int ae_e;
    private boolean ae_c;
    private int ae_d;
    private volatile boolean ae_b = true;

    final synchronized int callback(int n, int n2, int n3, int n4) {
        block3: {
            int n5;
            if (this.ae_e != n) {
                int n6 = User32.GetWindowLong((int)n, (int)-4);
                return User32.CallWindowProc((int)n6, (int)n, (int)n2, (int)n3, (int)n4);
            }
            if (32 == n2 && 1 == (n5 = n4 & 0xFFFF)) {
                User32.SetCursor((int)(!this.ae_b ? 0 : this.ae_d));
                return 0;
            }
            if (~n2 == -101025) {
                User32.SetCursor((int)(this.ae_b ? this.ae_d : 0));
                return 0;
            }
            if (-2 != ~n2) break block3;
            this.ae_e = 0;
            this.ae_b = true;
        }
        return User32.CallWindowProc((int)this.ae_a, (int)n, (int)n2, (int)n3, (int)n4);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final void a(boolean bl, Component component, byte by) {
        WComponentPeer wComponentPeer = (WComponentPeer)component.getPeer();
        int n = wComponentPeer.getTopHwnd();
        if (~n == ~this.ae_e && this.ae_b != !bl) {
            return;
        }
        if (!this.ae_c) {
            this.ae_d = User32.LoadCursor((int)0, (int)32512);
            Root.alloc((Object)((Object)this));
            this.ae_c = true;
        }
        if (~n != ~this.ae_e) {
            ae ae2;
            if (0 != this.ae_e) {
                this.ae_b = true;
                User32.SendMessage((int)n, (int)101024, (int)0, (int)0);
                ae2 = this;
                synchronized (ae2) {
                    User32.SetWindowLong((int)this.ae_e, (int)-4, (int)this.ae_a);
                }
            }
            ae2 = this;
            synchronized (ae2) {
                this.ae_e = n;
                this.ae_a = User32.SetWindowLong((int)this.ae_e, (int)-4, (Object)((Object)this));
            }
        }
        this.ae_b = bl;
        int n2 = 126 / ((28 - by) / 47);
        User32.SendMessage((int)n, (int)101024, (int)0, (int)0);
    }

    final void a(int n, int n2, byte by) {
        block0: {
            User32.SetCursorPos((int)n, (int)n2);
            if (by == -98) break block0;
            Component component = null;
            this.a(false, component, (byte)-80);
        }
    }

    ae() {
    }
}
