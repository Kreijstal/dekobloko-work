/*
 * Decompiled with CFR 0.152.
 */
final class un {
    static String un_c;
    static String un_b;
    static String un_a;

    static final void a(byte by) {
        kf.I = null;
        int n = -59 / ((-91 - by) / 32);
        ce.C = null;
    }

    static final cd a(int n, String string, int n2) {
        cd cd2 = new cd(false);
        cd2.cd_f = string;
        int n3 = -78 % ((n2 - 59) / 32);
        cd2.cd_h = n;
        return cd2;
    }

    static final char a(int n, char c) {
        block12: {
            block11: {
                block10: {
                    block9: {
                        block8: {
                            block7: {
                                block6: {
                                    block5: {
                                        block4: {
                                            block3: {
                                                block2: {
                                                    block1: {
                                                        boolean bl = client.A;
                                                        if (n != 228) {
                                                            return 'N';
                                                        }
                                                        char c2 = c;
                                                        if (~c2 == -33 || c2 == '\u00a0' || -96 == ~c2 || -46 == ~c2) break block1;
                                                        if (c2 == '[' || -94 == ~c2 || '#' == c2) break block2;
                                                        if (c2 == '\u00e0' || ~c2 == -226 || '\u00e2' == c2 || '\u00e4' == c2 || -228 == ~c2 || ~c2 == -193 || -194 == ~c2 || c2 == '\u00c2' || -197 == ~c2 || '\u00c3' == c2) break block3;
                                                        if (-233 == ~c2 || -234 == ~c2 || c2 == '\u00ea' || -236 == ~c2 || '\u00c8' == c2 || c2 == '\u00c9' || c2 == '\u00ca' || ~c2 == -204) break block4;
                                                        if (c2 == '\u00ed' || ~c2 == -239 || ~c2 == -240 || '\u00cd' == c2 || c2 == '\u00ce' || -208 == ~c2) break block5;
                                                        if (-243 == ~c2 || '\u00f3' == c2 || ~c2 == -245 || ~c2 == -247 || '\u00f5' == c2 || -211 == ~c2 || ~c2 == -212 || c2 == '\u00d4' || -215 == ~c2 || '\u00d5' == c2) break block6;
                                                        if ('\u00f9' == c2 || -251 == ~c2 || -252 == ~c2 || '\u00fc' == c2 || '\u00d9' == c2 || -219 == ~c2 || '\u00db' == c2 || ~c2 == -221) break block7;
                                                        if ('\u00e7' == c2 || c2 == '\u00c7') break block8;
                                                        if (-256 == ~c2 || -377 == ~c2) break block9;
                                                        if (~c2 == -242 || '\u00d1' == c2) break block10;
                                                        if (c2 == '\u00df') break block11;
                                                        break block12;
                                                    }
                                                    return '_';
                                                }
                                                return c;
                                            }
                                            return 'a';
                                        }
                                        return 'e';
                                    }
                                    return 'i';
                                }
                                return 'o';
                            }
                            return 'u';
                        }
                        return 'c';
                    }
                    return 'y';
                }
                return 'n';
            }
            return 'b';
        }
        return Character.toLowerCase(c);
    }

    static final String a(byte[] byArray, int n, int n2, int n3) {
        char[] cArray;
        boolean bl = client.A;
        char[] cArray2 = cArray = new char[n3];
        int n4 = 0;
        int n5 = n;
        while (~n5 > ~n3) {
            int n6 = byArray[n5 + n2] & 0xFF;
            if (0 != n6) {
                if (-129 >= ~n6 && ~n6 > -161) {
                    int n7 = nh.nh_l[-128 + n6];
                    if (0 == n7) {
                        n7 = 63;
                    }
                    n6 = n7;
                }
                cArray[n4++] = (char)n6;
            }
            ++n5;
        }
        return new String(cArray, 0, n4);
    }

    static final boolean a(int n, int n2, int n3, byte by) {
        if (by != 52) {
            un_a = null;
        }
        if (0 > n2 || n2 > 11) {
            return false;
        }
        return ~n3 <= -2 && n3 <= gk.c(n, 1, n2);
    }

    static final vg a(int n, uf uf2) {
        vg vg2;
        block9: {
            boolean bl2 = client.A;
            int n2 = uf2.a(8, (byte)87);
            if (~n2 < -1) {
                throw new IllegalStateException("" + n2);
            }
            boolean bl3 = wg.a(uf2, (byte)-127);
            if (n != -128) {
                uf uf3 = null;
                un.a(36, uf3);
            }
            boolean bl4 = wg.a(uf2, (byte)-112);
            vg2 = new vg();
            vg2.vg_l = (short)uf2.a(16, (byte)103);
            vg2.J = v.a(uf2, true, vg2.J, 16);
            vg2.vg_o = v.a(uf2, true, vg2.vg_o, 16);
            vg2.vg_e = v.a(uf2, true, vg2.vg_e, 16);
            vg2.L = (short)uf2.a(16, (byte)55);
            vg2.M = v.a(uf2, true, vg2.M, 16);
            vg2.vg_c = v.a(uf2, true, vg2.vg_c, 16);
            vg2.A = v.a(uf2, true, vg2.A, 16);
            if (bl3) {
                vg2.D = (short)uf2.a(16, (byte)90);
                vg2.vg_k = v.a(uf2, true, vg2.vg_k, 16);
                vg2.vg_u = v.a(uf2, true, vg2.vg_u, 16);
                vg2.O = v.a(uf2, true, vg2.O, 16);
                vg2.F = v.a(uf2, true, vg2.F, 16);
                vg2.vg_t = v.a(uf2, true, vg2.vg_t, 16);
                vg2.vg_r = v.a(uf2, true, vg2.vg_r, 16);
            }
            if (bl4) {
                uf2.a(16, (byte)125);
                vg2.y = v.a(uf2, true, vg2.y, 16);
                vg2.z = v.a(uf2, true, vg2.z, 16);
                vg2.C = v.a(uf2, true, vg2.C, 16);
                vg2.N = v.a(uf2, true, vg2.N, 16);
                vg2.P = v.a(uf2, true, vg2.P, 16);
            }
            if (wg.a(uf2, (byte)-123)) {
                vg2.vg_j = v.a(uf2, true, vg2.vg_j, 16);
            }
            if (!wg.a(uf2, (byte)-115)) break block9;
            vg2.Q = he.a((byte)5, vg2.Q, 16, uf2);
            int n3 = 0;
            int n4 = 0;
            while (~vg2.Q.length < ~n4) {
                if (n3 < (vg2.Q[n4] & 0xFF)) {
                    n3 = vg2.Q[n4] & 0xFF;
                }
                ++n4;
            }
            if (~n3 == -1) {
                vg2.Q = null;
            } else {
                vg2.B = (byte)(n3 + 1);
            }
        }
        return vg2;
    }

    public static void b(byte by) {
        un_c = null;
        if (by < 84) {
            return;
        }
        un_a = null;
        un_b = null;
    }

    static {
        un_b = "Names cannot contain consecutive spaces";
        un_a = "Loading fonts";
        un_c = "Kick <%0> from this game";
    }
}
