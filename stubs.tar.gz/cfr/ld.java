/*
 * Decompiled with CFR 0.152.
 */
final class ld
extends ck {
    private static final void d(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11) {
        int n12 = n2;
        for (int i = -n7; i < 0; ++i) {
            int n13 = (n3 >> 16) * n10;
            for (int j = -n6; j < 0; ++j) {
                n = nArray2[(n2 >> 16) + n13];
                int n14 = n >>> 24;
                if (n14 != 0) {
                    int n15 = nArray[n4];
                    int n16 = 256 - n14;
                    int n17 = (n & 0xFF00FF) * n11 & 0xFF00FF00;
                    int n18 = (n & 0xFF00) * n11 & 0xFF0000;
                    n = (n17 | n18) >>> 8;
                    nArray[n4++] = ((n & 0xFF00FF) * n14 + (n15 & 0xFF00FF) * n16 & 0xFF00FF00) + ((n & 0xFF00) * n14 + (n15 & 0xFF00) * n16 & 0xFF0000) >>> 8;
                } else {
                    ++n4;
                }
                n2 += n8;
            }
            n3 += n9;
            n2 = n12;
            n4 += n5;
        }
    }

    private static final void e(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11) {
        int n12 = n2;
        for (int i = -n7; i < 0; ++i) {
            int n13 = (n3 >> 16) * n10;
            for (int j = -n6; j < 0; ++j) {
                int n14 = nArray2[(n2 >> 16) + n13];
                int n15 = nArray[n4];
                int n16 = (n14 >>> 24) * n11 >> 8;
                int n17 = 256 - n16;
                nArray[n4++] = ((n14 & 0xFF00FF) * n16 + (n15 & 0xFF00FF) * n17 & 0xFF00FF00) + ((n14 & 0xFF00) * n16 + (n15 & 0xFF00) * n17 & 0xFF0000) >>> 8;
                n2 += n8;
            }
            n3 += n9;
            n2 = n12;
            n4 += n5;
        }
    }

    private static final void d(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
        int n11 = n10 & 0xFF00FF;
        int n12 = n10 >> 8 & 0xFF;
        for (n5 = -n7; n5 < 0; ++n5) {
            for (n4 = -n6; n4 < 0; ++n4) {
                n = nArray2[n2++];
                int n13 = n >>> 24;
                n &= 0xFFFFFF;
                if (n13 != 0) {
                    int n14 = 0;
                    n14 = n >> 8 == (n & 0xFFFF) ? ((n &= 0xFF) * n11 >> 8 & 0xFF00FE) + (n * n12 & 0xFF00) + 1 : n;
                    int n15 = 256 - n13;
                    int n16 = nArray[n3];
                    nArray[n3++] = ((n14 & 0xFF00FF) * n13 + (n16 & 0xFF00FF) * n15 & 0xFF00FF00) + ((n14 & 0xFF00) * n13 + (n16 & 0xFF00) * n15 & 0xFF0000) >>> 8;
                    continue;
                }
                ++n3;
            }
            n3 += n8;
            n2 += n9;
        }
    }

    @Override
    final void d(int n, int n2) {
        int n3 = this.I >> 1;
        int n4 = this.H >> 1;
        int n5 = (n += this.F / 2) < hk.hk_c ? hk.hk_c - n << 1 : 0;
        int n6 = n + n3 > hk.hk_g ? (hk.hk_g - n << 1) - 2 : this.I - 2;
        int n7 = n2 < hk.hk_h ? hk.hk_h - (n2 += this.z / 2) << 1 : 0;
        int n8 = n2 + n4 > hk.hk_b ? (hk.hk_b - n2 << 1) - 2 : this.H - 2;
        for (int i = n7; i <= n8; i += 2) {
            int n9 = i * this.I + n5;
            int n10 = (n2 + (i >> 1)) * hk.hk_j + (n + (n5 >> 1));
            int n11 = n5;
            while (n11 <= n6) {
                int n12;
                int n13 = 0;
                int n14 = 0;
                int n15 = 0;
                int n16 = 0;
                int n17 = 0;
                int n18 = 0;
                for (n12 = 0; n12 < 4; ++n12) {
                    n13 = this.D[n9 + (n12 & 1) + ((n12 & 2) == 0 ? this.I : 0)];
                    n14 = n13 >>> 24;
                    n18 += n14;
                    n15 += n14 * (n13 >> 16 & 0xFF);
                    n16 += n14 * (n13 >> 8 & 0xFF);
                    n17 += n14 * (n13 & 0xFF);
                }
                if (n18 != 0) {
                    n15 = (n15 / n18 << 16) + n17 / n18;
                    n16 = n16 / n18 << 8;
                    n12 = n18 >> 2;
                    int n19 = 256 - n12;
                    int n20 = hk.hk_l[n10];
                    hk.hk_l[n10] = (n12 * n15 + n19 * (n20 & 0xFF00FF) & 0xFF00FF00) + (n12 * n16 + n19 * (n20 & 0xFF00) & 0xFF0000) >>> 8;
                }
                n11 += 2;
                ++n10;
                n9 += 2;
            }
        }
    }

    private static final void d(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        for (int i = -n5; i < 0; ++i) {
            for (int j = -n4; j < 0; ++j) {
                int n9 = (nArray2[n2] >>> 24) * n8 >> 8;
                int n10 = 256 - n9;
                int n11 = nArray2[n2++];
                int n12 = nArray[n3];
                nArray[n3++] = ((n11 & 0xFF00FF) * n9 + (n12 & 0xFF00FF) * n10 & 0xFF00FF00) + ((n11 & 0xFF00) * n9 + (n12 & 0xFF00) * n10 & 0xFF0000) >>> 8;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    private static final void c(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10) {
        int n11 = n2;
        for (int i = -n7; i < 0; ++i) {
            int n12 = (n3 >> 16) * n10;
            for (int j = -n6; j < 0; ++j) {
                n = nArray2[(n2 >> 16) + n12];
                int n13 = n >>> 24;
                if (n13 != 0) {
                    int n14 = 256 - n13;
                    int n15 = nArray[n4];
                    nArray[n4++] = ((n & 0xFF00FF) * n13 + (n15 & 0xFF00FF) * n14 & 0xFF00FF00) + ((n & 0xFF00) * n13 + (n15 & 0xFF00) * n14 & 0xFF0000) >>> 8;
                } else {
                    ++n4;
                }
                n2 += n8;
            }
            n3 += n9;
            n2 = n11;
            n4 += n5;
        }
    }

    ld(int n, int n2) {
        super(n, n2);
    }

    @Override
    final void b(int n, int n2, int n3, int n4, int n5) {
        if (n3 > 0) {
            int n6;
            int n7;
            if (n4 <= 0) {
                return;
            }
            int n8 = this.I;
            int n9 = this.H;
            int n10 = 0;
            int n11 = 0;
            int n12 = this.K;
            int n13 = this.C;
            int n14 = (n12 << 16) / n3;
            int n15 = (n13 << 16) / n4;
            if (this.F > 0) {
                n7 = ((this.F << 16) + n14 - 1) / n14;
                n += n7;
                n10 += n7 * n14 - (this.F << 16);
            }
            if (this.z > 0) {
                n7 = ((this.z << 16) + n15 - 1) / n15;
                n2 += n7;
                n11 += n7 * n15 - (this.z << 16);
            }
            if (n8 < n12) {
                n3 = ((n8 << 16) - n10 + n14 - 1) / n14;
            }
            if (n9 < n13) {
                n4 = ((n9 << 16) - n11 + n15 - 1) / n15;
            }
            n7 = n + n2 * hk.hk_j;
            int n16 = hk.hk_j - n3;
            if (n2 + n4 > hk.hk_b) {
                n4 -= n2 + n4 - hk.hk_b;
            }
            if (n2 < hk.hk_h) {
                n6 = hk.hk_h - n2;
                n4 -= n6;
                n7 += n6 * hk.hk_j;
                n11 += n15 * n6;
            }
            if (n + n3 > hk.hk_g) {
                n6 = n + n3 - hk.hk_g;
                n3 -= n6;
                n16 += n6;
            }
            if (n < hk.hk_c) {
                n6 = hk.hk_c - n;
                n3 -= n6;
                n7 += n6;
                n10 += n14 * n6;
                n16 += n6;
            }
            ld.e(hk.hk_l, this.D, 0, n10, n11, n7, n16, n3, n4, n14, n15, n8, n5);
            return;
        }
    }

    ld(int n, int n2, int n3, int n4, int n5, int n6, int[] nArray) {
        super(n, n2, n3, n4, n5, n6, nArray);
    }

    private static final void e(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        int n9 = n8 >> 16 & 0xFF;
        int n10 = n8 >> 8 & 0xFF;
        int n11 = n8 & 0xFF;
        int n12 = -(n4 >> 2);
        n4 = -(n4 & 3);
        int n13 = n12 + n12 + n12 + n12 + n4;
        for (int i = -n5; i < 0; ++i) {
            for (int j = n13; j < 0; ++j) {
                int n14;
                if ((n14 = (n = nArray2[n2++]) >>> 24) != 0) {
                    int n15 = n >> 16 & 0xFF;
                    int n16 = n >> 8 & 0xFF;
                    int n17 = n & 0xFF;
                    int n18 = n15 == n16 && n16 == n17 ? (n15 <= 128 ? (n15 * n9 >> 7 << 16) + (n16 * n10 >> 7 << 8) + (n17 * n11 >> 7) : (n9 * (256 - n15) + 255 * (n15 - 128) >> 7 << 16) + (n10 * (256 - n16) + 255 * (n16 - 128) >> 7 << 8) + (n11 * (256 - n17) + 255 * (n17 - 128) >> 7)) : n;
                    int n19 = 256 - n14;
                    int n20 = nArray[n3];
                    nArray[n3++] = ((n18 & 0xFF00FF) * n14 + (n20 & 0xFF00FF) * n19 & 0xFF00FF00) + ((n18 & 0xFF00) * n14 + (n20 & 0xFF00) * n19 & 0xFF0000) >>> 8;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    @Override
    final void e(int n, int n2, int n3) {
        int n4;
        if (n3 == 256) {
            this.c(n, n2);
            return;
        }
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ld.f(hk.hk_l, this.D, 0, n6, n5, n8, n7, n9, n10, n3);
            return;
        }
    }

    @Override
    final void a(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ld.e(hk.hk_l, this.D, 0, n6, n5, n8, n7, n9, n10, n3);
            return;
        }
    }

    @Override
    final void c(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ld.d(hk.hk_l, this.D, 0, n6, n5, n8, n7, n9, n10, n3);
            return;
        }
    }

    private static final void f(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        for (int i = -n5; i < 0; ++i) {
            for (int j = -n4; j < 0; ++j) {
                int n9;
                if ((n9 = (n = nArray2[n2++]) >>> 24) != 0) {
                    int n10 = nArray[n3];
                    int n11 = 256 - n9;
                    int n12 = (n & 0xFF00FF) * n8 & 0xFF00FF00;
                    int n13 = (n & 0xFF00) * n8 & 0xFF0000;
                    n = (n12 | n13) >>> 8;
                    nArray[n3++] = ((n & 0xFF00FF) * n9 + (n10 & 0xFF00FF) * n11 & 0xFF00FF00) + ((n & 0xFF00) * n9 + (n10 & 0xFF00) * n11 & 0xFF0000) >>> 8;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    @Override
    final void d(int n, int n2, int n3, int n4, int n5) {
        if (n5 == 256) {
            this.c(n, n2, n3, n4);
            return;
        }
        if (n3 > 0) {
            int n6;
            int n7;
            if (n4 <= 0) {
                return;
            }
            int n8 = this.I;
            int n9 = this.H;
            int n10 = 0;
            int n11 = 0;
            int n12 = this.K;
            int n13 = this.C;
            int n14 = (n12 << 16) / n3;
            int n15 = (n13 << 16) / n4;
            if (this.F > 0) {
                n7 = ((this.F << 16) + n14 - 1) / n14;
                n += n7;
                n10 += n7 * n14 - (this.F << 16);
            }
            if (this.z > 0) {
                n7 = ((this.z << 16) + n15 - 1) / n15;
                n2 += n7;
                n11 += n7 * n15 - (this.z << 16);
            }
            if (n8 < n12) {
                n3 = ((n8 << 16) - n10 + n14 - 1) / n14;
            }
            if (n9 < n13) {
                n4 = ((n9 << 16) - n11 + n15 - 1) / n15;
            }
            n7 = n + n2 * hk.hk_j;
            int n16 = hk.hk_j - n3;
            if (n2 + n4 > hk.hk_b) {
                n4 -= n2 + n4 - hk.hk_b;
            }
            if (n2 < hk.hk_h) {
                n6 = hk.hk_h - n2;
                n4 -= n6;
                n7 += n6 * hk.hk_j;
                n11 += n15 * n6;
            }
            if (n + n3 > hk.hk_g) {
                n6 = n + n3 - hk.hk_g;
                n3 -= n6;
                n16 += n6;
            }
            if (n < hk.hk_c) {
                n6 = hk.hk_c - n;
                n3 -= n6;
                n7 += n6;
                n10 += n14 * n6;
                n16 += n6;
            }
            ld.d(hk.hk_l, this.D, 0, n10, n11, n7, n16, n3, n4, n14, n15, n8, n5);
            return;
        }
    }

    @Override
    final void b(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ld.d(hk.hk_l, this.D, 0, n6, n5, 0, 0, n8, n7, n9, n10, n3);
            return;
        }
    }

    @Override
    final void f(int n, int n2, int n3) {
        int n4;
        int n5 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n6 = 0;
        int n7 = this.H;
        int n8 = this.I;
        int n9 = hk.hk_j - n8;
        int n10 = 0;
        if (n2 < hk.hk_h) {
            n4 = hk.hk_h - n2;
            n7 -= n4;
            n2 = hk.hk_h;
            n6 += n4 * n8;
            n5 += n4 * hk.hk_j;
        }
        if (n2 + n7 > hk.hk_b) {
            n7 -= n2 + n7 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n4 = hk.hk_c - n;
            n8 -= n4;
            n = hk.hk_c;
            n6 += n4;
            n5 += n4;
            n10 += n4;
            n9 += n4;
        }
        if (n + n8 > hk.hk_g) {
            n4 = n + n8 - hk.hk_g;
            n8 -= n4;
            n10 += n4;
            n9 += n4;
        }
        if (n8 > 0) {
            if (n7 <= 0) {
                return;
            }
            ld.b(0, 0, 0, hk.hk_l, this.D, n6, 0, n5, 0, n8, n7, n9, n10, n3);
            return;
        }
    }

    private static final void b(int n, int n2, int n3, int[] nArray, int[] nArray2, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12) {
        for (n7 = -n9; n7 < 0; ++n7) {
            for (n5 = -n8; n5 < 0; ++n5) {
                if ((n = nArray2[n4++]) != 0) {
                    int n13 = n12 * (n >>> 24) >> 8 & 0xFF;
                    n2 = (n & 0xFF00FF) * n13;
                    n = (n2 & 0xFF00FF00) + (n * n13 - n2 & 0xFF0000) >>> 8;
                    n2 = nArray[n6];
                    n3 = n + n2;
                    n = (n & 0xFF00FF) + (n2 & 0xFF00FF);
                    n2 = (n & 0x1000100) + (n3 - n & 0x10000);
                    nArray[n6++] = n3 - n2 | n2 - (n2 >>> 8);
                    continue;
                }
                ++n6;
            }
            n6 += n10;
            n4 += n11;
        }
    }

    private static final void c(int[] nArray, int[] nArray2, int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = -n4;
        for (int i = -n5; i < 0; ++i) {
            for (int j = n8; j < 0; ++j) {
                int n9;
                if ((n9 = (n = nArray2[n2++]) >>> 24) != 0) {
                    int n10 = 256 - n9;
                    int n11 = nArray[n3];
                    nArray[n3++] = ((n & 0xFF00FF) * n9 + (n11 & 0xFF00FF) * n10 & 0xFF00FF00) + ((n & 0xFF00) * n9 + (n11 & 0xFF00) * n10 & 0xFF0000) >>> 8;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    @Override
    final void e(int n, int n2) {
        int n3;
        int n4 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n5 = 0;
        int n6 = this.H;
        int n7 = this.I;
        int n8 = hk.hk_j - n7;
        int n9 = 0;
        if (n2 < hk.hk_h) {
            n3 = hk.hk_h - n2;
            n6 -= n3;
            n2 = hk.hk_h;
            n5 += n3 * n7;
            n4 += n3 * hk.hk_j;
        }
        if (n2 + n6 > hk.hk_b) {
            n6 -= n2 + n6 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n3 = hk.hk_c - n;
            n7 -= n3;
            n = hk.hk_c;
            n5 += n3;
            n4 += n3;
            n9 += n3;
            n8 += n3;
        }
        if (n + n7 > hk.hk_g) {
            n3 = n + n7 - hk.hk_g;
            n7 -= n3;
            n9 += n3;
            n8 += n3;
        }
        if (n7 > 0) {
            if (n6 <= 0) {
                return;
            }
            ld.c(hk.hk_l, this.D, 0, n5, n4, n7, n6, n8, n9);
            return;
        }
    }

    @Override
    final void c(int n, int n2) {
        int n3;
        int n4 = (n += this.F) + (n2 += this.z) * hk.hk_j;
        int n5 = 0;
        int n6 = this.H;
        int n7 = this.I;
        int n8 = hk.hk_j - n7;
        int n9 = 0;
        if (n2 < hk.hk_h) {
            n3 = hk.hk_h - n2;
            n6 -= n3;
            n2 = hk.hk_h;
            n5 += n3 * n7;
            n4 += n3 * hk.hk_j;
        }
        if (n2 + n6 > hk.hk_b) {
            n6 -= n2 + n6 - hk.hk_b;
        }
        if (n < hk.hk_c) {
            n3 = hk.hk_c - n;
            n7 -= n3;
            n = hk.hk_c;
            n5 += n3;
            n4 += n3;
            n9 += n3;
            n8 += n3;
        }
        if (n + n7 > hk.hk_g) {
            n3 = n + n7 - hk.hk_g;
            n7 -= n3;
            n9 += n3;
            n8 += n3;
        }
        if (n7 > 0) {
            if (n6 <= 0) {
                return;
            }
            ld.c(hk.hk_l, this.D, 0, n5, n4, n7, n6, n8, n9);
            return;
        }
    }

    @Override
    final void c(int n, int n2, int n3, int n4) {
        if (n3 > 0) {
            int n5;
            int n6;
            if (n4 <= 0) {
                return;
            }
            int n7 = this.I;
            int n8 = this.H;
            int n9 = 0;
            int n10 = 0;
            int n11 = this.K;
            int n12 = this.C;
            int n13 = (n11 << 16) / n3;
            int n14 = (n12 << 16) / n4;
            if (this.F > 0) {
                n6 = ((this.F << 16) + n13 - 1) / n13;
                n += n6;
                n9 += n6 * n13 - (this.F << 16);
            }
            if (this.z > 0) {
                n6 = ((this.z << 16) + n14 - 1) / n14;
                n2 += n6;
                n10 += n6 * n14 - (this.z << 16);
            }
            if (n7 < n11) {
                n3 = ((n7 << 16) - n9 + n13 - 1) / n13;
            }
            if (n8 < n12) {
                n4 = ((n8 << 16) - n10 + n14 - 1) / n14;
            }
            n6 = n + n2 * hk.hk_j;
            int n15 = hk.hk_j - n3;
            if (n2 + n4 > hk.hk_b) {
                n4 -= n2 + n4 - hk.hk_b;
            }
            if (n2 < hk.hk_h) {
                n5 = hk.hk_h - n2;
                n4 -= n5;
                n6 += n5 * hk.hk_j;
                n10 += n14 * n5;
            }
            if (n + n3 > hk.hk_g) {
                n5 = n + n3 - hk.hk_g;
                n3 -= n5;
                n15 += n5;
            }
            if (n < hk.hk_c) {
                n5 = hk.hk_c - n;
                n3 -= n5;
                n6 += n5;
                n9 += n13 * n5;
                n15 += n5;
            }
            ld.c(hk.hk_l, this.D, 0, n9, n10, n6, n15, n3, n4, n13, n14, n7);
            return;
        }
    }
}
