/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.Point;
import java.awt.Robot;
import java.awt.image.BufferedImage;

final class il {
    private Robot il_a;
    private Component il_b;

    public final void showcursor(Component component, boolean bl) {
        block5: {
            if (bl) {
                component = null;
            } else if (component == null) {
                throw new NullPointerException();
            }
            if (component == this.il_b) {
                return;
            }
            if (null != this.il_b) {
                this.il_b.setCursor(null);
                this.il_b = null;
            }
            if (component == null) break block5;
            component.setCursor(component.getToolkit().createCustomCursor(new BufferedImage(1, 1, 2), new Point(0, 0), null));
            this.il_b = component;
        }
    }

    public final void movemouse(int n, int n2) {
        this.il_a.mouseMove(n, n2);
    }

    public il() throws Exception {
        Robot robot;
        this.il_a = robot = new Robot();
    }

    public final void setcustomcursor(Component component, int[] nArray, int n, int n2, Point point) {
        if (nArray == null) {
            component.setCursor(null);
        } else {
            BufferedImage bufferedImage = new BufferedImage(n, n2, 2);
            bufferedImage.setRGB(0, 0, n, n2, nArray, 0, n);
            component.setCursor(component.getToolkit().createCustomCursor(bufferedImage, point, null));
        }
    }
}
