/*
 * Decompiled with CFR 0.152.
 */
import java.io.IOException;
import java.net.Socket;

final class mb {
    private boolean mb_a;
    static String mb_e = "Special Items";
    private int[] mb_b;
    private int mb_g;
    static int mb_c;
    static int[] mb_d;
    private int mb_f;

    static final boolean a(boolean bl2, int n) {
        if (k.k_c == null) {
            k.k_c = lf.lf_f.a(114, mc.mc_e, hc.hc_a);
        }
        if (~k.k_c.mh_c == -1) {
            return false;
        }
        p.p_a = el.J = ik.a(4);
        if (-2 != ~k.k_c.mh_c) {
            ph.xb = kl.B;
        } else {
            try {
                qc.qc_s = new qk((Socket)k.k_c.mh_b, lf.lf_f);
                uf uf2 = de.V;
                we.we_b.wl_n = 0;
                ph.xb = ba.ba_f;
                lg.U = bl2 ? -2 : -1;
                bb.bb_d = lg.U;
                kf.L = lg.U;
                uf2.wl_n = 0;
                gi.a(kb.kb_g, l.l_c, 17, we.we_b, qk.qk_a);
                wj.c(4792, -1);
            }
            catch (IOException iOException) {
                ph.xb = kl.B;
            }
        }
        k.k_c = null;
        int n2 = 79 / ((n - 21) / 48);
        return true;
    }

    final int a(int n) {
        int n2 = 97 % ((n - 37) / 50);
        return this.mb_g + 1;
    }

    static final String a(int n2, hl hl2) {
        boolean bl2 = client.A;
        String string = null;
        if (hl2.hl_p != null) {
            string = hl2.hl_p;
            if (hl2.hl_l == 1) {
                string = "<img=0>" + string;
            }
            if (-3 == ~hl2.hl_l) {
                string = "<img=1>" + string;
            }
        }
        if (n2 <= 96) {
            mb_c = -12;
        }
        String string2 = "";
        if (2 != hl2.hl_m) {
            if (0 == hl2.hl_m && ii.ii_q) {
                string2 = "[" + uc.uc_b + "] ";
            }
            if (~hl2.hl_m == -2) {
                string2 = "[" + cm.a((byte)125, hf.hf_a, new String[]{hl2.hl_g}) + "] ";
            }
            if (4 == hl2.hl_m && f.f_q != null) {
                string2 = "[" + f.f_q + "] ";
            }
            if (-4 == ~hl2.hl_m) {
                string2 = "[#" + hl2.hl_g + "] ";
            }
            if (!hl2.hl_j) {
                string2 = string2 + string + ": ";
            }
        } else if (!hl2.hl_j) {
            string2 = 0 == hl2.hl_i && ~hl2.hl_n == -1 ? cm.a((byte)90, oj.oj_b, new String[]{string}) : cm.a((byte)110, im.im_j, new String[]{string});
        }
        return string2;
    }

    final int b(int n2, int n3) {
        block1: {
            if (n2 > this.mb_g) {
                throw new ArrayIndexOutOfBoundsException(n2);
            }
            if (n3 == 0) break block1;
            this.mb_f = -5;
        }
        return this.mb_b[n2];
    }

    private final void a(int n2, int n3) {
        int[] nArray = new int[this.a((byte)-63, n2)];
        if (n3 >= -4) {
            this.b(9, -101);
        }
        an.a(this.mb_b, 0, nArray, 0, this.mb_b.length);
        this.mb_b = nArray;
    }

    private final int a(byte by, int n2) {
        boolean bl2 = client.A;
        if (by != -63) {
            this.mb_f = -94;
        }
        int n3 = this.mb_b.length;
        while (~n2 <= ~n3) {
            if (this.mb_a) {
                if (~n3 != -1) {
                    n3 *= this.mb_f;
                    continue;
                }
                n3 = 1;
                continue;
            }
            n3 += this.mb_f;
        }
        return n3;
    }

    private final void a(byte by, int n2, int n3) {
        if (this.mb_g < n2) {
            this.mb_g = n2;
        }
        if (by < 38) {
            return;
        }
        if (~n2 <= ~this.mb_b.length) {
            this.a(n2, -23);
        }
        this.mb_b[n2] = n3;
    }

    private mb() throws Throwable {
        throw new Error();
    }

    static final int a(boolean bl2, int n2, byte by, int n3, int n4) {
        int n5;
        block1: {
            n5 = 256 + n2 * (-n4 + n3);
            if (bl2) {
                n5 += 64;
            }
            if (by == -122) break block1;
            mb_e = null;
        }
        return n5;
    }

    final void a(int n2, boolean bl2) {
        if (bl2) {
            mb_e = null;
        }
        this.a((byte)114, this.mb_g - -1, n2);
    }

    public static void a(boolean bl2) {
        block0: {
            mb_e = null;
            mb_d = null;
            if (!bl2) break block0;
            mb_e = null;
        }
    }

    final void c(int n2, int n3) {
        if (n3 < 0 || ~this.mb_g > ~n3) {
            throw new ArrayIndexOutOfBoundsException(n3);
        }
        if (n2 > -25) {
            this.mb_f = 15;
        }
        if (this.mb_g != n3) {
            an.a(this.mb_b, n3 + 1, this.mb_b, n3, this.mb_g + -n3);
        }
        --this.mb_g;
    }
}
