/*
 * Decompiled with CFR 0.152.
 */
import java.util.Iterator;

final class uh
implements Iterable {
    static w uh_c;
    be uh_a;
    static boolean uh_b;
    static int uh_d;

    static final ke a(int[] nArray, boolean bl2, int n, int n2) {
        ec ec2;
        ke ke2 = new ke(3);
        ke2.ke_v = nArray;
        ke2.ke_i = n;
        if (ph.n(-30146)) {
            ec2 = new ec(20, qn.qn_rb, a.a_t);
            ec2.ec_m = 387;
            ec2.ec_l = 320 + -(ec2.ec_n / 2);
            ke2.a(ec2, 100);
        }
        if (mg.Zb) {
            ec2 = new ec(10, jd.Ob, a.a_t);
            ec2.ec_l = -(ec2.ec_n / 2) + 320;
            ec2.ec_m = 387;
            ke2.a(ec2, 101);
        }
        if (fm.fm_e) {
            ec2 = new ec(19, jd.Ob, a.a_t);
            ec2.ec_m = 387;
            ec2.ec_l = -(ec2.ec_n / 2) + 320;
            ke2.a(ec2, 100);
        }
        if (he.he_db) {
            ec2 = new ec(3, oa.oa_c, a.a_t);
            ec2.ec_l = -(ec2.ec_n / 2) + 320;
            ec2.ec_m = 387;
            ke2.a(ec2, 123);
        }
        ec2 = new ec(13, pc.pc_f, a.a_t);
        if (n2 > -103) {
            uh.a(-120);
        }
        ec2.ec_l = 320 + -(ec2.ec_n / 2);
        ec2.ec_m = 415;
        ke2.a(ec2, 106);
        if (ke2.ke_b.sk_l >= 3) {
            ke2.a(387, 320, true, -118, 24);
        }
        ke2.y = 520;
        ke2.ke_q = 215;
        ke2.z = 166;
        ke2.ke_w = 62;
        ke2.a(0, bl2, -129);
        return ke2;
    }

    final be a(byte by) {
        be be2;
        block1: {
            be2 = this.uh_a.be_p;
            if (be2 == this.uh_a) {
                return null;
            }
            be2.e((byte)97);
            if (by >= 51) break block1;
            uh.a(null, true, 58, 67);
        }
        return be2;
    }

    static final void a(int n) {
        wc wc2;
        wc wc3 = wc2 = (wc)sn.sn_e.d(-89);
        if (n != -9074) {
            return;
        }
        if (null == wc2) {
            wc3 = new wc();
        }
        wc3.a((byte)37, hk.hk_i, hk.hk_l, hk.hk_j, hk.hk_g, hk.hk_c, hk.hk_h, hk.hk_b);
        ci.ci_a.a(wc3, 2777);
    }

    static final void a(pi[] piArray, byte by) {
        int n;
        boolean bl2 = client.A;
        if (piArray != null) {
            for (n = 0; piArray.length > n; ++n) {
                piArray[n].a();
            }
        }
        n = -73 / ((by - 53) / 55);
    }

    static final void b(int n) {
        boolean bl2 = client.A;
        int n2 = -ad.ad_a + fb.fb_f;
        ad.ad_a = -(n2 >> -1322795295) + af.af_f;
        if (n != 32659) {
            pi[] piArray = null;
            uh.a(piArray, (byte)12);
        }
        fb.fb_f = ad.ad_a - -n2;
        int n3 = rn.rn_d = -(ac.A >> 1209881953) + kk.kk_e;
        for (int j = 0; j < ef.M.length; ++j) {
            int n4 = ug.ug_q[j];
            int n5 = ~n4 > -1 ? ie.ie_b : (~wj.Jb.sk_h != ~n4 ? i.i_c : hd.hd_s);
            String string = ef.M[j];
            int n6 = qb.a(0, string, n4 >= 0);
            int n7 = -(n6 >> -1957955167) + af.af_f;
            if (-1 >= ~n4) {
                cc cc2;
                n3 += je.je_c;
                cc cc3 = cc2 = ~n4 == ~wj.Jb.sk_h ? gf.gf_b : ql.ql_b;
                if (null != cc2) {
                    cc2.a(n6 + (ba.ba_d << -878923967), 97, -ba.ba_d + n7, n3, (le.le_t << 1939779937) + vb.V);
                }
                n3 += le.le_t;
            }
            if (-1 < ~n4) {
                wf.wf_q.a(string, n7, hb.Wb + n3, n5, -1);
                n3 += ma.I;
                continue;
            }
            aj.aj_d.a(string, n7, pa.pa_fb + n3, n5, -1);
            n3 += le.le_t + je.je_c + vb.V;
        }
    }

    public static void b(byte by) {
        block0: {
            uh_c = null;
            if (by > 44) break block0;
            uh.b(-20);
        }
    }

    public final Iterator iterator() {
        return new dg(this);
    }

    final void a(byte by, be be2) {
        block1: {
            if (be2.be_v != null) {
                be2.e((byte)85);
            }
            be2.be_v = this.uh_a.be_v;
            be2.be_p = this.uh_a;
            be2.be_v.be_p = be2;
            be2.be_p.be_v = be2;
            if (by == 4) break block1;
            uh_c = null;
        }
    }

    uh() {
        this.uh_a.be_p = this.uh_a = new be();
        this.uh_a.be_v = this.uh_a;
    }
}
