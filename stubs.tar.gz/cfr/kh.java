/*
 * Decompiled with CFR 0.152.
 */
import java.io.EOFException;
import java.io.IOException;

final class kh {
    private nh kh_d = null;
    static String kh_b;
    static String kh_f;
    static int[] kh_e;
    private nh kh_a = null;
    private int kh_h;
    private int kh_g = 65000;
    static String kh_c;

    static final void a(int n) {
        boolean bl = client.A;
        int n2 = a.a_r[0];
        if (n != 2) {
            kh_e = null;
        }
        int n3 = 1;
        while (~a.a_r.length < ~n3) {
            int n4 = a.a_r[n3];
            an.a(hb.Vb, n3 << -461235580, hb.Vb, n2, n4);
            n2 += n4;
            ++n3;
        }
    }

    static final void a(int n, int n2, int n3, int n4) {
        vi.A.wl_n = 0;
        vi.A.a(true, 12);
        vi.A.a(gg.A.nextInt(), false);
        if (n >= -17) {
            return;
        }
        vi.A.a(gg.A.nextInt(), false);
        vi.A.a(true, n2);
        vi.A.a(true, n4);
        vi.A.d(-1, n3);
        vi.A.a(ea.ea_k, uk.uk_p, true);
        we.we_b.f(18, -4);
        int n5 = ++we.we_b.wl_n;
        we.we_b.a(false, vi.A.wl_n, vi.A.wl_r, 0);
        we.we_b.b(we.we_b.wl_n - n5, true);
    }

    public final String toString() {
        return "" + this.kh_h;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final boolean a(byte by, byte[] byArray, int n, int n2) {
        nh nh2 = this.kh_a;
        synchronized (nh2) {
            boolean bl;
            if (n2 < 0 || n2 > this.kh_g) {
                throw new IllegalArgumentException();
            }
            if (by != 43) {
                kh.a(')', -33);
            }
            if (!(bl = this.a(true, (byte)-108, n, n2, byArray))) {
                bl = this.a(false, (byte)-43, n, n2, byArray);
            }
            return bl;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final boolean a(boolean bl, byte by, int n, int n2, byte[] byArray) {
        boolean bl2 = client.A;
        nh nh2 = this.kh_a;
        synchronized (nh2) {
            try {
                int n3;
                if (by > -39) {
                    return false;
                }
                if (!bl) {
                    n3 = (int)((this.kh_a.b(74) + 519L) / 520L);
                    if (-1 == ~n3) {
                        n3 = 1;
                    }
                } else {
                    if ((this.kh_d.b(37) ^ 0xFFFFFFFFFFFFFFFFL) > ((long)(6 + n * 6) ^ 0xFFFFFFFFFFFFFFFFL)) {
                        return false;
                    }
                    this.kh_d.a(6 * n, (byte)-109);
                    this.kh_d.a(0, jb.jb_b, 741, 6);
                    n3 = (0xFF & jb.jb_b[5]) + (((0xFF & jb.jb_b[3]) << -1816350064) - -(jb.jb_b[4] << 1510451016 & 0xFF00));
                    if (0 >= n3 || (this.kh_a.b(-94) / 520L ^ 0xFFFFFFFFFFFFFFFFL) > ((long)n3 ^ 0xFFFFFFFFFFFFFFFFL)) {
                        return false;
                    }
                }
                jb.jb_b[0] = (byte)(n2 >> 1086853712);
                jb.jb_b[2] = (byte)n2;
                jb.jb_b[5] = (byte)n3;
                jb.jb_b[1] = (byte)(n2 >> 1683129256);
                jb.jb_b[3] = (byte)(n3 >> -1965896624);
                jb.jb_b[4] = (byte)(n3 >> 178310472);
                this.kh_d.a(6 * n, (byte)-109);
                this.kh_d.a(jb.jb_b, (byte)118, 0, 6);
                int n4 = 0;
                int n5 = 0;
                while (~n4 > ~n2) {
                    int n6;
                    int n7 = 0;
                    if (bl) {
                        int n8;
                        int n9;
                        this.kh_a.a(520 * n3, (byte)-109);
                        if (~n < -65536) {
                            try {
                                this.kh_a.a(0, jb.jb_b, 741, 10);
                            }
                            catch (EOFException eOFException) {
                                break;
                            }
                            n9 = ((jb.jb_b[4] & 0xFF) << -405989848) + (jb.jb_b[5] & 0xFF);
                            n8 = 0xFF & jb.jb_b[9];
                            n6 = (0xFF & jb.jb_b[3]) + (0xFF000000 & jb.jb_b[0] << 127232344) - -((jb.jb_b[1] & 0xFF) << -482871280) + ((jb.jb_b[2] & 0xFF) << -822689368);
                            n7 = ((0xFF & jb.jb_b[6]) << 324120208) + (0xFF00 & jb.jb_b[7] << -1788207480) - -(jb.jb_b[8] & 0xFF);
                        } else {
                            try {
                                this.kh_a.a(0, jb.jb_b, 741, 8);
                            }
                            catch (EOFException eOFException) {
                                break;
                            }
                            n7 = (0xFF & jb.jb_b[6]) + (0xFF0000 & jb.jb_b[4] << 392227152) + ((0xFF & jb.jb_b[5]) << -1090035704);
                            n8 = 0xFF & jb.jb_b[7];
                            n9 = (0xFF & jb.jb_b[3]) + ((jb.jb_b[2] & 0xFF) << 1475077992);
                            n6 = (0xFF & jb.jb_b[1]) + ((0xFF & jb.jb_b[0]) << -1042807800);
                        }
                        if (n6 != n || ~n5 != ~n9 || ~n8 != ~this.kh_h) {
                            return false;
                        }
                        if (~n7 > -1 || (long)n7 > this.kh_a.b(-103) / 520L) {
                            return false;
                        }
                    }
                    if (n7 == 0) {
                        bl = false;
                        n7 = (int)((this.kh_a.b(-121) + 519L) / 520L);
                        if (~n7 == -1) {
                            ++n7;
                        }
                        if (n3 == n7) {
                            ++n7;
                        }
                    }
                    if (-513 <= ~(-n4 + n2)) {
                        n7 = 0;
                    }
                    if (~n >= -65536) {
                        jb.jb_b[0] = (byte)(n >> -1704945272);
                        jb.jb_b[7] = (byte)this.kh_h;
                        jb.jb_b[3] = (byte)n5;
                        jb.jb_b[5] = (byte)(n7 >> -1400891000);
                        jb.jb_b[4] = (byte)(n7 >> 1717337616);
                        jb.jb_b[1] = (byte)n;
                        jb.jb_b[2] = (byte)(n5 >> -906719320);
                        jb.jb_b[6] = (byte)n7;
                        this.kh_a.a(n3 * 520, (byte)-109);
                        this.kh_a.a(jb.jb_b, (byte)124, 0, 8);
                        n6 = n2 - n4;
                        if (n6 > 512) {
                            n6 = 512;
                        }
                        this.kh_a.a(byArray, (byte)126, n4, n6);
                        n4 += n6;
                    } else {
                        jb.jb_b[3] = (byte)n;
                        jb.jb_b[1] = (byte)(n >> 531261328);
                        jb.jb_b[8] = (byte)n7;
                        jb.jb_b[6] = (byte)(n7 >> -948474160);
                        jb.jb_b[4] = (byte)(n5 >> 1676966632);
                        jb.jb_b[9] = (byte)this.kh_h;
                        jb.jb_b[0] = (byte)(n >> -2082895624);
                        jb.jb_b[5] = (byte)n5;
                        jb.jb_b[7] = (byte)(n7 >> -2143680568);
                        jb.jb_b[2] = (byte)(n >> -1189518136);
                        this.kh_a.a(n3 * 520, (byte)-109);
                        this.kh_a.a(jb.jb_b, (byte)96, 0, 10);
                        n6 = n2 + -n4;
                        if (~n6 < -511) {
                            n6 = 510;
                        }
                        this.kh_a.a(byArray, (byte)126, n4, n6);
                        n4 += n6;
                    }
                    n3 = n7;
                    ++n5;
                }
                return true;
            }
            catch (IOException iOException) {
                return false;
            }
        }
    }

    public static void b(int n) {
        block0: {
            kh_b = null;
            kh_c = null;
            kh_e = null;
            kh_f = null;
            if (n == -1643605936) break block0;
            kh.b(15);
        }
    }

    static final boolean a(char c, int n) {
        if (c >= ' ' && c <= '~') {
            return true;
        }
        if (c >= '\u00a0' && '\u00ff' >= c) {
            return true;
        }
        if ('\u20ac' == c || c == '\u0152' || c == '\u2014' || '\u0153' == c || c == '\u0178') {
            return true;
        }
        return n != 8212;
    }

    static final void a(boolean bl) {
        boolean bl2 = client.A;
        int n = 0;
        if (!bl) {
            kh_f = null;
        }
        while (~ic.ic_c < ~n) {
            pd.pd_g[n] = null;
            ++n;
        }
        ic.ic_c = 0;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    final byte[] a(int n, byte by) {
        boolean bl = client.A;
        nh nh2 = this.kh_a;
        synchronized (nh2) {
            try {
                if (((long)(6 + n * 6) ^ 0xFFFFFFFFFFFFFFFFL) < (this.kh_d.b(103) ^ 0xFFFFFFFFFFFFFFFFL)) {
                    return null;
                }
                this.kh_d.a(6 * n, (byte)-109);
                this.kh_d.a(0, jb.jb_b, 741, 6);
                int n2 = (jb.jb_b[2] & 0xFF) + (jb.jb_b[1] << 253972520 & 0xFF00) + (jb.jb_b[0] << 1692978896 & 0xFF0000);
                if (by <= 38) {
                    return null;
                }
                int n3 = (0xFF0000 & jb.jb_b[3] << 1493935856) - (-((jb.jb_b[4] & 0xFF) << 1799068744) - (0xFF & jb.jb_b[5]));
                if (-1 < ~n2) {
                    return null;
                }
                if (this.kh_g < n2) {
                    return null;
                }
                if (0 >= n3) {
                    return null;
                }
                if ((long)n3 > this.kh_a.b(-128) / 520L) {
                    return null;
                }
                byte[] byArray = new byte[n2];
                int n4 = 0;
                int n5 = 0;
                while (n4 < n2) {
                    int n6;
                    int n7;
                    int n8;
                    int n9;
                    int n10;
                    if (0 == n3) {
                        return null;
                    }
                    this.kh_a.a(n3 * 520, (byte)-109);
                    int n11 = -n4 + n2;
                    if (-65536 <= ~n) {
                        n10 = 8;
                        if (512 < n11) {
                            n11 = 512;
                        }
                        this.kh_a.a(0, jb.jb_b, 741, n10 + n11);
                        n9 = (jb.jb_b[4] << 1334482960 & 0xFF0000) + (jb.jb_b[5] << -1069089528 & 0xFF00) - -(0xFF & jb.jb_b[6]);
                        n8 = (0xFF & jb.jb_b[3]) + ((jb.jb_b[2] & 0xFF) << 1055080456);
                        n7 = jb.jb_b[7] & 0xFF;
                        n6 = (jb.jb_b[1] & 0xFF) + (0xFF00 & jb.jb_b[0] << -1366805240);
                    } else {
                        if (~n11 < -511) {
                            n11 = 510;
                        }
                        n10 = 10;
                        this.kh_a.a(0, jb.jb_b, 741, n11 - -n10);
                        n8 = ((0xFF & jb.jb_b[4]) << 818328936) + (jb.jb_b[5] & 0xFF);
                        n9 = ((jb.jb_b[6] & 0xFF) << 813250864) + (jb.jb_b[7] << 422628680 & 0xFF00) - -(jb.jb_b[8] & 0xFF);
                        n7 = jb.jb_b[9] & 0xFF;
                        n6 = (0xFF000000 & jb.jb_b[0] << -1576939336) + ((jb.jb_b[1] & 0xFF) << -1643605936) + ((jb.jb_b[2] & 0xFF) << 1367300264) + (0xFF & jb.jb_b[3]);
                    }
                    if (n6 != n) {
                        return null;
                    }
                    if (n5 != n8) {
                        return null;
                    }
                    if (~this.kh_h != ~n7) {
                        return null;
                    }
                    if (~n9 > -1) {
                        return null;
                    }
                    if (this.kh_a.b(55) / 520L < (long)n9) {
                        return null;
                    }
                    int n12 = n10 - -n11;
                    int n13 = n10;
                    while (~n12 < ~n13) {
                        byArray[n4++] = jb.jb_b[n13];
                        ++n13;
                    }
                    ++n5;
                    n3 = n9;
                }
                return byArray;
            }
            catch (IOException iOException) {
                return null;
            }
        }
    }

    kh(int n, nh nh2, nh nh3, int n2) {
        this.kh_d = nh3;
        this.kh_a = nh2;
        this.kh_g = n2;
        this.kh_h = n;
    }

    static {
        kh_f = "Connection timed out. Please try using a different server.";
        kh_b = "Hint: to start quickly, choose 'Don't mind' for as many options as you can!";
        kh_e = new int[4];
        kh_c = "Play the game without logging in just yet";
    }
}
