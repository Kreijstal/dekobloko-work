/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

class be
extends bh {
    static String be_s;
    static String be_o;
    static int[] be_t;
    be be_p;
    static int[] be_w;
    static int be_q;
    static jc x;
    static int be_n;
    be be_v;
    long be_r;
    static ck[][] be_u;

    public static void a(int n) {
        be_s = null;
        be_w = null;
        be_o = null;
        be_u = null;
        be_t = null;
        int n2 = -75 / ((-44 - n) / 60);
        x = null;
    }

    static final boolean a(byte by, CharSequence charSequence) {
        if (by != 98) {
            return false;
        }
        return sk.a(true, charSequence, true, 10);
    }

    final void a(long l, byte by) {
        block1: {
            if (this.be_v != null) {
                throw new RuntimeException();
            }
            this.be_r = l;
            if (by >= 107) break block1;
            be_n = 116;
        }
    }

    static final void a(Applet applet, byte by) {
        if (by != -57) {
            return;
        }
        oa.a(applet, -1, "");
        wb.a(applet, 30307);
    }

    final long c(byte by) {
        block0: {
            if (by == 57) break block0;
            this.c((byte)121);
        }
        return this.be_r;
    }

    static final void a(byte by, ig ig2) {
        if (ig2 == null) {
            return;
        }
        if (by <= 117) {
            ig ig3 = null;
            be.a((byte)85, ig3);
        }
        mg.mg_bc = ig2;
        ie.ie_c.M.c(110);
        ie.ie_c.a(mg.mg_bc, -16834);
        jh.jh_h = true;
    }

    final void e(byte by) {
        if (null == this.be_v) {
            return;
        }
        this.be_v.be_p = this.be_p;
        this.be_p.be_v = this.be_v;
        if (by < 68) {
            be_u = null;
        }
        this.be_v = null;
        this.be_p = null;
    }

    protected be() {
    }

    final boolean d(byte by) {
        if (by != -68) {
            this.be_r = 35L;
        }
        return this.be_v != null;
    }

    static {
        be_w = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, 85, 80, 84, -1, 91, -1, -1, -1, 81, 82, 86, -1, -1, -1, -1, -1, -1, -1, -1, 13, -1, -1, -1, -1, 83, 104, 105, 103, 102, 96, 98, 97, 99, -1, -1, -1, -1, -1, -1, -1, 25, 16, 17, 18, 19, 20, 21, 22, 23, 24, -1, -1, -1, -1, -1, -1, -1, 48, 68, 66, 50, 34, 51, 52, 53, 39, 54, 55, 56, 70, 69, 40, 41, 32, 35, 49, 36, 38, 67, 33, 65, 37, 64, -1, -1, -1, -1, -1, 228, 231, 227, 233, 224, 219, 225, 230, 226, 232, 89, 87, -1, 88, 229, 90, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, -1, -1, -1, 101, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 100, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
        be_t = new int[8192];
        be_s = "Unable to delete name - system busy";
        be_n = 0;
        be_o = "Average rating";
        be_q = 0;
        x = new jc();
    }
}
