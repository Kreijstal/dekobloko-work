/*
 * Decompiled with CFR 0.152.
 */
final class cl
extends bh {
    static w cl_n;
    static ke B;
    int cl_q;
    int z;
    int cl_t;
    int[][] cl_u;
    static w C;
    int cl_w;
    String[][] x;
    boolean A;
    static gk cl_r;
    static String cl_s;
    static ql cl_v;
    int cl_p;
    static ji y;
    int cl_o;

    static final void a(int n2, int n3, int n4, nm nm2, boolean bl) {
        int n5;
        boolean bl2 = client.A;
        boolean bl3 = false;
        int n6 = 0;
        if (n3 != -17339) {
            hl hl2 = null;
            cl.a(hl2, true);
        }
        int n7 = 0;
        int n8 = 0;
        if (cd.cd_m != null && (cb.cb_e != null || mg.Ob != null || ik.ik_h != null || null != af.af_b)) {
            for (n5 = 0; j.j_b > n5; ++n5) {
                int n9;
                int n10 = 0xFF & cd.cd_m.ve_kc[n5];
                if (cb.cb_e != null && cb.cb_e[n5] != null && cb.cb_e[n5][n10]) {
                    bl3 = true;
                }
                if (mg.Ob != null && null != mg.Ob[n5]) {
                    n9 = mg.Ob[n5][n10];
                    if (-1 != ~n9 && !uc.uc_a) {
                        bl3 = true;
                    }
                    if (~n9 < ~n6) {
                        n6 = n9;
                    }
                }
                if (af.af_b != null && null != af.af_b[n5]) {
                    n8 |= af.af_b[n5][n10];
                }
                if (ik.ik_h == null || null == ik.ik_h[n5]) continue;
                n9 = ik.ik_h[n5][n10];
                if (~n7 > ~n9) {
                    n7 = n9;
                }
                if (-1 == ~n9 || uc.uc_a) continue;
                bl3 = true;
            }
        }
        n5 = nm2.a(kf.O * 2 - -4, n2 * (8 + kf.O * 4), n3 + 2109, nm2 == ki.ki_w, 2, bl) ? 1 : 0;
        vj vj2 = nm2.Ob.M;
        tj tj2 = null;
        tj tj3 = (tj)vj2.c((byte)25);
        while (null != tj3) {
            int n11;
            int n12;
            int n13;
            boolean bl4;
            boolean bl5 = false;
            if (tj3.M == null) {
                tj3.Zb = new w(0L, gg.G);
                tj3.a(tj3.Zb, -16834);
                tj3.Tb = new w(0L, fc.fc_f);
                if (pd.pd_a) {
                    tj3.a(tj3.Tb, -16834);
                }
                tj3.Tb.X = 2;
                tj3.gc = new w(0L, ua.H);
                tj3.a(tj3.gc, -16834);
                tj3.d(-117);
                tj3.Wb = new w(0L, lj.lj_c);
                tj3.a(tj3.Wb, n3 + 505);
                tj3.Ob = new w(0L, gk.Hb);
                tj3.a(tj3.Ob, -16834);
                bl5 = true;
            }
            tj3.Zb.Y = null;
            w w2 = tj3.Zb;
            tj3.Zb.N = 0;
            w2.w_mb = 0;
            tj3.Tb.Y = null;
            w w3 = tj3.Tb;
            tj3.Tb.N = 0;
            w3.w_mb = 0;
            tj3.Wb.Y = null;
            tj3.Wb.N = 0;
            w w4 = tj3.Wb;
            w4.w_mb = 0;
            tj3.Ob.Y = null;
            tj3.Ob.N = 0;
            w w5 = tj3.Ob;
            tj3.gc.Y = null;
            w5.w_mb = 0;
            w w6 = tj3.gc;
            tj3.gc.N = 0;
            w6.w_mb = 0;
            tj3.w_mb = nm2.Ob.w_mb;
            int n14 = 0;
            String string = tj3.Yb;
            int n15 = 72;
            if (ec.ec_k == nm2) {
                n15 += 42;
            }
            boolean bl6 = bl4 = !(string = mm.a(tj3.Zb.J, string, n15)).equals(tj3.Yb);
            if (tj3.tj_dc < 4) {
                if (tj3.tj_dc > 0) {
                    string = "<img=" + (tj3.tj_dc - 1) + ">" + string;
                }
            } else {
                string = "<img=" + (n.n_c + -4 + tj3.tj_dc) + ">" + string;
            }
            tj3.Zb.Y = string;
            if (!tj3.g((byte)101)) {
                int n16 = 0xFFCC66;
                n13 = 0xFFFFFF;
                if (bl3 && !tj3.tj_ec || tj3.Ub < n6 || ~tj3.Xb > ~n7 || -1 > ~(~tj3.Sb & n8)) {
                    n13 = 0x808080;
                    n16 = 8414771;
                }
                tj3.Zb.w_fb = tj3.Zb.w_rb = n13;
                tj3.Zb.Bb = tj3.Zb.w_rb;
                tj3.Tb.G = tj3.Wb.G = n16;
                tj3.Zb.G = tj3.Wb.G;
                tj3.Tb.w_fb = tj3.Tb.w_rb = n13;
                tj3.Tb.Bb = tj3.Tb.w_rb;
                tj3.Wb.w_fb = tj3.Wb.w_rb = n13;
                tj3.Wb.Bb = tj3.Wb.w_rb;
                if (nm2 != tb.tb_b) {
                    if (!tj3.tj_bc) {
                        if (tj3.tj_fc) {
                            tj3.Zb.Y = cm.a((byte)91, ad.A, new String[]{string});
                            tj3.Wb.Y = uc.uc_f;
                            tj3.Ob.Y = ql.ql_f;
                        } else {
                            tj3.Wb.Y = a.a_l;
                        }
                    } else {
                        tj3.Zb.Y = cm.a((byte)116, lb.lb_i, new String[]{string});
                        tj3.Ob.Y = fc.fc_g;
                    }
                } else if (!cd.cd_m.ve_lc) {
                    tj3.Ob.Y = bn.bn_a;
                }
                n12 = 0;
                if (cd.cd_m != null && ig.b(true) && (tj3.tj_cc ^ 0xFFFFFFFFFFFFFFFFL) != (uc.uc_g ^ 0xFFFFFFFFFFFFFFFFL)) {
                    if (null != tj3.Wb.Y) {
                        n11 = tj3.Wb.a(true) + nk.nk_b * 2;
                        tj3.Wb.a(n11, 0, n14, kf.O, n12);
                        n12 += n11;
                    }
                    if (null != tj3.Ob.Y) {
                        n11 = nm2 == tb.tb_b ? 40 : tj3.Ob.a(true) - -(2 * nk.nk_b);
                        tj3.Ob.a(n11, n3 + 17339, n14, kf.O, n12);
                        n12 += n11;
                    }
                }
                tj3.Zb.a(tj3.w_mb + -(!pd.pd_a ? 0 : 42) + -n12, 0, n14, kf.O, n12);
                tj3.Tb.Y = Integer.toString(tj3.Ub);
                tj3.Tb.a(40, n3 + 17339, n14, kf.O, tj3.w_mb + -40);
                if (!tj3.Zb.w_jb || !bl4) {
                    if (tj3.Zb.w_jb && vj.vj_e != null && null != vj.vj_e[tj3.tj_dc]) {
                        sl.sl_g = vj.vj_e[tj3.tj_dc];
                    }
                } else {
                    sl.sl_g = tj3.Yb;
                    if (null != vj.vj_e && null != vj.vj_e[tj3.tj_dc]) {
                        sl.sl_g = sl.sl_g + " - " + vj.vj_e[tj3.tj_dc];
                    }
                }
                n14 += kf.O;
            }
            String string2 = je.a(string, tj3.tj_hc, (byte)-128);
            if (null != string2) {
                n13 = tj3.gc.J.a(string2, -nk.nk_b + tj3.w_mb - nk.nk_b);
                tj3.gc.w_wb = 256 * tj3.Qb / oa.oa_a;
                tj3.gc.Y = string2;
                tj3.gc.a(tj3.w_mb + -(nk.nk_b * 2), 0, n14, kf.O * n13, nk.nk_b);
                n14 += n13 * kf.O;
            }
            if (n5 == 0) {
                tj3.F = -tj3.N + n14;
            }
            if (bl5) {
                nm2.Ob.a(tj2, tj3, 2, 0);
            }
            if (~tj3.w_ob != -1 && !tj3.g((byte)101)) {
                if (0 != tj3.Wb.w_ob) {
                    bn.a(tj3.tj_cc, n4, (byte)-84);
                } else if (0 == tj3.Ob.w_ob) {
                    fl.a(0, tj3, nm2, he.S, 0, n3 ^ 0x43CE, nf.nf_h);
                } else {
                    mn.a(true, tj3.tj_cc, n4);
                }
            }
            tj2 = tj3;
            if (tj3.Kb && !tj3.g((byte)111)) {
                String string3 = null;
                if ((uc.uc_g ^ 0xFFFFFFFFFFFFFFFFL) != (tj3.tj_cc ^ 0xFFFFFFFFFFFFFFFFL)) {
                    if (!bl3 || tj3.tj_ec) {
                        if (tj3.Xb < n7) {
                            n12 = -tj3.Xb + n7;
                            if (~n12 == -2) {
                                string3 = cm.a((byte)93, qf.qf_m, new String[]{string});
                            }
                            string3 = cm.a((byte)99, kn.kn_n, new String[]{string, Integer.toString(n12)});
                        } else if (~tj3.Ub > ~n6) {
                            string3 = cm.a((byte)98, wm.wm_i, new String[]{string, Integer.toString(n6)});
                        } else if (0 != (~tj3.Sb & n8)) {
                            n12 = wb.b((byte)-120, n8 & ~tj3.Sb);
                            string3 = cm.a((byte)91, ci.ci_f, new String[]{string});
                            if (~n12 < -1 && lc.lc_e != null && lc.lc_e.length >= n12 && lc.lc_e[n12 - 1] != null) {
                                string3 = cm.a((byte)93, lc.lc_e[-1 + n12][2], new String[]{string});
                            }
                        }
                    } else {
                        string3 = cm.a((byte)92, in.in_s, new String[]{string});
                    }
                } else if (bl3 && !tj3.tj_ec) {
                    string3 = rn.rn_a;
                } else if (~tj3.Xb > ~n7) {
                    n12 = -tj3.Xb + n7;
                    if (n12 == 1) {
                        string3 = oa.oa_d;
                    }
                    string3 = cm.a((byte)118, lb.lb_a, new String[]{null, Integer.toString(n12)});
                } else if (~tj3.Ub > ~n6) {
                    string3 = cm.a((byte)90, gd.gd_a, new String[]{null, Integer.toString(n6)});
                } else if ((n8 & ~tj3.Sb) != 0) {
                    n12 = wb.b((byte)-94, n8 & ~tj3.Sb);
                    string3 = tm.tm_e;
                    if (~n12 < -1 && lc.lc_e != null && n12 <= lc.lc_e.length && lc.lc_e[-1 + n12] != null) {
                        string3 = lc.lc_e[n12 - 1][1];
                    }
                }
                if (string3 != null) {
                    string3 = "<col=A00000>" + string3;
                    String string4 = null;
                    n11 = 0;
                    int n17 = 0;
                    while (~n17 > ~j.j_b) {
                        int n18;
                        int n19 = cd.cd_m.ve_kc[n17] & 0xFF;
                        boolean bl7 = false;
                        if (cb.cb_e != null && null != cb.cb_e[n17] && cb.cb_e[n17][n19] && !tj3.tj_ec) {
                            bl7 = true;
                        }
                        if (null != mg.Ob && mg.Ob[n17] != null) {
                            n18 = mg.Ob[n17][n19];
                            if (n18 != 0 && !uc.uc_a && !tj3.tj_ec) {
                                bl7 = true;
                            }
                            if (~n18 < ~tj3.Ub) {
                                bl7 = true;
                            }
                        }
                        if (ik.ik_h != null && ik.ik_h[n17] != null) {
                            n18 = ik.ik_h[n17][n19];
                            if (0 != n18 && !uc.uc_a && !tj3.tj_ec) {
                                bl7 = true;
                            }
                            if (~n18 < ~tj3.Xb) {
                                bl7 = true;
                            }
                        }
                        if (null != af.af_b && af.af_b[n17] != null && (~tj3.Sb & af.af_b[n17][n19]) != 0) {
                            bl7 = true;
                        }
                        if (bl7) {
                            String string5 = "<col=A00000>" + pa.pa_db[n17] + "</col>";
                            if (string4 == null) {
                                string4 = string5;
                            } else {
                                n11 = 1;
                                string4 = string4 + ", " + string5;
                            }
                        }
                        ++n17;
                    }
                    string3 = nm2 == tb.tb_b && ig.b(true) ? (n11 == 0 ? string3 + "<br>" + cm.a((byte)111, ci.ci_b, new String[]{string4}) : string3 + "<br>" + pb.pb_k + string4) : (n11 == 0 ? string3 + "<br>" + cm.a((byte)101, fj.fj_i, new String[]{string4}) : string3 + "<br>" + am.am_b + string4);
                    if (tb.tb_b == nm2 && !ig.b(true)) {
                        String string6 = cd.cd_m.Vb;
                        string3 = string3 + "<br>" + cm.a((byte)116, jf.jf_b, new String[]{string6});
                    }
                    sl.sl_g = string3;
                }
            }
            tj3 = (tj)vj2.d(true);
        }
    }

    static final void a(String string, int n2, int n3, String string2, int n4) {
        wj.Mb.G = n3;
        wj.Mb.T = string;
        wj.Mb.w_mb += jb.jb_f.w_mb;
        wj.Mb.Y = string2;
        jb.jb_f.w_vb += jb.jb_f.w_mb;
        if (n4 != -24503) {
            return;
        }
        jb.jb_f.w_mb = n2;
        wj.Mb.w_mb -= jb.jb_f.w_mb;
        jb.jb_f.w_vb -= jb.jb_f.w_mb;
    }

    public static void c(byte by) {
        y = null;
        cl_v = null;
        B = null;
        cl_r = null;
        if (by != -39) {
            return;
        }
        C = null;
        cl_n = null;
        cl_s = null;
    }

    static final void a(boolean bl) {
        long l;
        boolean bl2 = client.A;
        int n2 = fc.fc_a;
        int n3 = 0;
        if (bc.B == 2 && -1 < ~(n3 = (int)((10999L - (l = ik.a(4) - di.F)) / 1000L))) {
            n3 = 0;
        }
        int n4 = 0;
        if (!bl) {
            B = null;
        }
        while (n4 < rk.P.length) {
            int n5;
            int n6;
            int n7 = k.k_g[n4];
            int n8 = 0 <= n7 ? (n7 == k.k_f.sk_h ? gn.gn_a : wa.wa_c) : wm.wm_l;
            String string = rk.P[n4];
            if (~bc.B == -3 && ~n3 == -2) {
                int n9 = n6 = vb.U.length > tg.tg_g.length ? vb.U.length : tg.tg_g.length;
                if (n4 >= 6 && ~(n6 + 6) < ~n4) {
                    string = -n6 + n4 - (6 - tg.tg_g.length) >= 0 ? tg.tg_g[-6 + (n4 - -tg.tg_g.length - n6)] : "";
                }
                int n10 = n5 = wb.Qb.length > dh.dh_b.length ? wb.Qb.length : dh.dh_b.length;
                if (~(n6 + 7) >= ~n4 && n5 + 7 + n6 > n4) {
                    String string2 = string = -7 + (n4 - n6) < dh.dh_b.length ? dh.dh_b[-7 + n4 + -n6] : "";
                }
            }
            if (n7 == -2) {
                string = Integer.toString(n3);
            }
            n6 = si.a(false, string, ~n7 <= -1);
            n5 = -(n6 >> -906219967) + qk.qk_d;
            if (~n7 <= -1) {
                cc cc2;
                n2 += qk.qk_m;
                cc cc3 = cc2 = ~k.k_f.sk_h == ~n7 ? nf.nf_g : da.da_c;
                if (null != cc2) {
                    cc2.a(n6 - -(mb.mb_c << -795183135), 102, n5 + -mb.mb_c, n2, (pa.Y << 327376481) + cc.cc_a);
                }
                n2 += pa.Y;
            }
            if (0 > n7) {
                rk.R.a(string, n5, nd.nd_b + n2, n8, -1);
                n2 += ke.ke_d;
            } else {
                bg.bg_g.a(string, n5, a.a_k + n2, n8, -1);
                n2 += pa.Y - (-qk.qk_m - cc.cc_a);
            }
            ++n4;
        }
    }

    static final void a(hl hl2, boolean bl) {
        boolean bl2 = client.A;
        if (hl2.hl_h == null) {
            return;
        }
        if (!bl) {
            cl.c((byte)-122);
        }
        if (~hl2.hl_i != -1 || ~hl2.hl_n != -1) {
            for (int i2 = 0; i2 < ic.ic_c; ++i2) {
                hl hl3 = pd.pd_g[i2];
                if (-3 != ~hl3.hl_m || ~hl3.hl_i != ~hl2.hl_i || ~hl3.hl_n != ~hl2.hl_n) continue;
                return;
            }
        }
        if (hl2.hl_q != null) {
            wf.wf_o = hl2.hl_q;
            he.Y = hl2.hl_o;
            uh.uh_d = hl2.hl_m;
            ng.ng_a = hl2.hl_r;
        }
        rb.a(hl2, -3);
    }

    cl() {
    }

    static {
        cl_s = "Rated game";
    }
}
