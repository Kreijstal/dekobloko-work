/*
 * Decompiled with CFR 0.152.
 */
final class dm {
    static he dm_c;
    static f dm_b;
    static int dm_a;
    static int dm_d;

    static final w a(byte by) {
        block0: {
            if (by > 95) break block0;
            dm.a(-23);
        }
        return ge.ge_f.Sb;
    }

    public static void a(int n) {
        dm_b = null;
        dm_c = null;
        int n2 = -77 / ((69 - n) / 33);
    }
}
