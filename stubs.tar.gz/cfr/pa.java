/*
 * Decompiled with CFR 0.152.
 */
final class pa
extends qi {
    static af V;
    static volatile int pa_bb;
    static int Z;
    private int pa_cb;
    static int Y;
    private nb X;
    static ck U;
    private ck pa_eb;
    static String[] pa_db;
    private String pa_ab;
    static String[] pa_gb;
    static int pa_fb;
    static String W;

    pa(nb nb2, String string, int n, int n2, int n3, int n4) {
        super(string, vh.a(1424));
        this.pa_ab = string;
        this.X = nb2;
        this.b(n4, n3, n, n2, -16555);
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        block9: {
            int n5;
            int n6;
            block7: {
                tb tb2;
                block8: {
                    String string;
                    boolean bl = client.A;
                    tb2 = this.X.a(20350);
                    if (tb2 == le.le_o || jb.jb_j == tb2) {
                        string = qi.T;
                    } else {
                        string = this.X.b((byte)107);
                        if (string == null) {
                            string = this.pa_ab;
                        }
                    }
                    if (!string.equals(this.E)) {
                        this.E = string;
                        this.a(2874);
                    }
                    super.a(n, -105, n3, n4);
                    tb2 = this.X.a(20350);
                    nl nl2 = (nl)((Object)this.ce_p);
                    n6 = this.ce_u + n;
                    if (n2 >= -103) {
                        ce ce2 = null;
                        this.a(true, ce2);
                    }
                    n5 = nl2.a(n4, 0, this) + (nl2.a((ce)this, (byte)44).b(-1) >> -492294047);
                    if (le.le_o == tb2 || jb.jb_j == tb2) break block7;
                    if (tb2 != vm.vm_u) break block8;
                    ck ck2 = tl.tl_u[2];
                    ck2.f(n6, n5 - (ck2.H >> 1308895041), 256);
                    break block9;
                }
                if (tb2 != dc.dc_b) break block9;
                ck ck3 = tl.tl_u[1];
                ck3.f(n6, n5 + -(ck3.H >> -833126175), 256);
                break block9;
            }
            ck ck4 = tl.tl_u[0];
            int n7 = ck4.K << 519281857;
            int n8 = ck4.C << 422930689;
            if (this.pa_eb == null || ~n7 < ~this.pa_eb.I || n8 > this.pa_eb.H) {
                this.pa_eb = new ck(n7, n8);
                tb.a(true, this.pa_eb);
            } else {
                tb.a(true, this.pa_eb);
                hk.b();
            }
            ck4.a(112, 144, ck4.K << -1720750332, ck4.C << 122544644, -this.pa_cb << -138915254, 4096);
            mk.a((byte)-5);
            this.pa_eb.f(n6 - (ck4.K >> 476953697), n5 - ck4.C, 256);
        }
    }

    public static void h(byte by) {
        U = null;
        pa_db = null;
        pa_gb = null;
        if (by <= 19) {
            pa_bb = -63;
        }
        V = null;
        W = null;
    }

    static final int b(int n, int n2) {
        block1: {
            if (-5 < ~n) {
                throw new IllegalArgumentException();
            }
            if (n2 > 45) break block1;
            W = null;
        }
        return 400 - -(50 * (-2 + n) * (n + -3));
    }

    @Override
    final boolean a(boolean bl, ce ce2) {
        return bl;
    }

    @Override
    final String c(byte by) {
        if (by == 113) {
            return null;
        }
        ce ce2 = null;
        this.a(ce2, -51, 86, -72);
        return null;
    }

    static final void g(byte by) {
        int n = (-640 + wj.Lb) / 2;
        int n2 = dl.M * dl.M;
        int n3 = n2 - lg.W * lg.W;
        int n4 = 50 / ((by - 51) / 46);
        g.R.a(199, 0, 90, -90 + (-120 + hk.hk_i) + -4, -(n3 * 199 / n2) + n);
        wm.wm_h.a(438, 0, 0, -4 + (hk.hk_i + -120), 202 + (n - -(438 * n3 / n2)));
    }

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        ++this.pa_cb;
        if (n <= 38) {
            pa_gb = null;
        }
        super.a(ce2, 109, n2, n3);
    }

    static {
        pa_bb = 0;
        Z = -1;
        V = new af();
        pa_gb = new String[]{"All other member expansions", "Loads more Achievements", "Full community features"};
        W = "Eight-bit";
    }
}
