/*
 * Decompiled with CFR 0.152.
 */
final class um {
    static String um_b = "Please enter your age in years";
    static int um_d = 65;
    static String um_e;
    static int um_a;
    static w[] um_c;

    um() {
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    static final byte[] a(int n, byte[] byArray, int n2, int n3) {
        byte[] byArray2;
        boolean bl = client.A;
        if (-1 > ~n2) {
            byte[] byArray3 = new byte[n3];
            byArray2 = byArray3;
            for (int i = 0; n3 > i; ++i) {
                byArray3[i] = byArray[n2 + i];
            }
        } else {
            byArray2 = byArray;
        }
        qe qe2 = new qe();
        qe2.b((byte)-44);
        qe2.a(255, byArray2, 8 * n3);
        byte[] byArray4 = new byte[64];
        qe2.a(64767752, n, byArray4);
        return byArray4;
    }

    static final int a(int n, int n2, int n3) {
        int n4 = n2 >> 143976848;
        if (n3 != 11469) {
            return 84;
        }
        int n5 = n2 & 0xFFFF;
        int n6 = n >> -1527702128;
        int n7 = n & 0xFFFF;
        return n * n4 - -(n5 * n6) + (n5 * n7 >> -1278714480);
    }

    final boolean b(int n) {
        if (n != 22277) {
            return false;
        }
        return this == nn.nn_c || this == of.of_a || this == wf.wf_u;
    }

    public static void a(int n) {
        um_c = null;
        if (n != 0) {
            um_e = null;
        }
        um_b = null;
        um_e = null;
    }

    static {
        um_a = 4;
        um_e = "If you are not, please change your password to something more obscure!";
    }
}
