/*
 * Decompiled with CFR 0.152.
 */
import java.util.Date;

final class jj {
    static String[] jj_d = new String[]{"Match shapes and try to keep your bucket clear.", "Use wildcards to match multiple shapes for big points!", "Keep solid shapes under control by repeatedly popping them.", "Have you noticed the special items? Make two or more shapes at the same time to get them!", "Solid shapes will now come back with a vengeance, getting larger each time. Use special items to keep your bucket under control!", "Danger looms! Try to empty your bucket as much as possible before this next theme ends...", "Special items will no longer save you. Try to hold on and grab as many points as possible!", "Congratulations, this is the last theme! Hint: get the best highscores by choosing and perfecting a different strategy for each theme..."};
    static String[] jj_a;
    static ta jj_f;
    static ji jj_c;
    static pi[] jj_e;
    static int jj_b;

    static long a(long l, long l2) {
        return l | l2;
    }

    static final int a(int n) {
        int n2 = -122 / ((n - -40) / 55);
        return new Date().getYear() + 1900;
    }

    public static void a(boolean bl) {
        jj_c = null;
        jj_e = null;
        if (bl) {
            jj_f = null;
        }
        jj_f = null;
        jj_a = null;
        jj_d = null;
    }
}
