/*
 * Decompiled with CFR 0.152.
 */
final class gb
extends w {
    static int[] Pb;
    static String gb_ac;
    private ck[] gb_cc;
    static boolean Zb;
    private qd[] Wb = new qd[256];
    static int Vb;
    private int gb_bc;
    private int Rb;
    private int Sb;
    private w gb_ec;
    private w Qb;
    private int Ub;
    private int[] Yb = new int[256];
    private int gb_dc = -2;
    private int Xb;
    static String Tb;
    private int Nb;
    static int Ob;

    final boolean f(int n) {
        if (~this.gb_dc != 1) {
            return false;
        }
        int n2 = -62 % ((-76 - n) / 48);
        if (wh.wh_c != 13) {
            return true;
        }
        this.gb_dc = -1;
        return true;
    }

    final int b(int n, boolean bl) {
        int n2;
        boolean bl2 = client.A;
        this.a(false, bl);
        if (!bl) {
            return -2;
        }
        for (n2 = 0; n2 < this.Rb; ++n2) {
            if (~this.Wb[n2].w_ob == -1) continue;
            return this.Yb[n2];
        }
        if (0 != ig.Yb) {
            return -1;
        }
        n2 = -1 / ((n - 52) / 63);
        return this.gb_dc;
    }

    final void b(int n, int n2, int n3, int n4, int n5) {
        int n6;
        boolean bl = client.A;
        if (0 == this.Rb) {
            this.Wb[this.Rb] = new qd(0L, null, null, this.Qb, null, on.on_i);
            this.Wb[this.Rb].W = 1;
            this.a(this.Wb[this.Rb], -16834);
            this.Yb[this.Rb] = -1;
            ++this.Rb;
        }
        int n7 = 0;
        int n8 = 0;
        while (~this.Rb < ~n8) {
            n6 = this.Wb[n8].b(this.Ub, this.Nb, 1940);
            if (~n7 > ~n6) {
                n7 = n6;
            }
            ++n8;
        }
        n8 = this.Rb * this.Xb + this.gb_bc - -this.gb_bc;
        n6 = vh.a(n5, -18265, n7 += this.Sb * 2, n2);
        int n9 = o.a(n4, 0, n8, n);
        this.a(n7, 0, n9, n8, n6);
        if (n3 < 38) {
            String string = null;
            this.a(string, -17, -15);
        }
        for (int i = 0; i < this.Rb; ++i) {
            this.Wb[i].a(this.Xb, this.Ub, this.Sb, this.gb_bc + this.Xb * i, -(this.Sb * 2) + n7, this.Nb, 500);
        }
    }

    static final void a(int n, String string) {
        rm.a((byte)73, string);
        if (n >= -68) {
            return;
        }
        wi.a(false, -106, jc.jc_a);
    }

    static final boolean a(int n, ji ji2, int n2, int n3) {
        byte[] byArray = ji2.a(n2, 108, n);
        if (n3 <= 34) {
            return true;
        }
        if (byArray == null) {
            return false;
        }
        eh.a((byte)-72, byArray);
        return true;
    }

    static final void a(int n, boolean bl2, byte by, int n2) {
        block5: {
            int n3;
            block4: {
                if (!jh.jh_h) {
                    return;
                }
                ie.ie_c.a(false, bl2);
                boolean bl3 = mg.mg_bc.f(-1);
                if (~ig.Yb != -1 && !bl3) {
                    bl2 = false;
                    qn.l(13);
                }
                if (bl2) {
                    mg.mg_bc.a(n2, n, -115);
                }
                if (bl3) {
                    ie.ie_c.a(false, bl2);
                }
                int n4 = -27 % ((by - -66) / 56);
                n3 = mg.mg_bc.g(-108) + mg.mg_bc.E;
                if (~n3 >= -641) break block4;
                l.l_f += 5;
                break block5;
            }
            if (n3 >= 635 || 0 >= l.l_f) break block5;
            l.l_f -= 5;
        }
    }

    final void a(int n, int n2, ck ck2, String string) {
        this.Wb[this.Rb] = new qd(0L, null, null, this.gb_ec, ck2, string);
        this.Wb[this.Rb].S = this.gb_cc;
        this.Wb[this.Rb].Gb = true;
        this.Wb[this.Rb].W = 1;
        this.a(this.Wb[this.Rb], -16834);
        this.Yb[this.Rb] = n2;
        if (n != 4193) {
            return;
        }
        ++this.Rb;
    }

    gb(gb gb2) {
        this(gb2, gb2.gb_cc, gb2.Qb, gb2.gb_ec, gb2.Sb, gb2.Ub, gb2.Nb, gb2.gb_bc, gb2.Xb);
    }

    gb(w w2, ck[] ckArray, w w3, w w4, int n, int n2, int n3, int n4, int n5) {
        super(0L, w2);
        this.gb_ec = w4;
        this.Sb = n;
        this.Xb = n5;
        this.Ub = n2;
        this.Nb = n3;
        this.Qb = w3;
        this.gb_cc = ckArray;
        this.gb_bc = n4;
    }

    final void a(String string, int n, int n2) {
        this.Wb[this.Rb] = new qd(0L, null, null, this.gb_ec, null, string);
        this.Wb[this.Rb].S = this.gb_cc;
        this.Wb[this.Rb].Gb = true;
        this.Wb[this.Rb].W = 1;
        int n3 = -81 / ((24 - n2) / 32);
        this.a(this.Wb[this.Rb], -16834);
        this.Yb[this.Rb] = n;
        ++this.Rb;
    }

    public static void e(int n) {
        block0: {
            gb_ac = null;
            Pb = null;
            Tb = null;
            if (n == -2) break block0;
            Vb = -46;
        }
    }

    static {
        gb_ac = "Join";
        Vb = 0;
        Tb = "Encouraging rule breaking";
        Pb = new int[12];
        Ob = Vb;
    }
}
