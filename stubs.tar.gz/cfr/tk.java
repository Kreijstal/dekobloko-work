/*
 * Decompiled with CFR 0.152.
 */
interface tk {
    public void a(int var1, int var2, int var3);
}
