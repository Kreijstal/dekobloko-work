/*
 * Decompiled with CFR 0.152.
 */
import java.util.Iterator;

final class cm
implements Iterator {
    private int cm_e;
    private bh cm_c;
    private bh cm_j = null;
    private si cm_k;
    static int[] cm_a;
    static int[] cm_h;
    static int[] cm_g;
    static int[] cm_b;
    static String cm_i;
    static String cm_d;
    static ie cm_f;

    public final Object next() {
        bh bh2;
        boolean bl = client.A;
        if (this.cm_c != this.cm_k.si_h[this.cm_e + -1]) {
            bh bh3 = this.cm_c;
            this.cm_c = bh3.bh_b;
            this.cm_j = bh3;
            return bh3;
        }
        do {
            if (this.cm_k.si_a > this.cm_e) continue;
            return null;
        } while ((bh2 = this.cm_k.si_h[this.cm_e++].bh_b) == this.cm_k.si_h[-1 + this.cm_e]);
        this.cm_c = bh2.bh_b;
        this.cm_j = bh2;
        return bh2;
    }

    static final void a(byte by) {
        boolean bl = client.A;
        uf uf2 = de.V;
        if (by != 53) {
            cm.a(20);
        }
        int n = uf2.d((byte)-44);
        int n2 = uf2.d((byte)-117);
        if (~n == -1) {
            sb sb2 = (sb)ef.S.c((byte)-68);
            if (null == sb2) {
                si.a(78);
                return;
            }
            int n3 = sm.sm_e - uf2.wl_n;
            int[] nArray = sb2.sb_q;
            if (nArray.length << 1327655874 < n3) {
                n3 = nArray.length << -816484830;
            }
            for (int i = 0; i < n3; ++i) {
                int n4 = i >> -1175205182;
                nArray[n4] = nArray[n4] + (uf2.d((byte)-108) << (lb.a(3, i) << 1714134600));
            }
            sb2.sb_s = true;
            sb2.b((byte)118);
        } else if (n == 1) {
            ff ff2;
            int n5 = uf2.e((byte)-2);
            ff ff3 = ff2 = (ff)cd.cd_c.c((byte)-124);
            while (null != ff2 && (n2 != ff2.ff_q || ~n5 != ~ff2.ff_r)) {
                ff3 = (ff)cd.cd_c.d(true);
            }
            if (null == ff3) {
                si.a(71);
                return;
            }
            ff3.b((byte)124);
        } else {
            qb.a(null, 16408, "LR1: " + qk.d((byte)74));
            si.a(100);
        }
    }

    private final void b(byte by) {
        int n = 4 / ((-61 - by) / 36);
        this.cm_e = 1;
        this.cm_j = null;
        this.cm_c = this.cm_k.si_h[0].bh_b;
    }

    @Override
    public final boolean hasNext() {
        boolean bl = client.A;
        if (this.cm_c != this.cm_k.si_h[-1 + this.cm_e]) {
            return true;
        }
        while (this.cm_e < this.cm_k.si_a) {
            if (this.cm_k.si_h[this.cm_e++].bh_b != this.cm_k.si_h[this.cm_e - 1]) {
                this.cm_c = this.cm_k.si_h[-1 + this.cm_e].bh_b;
                return true;
            }
            this.cm_c = this.cm_k.si_h[this.cm_e + -1];
        }
        return false;
    }

    public static void a(int n) {
        block0: {
            cm_h = null;
            cm_f = null;
            cm_b = null;
            cm_g = null;
            cm_a = null;
            cm_i = null;
            cm_d = null;
            if (n == 1714134600) break block0;
            cm_a = null;
        }
    }

    @Override
    public final void remove() {
        if (this.cm_j == null) {
            throw new IllegalStateException();
        }
        this.cm_j.b((byte)112);
        this.cm_j = null;
    }

    static final String a(byte by, String string, String[] stringArray) {
        int n;
        int n2;
        int n3;
        boolean bl = client.A;
        int n4 = n3 = string.length();
        int n5 = 0;
        while (~(n2 = string.indexOf("<%", n5)) <= -1) {
            for (n5 = 2 + n2; n5 < n3 && fl.a(string.charAt(n5), (byte)23); ++n5) {
            }
            String string2 = string.substring(2 + n2, n5);
            if (!be.a((byte)98, string2) || n3 <= n5 || string.charAt(n5) != '>') continue;
            n = cb.a((byte)-72, string2);
            n4 += n2 - (++n5 - stringArray[n].length());
        }
        StringBuilder stringBuilder = new StringBuilder(n4);
        n5 = 0;
        if (by <= 80) {
            cm.a((byte)-121);
        }
        int n6 = 0;
        while (~(n = string.indexOf("<%", n5)) <= -1) {
            n5 = n - -2;
            while (~n3 < ~n5 && fl.a(string.charAt(n5), (byte)23)) {
                ++n5;
            }
            String string3 = string.substring(2 + n, n5);
            if (!be.a((byte)98, string3) || ~n5 <= ~n3 || string.charAt(n5) != '>') continue;
            int n7 = cb.a((byte)100, string3);
            stringBuilder.append(string.substring(n6, n));
            n6 = ++n5;
            stringBuilder.append(stringArray[n7]);
        }
        stringBuilder.append(string.substring(n6));
        return stringBuilder.toString();
    }

    cm(si si2) {
        this.cm_k = si2;
        this.b((byte)-117);
    }

    static {
        int n;
        int[] nArray;
        cm_a = b.h(-126);
        cm_h = b.h(80);
        cm_g = b.h(-125);
        cm_b = b.h(86);
        int n2 = 0;
        while (~n2 > -16) {
            nArray = cm_a;
            n = n2++;
            nArray[n >> -1741755611] = de.b(nArray[n >> -1741755611], 1 << lb.a(n, 31));
        }
        n2 = 15;
        while (31 > n2) {
            nArray = cm_h;
            n = n2++;
            nArray[n >> 342484197] = de.b(nArray[n >> 342484197], 1 << lb.a(31, n));
        }
        int[] nArray2 = cm_g;
        nArray2[0] = de.b(nArray2[0], 8);
        int[] nArray3 = cm_g;
        nArray3[0] = de.b(nArray3[0], 128);
        int[] nArray4 = cm_g;
        nArray4[0] = de.b(nArray4[0], 0x400000);
        int[] nArray5 = cm_b;
        nArray5[0] = de.b(nArray5[0], 1);
        int[] nArray6 = cm_b;
        nArray6[0] = de.b(nArray6[0], 2048);
        cm_i = "Creating your account";
        cm_d = "Connection lost. <%0>";
    }
}
