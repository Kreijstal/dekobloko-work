/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

final class kj {
    private hj kj_q;
    int kj_r = 500;
    private sd kj_b;
    private sd y;
    private sd kj_a;
    private static int[] kj_c;
    private sd kj_s;
    private sd kj_f;
    private static int[] kj_j;
    private int[] kj_g = new int[]{0, 0, 0, 0, 0};
    private sd kj_v;
    private sd kj_n;
    private sd kj_l;
    int kj_h = 0;
    private int[] kj_i = new int[]{0, 0, 0, 0, 0};
    private int kj_o = 0;
    private static int[] kj_u;
    private int[] kj_e = new int[]{0, 0, 0, 0, 0};
    private sd kj_k;
    private static int[] kj_w;
    private int kj_t = 100;
    private static int[] x;
    private static int[] kj_m;
    private static int[] kj_d;
    private static int[] kj_p;

    public static void a() {
        kj_c = null;
        kj_u = null;
        kj_j = null;
        kj_w = null;
        x = null;
        kj_d = null;
        kj_m = null;
        kj_p = null;
    }

    final int[] a(int n, int n2) {
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        an.a(kj_c, 0, n);
        if (n2 < 10) {
            return kj_c;
        }
        double d = (double)n / ((double)n2 + 0.0);
        this.kj_b.a();
        this.kj_n.a();
        int n9 = 0;
        int n10 = 0;
        int n11 = 0;
        if (this.y != null) {
            this.y.a();
            this.kj_a.a();
            n9 = (int)((double)(this.y.sd_i - this.y.sd_e) * 32.768 / d);
            n10 = (int)((double)this.y.sd_e * 32.768 / d);
        }
        int n12 = 0;
        int n13 = 0;
        int n14 = 0;
        if (this.kj_f != null) {
            this.kj_f.a();
            this.kj_v.a();
            n12 = (int)((double)(this.kj_f.sd_i - this.kj_f.sd_e) * 32.768 / d);
            n13 = (int)((double)this.kj_f.sd_e * 32.768 / d);
        }
        for (n8 = 0; n8 < 5; ++n8) {
            if (this.kj_g[n8] == 0) continue;
            kj.kj_w[n8] = 0;
            kj.x[n8] = (int)((double)this.kj_i[n8] * d);
            kj.kj_d[n8] = (this.kj_g[n8] << 14) / 100;
            kj.kj_m[n8] = (int)((double)(this.kj_b.sd_i - this.kj_b.sd_e) * 32.768 * Math.pow(1.0057929410678534, this.kj_e[n8]) / d);
            kj.kj_p[n8] = (int)((double)this.kj_b.sd_e * 32.768 / d);
        }
        for (n8 = 0; n8 < n; ++n8) {
            n7 = this.kj_b.a(n);
            n6 = this.kj_n.a(n);
            if (this.y != null) {
                n5 = this.y.a(n);
                n4 = this.kj_a.a(n);
                n7 += this.a(n11, n4, this.y.sd_a) >> 1;
                n11 += (n5 * n9 >> 16) + n10;
            }
            if (this.kj_f != null) {
                n5 = this.kj_f.a(n);
                n4 = this.kj_v.a(n);
                n6 = n6 * ((this.a(n14, n4, this.kj_f.sd_a) >> 1) + 32768) >> 15;
                n14 += (n5 * n12 >> 16) + n13;
            }
            for (n5 = 0; n5 < 5; ++n5) {
                if (this.kj_g[n5] == 0 || (n4 = n8 + x[n5]) >= n) continue;
                int n15 = n4;
                kj_c[n15] = kj_c[n15] + this.a(kj_w[n5], n6 * kj_d[n5] >> 15, this.kj_b.sd_a);
                int n16 = n5;
                kj_w[n16] = kj_w[n16] + ((n7 * kj_m[n5] >> 16) + kj_p[n5]);
            }
        }
        if (this.kj_s != null) {
            this.kj_s.a();
            this.kj_l.a();
            n8 = 0;
            n7 = 0;
            n6 = 1;
            for (n5 = 0; n5 < n; ++n5) {
                n4 = this.kj_s.a(n);
                n3 = this.kj_l.a(n);
                n7 = n6 != 0 ? this.kj_s.sd_e + ((this.kj_s.sd_i - this.kj_s.sd_e) * n4 >> 8) : this.kj_s.sd_e + ((this.kj_s.sd_i - this.kj_s.sd_e) * n3 >> 8);
                if ((n8 += 256) >= n7) {
                    n8 = 0;
                    int n17 = n6 = n6 == 0 ? 1 : 0;
                }
                if (n6 == 0) continue;
                kj.kj_c[n5] = 0;
            }
        }
        if (this.kj_o > 0 && this.kj_t > 0) {
            for (n7 = n8 = (int)((double)this.kj_o * d); n7 < n; ++n7) {
                int n18 = n7;
                kj_c[n18] = kj_c[n18] + kj_c[n7 - n8] * this.kj_t / 100;
            }
        }
        if (this.kj_q.hj_g[0] > 0 || this.kj_q.hj_g[1] > 0) {
            this.kj_k.a();
            n8 = this.kj_k.a(n + 1);
            n7 = this.kj_q.a(0, (float)n8 / 65536.0f);
            n6 = this.kj_q.a(1, (float)n8 / 65536.0f);
            if (n >= n7 + n6) {
                int n19;
                n5 = 0;
                n4 = n6;
                if (n4 > n - n7) {
                    n4 = n - n7;
                }
                while (n5 < n4) {
                    n3 = (int)((long)kj_c[n5 + n7] * (long)hj.hj_d >> 16);
                    for (n19 = 0; n19 < n7; ++n19) {
                        n3 += (int)((long)kj_c[n5 + n7 - 1 - n19] * (long)hj.hj_a[0][n19] >> 16);
                    }
                    for (n19 = 0; n19 < n5; ++n19) {
                        n3 -= (int)((long)kj_c[n5 - 1 - n19] * (long)hj.hj_a[1][n19] >> 16);
                    }
                    kj.kj_c[n5] = n3;
                    n8 = this.kj_k.a(n + 1);
                    ++n5;
                }
                n4 = 128;
                while (true) {
                    if (n4 > n - n7) {
                        n4 = n - n7;
                    }
                    while (n5 < n4) {
                        n3 = (int)((long)kj_c[n5 + n7] * (long)hj.hj_d >> 16);
                        for (n19 = 0; n19 < n7; ++n19) {
                            n3 += (int)((long)kj_c[n5 + n7 - 1 - n19] * (long)hj.hj_a[0][n19] >> 16);
                        }
                        for (n19 = 0; n19 < n6; ++n19) {
                            n3 -= (int)((long)kj_c[n5 - 1 - n19] * (long)hj.hj_a[1][n19] >> 16);
                        }
                        kj.kj_c[n5] = n3;
                        n8 = this.kj_k.a(n + 1);
                        ++n5;
                    }
                    if (n5 >= n - n7) break;
                    n7 = this.kj_q.a(0, (float)n8 / 65536.0f);
                    n6 = this.kj_q.a(1, (float)n8 / 65536.0f);
                    n4 += 128;
                }
                while (n5 < n) {
                    n3 = 0;
                    for (n19 = n5 + n7 - n; n19 < n7; ++n19) {
                        n3 += (int)((long)kj_c[n5 + n7 - 1 - n19] * (long)hj.hj_a[0][n19] >> 16);
                    }
                    for (n19 = 0; n19 < n6; ++n19) {
                        n3 -= (int)((long)kj_c[n5 - 1 - n19] * (long)hj.hj_a[1][n19] >> 16);
                    }
                    kj.kj_c[n5] = n3;
                    n8 = this.kj_k.a(n + 1);
                    ++n5;
                }
            }
        }
        for (n8 = 0; n8 < n; ++n8) {
            if (kj_c[n8] < Short.MIN_VALUE) {
                kj.kj_c[n8] = Short.MIN_VALUE;
            }
            if (kj_c[n8] <= Short.MAX_VALUE) continue;
            kj.kj_c[n8] = Short.MAX_VALUE;
        }
        return kj_c;
    }

    private final int a(int n, int n2, int n3) {
        if (n3 == 1) {
            if ((n & Short.MAX_VALUE) < 16384) {
                return n2;
            }
            return -n2;
        }
        if (n3 == 2) {
            return kj_j[n & Short.MAX_VALUE] * n2 >> 14;
        }
        if (n3 == 3) {
            return ((n & Short.MAX_VALUE) * n2 >> 14) - n2;
        }
        if (n3 == 4) {
            return kj_u[n / 2607 & Short.MAX_VALUE] * n2;
        }
        return 0;
    }

    final void a(wl wl2) {
        int n;
        this.kj_b = new sd();
        this.kj_b.b(wl2);
        this.kj_n = new sd();
        this.kj_n.b(wl2);
        int n2 = wl2.d((byte)-127);
        if (n2 != 0) {
            --wl2.wl_n;
            this.y = new sd();
            this.y.b(wl2);
            this.kj_a = new sd();
            this.kj_a.b(wl2);
        }
        if ((n2 = wl2.d((byte)-31)) != 0) {
            --wl2.wl_n;
            this.kj_f = new sd();
            this.kj_f.b(wl2);
            this.kj_v = new sd();
            this.kj_v.b(wl2);
        }
        if ((n2 = wl2.d((byte)-89)) != 0) {
            --wl2.wl_n;
            this.kj_s = new sd();
            this.kj_s.b(wl2);
            this.kj_l = new sd();
            this.kj_l.b(wl2);
        }
        for (int i = 0; i < 10 && (n = wl2.a(false)) != 0; ++i) {
            this.kj_g[i] = n;
            this.kj_e[i] = wl2.e((byte)126);
            this.kj_i[i] = wl2.a(false);
        }
        this.kj_o = wl2.a(false);
        this.kj_t = wl2.a(false);
        this.kj_r = wl2.e(3);
        this.kj_h = wl2.e(3);
        this.kj_q = new hj();
        this.kj_k = new sd();
        this.kj_q.a(wl2, this.kj_k);
    }

    kj() {
    }

    static {
        int n;
        kj_u = new int[32768];
        Random random = new Random(0L);
        for (n = 0; n < 32768; ++n) {
            kj.kj_u[n] = (random.nextInt() & 2) - 1;
        }
        kj_j = new int[32768];
        for (n = 0; n < 32768; ++n) {
            kj.kj_j[n] = (int)(Math.sin((double)n / 5215.1903) * 16384.0);
        }
        kj_c = new int[220500];
        kj_w = new int[5];
        x = new int[5];
        kj_m = new int[5];
        kj_d = new int[5];
        kj_p = new int[5];
    }
}
