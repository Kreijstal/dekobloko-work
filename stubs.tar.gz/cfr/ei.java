/*
 * Decompiled with CFR 0.152.
 */
final class ei
extends ol {
    private int G;
    private int y;
    private int ei_v;
    private int ei_r;
    private int F;
    private int ei_t;
    private int z;
    private boolean B;
    private int A;
    private int D;
    private int ei_s;
    private int x;
    private int ei_u;
    private int ei_w;
    private int C;

    private final synchronized int h() {
        return this.ei_w < 0 ? -1 : this.ei_w;
    }

    private final synchronized void b(int n, int n2) {
        this.F = n;
        this.ei_w = n2;
        this.A = 0;
        this.f();
    }

    static final ei c(ud ud2, int n, int n2, int n3) {
        if (ud2.ud_o == null) {
            return null;
        }
        if (ud2.ud_o.length == 0) {
            return null;
        }
        return new ei(ud2, (int)((long)ud2.ud_p * 256L * (long)n / (long)(100 * en.en_o)), n2, n3);
    }

    private static final int a(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, ei ei2, int n9, int n10) {
        if (n9 == 0 || (n6 = n4 + (n8 + 256 - n3 + n9) / n9) > n7) {
            n6 = n7;
        }
        while (n4 < n6) {
            n2 = n3 >> 8;
            n = byArray[n2 - 1];
            int n11 = n4++;
            nArray[n11] = nArray[n11] + (((n << 8) + (byArray[n2] - n) * (n3 & 0xFF)) * n5 >> 6);
            n3 += n9;
        }
        if (n9 == 0 || (n6 = n4 + (n8 - n3 + n9) / n9) > n7) {
            n6 = n7;
        }
        n = n10;
        n2 = n9;
        while (n4 < n6) {
            int n12 = n4++;
            nArray[n12] = nArray[n12] + (((n << 8) + (byArray[n3 >> 8] - n) * (n3 & 0xFF)) * n5 >> 6);
            n3 += n2;
        }
        ei2.x = n3;
        return n4;
    }

    private static final int b(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, ei ei2, int n9, int n10) {
        if (n9 == 0 || (n6 = n4 + (n8 - n3 + n9 - 257) / n9) > n7) {
            n6 = n7;
        }
        while (n4 < n6) {
            n2 = n3 >> 8;
            n = byArray[n2];
            int n11 = n4++;
            nArray[n11] = nArray[n11] + (((n << 8) + (byArray[n2 + 1] - n) * (n3 & 0xFF)) * n5 >> 6);
            n3 += n9;
        }
        if (n9 == 0 || (n6 = n4 + (n8 - n3 + n9 - 1) / n9) > n7) {
            n6 = n7;
        }
        n2 = n10;
        while (n4 < n6) {
            n = byArray[n3 >> 8];
            int n12 = n4++;
            nArray[n12] = nArray[n12] + (((n << 8) + (n2 - n) * (n3 & 0xFF)) * n5 >> 6);
            n3 += n9;
        }
        ei2.x = n3;
        return n4;
    }

    private static final int c(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, int n9, ei ei2, int n10, int n11) {
        ei2.C -= ei2.ei_s * n4;
        ei2.ei_u -= ei2.ei_r * n4;
        if (n10 == 0 || (n7 = n4 + (n9 - n3 + n10 - 257) / n10) > n8) {
            n7 = n8;
        }
        while (n4 < n7) {
            n2 = n3 >> 8;
            n = byArray[n2];
            int n12 = n4++;
            nArray[n12] = nArray[n12] + (((n << 8) + (byArray[n2 + 1] - n) * (n3 & 0xFF)) * n5 >> 6);
            n5 += n6;
            n3 += n10;
        }
        if (n10 == 0 || (n7 = n4 + (n9 - n3 + n10 - 1) / n10) > n8) {
            n7 = n8;
        }
        n2 = n11;
        while (n4 < n7) {
            n = byArray[n3 >> 8];
            int n13 = n4++;
            nArray[n13] = nArray[n13] + (((n << 8) + (n2 - n) * (n3 & 0xFF)) * n5 >> 6);
            n5 += n6;
            n3 += n10;
        }
        ei2.C += ei2.ei_s * n4;
        ei2.ei_u += ei2.ei_r * n4;
        ei2.ei_v = n5;
        ei2.x = n3;
        return n4;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    final synchronized void b(int[] nArray, int n, int n2) {
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        ud ud2;
        block36: {
            block37: {
                block33: {
                    block35: {
                        block31: {
                            block32: {
                                block30: {
                                    block34: {
                                        block28: {
                                            block29: {
                                                if (this.F == 0 && this.A == 0) {
                                                    this.a(n2);
                                                    return;
                                                }
                                                ud2 = (ud)this.ol_q;
                                                n7 = this.G << 8;
                                                n6 = this.y << 8;
                                                n5 = ud2.ud_o.length << 8;
                                                n4 = n6 - n7;
                                                if (n4 <= 0) {
                                                    this.D = 0;
                                                }
                                                n3 = n;
                                                n2 += n;
                                                if (this.x < 0) {
                                                    if (this.z <= 0) {
                                                        this.e();
                                                        this.b((byte)121);
                                                        return;
                                                    }
                                                    this.x = 0;
                                                }
                                                if (this.x >= n5) {
                                                    if (this.z >= 0) {
                                                        this.e();
                                                        this.b((byte)113);
                                                        return;
                                                    }
                                                    this.x = n5 - 1;
                                                }
                                                if (this.D >= 0) break block28;
                                                if (!this.B) break block29;
                                                if (this.z < 0) {
                                                    n3 = this.a(nArray, n3, n7, n2, ud2.ud_o[this.G]);
                                                    if (this.x >= n7) {
                                                        return;
                                                    }
                                                    this.x = n7 + n7 - 1 - this.x;
                                                    this.z = -this.z;
                                                }
                                                break block30;
                                            }
                                            if (this.z >= 0) break block31;
                                            break block32;
                                        }
                                        if (this.D <= 0) break block33;
                                        if (!this.B) break block34;
                                        if (this.z >= 0) break block35;
                                        n3 = this.a(nArray, n3, n7, n2, ud2.ud_o[this.G]);
                                        if (this.x >= n7) {
                                            return;
                                        }
                                        this.x = n7 + n7 - 1 - this.x;
                                        this.z = -this.z;
                                        if (--this.D != 0) break block35;
                                        break block33;
                                    }
                                    if (this.z >= 0) break block36;
                                    break block37;
                                }
                                while (true) {
                                    n3 = this.b(nArray, n3, n6, n2, ud2.ud_o[this.y - 1]);
                                    if (this.x < n6) {
                                        return;
                                    }
                                    this.x = n6 + n6 - 1 - this.x;
                                    this.z = -this.z;
                                    n3 = this.a(nArray, n3, n7, n2, ud2.ud_o[this.G]);
                                    if (this.x >= n7) {
                                        return;
                                    }
                                    this.x = n7 + n7 - 1 - this.x;
                                    this.z = -this.z;
                                }
                            }
                            while (true) {
                                n3 = this.a(nArray, n3, n7, n2, ud2.ud_o[this.y - 1]);
                                if (this.x >= n7) {
                                    return;
                                }
                                this.x = n6 - 1 - (n6 - 1 - this.x) % n4;
                            }
                        }
                        while (true) {
                            n3 = this.b(nArray, n3, n6, n2, ud2.ud_o[this.G]);
                            if (this.x < n6) {
                                return;
                            }
                            this.x = n7 + (this.x - n7) % n4;
                        }
                    }
                    do {
                        n3 = this.b(nArray, n3, n6, n2, ud2.ud_o[this.y - 1]);
                        if (this.x < n6) {
                            return;
                        }
                        this.x = n6 + n6 - 1 - this.x;
                        this.z = -this.z;
                        if (--this.D == 0) break;
                        n3 = this.a(nArray, n3, n7, n2, ud2.ud_o[this.G]);
                        if (this.x >= n7) {
                            return;
                        }
                        this.x = n7 + n7 - 1 - this.x;
                        this.z = -this.z;
                    } while (--this.D != 0);
                }
                if (this.z < 0) {
                    this.a(nArray, n3, 0, n2, 0);
                    if (this.x >= 0) return;
                    this.x = -1;
                    this.e();
                    this.b((byte)124);
                    return;
                }
                this.b(nArray, n3, n5, n2, 0);
                if (this.x < n5) return;
                this.x = n5;
                this.e();
                this.b((byte)123);
                return;
            }
            while (true) {
                n3 = this.a(nArray, n3, n7, n2, ud2.ud_o[this.y - 1]);
                if (this.x >= n7) {
                    return;
                }
                int n8 = (n6 - 1 - this.x) / n4;
                if (n8 >= this.D) {
                    this.x += n4 * this.D;
                    this.D = 0;
                    if (this.z < 0) {
                        this.a(nArray, n3, 0, n2, 0);
                        if (this.x >= 0) return;
                        this.x = -1;
                        this.e();
                        this.b((byte)124);
                        return;
                    }
                    this.b(nArray, n3, n5, n2, 0);
                    if (this.x < n5) return;
                    this.x = n5;
                    this.e();
                    this.b((byte)123);
                    return;
                }
                this.x += n4 * n8;
                this.D -= n8;
            }
        }
        while (true) {
            n3 = this.b(nArray, n3, n6, n2, ud2.ud_o[this.G]);
            if (this.x < n6) {
                return;
            }
            int n9 = (this.x - n7) / n4;
            if (n9 >= this.D) {
                this.x -= n4 * this.D;
                this.D = 0;
                if (this.z < 0) {
                    this.a(nArray, n3, 0, n2, 0);
                    if (this.x >= 0) return;
                    this.x = -1;
                    this.e();
                    this.b((byte)124);
                    return;
                }
                this.b(nArray, n3, n5, n2, 0);
                if (this.x < n5) return;
                this.x = n5;
                this.e();
                this.b((byte)123);
                return;
            }
            this.x -= n4 * n9;
            this.D -= n9;
        }
    }

    final synchronized void a(boolean bl) {
        this.B = bl;
    }

    @Override
    final ol c() {
        return null;
    }

    private final int a(int[] nArray, int n, int n2, int n3, int n4) {
        while (this.A > 0) {
            int n5 = n + this.A;
            if (n5 > n3) {
                n5 = n3;
            }
            this.A += n;
            n = this.z == -256 && (this.x & 0xFF) == 0 ? (en.en_u ? ei.b(0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, this.ei_s, this.ei_r, 0, n5, n2, this) : ei.a(((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, this.ei_t, 0, n5, n2, this)) : (en.en_u ? ei.b(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, this.ei_s, this.ei_r, 0, n5, n2, this, this.z, n4) : ei.b(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, this.ei_t, 0, n5, n2, this, this.z, n4));
            this.A -= n;
            if (this.A != 0) {
                return n;
            }
            if (!this.g()) continue;
            return n3;
        }
        if (this.z == -256 && (this.x & 0xFF) == 0) {
            if (en.en_u) {
                return ei.a(0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, 0, n3, n2, this);
            }
            return ei.b(((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, 0, n3, n2, this);
        }
        if (en.en_u) {
            return ei.d(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, 0, n3, n2, this, this.z, n4);
        }
        return ei.a(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, 0, n3, n2, this, this.z, n4);
    }

    static final ei a(ud ud2, int n, int n2, int n3) {
        if (ud2.ud_o == null) {
            return null;
        }
        if (ud2.ud_o.length == 0) {
            return null;
        }
        return new ei(ud2, n, n2, n3);
    }

    private static final int b(int n, byte[] byArray, int[] nArray, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, ei ei2) {
        n4 <<= 2;
        n5 <<= 2;
        n6 <<= 2;
        n7 <<= 2;
        n8 = n3 + (n2 >>= 8) - ((n10 >>= 8) - 1);
        if (n8 > n9) {
            n8 = n9;
        }
        ei2.ei_v += ei2.ei_t * (n8 - n3);
        n3 <<= 1;
        n8 <<= 1;
        n8 -= 6;
        while (n3 < n8) {
            n = byArray[n2--];
            int n11 = n3++;
            nArray[n11] = nArray[n11] + n * n4;
            n4 += n6;
            int n12 = n3++;
            nArray[n12] = nArray[n12] + n * n5;
            n5 += n7;
            n = byArray[n2--];
            int n13 = n3++;
            nArray[n13] = nArray[n13] + n * n4;
            n4 += n6;
            int n14 = n3++;
            nArray[n14] = nArray[n14] + n * n5;
            n5 += n7;
            n = byArray[n2--];
            int n15 = n3++;
            nArray[n15] = nArray[n15] + n * n4;
            n4 += n6;
            int n16 = n3++;
            nArray[n16] = nArray[n16] + n * n5;
            n5 += n7;
            n = byArray[n2--];
            int n17 = n3++;
            nArray[n17] = nArray[n17] + n * n4;
            n4 += n6;
            int n18 = n3++;
            nArray[n18] = nArray[n18] + n * n5;
            n5 += n7;
        }
        n8 += 6;
        while (n3 < n8) {
            n = byArray[n2--];
            int n19 = n3++;
            nArray[n19] = nArray[n19] + n * n4;
            n4 += n6;
            int n20 = n3++;
            nArray[n20] = nArray[n20] + n * n5;
            n5 += n7;
        }
        ei2.C = n4 >> 2;
        ei2.ei_u = n5 >> 2;
        ei2.x = n2 << 8;
        return n3 >> 1;
    }

    private final boolean g() {
        int n;
        int n2;
        int n3 = this.F;
        if (n3 == Integer.MIN_VALUE) {
            n2 = 0;
            n = 0;
            n3 = 0;
        } else {
            n = ei.d(n3, this.ei_w);
            n2 = ei.c(n3, this.ei_w);
        }
        if (this.ei_v != n3 || this.C != n || this.ei_u != n2) {
            if (this.ei_v < n3) {
                this.ei_t = 1;
                this.A = n3 - this.ei_v;
            } else if (this.ei_v > n3) {
                this.ei_t = -1;
                this.A = this.ei_v - n3;
            } else {
                this.ei_t = 0;
            }
            if (this.C < n) {
                this.ei_s = 1;
                if (this.A == 0 || this.A > n - this.C) {
                    this.A = n - this.C;
                }
            } else if (this.C > n) {
                this.ei_s = -1;
                if (this.A == 0 || this.A > this.C - n) {
                    this.A = this.C - n;
                }
            } else {
                this.ei_s = 0;
            }
            if (this.ei_u < n2) {
                this.ei_r = 1;
                if (this.A == 0 || this.A > n2 - this.ei_u) {
                    this.A = n2 - this.ei_u;
                    return false;
                }
            } else if (this.ei_u > n2) {
                this.ei_r = -1;
                if (this.A == 0 || this.A > this.ei_u - n2) {
                    this.A = this.ei_u - n2;
                }
            } else {
                this.ei_r = 0;
            }
            return false;
        }
        if (this.F == Integer.MIN_VALUE) {
            this.F = 0;
            this.ei_u = 0;
            this.C = 0;
            this.ei_v = 0;
            this.b((byte)101);
            return true;
        }
        this.f();
        return false;
    }

    final synchronized void f(int n, int n2) {
        this.G = n;
        this.y = n2;
    }

    private static final int a(byte[] byArray, int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, int n7, ei ei2) {
        n3 <<= 2;
        n4 <<= 2;
        n5 = n2 + (n >>= 8) - ((n7 >>= 8) - 1);
        if (n5 > n6) {
            n5 = n6;
        }
        ei2.C += ei2.ei_s * (n5 - n2);
        ei2.ei_u += ei2.ei_r * (n5 - n2);
        n5 -= 3;
        while (n2 < n5) {
            int n8 = n2++;
            nArray[n8] = nArray[n8] + byArray[n--] * n3;
            int n9 = n2++;
            nArray[n9] = nArray[n9] + byArray[n--] * (n3 += n4);
            int n10 = n2++;
            nArray[n10] = nArray[n10] + byArray[n--] * (n3 += n4);
            int n11 = n2++;
            nArray[n11] = nArray[n11] + byArray[n--] * (n3 += n4);
            n3 += n4;
        }
        n5 += 3;
        while (n2 < n5) {
            int n12 = n2++;
            nArray[n12] = nArray[n12] + byArray[n--] * n3;
            n3 += n4;
        }
        ei2.ei_v = n3 >> 2;
        ei2.x = n << 8;
        return n2;
    }

    private static final int a(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, int n9, ei ei2, int n10, int n11) {
        if (n10 == 0 || (n7 = n4 + (n9 - n3 + n10 - 257) / n10) > n8) {
            n7 = n8;
        }
        n4 <<= 1;
        n7 <<= 1;
        while (n4 < n7) {
            n2 = n3 >> 8;
            n = byArray[n2];
            n = (n << 8) + (byArray[n2 + 1] - n) * (n3 & 0xFF);
            int n12 = n4++;
            nArray[n12] = nArray[n12] + (n * n5 >> 6);
            int n13 = n4++;
            nArray[n13] = nArray[n13] + (n * n6 >> 6);
            n3 += n10;
        }
        if (n10 == 0 || (n7 = (n4 >> 1) + (n9 - n3 + n10 - 1) / n10) > n8) {
            n7 = n8;
        }
        n7 <<= 1;
        n2 = n11;
        while (n4 < n7) {
            n = byArray[n3 >> 8];
            n = (n << 8) + (n2 - n) * (n3 & 0xFF);
            int n14 = n4++;
            nArray[n14] = nArray[n14] + (n * n5 >> 6);
            int n15 = n4++;
            nArray[n15] = nArray[n15] + (n * n6 >> 6);
            n3 += n10;
        }
        ei2.x = n3;
        return n4 >> 1;
    }

    private static final int b(byte[] byArray, int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, int n7, ei ei2) {
        n3 <<= 2;
        n4 <<= 2;
        n5 = n2 + (n7 >>= 8) - (n >>= 8);
        if (n5 > n6) {
            n5 = n6;
        }
        ei2.C += ei2.ei_s * (n5 - n2);
        ei2.ei_u += ei2.ei_r * (n5 - n2);
        n5 -= 3;
        while (n2 < n5) {
            int n8 = n2++;
            nArray[n8] = nArray[n8] + byArray[n++] * n3;
            int n9 = n2++;
            nArray[n9] = nArray[n9] + byArray[n++] * (n3 += n4);
            int n10 = n2++;
            nArray[n10] = nArray[n10] + byArray[n++] * (n3 += n4);
            int n11 = n2++;
            nArray[n11] = nArray[n11] + byArray[n++] * (n3 += n4);
            n3 += n4;
        }
        n5 += 3;
        while (n2 < n5) {
            int n12 = n2++;
            nArray[n12] = nArray[n12] + byArray[n++] * n3;
            n3 += n4;
        }
        ei2.ei_v = n3 >> 2;
        ei2.x = n << 8;
        return n2;
    }

    final synchronized void a(int n, int n2, int n3) {
        this.b(n, n2 << 6, n3 << 6);
    }

    private static final int c(int n, int n2) {
        return n2 < 0 ? -n : (int)((double)n * Math.sqrt((double)n2 * 1.220703125E-4) + 0.5);
    }

    static final ei b(ud ud2, int n, int n2, int n3) {
        if (ud2.ud_o == null) {
            return null;
        }
        if (ud2.ud_o.length == 0) {
            return null;
        }
        return new ei(ud2, n, n2 << 6, n3 << 6);
    }

    private static final int a(byte[] byArray, int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, ei ei2) {
        n3 <<= 2;
        n4 = n2 + (n6 >>= 8) - (n >>= 8);
        if (n4 > n5) {
            n4 = n5;
        }
        n4 -= 3;
        while (n2 < n4) {
            int n7 = n2++;
            nArray[n7] = nArray[n7] + byArray[n++] * n3;
            int n8 = n2++;
            nArray[n8] = nArray[n8] + byArray[n++] * n3;
            int n9 = n2++;
            nArray[n9] = nArray[n9] + byArray[n++] * n3;
            int n10 = n2++;
            nArray[n10] = nArray[n10] + byArray[n++] * n3;
        }
        n4 += 3;
        while (n2 < n4) {
            int n11 = n2++;
            nArray[n11] = nArray[n11] + byArray[n++] * n3;
        }
        ei2.x = n << 8;
        return n2;
    }

    private final void f() {
        this.ei_v = this.F;
        this.C = ei.d(this.F, this.ei_w);
        this.ei_u = ei.c(this.F, this.ei_w);
    }

    private static final int a(int n, byte[] byArray, int[] nArray, int n2, int n3, int n4, int n5, int n6, int n7, int n8, ei ei2) {
        n4 <<= 2;
        n5 <<= 2;
        n6 = n3 + (n2 >>= 8) - ((n8 >>= 8) - 1);
        if (n6 > n7) {
            n6 = n7;
        }
        n3 <<= 1;
        n6 <<= 1;
        n6 -= 6;
        while (n3 < n6) {
            n = byArray[n2--];
            int n9 = n3++;
            nArray[n9] = nArray[n9] + n * n4;
            int n10 = n3++;
            nArray[n10] = nArray[n10] + n * n5;
            n = byArray[n2--];
            int n11 = n3++;
            nArray[n11] = nArray[n11] + n * n4;
            int n12 = n3++;
            nArray[n12] = nArray[n12] + n * n5;
            n = byArray[n2--];
            int n13 = n3++;
            nArray[n13] = nArray[n13] + n * n4;
            int n14 = n3++;
            nArray[n14] = nArray[n14] + n * n5;
            n = byArray[n2--];
            int n15 = n3++;
            nArray[n15] = nArray[n15] + n * n4;
            int n16 = n3++;
            nArray[n16] = nArray[n16] + n * n5;
        }
        n6 += 6;
        while (n3 < n6) {
            n = byArray[n2--];
            int n17 = n3++;
            nArray[n17] = nArray[n17] + n * n4;
            int n18 = n3++;
            nArray[n18] = nArray[n18] + n * n5;
        }
        ei2.x = n2 << 8;
        return n3 >> 1;
    }

    private static final int a(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, ei ei2, int n12, int n13) {
        ei2.ei_v -= ei2.ei_t * n4;
        if (n12 == 0 || (n9 = n4 + (n11 - n3 + n12 - 257) / n12) > n10) {
            n9 = n10;
        }
        n4 <<= 1;
        n9 <<= 1;
        while (n4 < n9) {
            n2 = n3 >> 8;
            n = byArray[n2];
            n = (n << 8) + (byArray[n2 + 1] - n) * (n3 & 0xFF);
            int n14 = n4++;
            nArray[n14] = nArray[n14] + (n * n5 >> 6);
            n5 += n7;
            int n15 = n4++;
            nArray[n15] = nArray[n15] + (n * n6 >> 6);
            n6 += n8;
            n3 += n12;
        }
        if (n12 == 0 || (n9 = (n4 >> 1) + (n11 - n3 + n12 - 1) / n12) > n10) {
            n9 = n10;
        }
        n9 <<= 1;
        n2 = n13;
        while (n4 < n9) {
            n = byArray[n3 >> 8];
            n = (n << 8) + (n2 - n) * (n3 & 0xFF);
            int n16 = n4++;
            nArray[n16] = nArray[n16] + (n * n5 >> 6);
            n5 += n7;
            int n17 = n4++;
            nArray[n17] = nArray[n17] + (n * n6 >> 6);
            n6 += n8;
            n3 += n12;
        }
        ei2.ei_v += ei2.ei_t * (n4 >>= 1);
        ei2.C = n5;
        ei2.ei_u = n6;
        ei2.x = n3;
        return n4;
    }

    final synchronized void d(int n) {
        this.z = this.z < 0 ? -n : n;
    }

    private final synchronized void c(int n) {
        this.b(n, this.h());
    }

    final synchronized void b(int n, int n2, int n3) {
        if (n == 0) {
            this.b(n2, n3);
            return;
        }
        int n4 = ei.d(n2, n3);
        int n5 = ei.c(n2, n3);
        if (this.C == n4 && this.ei_u == n5) {
            this.A = 0;
            return;
        }
        int n6 = n2 - this.ei_v;
        if (this.ei_v - n2 > n6) {
            n6 = this.ei_v - n2;
        }
        if (n4 - this.C > n6) {
            n6 = n4 - this.C;
        }
        if (this.C - n4 > n6) {
            n6 = this.C - n4;
        }
        if (n5 - this.ei_u > n6) {
            n6 = n5 - this.ei_u;
        }
        if (this.ei_u - n5 > n6) {
            n6 = this.ei_u - n5;
        }
        if (n > n6) {
            n = n6;
        }
        this.A = n;
        this.F = n2;
        this.ei_w = n3;
        this.ei_t = (n2 - this.ei_v) / n;
        this.ei_s = (n4 - this.C) / n;
        this.ei_r = (n5 - this.ei_u) / n;
    }

    private static final int b(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, int n9, ei ei2, int n10, int n11) {
        ei2.C -= ei2.ei_s * n4;
        ei2.ei_u -= ei2.ei_r * n4;
        if (n10 == 0 || (n7 = n4 + (n9 + 256 - n3 + n10) / n10) > n8) {
            n7 = n8;
        }
        while (n4 < n7) {
            n2 = n3 >> 8;
            n = byArray[n2 - 1];
            int n12 = n4++;
            nArray[n12] = nArray[n12] + (((n << 8) + (byArray[n2] - n) * (n3 & 0xFF)) * n5 >> 6);
            n5 += n6;
            n3 += n10;
        }
        if (n10 == 0 || (n7 = n4 + (n9 - n3 + n10) / n10) > n8) {
            n7 = n8;
        }
        n = n11;
        n2 = n10;
        while (n4 < n7) {
            int n13 = n4++;
            nArray[n13] = nArray[n13] + (((n << 8) + (byArray[n3 >> 8] - n) * (n3 & 0xFF)) * n5 >> 6);
            n5 += n6;
            n3 += n2;
        }
        ei2.C += ei2.ei_s * n4;
        ei2.ei_u += ei2.ei_r * n4;
        ei2.ei_v = n5;
        ei2.x = n3;
        return n4;
    }

    final synchronized void e(int n, int n2) {
        this.b(n, n2, this.h());
    }

    @Override
    final int a() {
        if (this.F == 0 && this.A == 0) {
            return 0;
        }
        return 1;
    }

    private static final int d(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, int n9, ei ei2, int n10, int n11) {
        if (n10 == 0 || (n7 = n4 + (n9 + 256 - n3 + n10) / n10) > n8) {
            n7 = n8;
        }
        n4 <<= 1;
        n7 <<= 1;
        while (n4 < n7) {
            n2 = n3 >> 8;
            n = byArray[n2 - 1];
            n = (n << 8) + (byArray[n2] - n) * (n3 & 0xFF);
            int n12 = n4++;
            nArray[n12] = nArray[n12] + (n * n5 >> 6);
            int n13 = n4++;
            nArray[n13] = nArray[n13] + (n * n6 >> 6);
            n3 += n10;
        }
        if (n10 == 0 || (n7 = (n4 >> 1) + (n9 - n3 + n10) / n10) > n8) {
            n7 = n8;
        }
        n7 <<= 1;
        n2 = n11;
        while (n4 < n7) {
            n = (n2 << 8) + (byArray[n3 >> 8] - n2) * (n3 & 0xFF);
            int n14 = n4++;
            nArray[n14] = nArray[n14] + (n * n5 >> 6);
            int n15 = n4++;
            nArray[n15] = nArray[n15] + (n * n6 >> 6);
            n3 += n10;
        }
        ei2.x = n3;
        return n4 >> 1;
    }

    private static final int d(int n, int n2) {
        return n2 < 0 ? n : (int)((double)n * Math.sqrt((double)(16384 - n2) * 1.220703125E-4) + 0.5);
    }

    @Override
    final int b() {
        int n = this.ei_v * 3 >> 6;
        n = (n ^ n >> 31) + (n >>> 31);
        if (this.D == 0) {
            n -= n * this.x / (((ud)this.ol_q).ud_o.length << 8);
        } else if (this.D >= 0) {
            n -= n * this.G / ((ud)this.ol_q).ud_o.length;
        }
        return n > 255 ? 255 : n;
    }

    private final int b(int[] nArray, int n, int n2, int n3, int n4) {
        while (this.A > 0) {
            int n5 = n + this.A;
            if (n5 > n3) {
                n5 = n3;
            }
            this.A += n;
            n = this.z == 256 && (this.x & 0xFF) == 0 ? (en.en_u ? ei.a(0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, this.ei_s, this.ei_r, 0, n5, n2, this) : ei.b(((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, this.ei_t, 0, n5, n2, this)) : (en.en_u ? ei.a(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, this.ei_s, this.ei_r, 0, n5, n2, this, this.z, n4) : ei.c(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, this.ei_t, 0, n5, n2, this, this.z, n4));
            this.A -= n;
            if (this.A != 0) {
                return n;
            }
            if (!this.g()) continue;
            return n3;
        }
        if (this.z == 256 && (this.x & 0xFF) == 0) {
            if (en.en_u) {
                return ei.b(0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, 0, n3, n2, this);
            }
            return ei.a(((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, 0, n3, n2, this);
        }
        if (en.en_u) {
            return ei.a(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.C, this.ei_u, 0, n3, n2, this, this.z, n4);
        }
        return ei.b(0, 0, ((ud)this.ol_q).ud_o, nArray, this.x, n, this.ei_v, 0, n3, n2, this, this.z, n4);
    }

    final synchronized void g(int n) {
        if (n == 0) {
            this.c(0);
            this.b((byte)102);
            return;
        }
        if (this.C == 0 && this.ei_u == 0) {
            this.A = 0;
            this.F = 0;
            this.ei_v = 0;
            this.b((byte)127);
            return;
        }
        int n2 = -this.ei_v;
        if (this.ei_v > n2) {
            n2 = this.ei_v;
        }
        if (-this.C > n2) {
            n2 = -this.C;
        }
        if (this.C > n2) {
            n2 = this.C;
        }
        if (-this.ei_u > n2) {
            n2 = -this.ei_u;
        }
        if (this.ei_u > n2) {
            n2 = this.ei_u;
        }
        if (n > n2) {
            n = n2;
        }
        this.A = n;
        this.F = Integer.MIN_VALUE;
        this.ei_t = -this.ei_v / n;
        this.ei_s = -this.C / n;
        this.ei_r = -this.ei_u / n;
    }

    private static final int b(int n, byte[] byArray, int[] nArray, int n2, int n3, int n4, int n5, int n6, int n7, int n8, ei ei2) {
        n4 <<= 2;
        n5 <<= 2;
        n6 = n3 + (n8 >>= 8) - (n2 >>= 8);
        if (n6 > n7) {
            n6 = n7;
        }
        n3 <<= 1;
        n6 <<= 1;
        n6 -= 6;
        while (n3 < n6) {
            n = byArray[n2++];
            int n9 = n3++;
            nArray[n9] = nArray[n9] + n * n4;
            int n10 = n3++;
            nArray[n10] = nArray[n10] + n * n5;
            n = byArray[n2++];
            int n11 = n3++;
            nArray[n11] = nArray[n11] + n * n4;
            int n12 = n3++;
            nArray[n12] = nArray[n12] + n * n5;
            n = byArray[n2++];
            int n13 = n3++;
            nArray[n13] = nArray[n13] + n * n4;
            int n14 = n3++;
            nArray[n14] = nArray[n14] + n * n5;
            n = byArray[n2++];
            int n15 = n3++;
            nArray[n15] = nArray[n15] + n * n4;
            int n16 = n3++;
            nArray[n16] = nArray[n16] + n * n5;
        }
        n6 += 6;
        while (n3 < n6) {
            n = byArray[n2++];
            int n17 = n3++;
            nArray[n17] = nArray[n17] + n * n4;
            int n18 = n3++;
            nArray[n18] = nArray[n18] + n * n5;
        }
        ei2.x = n2 << 8;
        return n3 >> 1;
    }

    @Override
    final ol d() {
        return null;
    }

    final synchronized void f(int n) {
        this.D = n;
    }

    private static final int b(int n, int n2, byte[] byArray, int[] nArray, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, ei ei2, int n12, int n13) {
        ei2.ei_v -= ei2.ei_t * n4;
        if (n12 == 0 || (n9 = n4 + (n11 + 256 - n3 + n12) / n12) > n10) {
            n9 = n10;
        }
        n4 <<= 1;
        n9 <<= 1;
        while (n4 < n9) {
            n2 = n3 >> 8;
            n = byArray[n2 - 1];
            n = (n << 8) + (byArray[n2] - n) * (n3 & 0xFF);
            int n14 = n4++;
            nArray[n14] = nArray[n14] + (n * n5 >> 6);
            n5 += n7;
            int n15 = n4++;
            nArray[n15] = nArray[n15] + (n * n6 >> 6);
            n6 += n8;
            n3 += n12;
        }
        if (n12 == 0 || (n9 = (n4 >> 1) + (n11 - n3 + n12) / n12) > n10) {
            n9 = n10;
        }
        n9 <<= 1;
        n2 = n13;
        while (n4 < n9) {
            n = (n2 << 8) + (byArray[n3 >> 8] - n2) * (n3 & 0xFF);
            int n16 = n4++;
            nArray[n16] = nArray[n16] + (n * n5 >> 6);
            n5 += n7;
            int n17 = n4++;
            nArray[n17] = nArray[n17] + (n * n6 >> 6);
            n6 += n8;
            n3 += n12;
        }
        ei2.ei_v += ei2.ei_t * (n4 >>= 1);
        ei2.C = n5;
        ei2.ei_u = n6;
        ei2.x = n3;
        return n4;
    }

    final synchronized void e(int n) {
        int n2 = ((ud)this.ol_q).ud_o.length << 8;
        if ((n <<= 8) < -1) {
            n = -1;
        }
        if (n > n2) {
            n = n2;
        }
        this.x = n;
    }

    private final void e() {
        if (this.A != 0) {
            if (this.F == Integer.MIN_VALUE) {
                this.F = 0;
            }
            this.A = 0;
            this.f();
            return;
        }
    }

    private static final int b(byte[] byArray, int[] nArray, int n, int n2, int n3, int n4, int n5, int n6, ei ei2) {
        n3 <<= 2;
        n4 = n2 + (n >>= 8) - ((n6 >>= 8) - 1);
        if (n4 > n5) {
            n4 = n5;
        }
        n4 -= 3;
        while (n2 < n4) {
            int n7 = n2++;
            nArray[n7] = nArray[n7] + byArray[n--] * n3;
            int n8 = n2++;
            nArray[n8] = nArray[n8] + byArray[n--] * n3;
            int n9 = n2++;
            nArray[n9] = nArray[n9] + byArray[n--] * n3;
            int n10 = n2++;
            nArray[n10] = nArray[n10] + byArray[n--] * n3;
        }
        n4 += 3;
        while (n2 < n4) {
            int n11 = n2++;
            nArray[n11] = nArray[n11] + byArray[n--] * n3;
        }
        ei2.x = n << 8;
        return n2;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    final synchronized void a(int n) {
        int n2;
        block32: {
            int n3;
            int n4;
            block34: {
                block31: {
                    int n5;
                    block33: {
                        if (this.A > 0) {
                            if (n >= this.A) {
                                if (this.F == Integer.MIN_VALUE) {
                                    this.F = 0;
                                    this.ei_u = 0;
                                    this.C = 0;
                                    this.ei_v = 0;
                                    this.b((byte)125);
                                    n = this.A;
                                }
                                this.A = 0;
                                this.f();
                            } else {
                                this.ei_v += this.ei_t * n;
                                this.C += this.ei_s * n;
                                this.ei_u += this.ei_r * n;
                                this.A -= n;
                            }
                        }
                        ud ud2 = (ud)this.ol_q;
                        n4 = this.G << 8;
                        n3 = this.y << 8;
                        n2 = ud2.ud_o.length << 8;
                        n5 = n3 - n4;
                        if (n5 <= 0) {
                            this.D = 0;
                        }
                        if (this.x < 0) {
                            if (this.z <= 0) {
                                this.e();
                                this.b((byte)123);
                                return;
                            }
                            this.x = 0;
                        }
                        if (this.x >= n2) {
                            if (this.z >= 0) {
                                this.e();
                                this.b((byte)119);
                                return;
                            }
                            this.x = n2 - 1;
                        }
                        this.x += this.z * n;
                        if (this.D < 0) {
                            if (this.B) {
                                if (this.z < 0) {
                                    if (this.x >= n4) {
                                        return;
                                    }
                                    this.x = n4 + n4 - 1 - this.x;
                                    this.z = -this.z;
                                }
                                break block31;
                            } else {
                                if (this.z < 0) {
                                    if (this.x >= n4) {
                                        return;
                                    }
                                    this.x = n3 - 1 - (n3 - 1 - this.x) % n5;
                                    return;
                                }
                                if (this.x < n3) {
                                    return;
                                }
                                this.x = n4 + (this.x - n4) % n5;
                                return;
                            }
                        }
                        if (this.D <= 0) break block32;
                        if (!this.B) break block33;
                        if (this.z >= 0) break block34;
                        if (this.x >= n4) {
                            return;
                        }
                        this.x = n4 + n4 - 1 - this.x;
                        this.z = -this.z;
                        if (--this.D != 0) break block34;
                        break block32;
                    }
                    if (this.z < 0) {
                        if (this.x >= n4) {
                            return;
                        }
                        int n6 = (n3 - 1 - this.x) / n5;
                        if (n6 < this.D) {
                            this.x += n5 * n6;
                            this.D -= n6;
                            return;
                        }
                        this.x += n5 * this.D;
                        this.D = 0;
                        break block32;
                    } else {
                        if (this.x < n3) {
                            return;
                        }
                        int n7 = (this.x - n4) / n5;
                        if (n7 < this.D) {
                            this.x -= n5 * n7;
                            this.D -= n7;
                            return;
                        }
                        this.x -= n5 * this.D;
                        this.D = 0;
                    }
                    break block32;
                }
                while (true) {
                    if (this.x < n3) {
                        return;
                    }
                    this.x = n3 + n3 - 1 - this.x;
                    this.z = -this.z;
                    if (this.x >= n4) {
                        return;
                    }
                    this.x = n4 + n4 - 1 - this.x;
                    this.z = -this.z;
                }
            }
            do {
                if (this.x < n3) {
                    return;
                }
                this.x = n3 + n3 - 1 - this.x;
                this.z = -this.z;
                if (--this.D == 0) break;
                if (this.x >= n4) {
                    return;
                }
                this.x = n4 + n4 - 1 - this.x;
                this.z = -this.z;
            } while (--this.D != 0);
        }
        if (this.z < 0) {
            if (this.x >= 0) return;
            this.x = -1;
            this.e();
            this.b((byte)105);
            return;
        }
        if (this.x < n2) return;
        this.x = n2;
        this.e();
        this.b((byte)122);
    }

    private static final int a(int n, byte[] byArray, int[] nArray, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, ei ei2) {
        n4 <<= 2;
        n5 <<= 2;
        n6 <<= 2;
        n7 <<= 2;
        n8 = n3 + (n10 >>= 8) - (n2 >>= 8);
        if (n8 > n9) {
            n8 = n9;
        }
        ei2.ei_v += ei2.ei_t * (n8 - n3);
        n3 <<= 1;
        n8 <<= 1;
        n8 -= 6;
        while (n3 < n8) {
            n = byArray[n2++];
            int n11 = n3++;
            nArray[n11] = nArray[n11] + n * n4;
            n4 += n6;
            int n12 = n3++;
            nArray[n12] = nArray[n12] + n * n5;
            n5 += n7;
            n = byArray[n2++];
            int n13 = n3++;
            nArray[n13] = nArray[n13] + n * n4;
            n4 += n6;
            int n14 = n3++;
            nArray[n14] = nArray[n14] + n * n5;
            n5 += n7;
            n = byArray[n2++];
            int n15 = n3++;
            nArray[n15] = nArray[n15] + n * n4;
            n4 += n6;
            int n16 = n3++;
            nArray[n16] = nArray[n16] + n * n5;
            n5 += n7;
            n = byArray[n2++];
            int n17 = n3++;
            nArray[n17] = nArray[n17] + n * n4;
            n4 += n6;
            int n18 = n3++;
            nArray[n18] = nArray[n18] + n * n5;
            n5 += n7;
        }
        n8 += 6;
        while (n3 < n8) {
            n = byArray[n2++];
            int n19 = n3++;
            nArray[n19] = nArray[n19] + n * n4;
            n4 += n6;
            int n20 = n3++;
            nArray[n20] = nArray[n20] + n * n5;
            n5 += n7;
        }
        ei2.C = n4 >> 2;
        ei2.ei_u = n5 >> 2;
        ei2.x = n2 << 8;
        return n3 >> 1;
    }

    private ei(ud ud2, int n, int n2, int n3) {
        this.ol_q = ud2;
        this.G = ud2.ud_q;
        this.y = ud2.ud_s;
        this.B = ud2.ud_r;
        this.z = n;
        this.F = n2;
        this.ei_w = n3;
        this.x = 0;
        this.f();
    }
}
