/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Canvas;
import java.math.BigInteger;

final class ne {
    private le[] ne_h;
    private wl ne_a;
    static byte[] ne_c;
    private im ne_f;
    static String ne_b;
    static String ne_d;
    private pj ne_j;
    private dd ne_i;
    private BigInteger ne_g;
    private BigInteger ne_e;

    public static void a(byte by) {
        block0: {
            ne_c = null;
            ne_b = null;
            ne_d = null;
            if (by == 0) break block0;
            ne_c = null;
        }
    }

    static final int a(int n, int n2, boolean bl, int n3) {
        if (n != 255) {
            return -17;
        }
        return qm.a((byte)57);
    }

    final boolean a(boolean bl) {
        Object object;
        byte[] byArray;
        boolean bl2 = client.A;
        if (null != this.ne_a) {
            return true;
        }
        if (null == this.ne_j) {
            if (this.ne_i.a(true)) {
                return false;
            }
            this.ne_j = this.ne_i.a(true, (byte)0, bl, 255, 255);
        }
        if (this.ne_j.z) {
            return false;
        }
        wl wl2 = new wl(this.ne_j.g((byte)113));
        wl2.wl_n = 5;
        int n = wl2.d((byte)-69);
        wl2.wl_n += n * 72;
        byte[] byArray2 = new byte[-wl2.wl_n + wl2.wl_r.length];
        wl2.a(byArray2, 0, (byte)125, byArray2.length);
        if (!bl) {
            return true;
        }
        if (this.ne_e == null || null == this.ne_g) {
            byArray = byArray2;
        } else {
            object = new BigInteger(byArray2);
            BigInteger bigInteger = ((BigInteger)object).modPow(this.ne_e, this.ne_g);
            byArray = bigInteger.toByteArray();
        }
        if (byArray.length != 65) {
            throw new RuntimeException();
        }
        byte[] byArray3 = um.a(0, wl2.wl_r, 5, wl2.wl_n - (byArray2.length - -5));
        object = byArray3;
        int n2 = 0;
        while (~n2 > -65) {
            if (~byArray3[n2] != ~byArray[n2 - -1]) {
                throw new RuntimeException();
            }
            ++n2;
        }
        this.ne_h = new le[n];
        this.ne_a = wl2;
        return true;
    }

    final le a(byte by, int n, kh kh2, kh kh3, boolean bl) {
        le le2;
        if (this.ne_a == null) {
            throw new RuntimeException();
        }
        if (0 > n || this.ne_h.length <= n) {
            throw new RuntimeException();
        }
        if (this.ne_h[n] != null) {
            return this.ne_h[n];
        }
        this.ne_a.wl_n = n * 72 + 6;
        int n2 = 10 / ((-41 - by) / 42);
        int n3 = this.ne_a.i(7553);
        int n4 = this.ne_a.i(7553);
        byte[] byArray = new byte[64];
        this.ne_a.a(byArray, 0, (byte)127, 64);
        this.ne_h[n] = le2 = new le(n, kh2, kh3, this.ne_i, this.ne_f, n3, byArray, n4, bl);
        return le2;
    }

    static final void e(int n) {
        wj.q(114);
        if (n != -5) {
            ne_c = null;
        }
        vb.Z = true;
        tj.Vb = true;
        ah.ah_c.c(true);
        wi.a(false, n ^ 0x31, ak.ak_g);
    }

    static final Canvas d(int n) {
        if (n > -25) {
            ne.a((byte)18);
        }
        return null != cl.cl_v ? cl.cl_v : jh.jh_b;
    }

    ne(dd dd2, im im2) {
        this(dd2, im2, null, null);
    }

    static final boolean b(int n) {
        if (n != -18163) {
            return true;
        }
        if (!jg.jg_i) {
            return false;
        }
        return 0 == pk.pk_r;
    }

    static final int b(byte by) {
        block0: {
            if (by == -40) break block0;
            ne.b(-2);
        }
        return pf.pf_g;
    }

    final void a(int n) {
        int n2;
        int n3;
        boolean bl2 = client.A;
        if (this.ne_h == null) {
            return;
        }
        for (n3 = 0; n3 < this.ne_h.length; ++n3) {
            if (this.ne_h[n3] == null) continue;
            this.ne_h[n3].b(16322);
        }
        n3 = n2 = 0;
        if (n > -106) {
            return;
        }
        while (n2 < this.ne_h.length) {
            if (null != this.ne_h[n2]) {
                this.ne_h[n2].c(true);
            }
            ++n2;
        }
    }

    static final void c(int n) {
        block0: {
            wc.wc_n = false;
            boolean bl2 = wl.wl_p = 0 == de.V.d((byte)-96);
            if (n == 27721) break block0;
            ne.a((byte)94);
        }
    }

    private ne(dd dd2, im im2, BigInteger bigInteger, BigInteger bigInteger2) {
        block0: {
            this.ne_f = im2;
            this.ne_e = bigInteger;
            this.ne_g = bigInteger2;
            this.ne_i = dd2;
            if (this.ne_i.a(true)) break block0;
            this.ne_j = this.ne_i.a(true, (byte)0, true, 255, 255);
        }
    }

    static {
        ne_d = "Waiting for fonts";
        ne_b = "Achieved";
    }
}
