/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;
import java.net.URL;

final class aj {
    static w aj_a;
    static String aj_b;
    static ck aj_c;
    static mm aj_e;
    static mm aj_d;

    public static void b(int n) {
        aj_b = null;
        aj_d = null;
        aj_e = null;
        if (n != 0) {
            return;
        }
        aj_a = null;
        aj_c = null;
    }

    static final void a(String string, int n, Applet applet) {
        try {
            URL uRL = new URL(applet.getCodeBase(), string);
            uRL = gn.a(uRL, -1, applet);
            c.a((byte)92, uRL.toString(), true, applet);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        int n2 = 92 / ((44 - n) / 48);
    }

    static final void a(int n) {
        pk.pk_r = 0;
        if (n != -1045) {
            return;
        }
        v.b(0);
    }

    static {
        aj_b = "<%0> has left the lobby.";
    }
}
