/*
 * Decompiled with CFR 0.152.
 */
final class nf {
    static lm nf_d;
    static int[] nf_f;
    int nf_c;
    static cc nf_g;
    int nf_i;
    static int nf_e;
    static boolean nf_b;
    static int nf_h;
    int[] nf_a;

    final int b(int n) {
        if (n != -6375) {
            this.b(75);
        }
        return null != this.nf_a && 0 != this.nf_a.length ? this.nf_a[this.nf_a.length - 1] : 0;
    }

    static final void a(int n, int n2, byte by, int n3, int n4) {
        block2: {
            fl.a(n3 - -20, 256, 0xFFFFFF, o.o_c, n2, w.w_kb);
            se.S.a(jg.jg_k[n], n2, n3 + 24, 120, 200, 0xFFFFFF, -1, 0, 0, 16);
            if (-1 == ~n) {
                fb.fb_c[n4][0].c(30 + n2, n3 + 101, 18, 18);
                fb.fb_c[n4][0].c(48 + n2, 101 + n3, 18, 18);
                fb.fb_c[n4][0].c(n2 - -66, n3 - -101, 18, 18);
                fb.fb_c[n4][0].c(48 + n2, 83 + n3, 18, 18);
            }
            if (by < 59) {
                nf_d = null;
            }
            if (-2 != ~n) break block2;
            fb.fb_c[n4][4].c(n2 + 30, n3 + 101, 18, 18);
            fb.fb_c[n4][4].c(48 + n2, 101 + n3, 18, 18);
            fb.fb_c[n4][4].c(n2 - -66, n3 - -101, 18, 18);
            fb.fb_c[n4][4].c(30 + n2, n3 + 83, 18, 18);
            fb.fb_c[n4][4].c(66 + n2, n3 - -83, 18, 18);
        }
    }

    public static void a(int n) {
        nf_f = null;
        nf_d = null;
        nf_g = null;
        int n2 = -117 / ((-57 - n) / 50);
    }

    final int a(int n, int n2) {
        block3: {
            boolean bl = client.A;
            if (this.nf_a == null || -1 == ~this.nf_a.length) {
                return 0;
            }
            int n3 = 1;
            while (~this.nf_a.length < ~n3) {
                if (~n > ~(this.nf_a[-1 + n3] + this.nf_a[n3] >> 4945089)) {
                    return n3 + -1;
                }
                ++n3;
            }
            if (n2 > 103) break block3;
            nf.a(-11);
        }
        return -1 + this.nf_a.length;
    }

    static final boolean c(int n) {
        block0: {
            if (n == 48) break block0;
            nf.a(-116, 95, (byte)-90, 127, 46);
        }
        return sc.sc_l.a(true);
    }

    nf(int n, int n2, int n3) {
        this.nf_c = n;
        this.nf_a = new int[n3 + 1];
        this.nf_i = n2;
    }

    static {
        nf_h = 0;
    }
}
