/*
 * Decompiled with CFR 0.152.
 */
final class sn {
    private int sn_i = Integer.MIN_VALUE;
    private int sn_f = -2;
    private int sn_d = -2;
    private boolean sn_h = false;
    ck[] sn_a = null;
    static vj sn_e = new vj();
    ck sn_b = null;
    private int sn_c = Integer.MIN_VALUE;
    static boolean sn_g;
    static cn sn_k;
    private int sn_j = Integer.MIN_VALUE;

    final sn c(int n, int n2) {
        if (n != -1) {
            this.sn_c = 9;
        }
        this.sn_i = n2;
        return this;
    }

    final void a(sn sn2, int n) {
        sn2.sn_b = this.sn_b;
        if (n != 1) {
            sn sn3 = null;
            this.a(sn3, -53);
        }
        sn2.sn_a = this.sn_a;
        sn2.sn_i = this.sn_i;
        sn2.sn_c = this.sn_c;
        sn2.sn_f = this.sn_f;
        sn2.sn_j = this.sn_j;
        sn2.sn_d = this.sn_d;
        sn2.sn_h = this.sn_h;
    }

    final void a(int n, ce ce2, int n2, bc bc2, int n3) {
        block6: {
            String string;
            vk.a(ce2.y, (byte)50, this.sn_a, ce2.ce_t, n3 + ce2.D, n2 + ce2.ce_u);
            if (n != -2) {
                ck[] ckArray = null;
                this.a(-28, ckArray);
            }
            if (null != this.sn_b) {
                int n4 = this.sn_i + ce2.ce_u + n2;
                int n5 = n3 + (ce2.D + this.sn_j);
                if (bc2.a_f == 1) {
                    n4 += (-this.sn_b.K + ce2.ce_t) / 2;
                }
                if (1 == bc2.a_o) {
                    n5 += (-this.sn_b.C + ce2.y) / 2;
                }
                if (~bc2.a_f == -3) {
                    n4 += ce2.ce_t + -this.sn_b.K;
                }
                if (-3 == ~bc2.a_o) {
                    n5 += -this.sn_b.C + ce2.y;
                }
                this.sn_b.c(n4, n5);
            }
            if (null == (string = bc2.b(ce2, (byte)-116)) || bc2.z == null || ~this.sn_f > -1) break block6;
            bc2.z.a(string, (Integer.MAX_VALUE != ~this.sn_i ? this.sn_i : 0) + (ce2.ce_u + n2) - -bc2.a_s, (this.sn_j != Integer.MIN_VALUE ? this.sn_j : 0) + (bc2.a_m + (ce2.D + n3)), ce2.ce_t + -bc2.a_s + -bc2.a_i, -bc2.a_m + (ce2.y + -bc2.y), this.sn_f, this.sn_d, this.sn_c == Integer.MIN_VALUE ? 256 : this.sn_c, bc2.a_f, bc2.a_o, bc2.a_b);
        }
    }

    final sn a(int n, int n2) {
        block0: {
            this.sn_j = n;
            if (n2 == Integer.MIN_VALUE) break block0;
            sn_e = null;
        }
        return this;
    }

    static final void a(long l, int n, String string, int n2, boolean bl, int n3) {
        we.we_b.f(n, -4);
        ++we.we_b.wl_n;
        if (n2 <= 34) {
            sn_e = null;
        }
        int n4 = we.we_b.wl_n;
        we.we_b.a(l, (byte)0);
        we.we_b.a(0, string);
        we.we_b.a(true, n3);
        we.we_b.a(true, bl ? 1 : 0);
        we.we_b.b(-n4 + we.we_b.wl_n, true);
    }

    static final void c(byte by) {
        ta.ta_k.dd_j = 0;
        ta.ta_k.dd_o = 0;
        int n = -59 % ((-49 - by) / 38);
    }

    final sn b(int n, int n2) {
        this.sn_d = n2;
        if (n >= -76) {
            return null;
        }
        return this;
    }

    final void b(byte by) {
        this.sn_f = 0;
        this.sn_c = 256;
        this.sn_b = null;
        if (by <= 66) {
            return;
        }
        this.sn_d = -1;
        this.sn_i = 0;
        this.sn_a = null;
        this.sn_j = 0;
    }

    static final int a(String string, boolean bl2, String string2, byte by, int n, boolean bl3) {
        int n2;
        boolean bl4 = client.A;
        if (qc.qc_s == null && !mb.a(bl3, by + -129)) {
            return -1;
        }
        if (ba.ba_f == ph.xb) {
            wb.Nb = !bl3 ? hm.a(false, string2, string, 9507) : sb.a(sh.sh_f, string2, false, null, 0);
            we.we_b.wl_n = 0;
            we.we_b.a(true, 14);
            we.we_b.a(true, wb.Nb.a((int)(by ^ 0x25)).gh_a);
            wj.c(4792, -1);
            ph.xb = wf.wf_p;
        }
        if (ph.xb == wf.wf_p && pe.b(25973, 1)) {
            n2 = de.V.d((byte)-85);
            if (~n2 == -1) {
                ph.xb = kk.kk_p;
            } else {
                bh.bh_k = n2;
                ph.xb = bh.bh_l;
                sm.sm_e = -1;
            }
            de.V.wl_n = 0;
        }
        if (by != 55) {
            return -94;
        }
        if (kk.kk_p == ph.xb && pe.b(25973, 8)) {
            lc.lc_j = de.V.f((byte)-108);
            de.V.wl_n = 0;
            jm.a(bl3, wb.Nb, n, (byte)127, bl2);
            ph.xb = nn.nn_c;
        }
        if (ph.xb == nn.nn_c && pe.b(25973, 1)) {
            n2 = de.V.d((byte)-46);
            vh.vh_f = null;
            bh.bh_k = n2;
            de.V.wl_n = 0;
            if (n2 == 0 || -2 == ~n2) {
                sm.sm_e = -1;
                ph.xb = of.of_a;
            } else if (8 != n2) {
                sm.sm_e = -1;
                ph.xb = bh.bh_l;
            } else {
                si.a(by + 22);
                jd.Qb = false;
                return n2;
            }
        }
        if (ph.xb == of.of_a && fh.a((byte)-62)) {
            sh.sh_f = de.V.f((byte)-108);
            jk.jk_a = string2;
            te.te_p = de.V.d((byte)-76);
            d.d_b = de.V.d((byte)-113);
            eh.eh_a = de.V.e(3);
            String string3 = de.V.c(-16829);
            int n3 = de.V.d((byte)-93);
            if (-1 != ~(n3 & 1)) {
                qj.a((byte)64);
            }
            if (!bl3) {
                wc.wc_n = 0 != (8 & n3);
                on.on_d = (4 & n3) != 0;
                boolean bl5 = wl.wl_p = ~(n3 & 2) != -1;
                if (wc.wc_n) {
                    wl.wl_p = true;
                }
            }
            boolean bl6 = gf.gf_i = 0 != (0x10 & n3);
            if (ci.ci_c) {
                de.V.d((byte)-25);
                de.V.d((byte)-71);
                de.V.i(by ^ 0x1DB6);
                uj.uj_a = de.V.e(3);
                ai.N = new byte[uj.uj_a];
                int n4 = 0;
                while (~n4 > ~uj.uj_a) {
                    ai.N[n4] = de.V.g((byte)-99);
                    ++n4;
                }
            }
            oa.oa_f = de.V.c((byte)-38);
            h.h_c = kf.a(oa.oa_f, (byte)2);
            bb.bb_e = de.V.d((byte)-49);
            ph.xb = wf.wf_u;
            if (wb.Nb.a(18) == pb.pb_i) {
                ah.ah_f.a(-69, se.h(by ^ 0x620F));
            } else if (wb.Nb.a(18) == ui.ui_t) {
                ge.ge_g.a(-117, se.h(25144));
            }
            jd.Qb = false;
            if (string3 != null) {
                a.a(string3, false, se.h(25144));
            }
            if (eh.eh_a > 0 || on.on_d) {
                try {
                    nc.a("zap", -14541, se.h(25144), new Object[]{cf.a(0, sh.sh_f)});
                }
                catch (Throwable throwable) {}
            } else {
                try {
                    nc.a(true, "unzap", se.h(25144));
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            if (-1 > ~eh.eh_a) {
                ce.ce_w = true;
            }
            we.we_b.a(pd.pd_h, (byte)63);
            int n5 = 0;
            while (-5 < ~n5) {
                int n6 = n5++;
                pd.pd_h[n6] = pd.pd_h[n6] + 50;
            }
            de.V.a(pd.pd_h, (byte)123);
            return bh.bh_k;
        }
        if (ph.xb == bh.bh_l && fh.a((byte)122)) {
            si.a(119);
            if (~bh.bh_k == -8 && !jd.Qb) {
                jd.Qb = true;
                return -1;
            }
            if (~bh.bh_k == -8) {
                bh.bh_k = 3;
            }
            rk.Y = de.V.c((byte)-38);
            jd.Qb = false;
            return bh.bh_k;
        }
        if (qc.qc_s == null) {
            if (jd.Qb) {
                rk.Y = sl.a(-1) > 30000L ? kh.kh_f : re.re_u;
                jd.Qb = false;
                return 3;
            }
            n2 = hc.hc_a;
            hc.hc_a = ef.P;
            jd.Qb = true;
            ef.P = n2;
        }
        return -1;
    }

    final sn a(int n, byte by) {
        this.sn_f = n;
        if (by != 106) {
            return null;
        }
        return this;
    }

    final void a(sn sn2, bc bc2, int n, int n2, int n3, ce ce2) {
        block8: {
            if (this.sn_h) {
                sn2.a(-2, ce2, n3, bc2, n2);
                sn2.b((byte)76);
            }
            if (Integer.MIN_VALUE != this.sn_j) {
                sn2.sn_j = this.sn_j;
            }
            if (Integer.MAX_VALUE != ~this.sn_i) {
                sn2.sn_i = this.sn_i;
            }
            if (n <= 121) {
                ce ce3 = null;
                this.a(null, null, 121, -77, -29, ce3);
            }
            if (this.sn_c != Integer.MIN_VALUE) {
                sn2.sn_c = this.sn_c;
            }
            if (0 >= ~this.sn_f) {
                sn2.sn_f = this.sn_f;
            }
            if (-1 <= this.sn_d) {
                sn2.sn_d = this.sn_d;
            }
            if (this.sn_b != null) {
                sn2.sn_b = this.sn_b;
            }
            if (null == this.sn_a) break block8;
            sn2.sn_a = this.sn_a;
        }
    }

    final sn a(int n, ck[] ckArray) {
        this.sn_a = ckArray;
        int n2 = -21 % ((45 - n) / 52);
        return this;
    }

    static final void a(boolean bl2) {
        if (cl.cl_v == null) {
            return;
        }
        tj.a(bl2, cl.cl_v);
        cl.cl_v.a(lf.lf_e, 115);
        cl.cl_v = null;
        if (null != li.li_b) {
            li.li_b.b((byte)-110);
        }
        jh.jh_b.requestFocus();
    }

    sn() {
    }

    final sn a(int n, boolean bl2) {
        if (n != -16598) {
            this.sn_h = true;
        }
        this.sn_h = bl2;
        return this;
    }

    public static void a(byte by) {
        sn_k = null;
        int n = -72 % ((by - 30) / 37);
        sn_e = null;
    }
}
