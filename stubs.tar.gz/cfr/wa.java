/*
 * Decompiled with CFR 0.152.
 */
final class wa {
    static String wa_b = "Invalid password.";
    static int wa_c;
    static String wa_e;
    static w wa_a;
    static String wa_f;
    static int[] wa_d;

    static final ig a(int[] nArray, w w2, byte by, w w3, w w4) {
        boolean bl = client.A;
        if (by != -127) {
            return null;
        }
        int n = nArray.length;
        String[] stringArray = new String[n];
        char[] cArray = new char[n];
        ig[] igArray = new ig[n];
        int n2 = 49;
        try {
            int n3 = 0;
            while (~n < ~n3) {
                me me2 = wj.Qb.a(126, nArray[n3]);
                stringArray[n3] = me2.f((byte)-92);
                int n4 = n2;
                n2 = (char)(n2 + 1);
                cArray[n3] = (char)n4;
                igArray[n3] = null;
                ++n3;
            }
        }
        catch (Exception exception) {
            return null;
        }
        return new ig(0L, w2, w3, w4, igArray, nArray, stringArray, cArray);
    }

    static final void a(int n, int n2) {
        ff ff2;
        boolean bl = client.A;
        bh bh2 = ff2 = (ff)cd.cd_c.c((byte)119);
        while (null != ff2) {
            mc.a(true, ff2, n2);
            bh2 = (ff)cd.cd_c.d(true);
        }
        if (n != 3) {
            return;
        }
        sb sb2 = (sb)ef.S.c((byte)80);
        bh2 = sb2;
        while (null != sb2) {
            oi.a(n ^ 0xFFFFFFA9, n2, sb2);
            bh2 = (sb)ef.S.d(true);
        }
    }

    static final w a(int n, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, mm mm2) {
        w w2 = new w(0L, null);
        w2.w_lb = df.a(n10, 0, n7);
        w2.S = df.a(n4, 0, n2);
        w2.w_eb = df.a(n, 0, n6);
        w2.Q = df.a(n5, n12 + 24447, n9);
        w2.Ab = df.a(n11, 0, n8);
        w2.G = n3;
        if (n12 != -24447) {
            w w3 = null;
            wa.a(null, null, (byte)-92, null, w3);
        }
        w2.J = mm2;
        return w2;
    }

    public static void a(int n) {
        wa_b = null;
        if (n != 18) {
            wa.a(-113, -90);
        }
        wa_a = null;
        wa_d = null;
        wa_f = null;
        wa_e = null;
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        boolean bl = client.A;
        int n8 = ~n7 <= -81 ? 54 : n7 / 20 * 18;
        int n9 = 0;
        if (~n7 <= -61) {
            if (~n7 > -81) {
                n8 += vl.a(23841, 80, 18 * n2 - -40);
            } else if (93 <= n7) {
                hk.a(n4 - 3, n3 + 36 - 3, 60, 60, 4, 65280, 100);
            } else {
                n9 = vl.a(23841, 80, ve.ve_ic[1 + n7 - 80] * 18 + 40);
            }
        } else {
            n8 += vl.a(23841, 80, 40 + 18 * n);
        }
        cg.a(n6, 2, 6, n4, 1 + (72 + n3), 2, -2);
        cg.a(n6, 2, 12, n4, 1 + (n3 - -54), 2, n5);
        cg.a(n6, 2, 8, n4, 36 + (n3 + 1), 2, -1);
        cg.a(n6, 2, 1, n4 + 18, n3 + 72 - -1, 1, -2);
        fb.fb_c[n6][2].c(n4 - -18, n3 + 36, 18, 18);
        fb.fb_c[n6][2].c(n4 + 18, 54 + n3, 18, 18);
        fb.fb_c[n6][2].c(n4 + 36, 72 + n3, 18, 18);
        fb.fb_c[n6][2].c(36 + n4, n8 + (n3 + n9), 18, 18 - n9);
    }

    static {
        wa_f = "You can join this game";
        wa_e = "Send private Quick Chat to <%0>";
    }
}
