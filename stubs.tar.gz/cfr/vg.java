/*
 * Decompiled with CFR 0.152.
 */
final class vg {
    int[] K;
    short[] J;
    short[] M;
    short[] N;
    static ck vg_h;
    short[] vg_o;
    int H;
    int[] T;
    int[] S;
    int vg_n;
    int[] R;
    int[] vg_g;
    static ck x;
    static String vg_s;
    short[] F;
    static oh E;
    short[] vg_r;
    short L;
    int[] vg_w;
    int[] vg_m;
    short[] O;
    int vg_f;
    static String[] I;
    short D;
    byte[] Q;
    private boolean vg_d = false;
    int[] vg_v;
    short[] A;
    short vg_l;
    short[] vg_e;
    short[] z;
    static int[] G;
    int[] vg_q;
    short[] vg_u;
    short[] vg_j;
    short[] vg_k;
    short[] vg_t;
    short[] vg_c;
    int vg_b;
    short[] P;
    short[] C;
    static String vg_p;
    int vg_a;
    byte B = 0;
    short[] y;
    int vg_i;

    final void a(int n) {
        boolean bl = client.A;
        if (this.vg_d) {
            return;
        }
        this.vg_d = true;
        int n2 = Short.MAX_VALUE;
        int n3 = Short.MAX_VALUE;
        int n4 = Short.MAX_VALUE;
        if (n != -14200) {
            this.a(70, 90, (byte)-86, 59, -78);
        }
        int n5 = Short.MIN_VALUE;
        int n6 = Short.MIN_VALUE;
        int n7 = Short.MIN_VALUE;
        for (int i = 0; i < this.vg_l; ++i) {
            int n8 = this.J[i];
            int n9 = this.vg_o[i];
            if (n8 > n5) {
                n5 = n8;
            }
            int n10 = this.vg_e[i];
            if (n8 < n2) {
                n2 = n8;
            }
            if (~n9 < ~n6) {
                n6 = n9;
            }
            if (~n9 > ~n3) {
                n3 = n9;
            }
            if (~n7 > ~n10) {
                n7 = n10;
            }
            if (~n4 >= ~n10) continue;
            n4 = n10;
        }
        this.vg_f = n5;
        this.H = n2;
        this.vg_i = n7;
        this.vg_a = n4;
        this.vg_n = n6;
        this.vg_b = n3;
    }

    static final void a(int n, int n2, int n3) {
        block2: {
            if (n != -20974) {
                return;
            }
            if (ta.ta_b == n3) break block2;
            ve ve2 = (ve)tg.tg_b.a(24710, ta.ta_b);
            if (null != ve2) {
                ve2.xc = null;
            }
            ta.ta_b = n3;
            uf uf2 = we.we_b;
            uf2.f(n2, -4);
            uf2.a(true, 3);
            uf2.a(true, 11);
            uf2.d(-1, n3);
        }
    }

    static final void a(int n, boolean bl, boolean bl2, int n2) {
        block25: {
            boolean bl3 = client.A;
            qf.a(bf.bf_r, 109);
            if (g.N != null) {
                int n3;
                int n4;
                boolean bl4;
                fh.fh_d.N = 0;
                w w2 = fh.fh_d;
                w2.w_mb = 0;
                nn.nn_a.N = 0;
                w w3 = nn.nn_a;
                w3.w_mb = 0;
                w w4 = tg.tg_i;
                tg.tg_i.N = 0;
                w4.w_mb = 0;
                fl.fl_b.Y = cl.cl_s.toUpperCase();
                int n5 = (2 + oh.oh_d.w_mb) / 2;
                tg.tg_i.a(-2 + n5, n2 ^ 0x30, -40 + oh.oh_d.N, 40, 0);
                nn.nn_a.a(oh.oh_d.w_mb + -n5, n2 + -48, -40 + oh.oh_d.N, 40, n5);
                if (~b.P.length == -2 && ~b.P[0] == -3) {
                    bl4 = false;
                } else {
                    bl4 = false;
                    n4 = 0;
                    n3 = 0;
                    while (~b.P.length < ~n3) {
                        boolean bl5;
                        boolean bl6 = bl5 = -1 != ~(kk.kk_l[n3 / 8] & 1 << (n3 & 7));
                        if (bl5) {
                            ++n4;
                        }
                        if (bl5 && ~b.P[n3] != -3) {
                            bl4 = true;
                            break;
                        }
                        ++n3;
                    }
                    if (0 == n4) {
                        bl4 = true;
                    }
                }
                nn.nn_a.Hb = true;
                if (!fj.fj_h) {
                    nn.nn_a.Y = (!bl4 ? kd.kd_r : wg.wg_g).toUpperCase();
                    cl.cl_n.Y = cm.a((byte)94, bl4 ? af.af_c : wd.wd_e, new String[]{nn.nn_a.Y});
                    ma.G.Hb = true;
                    tg.tg_i.Y = kh.kh_b;
                    ve.ve_ac = true;
                    if (bc.D != null) {
                        int n6;
                        gd.gd_b = false;
                        if (km.D == null) {
                            km.D = new byte[j.j_b];
                            rd.rd_c = new boolean[j.j_b];
                        }
                        ve.ve_ac = false;
                        n4 = n6 = 0;
                        while (n6 < j.j_b) {
                            rd.rd_c[n6] = false;
                            ++n6;
                        }
                        uc.a(-1, true, -1, 0, -1, j.j_b, g.N, false);
                        if (2 <= te.te_p && bj.bj_d[12]) {
                            ve.ve_ac = true;
                        }
                    }
                    if (!ve.ve_ac) {
                        nn.nn_a.Hb = false;
                        if (nn.nn_a.Kb) {
                            String string = null;
                            if (gd.gd_b) {
                                string = "<col=A00000>" + hb.Pb + "</col>";
                            }
                            for (n3 = 0; j.j_b > n3; ++n3) {
                                if (!rd.rd_c[n3]) continue;
                                String string2 = "<col=A00000>" + pa.pa_db[n3] + "</col>";
                                string = null == string ? string2 : string + ", " + string2;
                            }
                            sl.sl_g = "<col=A00000>" + lk.lk_i + "<br>" + hb.Tb + string;
                        }
                    }
                } else {
                    ma.G.Hb = false;
                    cl.cl_n.Y = im.im_c;
                    String string = bl4 ? hc.hc_e : wk.wk_j;
                    n3 = tg.tg_i.J.a(string) - -(3 * tg.tg_i.J.a('.'));
                    tg.tg_i.X = 0;
                    tg.tg_i.w_ub = (-n3 + tg.tg_i.w_mb) / 2;
                    if (-17 == ~(0x30 & oe.G)) {
                        string = string + ".";
                    }
                    if (~(oe.G & 0x30) == -33) {
                        string = string + "..";
                    }
                    if ((0x30 & oe.G) == 48) {
                        string = string + "...";
                    }
                    tg.tg_i.Y = string;
                    nn.nn_a.Y = fc.fc_g.toUpperCase();
                }
            }
            ee.ee_i.a(false, bl && !bl2 && !dn.dn_k);
            oh.oh_d.a(false, bl && !bl2 && !dn.dn_k);
            mn.mn_e.a(false, bl && !bl2 && dn.dn_k);
            je.je_f.ak_h.b(false);
            if (n2 != 48) {
                vg.a(49, 2, 67);
            }
            if (g.N == null) break block25;
            if (ma.G.w_ob != 0) {
                ul.a(n, n2 ^ 0x34);
            }
            if (-1 != ~nn.nn_a.w_ob) {
                if (!fj.fj_h) {
                    th.a(n, true);
                } else {
                    ji.c(n, 1);
                }
            }
            mc.a(g.N, true, n, (byte)-127);
        }
    }

    private final void a(boolean bl) {
        this.vg_d = bl;
    }

    static final ji a(int n, int n2) {
        block0: {
            if (n2 > 20) break block0;
            G = null;
        }
        return kc.a(true, 1, n, false, false, false);
    }

    final void a(byte by, int n, int n2, int n3) {
        boolean bl = client.A;
        int n4 = 0;
        while (~this.vg_l < ~n4) {
            int n5 = n4;
            this.J[n5] = (short)(this.J[n5] + n);
            int n6 = n4;
            this.vg_o[n6] = (short)(this.vg_o[n6] + n2);
            int n7 = n4++;
            this.vg_e[n7] = (short)(this.vg_e[n7] + n3);
        }
        if (by > -62) {
            this.B = (byte)59;
        }
        this.a(false);
    }

    final void a(int n, int n2, byte by, int n3, int n4) {
        boolean bl = client.A;
        int n5 = 19 % ((68 - by) / 34);
        int n6 = 0;
        while (~this.vg_l < ~n6) {
            this.J[n6] = (short)(this.J[n6] * n2 / n4);
            this.vg_o[n6] = (short)(n * this.vg_o[n6] / n4);
            this.vg_e[n6] = (short)(this.vg_e[n6] * n3 / n4);
            ++n6;
        }
        this.a(false);
    }

    public static void a(byte by) {
        I = null;
        int n = 0 / ((10 - by) / 39);
        vg_s = null;
        vg_p = null;
        vg_h = null;
        x = null;
        G = null;
        E = null;
    }

    vg() {
    }

    static {
        vg_s = "Chat is currently disabled.";
        I = new String[16];
        G = new int[8192];
        vg_p = "Only show lobby chat from my friends";
    }
}
