/*
 * Decompiled with CFR 0.152.
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.List;

final class sc
extends we {
    static pi[][] sc_j;
    static int sc_n;
    static String sc_h;
    static boolean sc_m;
    private ProxySelector sc_i = ProxySelector.getDefault();
    static char[] sc_o;
    static String sc_p;
    static String sc_k;
    static ne sc_l;

    @Override
    final Socket a(int n) throws IOException {
        List<Proxy> list;
        List<Proxy> list2;
        boolean bl = client.A;
        if (!Boolean.parseBoolean(System.getProperty("java.net.useSystemProxies"))) {
            System.setProperty("java.net.useSystemProxies", "true");
        }
        boolean bl2 = 443 == this.we_f;
        try {
            list2 = this.sc_i.select(new URI((!bl2 ? "http" : "https") + "://" + this.we_d));
            list = this.sc_i.select(new URI((bl2 ? "http" : "https") + "://" + this.we_d));
        }
        catch (URISyntaxException uRISyntaxException) {
            return this.b(2);
        }
        list2.addAll(list);
        Object[] objectArray = list2.toArray();
        if (n >= -2) {
            sc.b(true);
        }
        db db2 = null;
        Object[] objectArray2 = objectArray;
        int n2 = 0;
        while (~objectArray2.length < ~n2) {
            Object object = objectArray2[n2];
            Proxy proxy = (Proxy)object;
            try {
                Socket socket = this.a((byte)-86, proxy);
                if (socket != null) {
                    return socket;
                }
            }
            catch (db db3) {
                db2 = db3;
            }
            catch (IOException iOException) {
                // empty catch block
            }
            ++n2;
        }
        if (db2 != null) {
            throw db2;
        }
        return this.b(2);
    }

    private final Socket a(byte by, Proxy proxy) throws IOException {
        if (proxy.type() == Proxy.Type.DIRECT) {
            return this.b(2);
        }
        if (by >= -82) {
            return null;
        }
        SocketAddress socketAddress = proxy.address();
        if (!(socketAddress instanceof InetSocketAddress)) {
            return null;
        }
        InetSocketAddress inetSocketAddress = (InetSocketAddress)socketAddress;
        if (proxy.type() == Proxy.Type.HTTP) {
            String string = null;
            try {
                Class<?> clazz;
                Class<?> clazz2 = clazz = Class.forName("sun.net.www.protocol.http.AuthenticationInfo");
                Method method = clazz.getDeclaredMethod("getProxyAuth", String.class, Integer.TYPE);
                method.setAccessible(true);
                Object object = method.invoke(null, inetSocketAddress.getHostName(), new Integer(inetSocketAddress.getPort()));
                if (object != null) {
                    Method method2 = clazz2.getDeclaredMethod("supportsPreemptiveAuthorization", new Class[0]);
                    method2.setAccessible(true);
                    if (((Boolean)method2.invoke(object, new Object[0])).booleanValue()) {
                        Method method3 = clazz2.getDeclaredMethod("getHeaderName", new Class[0]);
                        method3.setAccessible(true);
                        Method method4 = clazz.getDeclaredMethod("getHeaderValue", URL.class, String.class);
                        method4.setAccessible(true);
                        String string2 = (String)method3.invoke(object, new Object[0]);
                        String string3 = (String)method4.invoke(object, new URL("https://" + this.we_d + "/"), "https");
                        string = string2 + ": " + string3;
                    }
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            return this.a(string, inetSocketAddress.getPort(), inetSocketAddress.getHostName(), 1323);
        }
        if (proxy.type() == Proxy.Type.SOCKS) {
            Socket socket = new Socket(proxy);
            socket.connect(new InetSocketAddress(this.we_d, this.we_f));
            return socket;
        }
        return null;
    }

    private final Socket a(String string, int n, String string2, int n2) throws IOException {
        BufferedReader bufferedReader;
        String string3;
        boolean bl = client.A;
        Socket socket = new Socket(string2, n);
        socket.setSoTimeout(10000);
        OutputStream outputStream = socket.getOutputStream();
        if (null != string) {
            outputStream.write(("CONNECT " + this.we_d + ":" + this.we_f + " HTTP/1.0\n" + string + "\n\n").getBytes(Charset.forName("ISO-8859-1")));
        } else {
            outputStream.write(("CONNECT " + this.we_d + ":" + this.we_f + " HTTP/1.0\n\n").getBytes(Charset.forName("ISO-8859-1")));
        }
        outputStream.flush();
        if (n2 != 1323) {
            this.sc_i = null;
        }
        if ((string3 = (bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()))).readLine()) != null) {
            if (string3.startsWith("HTTP/1.0 200") || string3.startsWith("HTTP/1.1 200")) {
                return socket;
            }
            if (string3.startsWith("HTTP/1.0 407") || string3.startsWith("HTTP/1.1 407")) {
                int n3 = 0;
                string3 = bufferedReader.readLine();
                String string4 = "proxy-authenticate: ";
                while (string3 != null && ~n3 > -51) {
                    if (string3.toLowerCase().startsWith(string4)) {
                        int n4 = (string3 = string3.substring(string4.length()).trim()).indexOf(32);
                        if (~n4 != 0) {
                            string3 = string3.substring(0, n4);
                        }
                        throw new db(string3);
                    }
                    string3 = bufferedReader.readLine();
                    ++n3;
                }
                throw new db("");
            }
        }
        outputStream.close();
        bufferedReader.close();
        socket.close();
        return null;
    }

    static final boolean c(byte by) {
        boolean bl = client.A;
        kl kl2 = (kl)aa.aa_f.c((byte)-95);
        kl kl3 = kl2;
        if (null == kl3) {
            return false;
        }
        if (by > -57) {
            sc_p = null;
        }
        for (int i = 0; i < kl3.kl_o; ++i) {
            if (kl2.y[i] != null && 0 == kl2.y[i].mh_c) {
                return false;
            }
            if (null == kl2.kl_t[i] || -1 != ~kl2.kl_t[i].mh_c) continue;
            return false;
        }
        return true;
    }

    sc() {
    }

    public static void b(boolean bl) {
        sc_j = null;
        sc_p = null;
        if (bl) {
            sc_h = null;
        }
        sc_h = null;
        sc_k = null;
        sc_o = null;
        sc_l = null;
    }

    static {
        sc_h = "Cancel rematch";
        sc_n = 0;
        sc_m = true;
        sc_j = new pi[8][];
        sc_o = new char[]{(char)32, (char)160, (char)95, (char)45, (char)224, (char)225, (char)226, (char)228, (char)227, (char)192, (char)193, (char)194, (char)196, (char)195, (char)232, (char)233, (char)234, (char)235, (char)200, (char)201, (char)202, (char)203, (char)237, (char)238, (char)239, (char)205, (char)206, (char)207, (char)242, (char)243, (char)244, (char)246, (char)245, (char)210, (char)211, (char)212, (char)214, (char)213, (char)249, (char)250, (char)251, (char)252, (char)217, (char)218, (char)219, (char)220, (char)231, (char)199, (char)255, (char)376, (char)241, (char)209, (char)223};
        sc_k = "Waiting for sound effects";
        sc_p = "Cancel";
    }
}
