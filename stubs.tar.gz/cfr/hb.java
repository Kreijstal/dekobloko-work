/*
 * Decompiled with CFR 0.152.
 */
final class hb
extends w {
    private w Nb;
    static String Pb = "Players";
    static ui Ub;
    private StringBuilder Xb;
    static int Wb;
    private w Sb;
    private int Rb = 0;
    static String[][] Qb;
    static String Tb;
    static String Ob;
    static int[] Vb;

    final int a(byte by, boolean bl) {
        block7: {
            boolean bl2 = client.A;
            this.a(false, bl);
            if (bl) {
                while (ab.c((byte)-126)) {
                    if (85 == wh.wh_c && -1 > ~this.Xb.length()) {
                        vf.a(this.Xb, -23510, -1 + this.Xb.length(), ' ');
                    }
                    if (re.a(by ^ 9, el.G, this.Xb) || -1 == ~this.Xb.length() && '[' == el.G || this.Xb.length() == 1 && el.G == '#' || el.G == ']') {
                        this.Xb.append(el.G);
                    }
                    if (wh.wh_c == 84) {
                        if (this.Xb.length() > 0) {
                            this.Y = this.Xb.toString();
                            return 2;
                        }
                        return 1;
                    }
                    if (-14 != ~wh.wh_c) continue;
                    return 1;
                }
            }
            this.Sb.Y = this.Xb.toString();
            if (bl && -1 != ~ig.Yb && ~this.w_ob == -1) {
                this.Rb = 1;
            }
            if (by == -63) break block7;
            Wb = 87;
        }
        return this.Rb;
    }

    final boolean f(int n) {
        if (~this.Rb != -1) {
            return false;
        }
        if (wh.wh_c == 85 && ~this.Xb.length() < -1) {
            vf.a(this.Xb, n ^ 0xFFFFA52F, this.Xb.length() + -1, ' ');
        }
        if (-13 < ~this.Xb.length()) {
            char c = Character.toLowerCase(el.G);
            if (c == ' ') {
                c = '_';
            }
            if ('_' == c && 0 < this.Xb.length()) {
                this.Xb.append(c);
            }
            if (v.a(c, -24380) || fl.a(c, (byte)23)) {
                this.Xb.append(c);
            }
        }
        if (-85 == ~wh.wh_c) {
            if (-1 <= ~this.Xb.length()) {
                this.Rb = 1;
            } else {
                this.Y = this.Xb.toString();
                this.Rb = 2;
            }
        }
        if (~wh.wh_c == -14) {
            this.Rb = 1;
        }
        if (n != 261) {
            this.a((byte)13, false);
        }
        return true;
    }

    static final void a(byte[] byArray, int n, pi[] piArray, ji ji2, String[] stringArray, int n2, int n3, ji ji3, String[][] stringArray2, ck[][] ckArray, boolean bl, int[] nArray, ck[][] ckArray2, byte[] byArray2, String[][] stringArray3, ji ji4, int n4, String[] stringArray4, int[] nArray2, String[] stringArray5) {
        bb.a(false, ji4, piArray, nArray, ji3);
        la.a(ji4, 32373);
        mf.a(n3, stringArray5, byArray, ji4, -8894, stringArray2, ckArray, n, stringArray3, stringArray4, stringArray, ckArray2, n4, byArray2, nArray2);
        if (n2 != 3) {
            hb.e(-36);
        }
        ua.a(46, ji4, bl, ji2);
        ge.a((byte)123);
        tj.h((byte)-27);
        f.d(18);
    }

    public static void e(int n) {
        Vb = null;
        Qb = null;
        if (n >= -48) {
            Pb = null;
        }
        Ob = null;
        Pb = null;
        Ub = null;
        Tb = null;
    }

    hb(int n, int n2, int n3, int n4, String string, w w2, w w3, w w4) {
        super(0L, w2);
        this.Nb = new w(0L, w3, string);
        this.a(this.Nb, -16834);
        this.Sb = new w(0L, w4);
        this.Sb.G = 0xFFCC66;
        this.a(this.Sb, -16834);
        this.Sb.T = "|";
        this.Xb = new StringBuilder(12);
        int n5 = this.Nb.a(true);
        this.Nb.a(n5, 0, 3, kf.O, 5);
        this.Sb.a(n5, 0, kf.O + 3, kf.O, 5);
        int n6 = 10 + n5;
        int n7 = 3 + (3 - -(2 * kf.O));
        int n8 = vh.a(n3, -18265, n6, n);
        int n9 = o.a(n4, 0, n7, n2);
        this.a(n6, 0, n9, n7, n8);
    }

    static {
        Tb = "Please try changing the following settings:  ";
        Vb = new int[16384];
    }
}
