/*
 * Decompiled with CFR 0.152.
 */
final class kn
extends bh {
    int kn_w;
    int y;
    static String kn_n = "<%0> must play <%1> more rated games before playing with the current options.";
    int kn_q;
    long kn_o;
    int kn_u = 0xFFFF & dk.dk_a++;
    int[] kn_s;
    int kn_v;
    int kn_t;
    static w kn_r;
    int x;
    static w kn_p;

    public static void a(int n) {
        kn_r = null;
        kn_p = null;
        if (n != -1) {
            kn.a(11);
        }
        kn_n = null;
    }

    static final void a(mm mm2, byte by, int n, String string, int n2, int n3) {
        if (by != -39) {
            return;
        }
        int n4 = 2;
        if (se.S == mm2) {
            n4 = 1;
        }
        mm2.c(string, -n4 + n3, -n4 + n, 0, -1);
        mm2.c(string, -n4 + n3, n, 0, -1);
        mm2.c(string, -n4 + n3, n + n4, 0, -1);
        mm2.c(string, n3, -n4 + n, 0, -1);
        mm2.c(string, n3, n - -n4, 0, -1);
        mm2.c(string, n3 + n4, -n4 + n, 0, -1);
        mm2.c(string, n4 + n3, n, 0, -1);
        mm2.c(string, n4 + n3, n4 + n, 0, -1);
        if (w.w_kb == mm2) {
            mm2.c(string, 1 + n3, n + -n4, 0, -1);
            mm2.c(string, -1 + n3, n + -n4, 0, -1);
            mm2.c(string, n4 + n3, -1 + n, 0, -1);
            mm2.c(string, -n4 + n3, -1 + n, 0, -1);
            mm2.c(string, n4 + n3, n - -1, 0, -1);
            mm2.c(string, -n4 + n3, 1 + n, 0, -1);
            mm2.c(string, n3 - -1, n4 + n, 0, -1);
            mm2.c(string, -1 + n3, n + n4, 0, -1);
        }
        mm2.c(string, n3, n, n2, -1);
    }

    kn(int n, int n2, int n3, int n4, int n5, int n6, int[] nArray) {
        this.kn_s = nArray;
        this.kn_v = n4;
        this.kn_q = n2;
        this.kn_t = n3;
        this.y = n6;
        this.kn_w = n5;
        this.x = n;
    }
}
