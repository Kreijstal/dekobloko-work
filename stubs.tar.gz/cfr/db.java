/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.io.IOException;

final class db
extends IOException {
    static char[] db_g = new char[]{(char)95, (char)97, (char)98, (char)99, (char)100, (char)101, (char)102, (char)103, (char)104, (char)105, (char)106, (char)107, (char)108, (char)109, (char)110, (char)111, (char)112, (char)113, (char)114, (char)115, (char)116, (char)117, (char)118, (char)119, (char)120, (char)121, (char)122, (char)48, (char)49, (char)50, (char)51, (char)52, (char)53, (char)54, (char)55, (char)56, (char)57};
    static w db_c;
    static String[] db_e;
    static int[] db_b;
    static boolean db_d;
    static ck db_f;
    static int db_a;

    public static void a(byte by) {
        db_b = null;
        db_c = null;
        db_g = null;
        db_f = null;
        if (by <= 40) {
            String string = null;
            db.a(-81, null, string, false);
        }
        db_e = null;
    }

    static final void a(int n, String string, String string2, boolean bl) {
        tc.Qb = string2;
        if (n >= -125) {
            Component component = null;
            db.a(component, true);
        }
        hb.Ob = string;
        wi.a(bl, -83, jc.jc_a);
    }

    static final void a(Component component, boolean bl) {
        component.setFocusTraversalKeysEnabled(bl);
        component.addKeyListener(f.f_r);
        component.addFocusListener(f.f_r);
    }

    static final String b(byte by) {
        if (oa.oa_f == null) {
            return "";
        }
        if (by < 59) {
            return null;
        }
        return oa.oa_f;
    }

    static final void a(boolean bl) {
        block0: {
            vh.vh_h = null;
            if (bl) break block0;
            db.a(true);
        }
    }

    static final String a(CharSequence[] charSequenceArray, int n2) {
        int n3 = 81 / ((n2 - 44) / 62);
        return hf.a(charSequenceArray.length, 0, charSequenceArray, (byte)74);
    }

    db(String string) {
        super(string);
    }

    static final void a(int n2, Object object, fd fd2) {
        boolean bl = client.A;
        if (fd2.fd_w == null) {
            return;
        }
        int n3 = 0;
        while (-51 < ~n3 && null != fd2.fd_w.peekEvent()) {
            ua.a(1L, -128);
            ++n3;
        }
        try {
            if (n2 >= -33) {
                db.a((CharSequence[])null, -126);
            }
            if (object != null) {
                fd2.fd_w.postEvent(new ActionEvent(object, 1001, "dummy"));
            }
        }
        catch (Exception exception) {}
    }

    static final ck[] a(String string, String string2, ji ji2, boolean bl, String string3) {
        ck[] ckArray = new ck[9];
        if (!bl) {
            return null;
        }
        ckArray[6] = ckArray[8] = id.a(ji2, string3, "", 8192);
        ckArray[2] = ckArray[8];
        ckArray[0] = ckArray[8];
        ckArray[1] = ckArray[7] = id.a(ji2, string2, "", 8192);
        ckArray[3] = ckArray[5] = id.a(ji2, string, "", 8192);
        return ckArray;
    }

    static {
        db_e = new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    }
}
