/*
 * Decompiled with CFR 0.152.
 */
import java.util.Hashtable;

class kf
extends ce
implements ra {
    static int M;
    static String N;
    static qc I;
    static String R;
    static ud P;
    static w Q;
    static int O;
    static int L;
    vj H = new vj();
    static ke G;
    static String J;
    static int K;

    @Override
    final boolean a(boolean bl) {
        if (!bl) {
            return false;
        }
        return null != this.e((byte)-74);
    }

    @Override
    void a(ce ce2, int n, int n2, int n3) {
        boolean bl = client.A;
        if (n <= 38) {
            this.a(false);
        }
        super.a(ce2, 68, n2, n3);
        rd rd2 = new rd(this.H);
        ce ce3 = (ce)rd2.a((byte)71);
        while (ce3 != null && ce3.a((byte)38)) {
            ce3.a(ce2, 47, this.D + n2, n3 - -this.ce_u);
            ce ce4 = (ce)rd2.a(-62);
        }
    }

    final void b(ce ce2, byte by) {
        if (by != -55) {
            ce ce3 = null;
            this.a(false, ce3);
        }
        this.H.a(ce2, 2777);
    }

    @Override
    boolean a(int n, int n2, ce ce2, char c) {
        boolean bl = client.A;
        rd rd2 = new rd(this.H);
        int n3 = 18 % ((-22 - n) / 49);
        ce ce3 = (ce)rd2.a((byte)71);
        while (ce3 != null && ce3.a((byte)124)) {
            if (ce3.a(true) && ce3.a(-79, n2, ce2, c)) {
                return true;
            }
            ce ce4 = (ce)rd2.a(-78);
        }
        int n4 = n2;
        if (-81 != ~n4) {
            return false;
        }
        return bj.bj_d[81] ? this.a(ce2, (byte)-120) : this.a(32, ce2);
    }

    @Override
    final void a(int n, int n2, int n3, ce ce2, int n4, int n5) {
        block1: {
            boolean bl = client.A;
            rd rd2 = new rd(this.H);
            ce ce3 = (ce)rd2.a((byte)71);
            while (ce3 != null && ce3.a((byte)119)) {
                ce3.a(n, n2 ^ 0, this.ce_u + n3, ce2, this.D + n4, n5);
                ce ce4 = (ce)rd2.a(-126);
            }
            if (n2 == 64) break block1;
            J = null;
        }
    }

    static final String a(CharSequence charSequence, byte by) {
        int n;
        boolean bl = client.A;
        if (charSequence == null) {
            return null;
        }
        int n2 = charSequence.length();
        for (n = 0; n2 > n && ug.a(charSequence.charAt(n), 32); ++n) {
        }
        while (n < n2 && ug.a(charSequence.charAt(n2 + -1), 32)) {
            --n2;
        }
        int n3 = -n + n2;
        if (~n3 > -2) {
            return null;
        }
        if (12 < n3) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder(n3);
        if (by != 2) {
            return null;
        }
        int n4 = n;
        while (~n2 < ~n4) {
            char c;
            char c2 = charSequence.charAt(n4);
            if (oe.a(c2, by ^ 0xFFFFE7A1) && (c = un.a(228, c2)) != '\u0000') {
                stringBuilder.append(c);
            }
            ++n4;
        }
        if (0 == stringBuilder.length()) {
            return null;
        }
        return stringBuilder.toString();
    }

    @Override
    final int d(int n) {
        int n2;
        boolean bl = client.A;
        int n3 = 0;
        rd rd2 = new rd(this.H);
        ce ce2 = (ce)rd2.a((byte)71);
        while (ce2 != null) {
            n2 = ce2.d(-31);
            if (n3 < n2) {
                n3 = n2;
            }
            ce ce3 = (ce)rd2.a(-61);
        }
        n2 = -18 / ((36 - n) / 51);
        return n3;
    }

    @Override
    String c(byte by) {
        boolean bl = client.A;
        rd rd2 = new rd(this.H);
        ce ce2 = (ce)rd2.a((byte)71);
        if (by != 113) {
            ce ce3 = null;
            this.a(59, 12, 76, ce3, -65, -4, true);
        }
        while (ce2 != null) {
            String string = ce2.c((byte)113);
            if (null != string) {
                return string;
            }
            ce2 = (ce)rd2.a(-47);
        }
        return null;
    }

    private final void g(int n) {
        boolean bl = client.A;
        if (n != 0) {
            L = -109;
        }
        rd rd2 = new rd(this.H);
        ce ce2 = (ce)rd2.a((byte)71);
        while (ce2 != null) {
            ce2.f(121);
            ce ce3 = (ce)rd2.a(n + -57);
        }
    }

    @Override
    void b(int n, int n2, int n3, int n4, int n5) {
        if (n5 != -16555) {
            ce ce2 = null;
            this.a(ce2, (byte)126);
        }
        super.b(n, n2, n3, n4, n5 + 0);
        this.g(0);
    }

    final boolean a(ce ce2, byte by) {
        boolean bl = client.A;
        if (this.H.b(-105)) {
            return false;
        }
        rd rd2 = new rd(this.H);
        ce ce3 = (ce)rd2.a(true);
        while (null != ce3) {
            if (ce3.a(true)) {
                rd rd3 = new rd(this.H);
                rd3.a((bh)ce3, (byte)-88);
                ce ce4 = (ce)rd3.d(2078965185);
                while (null != ce4) {
                    if (ce4.a(false, ce2)) {
                        return true;
                    }
                    ce ce5 = (ce)rd3.d(2078965185);
                }
            }
            ce3 = (ce)rd2.d(2078965185);
        }
        if (by >= -16) {
            Q = null;
        }
        return false;
    }

    @Override
    final void d(byte by) {
        boolean bl = client.A;
        rd rd2 = new rd(this.H);
        if (by != -95) {
            this.c((byte)50);
        }
        ce ce2 = (ce)rd2.a((byte)71);
        while (null != ce2) {
            ce2.d((byte)-95);
            ce ce3 = (ce)rd2.a(-98);
        }
    }

    @Override
    final boolean a(int n, int n2, ce ce2, int n3, int n4, int n5, byte by) {
        boolean bl = client.A;
        rd rd2 = new rd(this.H);
        ce ce3 = (ce)rd2.a((byte)71);
        if (by != -55) {
            return true;
        }
        while (null != ce3 && ce3.a((byte)120)) {
            if (ce3.a(n, n2, ce2, n3, this.D + n4, this.ce_u + n5, (byte)-55)) {
                return true;
            }
            ce3 = (ce)rd2.a(-113);
        }
        return false;
    }

    kf(int n, int n2, int n3, int n4, gl gl2) {
        super(n, n2, n3, n4, gl2, null);
    }

    @Override
    final boolean a(int n, int n2, int n3, ce ce2, int n4, int n5, boolean bl) {
        boolean bl2 = client.A;
        rd rd2 = new rd(this.H);
        if (bl) {
            ce ce3 = null;
            this.a(true, ce3);
        }
        ce ce4 = (ce)rd2.a((byte)71);
        while (null != ce4 && ce4.a((byte)67)) {
            if (ce4.a(true) && ce4.a(n, n2, n3, ce2, n4, n5, bl)) {
                return true;
            }
            ce ce5 = (ce)rd2.a(-128);
        }
        return false;
    }

    private final void a(int n, int n2, StringBuilder stringBuilder, Hashtable hashtable) {
        boolean bl = client.A;
        if (n2 != 0) {
            StringBuilder stringBuilder2 = null;
            this.a((Hashtable)null, -83, stringBuilder2, true);
        }
        rd rd2 = new rd(this.H);
        ce ce2 = (ce)rd2.a((byte)71);
        while (ce2 != null) {
            stringBuilder.append('\n');
            int n3 = 0;
            while (~n3 >= ~n) {
                stringBuilder.append(' ');
                ++n3;
            }
            ce2.a(hashtable, 1 + n, stringBuilder, true);
            ce2 = (ce)rd2.a(-113);
        }
    }

    @Override
    void a(int n, int n2, int n3, int n4) {
        block2: {
            boolean bl = client.A;
            if (n3 == 0 && this.ce_p != null) {
                this.ce_p.a(true, n, n4, (byte)-108, this);
            }
            rd rd2 = new rd(this.H);
            ce ce2 = (ce)rd2.a(true);
            while (ce2 != null) {
                ce2.a(n + this.ce_u, -124, n3, n4 - -this.D);
                ce ce3 = (ce)rd2.d(2078965185);
            }
            if (n2 <= -103) break block2;
            this.a(59, -115, 20, 76);
        }
    }

    @Override
    final StringBuilder a(Hashtable hashtable, int n, StringBuilder stringBuilder, boolean bl) {
        block1: {
            if (this.a(0, n, hashtable, stringBuilder)) {
                this.a((byte)72, stringBuilder, hashtable, n);
                this.a(n, 0, stringBuilder, hashtable);
            }
            if (bl) break block1;
            P = null;
        }
        return stringBuilder;
    }

    final boolean a(int n, ce ce2) {
        boolean bl = client.A;
        if (this.H.b(-15)) {
            return false;
        }
        rd rd2 = new rd(this.H);
        ce ce3 = (ce)rd2.a((byte)71);
        while (ce3 != null) {
            if (ce3.a(true)) {
                rd rd3 = new rd(this.H);
                rd3.a((bh)ce3, false);
                ce ce4 = (ce)rd3.a(n ^ 0xFFFFFFE8);
                while (ce4 != null) {
                    if (ce4.a(false, ce2)) {
                        return true;
                    }
                    ce ce5 = (ce)rd3.a(n + -119);
                }
            }
            ce3 = (ce)rd2.a(-109);
        }
        if (n != 32) {
            kf.h(-42);
        }
        return false;
    }

    public static void h(int n) {
        if (n < 72) {
            kf.h(-51);
        }
        P = null;
        R = null;
        Q = null;
        I = null;
        J = null;
        N = null;
        G = null;
    }

    ce e(byte by) {
        boolean bl = client.A;
        rd rd2 = new rd(this.H);
        ce ce2 = (ce)rd2.a((byte)71);
        while (ce2 != null) {
            if (ce2.a(true)) {
                return ce2;
            }
            ce ce3 = (ce)rd2.a(-92);
        }
        if (by == -74) {
            return null;
        }
        P = null;
        return null;
    }

    @Override
    final boolean a(boolean bl, ce ce2) {
        boolean bl2 = client.A;
        if (bl) {
            O = -99;
        }
        rd rd2 = new rd(this.H);
        ce ce3 = (ce)rd2.a((byte)71);
        while (null != ce3) {
            if (ce3.a(false, ce2)) {
                return true;
            }
            ce ce4 = (ce)rd2.a(-69);
        }
        return false;
    }

    static {
        R = "Offer draw";
        N = "Unable to connect to the data server. Please check any firewall you are using.";
        L = -1;
        J = "This is your RuneScape clan if you have one.";
    }
}
