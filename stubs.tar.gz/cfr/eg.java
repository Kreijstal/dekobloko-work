/*
 * Decompiled with CFR 0.152.
 */
final class eg {
    static String eg_a = "Playing";
    static String eg_b = "Game";
    static String eg_c = "Email (Login):";
    static boolean eg_d = false;
    static ji eg_e;

    static final void a(int n, int n2, int n3, byte by) {
        block3: {
            if (n == 0 && ~qk.qk_i != ~n3) {
                rg.rg_c = true;
                qk.qk_i = n3;
                mf.a((byte)125, n2);
            }
            if (1 == n && ~wh.wh_d != ~n3) {
                rg.rg_c = true;
                wh.wh_d = n3;
                mf.a((byte)108, n2);
            }
            if (2 == n && n3 != wl.wl_o) {
                wl.wl_o = n3;
                rg.rg_c = true;
                mf.a((byte)120, n2);
            }
            if (by > 67) break block3;
            eg_d = false;
        }
    }

    static final int[] a(int[] nArray, int[] nArray2, byte by) {
        int[] nArray3;
        boolean bl = client.A;
        if (by < 76) {
            eg.a(null, null, (byte)-36);
        }
        int[] nArray4 = nArray3 = new int[8];
        int n = 0;
        while (-9 < ~n) {
            nArray3[n] = lb.a(nArray2[n], nArray[n]);
            ++n;
        }
        return nArray3;
    }

    static final ie a(byte by) {
        if (by != 63) {
            eg.a((byte)127);
        }
        return new dn();
    }

    public static void a(int n) {
        eg_a = null;
        eg_b = null;
        if (n != 10140) {
            return;
        }
        eg_e = null;
        eg_c = null;
    }
}
