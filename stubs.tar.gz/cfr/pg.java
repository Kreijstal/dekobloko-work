/*
 * Decompiled with CFR 0.152.
 */
final class pg {
    static ck pg_f;
    static boolean[] pg_a;
    static ud pg_d;
    static ck pg_e;
    static String pg_g;
    static String pg_c;
    static double pg_b;

    static final Boolean a(int n) {
        if (n != 24994) {
            pg_g = null;
        }
        Boolean bl = wb.Ub;
        wb.Ub = null;
        return bl;
    }

    public static void a(byte by) {
        block0: {
            pg_c = null;
            pg_a = null;
            pg_g = null;
            pg_e = null;
            pg_f = null;
            pg_d = null;
            if (by == 126) break block0;
            pg.a((byte)95);
        }
    }

    static {
        pg_a = new boolean[8];
        pg_c = "Accept draw";
        pg_g = "TAB - hide chat temporarily";
        pg_b = 0.0;
    }
}
