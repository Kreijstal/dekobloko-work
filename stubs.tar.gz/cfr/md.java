/*
 * Decompiled with CFR 0.152.
 */
final class md
extends kf
implements rl,
vn {
    static String S;
    static String[] U;
    static int Z;
    private qi T;
    private ek V;
    private wj W;
    static String Y;
    static w X;

    @Override
    public final void a(qi qi2, int n, int n2, int n3) {
        block2: {
            block3: {
                block1: {
                    boolean bl = client.A;
                    if (n2 >= -87) {
                        return;
                    }
                    if (0 != n3) break block1;
                    jg.a(true, "terms.ws");
                    break block2;
                }
                if (~n3 == -2) break block3;
                if (n3 != 2) break block2;
                jg.a(true, "conduct.ws");
                break block2;
            }
            jg.a(true, "privacy.ws");
        }
    }

    md(wj wj2) {
        super(0, 0, 288, 0, null);
        this.W = wj2;
        this.V = new ek(fa.fa_o, null);
        this.V.ce_p = new fk();
        String string = cm.a((byte)118, i.i_a, new String[]{this.h((byte)60), this.g((byte)57)});
        int n = 20;
        a a2 = new a(hh.hh_e, 0, 0, 0, 0, 0xFFFFFF, -1, 3, 0, hh.hh_e.R, -1, Integer.MAX_VALUE, true);
        this.T = new qi(string, a2);
        this.T.B = "";
        this.T.a(rb.rb_i, 0, 1);
        this.T.a(rb.rb_i, 1, 1);
        this.T.ce_t = -40 + this.ce_t;
        this.T.ce_v = this;
        this.T.c(15, 26, n, this.ce_t + -40);
        this.b(this.T, (byte)-55);
        int n2 = 4;
        int n3 = 200;
        this.V.b(40, n3, 300 - n3 >> -1381308543, n += this.T.y + 15, -16555);
        this.V.ce_v = this;
        this.b(this.V, (byte)-55);
        this.b(n2 + 55 + n, 300, 0, 0, -16555);
    }

    static final String a(int n, String string, boolean bl) {
        bh bh2;
        boolean bl2 = client.A;
        if (!dc.a(string, (byte)-70)) {
            return ge.ge_d;
        }
        if (2 != jj.jj_b) {
            return kl.x;
        }
        wb wb2 = ed.a(string, (byte)-94);
        if (null == wb2) {
            return cm.a((byte)94, wc.wc_q, new String[]{string});
        }
        qi.S.a(64, wb2);
        while (true) {
            wb wb3 = (wb)qi.S.d(true);
            bh2 = wb3;
            if (wb3 == null) break;
            --wb3.Xb;
        }
        wb2.b((byte)119);
        wb2.e((byte)121);
        --Z;
        bh2 = we.we_b;
        ((uf)bh2).f(n, -4);
        ++((uf)bh2).wl_n;
        int n2 = ((uf)bh2).wl_n;
        ((wl)bh2).a(true, 1);
        ((wl)bh2).a(0, string);
        if (bl) {
            String string2 = null;
            md.a(-20, string2, false);
        }
        ((wl)bh2).b(((uf)bh2).wl_n + -n2, !bl);
        return null;
    }

    private final String g(byte by) {
        block0: {
            if (by == 57) break block0;
            qi qi2 = null;
            this.a(qi2, -92, 49, 97);
        }
        return "</col></u>";
    }

    @Override
    final boolean a(int n, int n2, ce ce2, char c) {
        if (super.a(-119, n2, ce2, c)) {
            return true;
        }
        if (~n2 == -99) {
            return this.a(ce2, (byte)-57);
        }
        if (-100 == ~n2) {
            return this.a(32, ce2);
        }
        int n3 = -29 / ((-22 - n) / 49);
        return false;
    }

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        block1: {
            if (by != 67) {
                S = null;
            }
            if (ek2 != this.V) break block1;
            in.c((byte)-51);
            this.W.n(69);
        }
    }

    static final void a(int n, int n2, int n3) {
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        uf2.a(true, 3);
        uf2.a(true, n);
        uf2.d(n ^ 0xFFFFFFF6, n3);
    }

    private final String h(byte by) {
        block0: {
            if (by == 60) break block0;
            this.W = null;
        }
        return "<u=2164A2><col=2164A2>";
    }

    public static void f(byte by) {
        if (by <= 62) {
            S = null;
        }
        S = null;
        U = null;
        X = null;
        Y = null;
    }

    static {
        U = new String[8];
        S = "<%0> has been removed.";
        Y = "Specials enabled:";
    }
}
