/*
 * Decompiled with CFR 0.152.
 */
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.SwingUtilities;

final class wg
implements MouseListener,
MouseMotionListener,
FocusListener {
    static int wg_e;
    static String wg_g;
    static ck wg_c;
    static ji wg_h;
    static qm wg_a;
    static ck wg_b;
    static int wg_d;
    static boolean wg_f;
    static long wg_i;

    @Override
    public final synchronized void mouseEntered(MouseEvent mouseEvent) {
        block0: {
            if (null == ik.ik_f) break block0;
            pf.pf_g = 0;
            lc.lc_f = mouseEvent.getX();
            te.te_r = mouseEvent.getY();
            ml.ml_b = true;
        }
    }

    static final int a(boolean bl, CharSequence charSequence, char c) {
        int n;
        block2: {
            boolean bl2 = client.A;
            n = 0;
            int n2 = charSequence.length();
            int n3 = 0;
            while (~n2 < ~n3) {
                if (~charSequence.charAt(n3) == ~c) {
                    ++n;
                }
                ++n3;
            }
            if (bl) break block2;
            wg_e = 126;
        }
        return n;
    }

    public static void a(boolean bl) {
        wg_g = null;
        wg_c = null;
        wg_a = null;
        wg_h = null;
        if (!bl) {
            return;
        }
        wg_b = null;
    }

    wg() {
    }

    @Override
    public final synchronized void mouseReleased(MouseEvent mouseEvent) {
        block4: {
            if (null != ik.ik_f) {
                pf.pf_g = 0;
                pa.pa_bb = 0;
                ml.ml_b = true;
                int n = mouseEvent.getModifiers();
                if ((8 & n) != 0) {
                    // empty if block
                }
                if (0 != (0x10 & n)) {
                    // empty if block
                }
                if (0 == (n & 4)) {
                    // empty if block
                }
            }
            if (!mouseEvent.isPopupTrigger()) break block4;
            mouseEvent.consume();
        }
    }

    @Override
    public final synchronized void mouseMoved(MouseEvent mouseEvent) {
        block0: {
            if (ik.ik_f == null) break block0;
            pf.pf_g = 0;
            lc.lc_f = mouseEvent.getX();
            te.te_r = mouseEvent.getY();
            ml.ml_b = true;
        }
    }

    static final void a(boolean bl, wl wl2, ve ve2, byte by) {
        boolean bl2 = client.A;
        if (bl) {
            ve2.ve_rc = wl2.d((byte)-75);
        }
        ve2.ve_mc = wl2.d((byte)-75);
        ve2.Wb = wl2.d((byte)-62);
        int n = wl2.d((byte)-95);
        ve2.Cc = -1 != ~(0x80 & n);
        ve2.Ic = (0x20 & n) != 0;
        ve2.gc = ve2.Cc && ~ve2.ve_rc > ~ve2.ve_mc;
        ve2.ve_lc = ~(0x40 & n) != -1;
        ve2.ve_wc = -1 != ~(n & 8);
        ve2.ve_qc = 0 == (0x10 & n) ? 1 : 2;
        boolean bl3 = 0 != (4 & n);
        boolean bl4 = (n & 2) != 0;
        wl2.a(ve2.ve_kc, 0, (byte)126, ve2.ve_kc.length);
        ve2.Ub = wl2.e(3);
        ve2.ve_tc = ik.a(4) - (long)wl2.i(7553);
        ve2.Nb = bl3 ? wl2.i(7553) : -1;
        if (by > -41) {
            return;
        }
        ve2.Xb = wl2.f((byte)-108);
        int n2 = wl2.wl_n;
        ve2.Vb = wl2.c((byte)-38);
        if (!bl4) {
            ve2.xc = null;
        } else {
            ve2.xc = new String[ve2.ve_rc];
            wl2.wl_n = n2;
            for (int i = 0; ve2.ve_rc > i; ++i) {
                ve2.xc[i] = wl2.c((byte)-38);
            }
        }
    }

    static final boolean a(uf uf2, byte by) {
        int n = 82 % ((-69 - by) / 43);
        return uf2.a(1, (byte)53) == 1;
    }

    @Override
    public final synchronized void focusLost(FocusEvent focusEvent) {
        block0: {
            if (ik.ik_f == null) break block0;
            pa.pa_bb = 0;
        }
    }

    @Override
    public final synchronized void mousePressed(MouseEvent mouseEvent) {
        block6: {
            if (ik.ik_f != null) {
                pf.pf_g = 0;
                ge.ge_a = mouseEvent.getX();
                qa.qa_t = mouseEvent.getY();
                ik.a(4);
                if (!SwingUtilities.isRightMouseButton(mouseEvent)) {
                    nk.nk_l = 1;
                    pa.pa_bb = 1;
                } else {
                    nk.nk_l = 2;
                    pa.pa_bb = 2;
                }
                int n = mouseEvent.getModifiers();
                if (0 == (4 & n)) {
                    // empty if block
                }
                ml.ml_b = true;
                if (~(n & 0x10) != -1) {
                    // empty if block
                }
                if (~(n & 8) != -1) {
                    // empty if block
                }
            }
            if (!mouseEvent.isPopupTrigger()) break block6;
            mouseEvent.consume();
        }
    }

    @Override
    public final synchronized void mouseDragged(MouseEvent mouseEvent) {
        block0: {
            if (ik.ik_f == null) break block0;
            pf.pf_g = 0;
            lc.lc_f = mouseEvent.getX();
            te.te_r = mouseEvent.getY();
            ml.ml_b = true;
        }
    }

    @Override
    public final void mouseClicked(MouseEvent mouseEvent) {
        block0: {
            if (!mouseEvent.isPopupTrigger()) break block0;
            mouseEvent.consume();
        }
    }

    @Override
    public final void focusGained(FocusEvent focusEvent) {
    }

    @Override
    public final synchronized void mouseExited(MouseEvent mouseEvent) {
        block0: {
            if (ik.ik_f == null) break block0;
            pf.pf_g = 0;
            lc.lc_f = -1;
            te.te_r = -1;
            ml.ml_b = true;
        }
    }

    static {
        wg_g = "Find opponents";
        wg_a = new qm(11, 0, 1, 2);
    }
}
