/*
 * Decompiled with CFR 0.152.
 */
final class ub {
    static String ub_f = "IO error - unable to communicate reliably with the data server. Please check any firewall/antivirus/filtering software.";
    static String ub_e = "Player";
    static int[] ub_d = new int[36];
    static String ub_b;
    static int ub_a;
    static String ub_c;

    static final int a(int n, byte by, int n2) {
        boolean bl = client.A;
        int n3 = fc.fc_a;
        for (int i = 0; rk.P.length > i; ++i) {
            int n4;
            int n5 = k.k_g[i];
            if (-1 < ~n5) {
                n3 += ke.ke_d;
                continue;
            }
            int n6 = si.a(false, rk.P[i], true);
            if (gi.a(17, n2, n, n6 + (mb.mb_c << 242737281), n3 += qk.qk_m, (pa.Y << 1992180769) + cc.cc_a, (n4 = qk.qk_d - (n6 >> -1844375231)) - mb.mb_c)) {
                return n5;
            }
            n3 += qk.qk_m + ((pa.Y << -922946463) - -cc.cc_a);
        }
        if (by != -81) {
            return -50;
        }
        return -1;
    }

    static final void a(byte by) {
        block1: {
            if (jh.jh_h) {
                hk.d(hk.hk_c, hk.hk_h, hk.hk_g + -hk.hk_c, hk.hk_b - hk.hk_h);
                ie.ie_c.a(1141039778, false);
            }
            if (by == 54) break block1;
            ub.a(-56, (byte)45, 35);
        }
    }

    static final sb a(int n, int n2, int n3, int n4) {
        sb sb2 = new sb();
        if (n4 <= 95) {
            ub_f = null;
        }
        sb2.sb_q = new int[n];
        sb2.sb_r = n3;
        ef.S.a(sb2, 2777);
        oi.a(-102, n2, sb2);
        return sb2;
    }

    public static void b(byte by) {
        if (by > -17) {
            ub_e = null;
        }
        ub_f = null;
        ub_e = null;
        ub_c = null;
        ub_d = null;
        ub_b = null;
    }

    static {
        ub_a = 0;
        ub_b = "Ready...";
    }
}
