/*
 * Decompiled with CFR 0.152.
 */
final class fj {
    static boolean fj_e;
    static String fj_i;
    static String fj_c;
    static w fj_d;
    static w fj_g;
    static ck[] fj_a;
    static String fj_f;
    static ud fj_k;
    static String fj_b;
    static String fj_j;
    static boolean fj_h;

    static final void a(int n, byte by, ud ud2) {
        block0: {
            ai.a(103, 0, ud2, 128, n);
            if (by == -89) break block0;
            fj_e = true;
        }
    }

    public static void a(int n) {
        fj_j = null;
        fj_g = null;
        if (n != 25988) {
            fj.a(-61);
        }
        fj_f = null;
        fj_a = null;
        fj_i = null;
        fj_c = null;
        fj_k = null;
        fj_b = null;
        fj_d = null;
    }

    static final void a(int n, int n2, int n3, int n4) {
        dk.dk_h.e(n, n4, n2);
        jh.jh_d.e(n + 35, n4, n2);
        sk.sk_g.e(n + 605, n4, n2);
        fl.fl_f.e(n, n4 + 35, n2);
        wm.wm_n.e(n + 605, n4 - -35, n2);
        if (n3 > -7) {
            return;
        }
        vg.x.e(n, 445 + n4, n2);
        pg.pg_f.e(n - -35, n4 + 445, n2);
        wc.wc_r.e(n + 605, n4 + 445, n2);
    }

    static {
        fj_j = "Withdraw request to join <%0>'s game";
        fj_e = false;
        fj_f = "Music: ";
        fj_b = "Enter name of friend to delete from list";
        fj_c = "Try again";
        fj_i = "The '<%0>' setting needs to be changed.";
    }
}
