/*
 * Decompiled with CFR 0.152.
 */
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

final class n
implements KeyListener,
FocusListener {
    static int n_c;
    static String n_d;
    static String n_a;
    static String n_b;

    public static void b(int n2) {
        if (n2 != 128) {
            n_d = null;
        }
        n_d = null;
        n_b = null;
        n_a = null;
    }

    static final void a(int n2, cc cc2, mm mm2, int n3, int n4, cc cc3, int n5, mm mm3, int n6, int n7, cc cc4, int n8, int n9, int n10, int n11, int n12, int n13, int n14, int n15, int n16, int n17) {
        lk.a(mm3, true, mm2, n6);
        int n18 = 80 % ((n9 - -81) / 39);
        s.a(n5, n17, (byte)-91, n2, n13);
        pj.a(31004, n12, n11);
        ci.a(cc4, n10, n4, (byte)-63, n8, cc3);
        gk.a(n16, n15, (byte)-75, cc2);
        wf.a(n14, n3, n7, true);
    }

    @Override
    public final synchronized void keyPressed(KeyEvent keyEvent) {
        block7: {
            int n2;
            if (f.f_r == null) break block7;
            om.om_d = 0;
            int n3 = keyEvent.getKeyCode();
            if (0 <= n3 && ~n3 > ~be.be_w.length) {
                if ((0x80 & (n3 = be.be_w[n3])) != 0) {
                    n3 = -1;
                }
            } else {
                n3 = -1;
            }
            if (wi.wi_b >= 0 && ~n3 <= -1) {
                la.la_h[wi.wi_b] = n3;
                if ((wi.wi_b = wi.wi_b - -1 & 0x7F) == rc.rc_a) {
                    wi.wi_b = -1;
                }
            }
            if (n3 >= 0 && ~(n2 = jh.jh_e + 1 & 0x7F) != ~sf.B) {
                pf.pf_i[jh.jh_e] = n3;
                bl.Z[jh.jh_e] = (char)0;
                jh.jh_e = n2;
            }
            if (~((n2 = keyEvent.getModifiers()) & 0xA) != -1 || n3 == 85 || n3 == 10) {
                keyEvent.consume();
            }
        }
    }

    @Override
    public final void focusGained(FocusEvent focusEvent) {
    }

    @Override
    public final synchronized void focusLost(FocusEvent focusEvent) {
        block0: {
            if (null == f.f_r) break block0;
            wi.wi_b = -1;
        }
    }

    @Override
    public final void keyTyped(KeyEvent keyEvent) {
        int n2;
        char c;
        if (f.f_r != null && (c = keyEvent.getKeyChar()) != '\u0000' && '\uffff' != c && he.a(-97, c) && (n2 = 1 + jh.jh_e & 0x7F) != sf.B) {
            pf.pf_i[jh.jh_e] = -1;
            bl.Z[jh.jh_e] = c;
            jh.jh_e = n2;
        }
        keyEvent.consume();
    }

    @Override
    public final synchronized void keyReleased(KeyEvent keyEvent) {
        if (f.f_r != null) {
            om.om_d = 0;
            int n2 = keyEvent.getKeyCode();
            n2 = n2 >= 0 && ~n2 > ~be.be_w.length ? be.be_w[n2] & 0xFFFFFF7F : -1;
            if (wi.wi_b >= 0 && n2 >= 0) {
                la.la_h[wi.wi_b] = ~n2;
                if (~rc.rc_a == ~(wi.wi_b = 0x7F & wi.wi_b - -1)) {
                    wi.wi_b = -1;
                }
            }
        }
        keyEvent.consume();
    }

    static final int a(byte by) {
        block0: {
            if (by == -74) break block0;
            n.a((byte)-95);
        }
        return (int)(1000000000L / ul.ul_g);
    }

    static final void a(int n2) {
        boolean bl2 = client.A;
        ed.ed_d = null;
        if (n2 != 1) {
            return;
        }
        mg.Nb = false;
        if (!vb.Z) {
            int n3 = bb.bb_e;
            if (0 < n3) {
                ed.ed_d = n3 != 1 ? cm.a((byte)87, jc.jc_e, new String[]{Integer.toString(n3)}) : aa.aa_d;
                ed.ed_d = db.a(new CharSequence[]{ed.ed_d, "<br>", hf.hf_b}, -62);
            }
            cl.cl_r.n(-127);
            em.a(-1199770620);
        } else {
            cl.cl_r.o(0x404040);
        }
    }

    static final int a(int n2, int n3, int n4) {
        int n5;
        boolean bl2 = client.A;
        if (~n3 > ~n4) {
            n5 = n3;
            n3 = n4;
            n4 = n5;
        }
        if (n2 < 37) {
            n.b(77);
        }
        while (n4 != 0) {
            n5 = n3 % n4;
            n3 = n4;
            n4 = n5;
        }
        return n3;
    }

    n() {
    }

    static {
        n_d = "Day";
        n_a = "Total: ";
    }
}
