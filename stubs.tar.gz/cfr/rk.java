/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.security.SecureRandom;

class rk
extends ek {
    static qk L;
    private int Q = -1;
    static String N;
    static int rk_cb;
    static String[] P;
    private long Z;
    static String rk_bb;
    static String[] O;
    private boolean T;
    private int M;
    static String U;
    static SecureRandom K;
    private long rk_ab = 0L;
    static mm R;
    static String Y;
    private int S;
    private int X;
    private boolean W = false;
    static int V;

    void l(int n) {
        block1: {
            if (n != 18929) {
                K = null;
            }
            if (!(this.ce_v instanceof qh)) break block1;
            ((qh)this.ce_v).a(0xFF6666, this);
        }
    }

    final void a(String string, byte by, boolean bl) {
        block3: {
            if (null == string) {
                string = "";
            }
            this.E = string;
            int n = string.length();
            if (~this.X != 0 && this.X < n) {
                this.E = this.E.substring(0, this.X);
            }
            this.S = this.M = this.E.length();
            if (by != 114) {
                U = null;
            }
            if (bl) break block3;
            this.l(18929);
        }
    }

    private final void k(int n) {
        block8: {
            block7: {
                int n2;
                int n3;
                boolean bl = client.A;
                if (!this.T) {
                    this.x = 0;
                    this.F = 0;
                    return;
                }
                if (!(this.ce_p instanceof nl)) {
                    return;
                }
                nl nl2 = (nl)((Object)this.ce_p);
                cf cf2 = nl2.a((ce)this, (byte)118);
                int n4 = cf2.a(false);
                if (n != -17122) {
                    this.M = -109;
                }
                if (~n4 > ~((n3 = nl2.a(false, this)) + -(n2 = nl2.a((byte)-106) >> -1897107391))) {
                    this.F = 0;
                    this.x = 0;
                    return;
                }
                int n5 = this.x + cf2.a((byte)-94, this.S);
                if (~(n3 + -n2) <= ~n5) {
                    if (~n2 < ~n5) {
                        this.x -= -n2 + n5;
                    }
                } else {
                    this.x = this.x + (-n2 + n3) + -n5;
                }
                if (0 < this.x) break block7;
                if (~(-n3 - -n2) >= ~this.x) break block8;
                this.x = -n3 - -n2;
                break block8;
            }
            this.x = 0;
        }
    }

    private final void f(byte by) {
        int n;
        if (~this.S != ~this.M) {
            n = ~this.S >= ~this.M ? this.S : this.M;
            int n2 = this.S <= this.M ? this.M : this.S;
            this.M = n;
            this.S = n;
            this.E = this.E.substring(0, n) + this.E.substring(n2, this.E.length());
            this.l(18929);
        }
        n = -30 / ((by - 40) / 59);
    }

    private final int e(byte by) {
        int n;
        block2: {
            boolean bl = client.A;
            int n2 = this.E.length();
            if (n2 == this.S) {
                return this.S;
            }
            n = 1 + this.S;
            while (~n > ~n2 && -33 != ~this.E.charAt(n + -1)) {
                ++n;
            }
            if (by == -30) break block2;
            this.X = 46;
        }
        return n;
    }

    @Override
    final boolean a(int n, int n2, ce ce2, int n3, int n4, int n5, byte by) {
        if (super.a(n, n2, ce2, n3, n4, n5, by)) {
            if (!(this.ce_p instanceof nl)) {
                return false;
            }
            int n6 = ((nl)((Object)this.ce_p)).a(n5, -257, this, n4, pm.pm_f, bh.bh_g);
            this.b(by ^ 0x7656, 0 != ~n6 ? n6 : 0);
            long l = ik.a(4);
            boolean bl = this.W = 250L > -this.rk_ab + l;
            if (this.W) {
                this.M = this.n(0);
                this.S = this.e((byte)-30);
                if (~this.S < -1 && this.E.charAt(-1 + this.S) == ' ') {
                    --this.S;
                }
                this.Q = this.S;
            }
            this.rk_ab = l;
            return true;
        }
        return false;
    }

    private final void g(byte by) {
        if (by != -76) {
            return;
        }
        this.h((byte)-113);
        this.f((byte)-95);
    }

    private final void b(boolean bl) {
        block1: {
            if (this.ce_v instanceof qh) {
                ((qh)this.ce_v).b(-2569, this);
            }
            if (!bl) break block1;
            this.rk_ab = 15L;
        }
    }

    rk(String string, kg kg2, int n) {
        super(string, kg2);
        this.X = n;
        this.ce_p = bf.x.c_l;
        this.a(string, (byte)114, true);
        this.T = true;
        this.Z = ik.a(4);
    }

    static final void c(boolean bl) {
        em.a(-1199770620);
        if (bl) {
            return;
        }
        hm.a(4, (byte)-104);
    }

    private final void a(String string, boolean bl) {
        if (!bl) {
            return;
        }
        if (0 != ~this.X) {
            int n = this.X + -this.E.length();
            if (-1 >= ~n) {
                return;
            }
            string = string.substring(0, n);
        }
        this.E = ~this.S != ~this.E.length() ? this.E.substring(0, this.S) + string + this.E.substring(this.S, this.E.length()) : this.E + string;
        this.S += string.length();
        this.M = this.S;
        this.l(18929);
    }

    private final void h(int n) {
        if (n < 112) {
            R = null;
        }
        try {
            String string = (String)Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null).getTransferData(DataFlavor.stringFlavor);
            this.f((byte)-92);
            this.a(string, true);
        }
        catch (Exception exception) {}
    }

    @Override
    final void a(int n, int n2, int n3, int n4) {
        block4: {
            if (n2 > -103) {
                ce ce2 = null;
                this.a(-88, -47, ce2, '%');
            }
            if (null == this.ce_p || ~n3 != -1) break block4;
            this.ce_p.a(this.I, n, n4, (byte)-110, this);
            if (this.ce_p instanceof nl) {
                long l;
                nl nl2 = (nl)((Object)this.ce_p);
                if (~this.M != ~this.S) {
                    nl2.a(this.M, this.S, n4, n, -123, this);
                }
                if ((((l = ik.a(4)) + -this.Z) % 1000L ^ 0xFFFFFFFFFFFFFFFFL) > -501L) {
                    nl2.a(this, this.S, 1, n, n4);
                }
            }
        }
    }

    @Override
    void a(ce ce2, int n, int n2, int n3) {
        block3: {
            nl nl2;
            int n4;
            super.a(ce2, 94, n2, n3);
            if (n < 38) {
                this.X = 63;
            }
            this.k(-17122);
            if (-2 != ~this.ce_o) break block3;
            if (this.ce_p instanceof nl && ~(n4 = (nl2 = (nl)((Object)this.ce_p)).a(n3, -257, this, n2, pm.pm_f, bh.bh_g)) != 0) {
                if (this.W && this.Q > n4 && ~this.M > ~n4) {
                    n4 = this.Q;
                }
                this.S = n4;
            }
            this.Z = ik.a(4);
        }
    }

    final void m(int n) {
        this.M = n;
        this.E = "";
        this.S = 0;
        this.l(18929);
    }

    private final String i(int n) {
        int n2;
        int n3 = n2 = ~this.S < ~this.M ? this.M : this.S;
        if (n <= 102) {
            return null;
        }
        int n4 = ~this.M <= ~this.S ? this.M : this.S;
        return this.E.substring(n2, n4);
    }

    public static void j(int n) {
        block0: {
            N = null;
            R = null;
            L = null;
            Y = null;
            P = null;
            U = null;
            rk_bb = null;
            O = null;
            K = null;
            if (n == 81) break block0;
            rk.c(true);
        }
    }

    private final void b(int n, int n2) {
        block1: {
            this.S = n2;
            if (!bj.bj_d[81]) {
                this.M = this.S;
            }
            if (n == -30305) break block1;
            this.Z = 4L;
        }
    }

    private final void h(byte by) {
        block1: {
            String string = this.i(127);
            if (-1 > ~string.length()) {
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(this.i(103)), null);
            }
            if (by <= -96) break block1;
            String string2 = null;
            this.a(string2, true);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    final boolean a(int n, int n2, ce ce2, char c2) {
        block22: {
            block26: {
                block27: {
                    block24: {
                        block25: {
                            block23: {
                                this.Z = ik.a(4);
                                if ('<' == c2 || c2 == '>') break block23;
                                if (' ' > c2) break block24;
                                break block25;
                            }
                            return false;
                        }
                        if (c2 <= '~') break block26;
                    }
                    if (~n2 == -86) break block27;
                    if (n2 == 101) {
                        if (this.S != this.M) {
                            this.f((byte)-65);
                            return true;
                        }
                        if (~this.S > ~this.E.length()) {
                            this.M = 1 + this.S;
                            this.f((byte)-50);
                            return true;
                        }
                        break block22;
                    } else {
                        if (~n2 == -14) {
                            this.m(0);
                            return true;
                        }
                        if (~n2 == -97) {
                            if (0 >= this.S) {
                                int n3 = -114 / ((-22 - n) / 49);
                                return false;
                            }
                            this.b(-30305, !bj.bj_d[82] ? -1 + this.S : this.n(0));
                            return true;
                        }
                        if (n2 != 97) {
                            if (102 == n2) {
                                this.b(-30305, 0);
                                return true;
                            }
                            if (n2 == 103) {
                                this.b(-30305, this.E.length());
                                return true;
                            }
                            if (-85 == ~n2) {
                                this.b(false);
                                return true;
                            }
                            if (bj.bj_d[82] && -66 == ~n2) {
                                this.g((byte)-76);
                                return true;
                            }
                            if (bj.bj_d[82] && 66 == n2) {
                                this.h((byte)-101);
                                return true;
                            }
                            if (bj.bj_d[82] && ~n2 == -68) {
                                this.h(118);
                                return true;
                            }
                            break block22;
                        } else if (~this.S > ~this.E.length()) {
                            this.b(-30305, !bj.bj_d[82] ? 1 + this.S : this.e((byte)-30));
                            return true;
                        }
                    }
                    break block22;
                }
                if (this.M != this.S) {
                    this.f((byte)-94);
                    return true;
                }
                if (this.S > 0) {
                    this.M = -1 + this.S;
                    this.f((byte)113);
                    return true;
                }
                break block22;
            }
            if (~this.S != ~this.M) {
                this.f((byte)-94);
            }
            if (~this.X == 0 || ~this.E.length() > ~this.X) {
                if (~this.S <= ~this.E.length()) {
                    this.E = this.E + c2;
                    this.M = this.S = this.E.length();
                } else {
                    this.E = this.E.substring(0, this.S) + c2 + this.E.substring(this.S, this.E.length());
                    ++this.S;
                    this.M = this.S;
                }
                this.l(18929);
            }
            return true;
        }
        int n4 = -114 / ((-22 - n) / 49);
        return false;
    }

    private final int n(int n) {
        int n2;
        boolean bl = client.A;
        if (n == this.S) {
            return this.S;
        }
        for (n2 = this.S - 1; 0 < n2 && this.E.charAt(n2 - 1) != ' '; --n2) {
        }
        return n2;
    }

    static {
        O = new String[]{"Get four of the same colour touching!", "The wildcard special item (multicoloured star) can be used in place of any other colour!", "Watch out! All shapes you match will now come back as solid shapes. Match four loose pieces of the same colour against the solid shape to get rid of it again.", "Did you know that if you get two or more matches at the same time, you get a special item?"};
        rk_bb = "Suggest muting this player";
        U = "You have entered another game.";
        N = "To clear a solid shape, make another shape of the same colour against it.";
        V = -1;
    }
}
