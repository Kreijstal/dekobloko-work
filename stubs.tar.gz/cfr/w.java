/*
 * Decompiled with CFR 0.152.
 */
class w
extends km {
    static pf H;
    ck[] Q;
    int w_nb = Integer.MIN_VALUE;
    int W;
    mm J;
    boolean Kb;
    int w_pb;
    String Y;
    String T;
    private int yb;
    int w_gb;
    boolean Hb = true;
    int Bb = -1;
    int w_vb;
    ck w_tb;
    int w_ob;
    private boolean O = false;
    ck[] w_lb;
    ck w_bb;
    int E;
    static ud Eb;
    int w_ub;
    private int Jb;
    ck[] Ab;
    boolean Gb;
    int F;
    int w_mb;
    ck[] S;
    int xb;
    private int V = Integer.MIN_VALUE;
    private boolean L;
    int w_fb = -1;
    private int Lb;
    private boolean w_cb = false;
    int Z = Integer.MIN_VALUE;
    int w_db = Integer.MIN_VALUE;
    int Ib;
    static lm w_kb;
    int Mb;
    ck R;
    private int zb = 256;
    boolean w_ab;
    int w_rb = -1;
    private int K;
    int Db;
    static ck w_qb;
    static int Fb;
    int G;
    boolean w_jb;
    ck w_sb;
    boolean U;
    ck[] w_eb;
    private int Cb;
    int P = -1;
    int w_ib = Integer.MIN_VALUE;
    ck I;
    private int w_hb = Integer.MIN_VALUE;
    vj M;
    int N;
    int X;
    int w_wb = 256;

    w(long l, w w2, String string) {
        this(l, w2, 0, 0, 0, 0, string);
    }

    static final void a(int n, int n2, fa fa2) {
        uf uf2 = we.we_b;
        uf2.f(n2, -4);
        ++uf2.wl_n;
        int n3 = uf2.wl_n;
        uf2.a(true, 1);
        if (null != fa2.fa_p) {
            uf2.a(true, fa2.fa_p.length);
            uf2.a(false, fa2.fa_p.length, fa2.fa_p, 0);
        } else {
            uf2.a(true, 0);
        }
        int n4 = 120 % ((n - 60) / 53);
        uf2.a((byte)-15, n3);
        uf2.wl_n -= 4;
        fa2.fa_s = uf2.i(7553);
        uf2.b(uf2.wl_n + -n3, true);
    }

    final void a(int n, int n2, int n3, int n4, int n5) {
        this.K = n2;
        this.F = 0;
        this.w_vb = n5;
        this.Ib = n3;
        this.Mb = 0;
        this.N = n4;
        this.w_mb = n;
        this.yb = 0;
    }

    public static void f(byte by) {
        w_qb = null;
        w_kb = null;
        int n = 10 % ((-8 - by) / 47);
        H = null;
        Eb = null;
    }

    final int a(boolean bl) {
        if (!bl) {
            return -120;
        }
        return this.a((byte)84, Integer.MAX_VALUE);
    }

    private final void a(boolean bl, int n, boolean bl2, boolean bl3, int n2, int n3, boolean bl4, int n4, boolean bl5, boolean bl6, int n5) {
        boolean bl7 = client.A;
        this.E = this.w_vb + n2;
        this.w_pb = n4 + this.Ib;
        int n6 = hk.hk_c;
        int n7 = hk.hk_h;
        int n8 = hk.hk_g;
        int n9 = hk.hk_b;
        hk.f(this.E, this.w_pb, this.E - -this.w_mb, this.N + this.w_pb);
        bl3 &= this.Hb;
        if (!this.L) {
            bl2 = this.w_jb;
            bl6 = 0 != this.w_gb;
            bl4 = this.w_ab;
        }
        ck[] ckArray = this.w_lb;
        ck ck2 = this.I;
        int n10 = this.G;
        int n11 = 0;
        if (!bl3) {
            if (0 <= this.P) {
                n10 = this.P;
            }
            if (this.Ab != null) {
                ckArray = this.Ab;
            }
            if (null != this.w_tb) {
                ck2 = this.w_tb;
            }
        }
        int n12 = 0;
        if (bl2) {
            if (~this.Bb <= -1) {
                n10 = this.Bb;
            }
            if (this.R != null) {
                ck2 = this.R;
            }
            if (null != this.S) {
                ckArray = this.S;
            }
            if (Integer.MAX_VALUE != ~this.V) {
                n11 = this.V;
            }
            if (this.w_hb != Integer.MIN_VALUE) {
                n12 = this.w_hb;
            }
        }
        if (bl6) {
            if (null != this.w_bb) {
                ck2 = this.w_bb;
            }
            if (~this.w_fb <= -1) {
                n10 = this.w_fb;
            }
            if (this.Z != Integer.MIN_VALUE) {
                n11 = this.Z;
            }
            if (null != this.w_eb) {
                ckArray = this.w_eb;
            }
            if (~this.w_db != Integer.MAX_VALUE) {
                n12 = this.w_db;
            }
        }
        if (bl4) {
            if (-1 >= ~this.w_rb) {
                n10 = this.w_rb;
            }
            if (this.w_nb != Integer.MIN_VALUE) {
                n12 = this.w_nb;
            }
            if (null != this.Q) {
                ckArray = this.Q;
            }
            if (null != this.w_sb) {
                ck2 = this.w_sb;
            }
            if (Integer.MIN_VALUE != this.w_ib) {
                n11 = this.w_ib;
            }
        }
        int n13 = this.Cb + n11;
        if (n5 != -29696) {
            return;
        }
        int n14 = n12 + this.Lb;
        if (this.Gb) {
            vk.a(n3, (byte)50, ckArray, n, n4, n2);
        } else {
            vk.a(this.N, (byte)50, ckArray, this.w_mb, this.w_pb, this.E);
        }
        if (ck2 != null) {
            int n15 = n13 + this.E;
            int n16 = this.w_pb + n14;
            if (~this.X == -2) {
                n15 += (this.w_mb - ck2.K) / 2;
            }
            if (this.W == 1) {
                n16 += (this.N + -ck2.C) / 2;
            }
            if (2 == this.X) {
                n15 += -ck2.K + this.w_mb;
            }
            if (this.W == 2) {
                n16 += this.N + -ck2.C;
            }
            if (~this.zb <= -257) {
                ck2.c(n15, n16);
            } else {
                ck2.c(n15, n16, this.zb);
            }
        }
        if (null != this.Y && this.J != null) {
            String string = this.Y;
            if (bl && this.T != null) {
                string = string + this.T;
            }
            if (~this.J.a(string) < ~(this.w_mb + -(2 * this.w_ub)) || 0 <= string.indexOf("<br>")) {
                this.J.a(string, n13 + this.w_ub + this.E, this.w_pb - -n14, -(this.w_ub * 2) + this.w_mb, this.N, n10, -1, this.w_wb, this.X, this.W, this.Db);
            } else {
                if (this.W == 1) {
                    n14 += (this.N - this.J.R + -this.J.K) / 2;
                } else if (-3 == ~this.W) {
                    n14 += -this.J.R + (-this.J.K + this.N);
                }
                if (~this.X == -1) {
                    this.J.c(string, this.w_ub + (this.E + n13), this.J.R + (n14 + this.w_pb), n10, -1, this.w_wb);
                } else if (~this.X != -2) {
                    if (2 != this.X) {
                        this.J.a(string, n13 + this.w_ub + this.E, n14 + this.w_pb, -(2 * this.w_ub) + this.w_mb, this.N, n10, -1, this.w_wb, this.X, this.W, this.Db);
                    } else {
                        this.J.a(string, -(this.w_ub * 2) + (this.w_mb + this.E - -this.w_ub) - -n13, this.w_pb + (n14 - -this.J.R), n10, -1, this.w_wb);
                    }
                } else {
                    this.J.b(string, (-(2 * this.w_ub) + this.w_mb) / 2 + (this.E - (-this.w_ub + -n13)), this.J.R + (this.w_pb + n14), n10, -1, this.w_wb);
                }
            }
        }
        if (this.M != null) {
            w w2;
            w w3 = w2 = (w)this.M.c((byte)-124);
            while (null != w2) {
                w2.a(bl, this.w_mb, bl2, bl3, n11 + this.E, this.N, bl4, this.w_pb - -n12, this.O, bl6, -29696);
                w3 = (w)this.M.d(true);
            }
        }
        hk.b(n6, n7, n8, n9);
    }

    static final lm a(byte[] byArray, byte by) {
        lm lm2;
        block1: {
            if (byArray == null) {
                return null;
            }
            lm2 = new lm(byArray, sg.sg_d, fh.fh_a, tm.tm_a, hc.hc_c, tc.Nb);
            oa.a(127);
            if (by == -5) break block1;
            w.a((byte[])null, (byte)-7);
        }
        return lm2;
    }

    final void a(byte by, int n, int n2, boolean bl) {
        int n3;
        int n4;
        boolean bl2 = client.A;
        int n5 = -this.Ib;
        int n6 = n5 - this.Mb;
        int n7 = this.N;
        int n8 = n7 - -this.F;
        if (!bl) {
            n4 = 0;
            w w2 = (w)this.M.c((byte)118);
            while (w2 != null) {
                w2.Mb = -w2.Ib + n4;
                n4 += w2.F + w2.N + n;
                w w3 = (w)this.M.d(true);
            }
            n8 = -n + n4;
        }
        if (by != -94) {
            this.U = true;
        }
        if (n6 > (n4 = -n2 + n8)) {
            n6 = n4;
        }
        if (n6 < 0) {
            n6 = 0;
        }
        if (~n5 < ~(n3 = n7 - n2)) {
            n5 = n3;
        }
        if (0 > n5) {
            n5 = 0;
        }
        this.F = n8 + -n7;
        this.N = n7;
        this.Mb = n5 - n6;
        this.Ib = -n5;
    }

    w(long l, w w2) {
        this(l, w2, 0, 0, 0, 0, null);
    }

    final void a(boolean bl, boolean bl2) {
        if (bl) {
            this.w_ub = -111;
        }
        gb.Zb = !bl2;
        sl.sl_c = !bl2;
        this.a(0, (byte)127, true, hk.hk_i, hk.hk_j, 0);
    }

    final void a(w w2, int n) {
        if (n != -16834) {
            w w3 = null;
            this.a(w3, -88);
        }
        if (null == this.M) {
            this.M = new vj();
        }
        this.M.a(w2, 2777);
    }

    final void d(int n) {
        block2: {
            boolean bl = client.A;
            if (this.M != null) {
                w w2;
                w w3 = w2 = (w)this.M.b(true);
                while (null != w2) {
                    w2.L = true;
                    w2.d(-92);
                    w3 = (w)this.M.c(true);
                }
            }
            if (n < -16) break block2;
            w_kb = null;
        }
    }

    private final void a(int n, byte by, boolean bl, int n2, int n3, int n4) {
        block13: {
            boolean bl2 = client.A;
            int n5 = this.yb > 0 ? -(-this.yb >> -992822398) : this.yb >> -369067166;
            this.w_vb += n5;
            this.yb -= n5;
            n5 = ~this.Mb < -1 ? -(-this.Mb >> 1141039778) : this.Mb >> -1033044574;
            this.Ib += n5;
            this.Mb -= n5;
            n5 = -1 <= ~this.K ? this.K >> -1321852478 : -(-this.K >> 1990658082);
            this.w_mb += n5;
            this.K -= n5;
            n5 = ~this.F < -1 ? -(-this.F >> 1858545890) : this.F >> -1104169118;
            this.w_pb = n4 + this.Ib;
            this.F -= n5;
            bl &= this.Hb;
            this.N += n5;
            this.E = this.w_vb + n;
            int n6 = hk.hk_c;
            int n7 = hk.hk_h;
            int n8 = hk.hk_g;
            int n9 = hk.hk_b;
            hk.f(this.E, this.w_pb, this.w_mb + this.E, this.N + this.w_pb);
            boolean bl3 = false;
            if (gb.Zb || !bl || 0 == ig.Yb || he.S < hk.hk_c || hk.hk_g <= he.S || ~hk.hk_h < ~nf.nf_h || ~nf.nf_h <= ~hk.hk_b) {
                this.w_ob = 0;
                if (-1 != ~ig.Yb) {
                    this.w_gb = 0;
                }
            } else {
                this.xb = -this.E + he.S;
                this.Jb = -this.w_pb + nf.nf_h;
                this.w_gb = ig.Yb;
                bl3 = true;
                this.w_ob = ig.Yb;
            }
            boolean bl4 = this.Kb = !sl.sl_c && ~hk.hk_c >= ~bh.bh_g && ~bh.bh_g > ~hk.hk_g && ~hk.hk_h >= ~pm.pm_f && pm.pm_f < hk.hk_b;
            if (0 == be.be_n) {
                this.w_gb = 0;
            }
            boolean bl5 = this.w_jb = this.Kb && ~be.be_n == ~this.w_gb && bl;
            if (null != this.M) {
                w w2 = (w)this.M.b(true);
                while (null != w2) {
                    w2.a(this.E, (byte)126, bl, this.N, this.w_mb, this.w_pb);
                    w w3 = (w)this.M.c(true);
                }
            }
            if (this.Kb) {
                sl.sl_c = true;
            }
            if (bl3) {
                gb.Zb = true;
            }
            hk.b(n6, n7, n8, n9);
            if (~this.w_gb != -1 && this.U) {
                this.w_vb = -n + bh.bh_g - this.xb;
                this.Ib = -this.Jb + pm.pm_f - n4;
                if (-1 < ~this.w_vb) {
                    this.w_vb = 0;
                }
                if (0 > this.Ib) {
                    this.Ib = 0;
                }
                if (~(-this.w_mb + n3) > ~this.w_vb) {
                    this.w_vb = n3 + -this.w_mb;
                }
                this.yb = 0;
                this.Mb = 0;
                if (~(n2 + -this.N) > ~this.Ib) {
                    this.Ib = n2 - this.N;
                }
                this.E = n - -this.w_vb;
                this.w_pb = this.Ib + n4;
            }
            if (by >= 125) break block13;
            this.E = 12;
        }
    }

    final void a(int n, boolean bl) {
        block0: {
            this.a(bl, hk.hk_j, false, true, 0, hk.hk_i, false, 0, false, false, -29696);
            if (n == 1141039778) break block0;
            this.w_sb = null;
        }
    }

    final void a(int n, w w2) {
        block38: {
            if (w2 != null) {
                if (w2.w_lb != null) {
                    this.w_lb = w2.w_lb;
                }
                if (~w2.w_rb <= -1) {
                    this.w_rb = w2.w_rb;
                }
                if (w2.w_ab) {
                    this.w_ab = w2.w_ab;
                }
                if (w2.w_bb != null) {
                    this.w_bb = w2.w_bb;
                }
                if (null != w2.Y) {
                    this.Y = w2.Y;
                }
                if (w2.S != null) {
                    this.S = w2.S;
                }
                if (w2.Gb) {
                    this.Gb = w2.Gb;
                }
                if (w2.Q != null) {
                    this.Q = w2.Q;
                }
                if (w2.Ab != null) {
                    this.Ab = w2.Ab;
                }
                if (null != w2.T) {
                    this.T = w2.T;
                }
                if (0 <= w2.w_fb) {
                    this.w_fb = w2.w_fb;
                }
                if (-1 >= ~w2.P) {
                    this.P = w2.P;
                }
                if (-1 != ~w2.w_ub) {
                    this.w_ub = w2.w_ub;
                }
                if (null != w2.w_tb) {
                    this.w_tb = w2.w_tb;
                }
                if (w2.L) {
                    this.L = w2.L;
                }
                if (-1 != ~w2.Db) {
                    this.Db = w2.Db;
                }
                if (!w2.Hb) {
                    this.Hb = w2.Hb;
                }
                if (0 <= w2.Bb) {
                    this.Bb = w2.Bb;
                }
                if (w2.w_eb != null) {
                    this.w_eb = w2.w_eb;
                }
                if (null != w2.R) {
                    this.R = w2.R;
                }
                if (w2.I != null) {
                    this.I = w2.I;
                }
                if (~w2.G != -1) {
                    this.G = w2.G;
                }
                if (-257 != ~w2.w_wb) {
                    this.w_wb = w2.w_wb;
                }
                if (null != w2.J) {
                    this.J = w2.J;
                }
                if (null != w2.w_sb) {
                    this.w_sb = w2.w_sb;
                }
                if (w2.w_cb) {
                    this.w_cb = w2.w_cb;
                }
                boolean bl = this.O = this.w_cb && w2.O;
                if (Integer.MAX_VALUE != ~w2.w_db) {
                    this.w_db = w2.w_db;
                }
                if (0 != w2.Lb) {
                    this.Lb = w2.Lb;
                }
                if (0 != w2.X) {
                    this.X = w2.X;
                }
                if (Integer.MAX_VALUE != ~w2.w_hb) {
                    this.w_hb = w2.w_hb;
                }
                if (w2.w_nb != Integer.MIN_VALUE) {
                    this.w_nb = w2.w_nb;
                }
                if (w2.w_ib != Integer.MIN_VALUE) {
                    this.w_ib = w2.w_ib;
                }
                if (w2.Cb != 0) {
                    this.Cb = w2.Cb;
                }
                if (Integer.MAX_VALUE != ~w2.V) {
                    this.V = w2.V;
                }
                if (w2.W != 0) {
                    this.W = w2.W;
                }
                if (w2.Z != Integer.MIN_VALUE) {
                    this.Z = w2.Z;
                }
                if (w2.U) {
                    this.U = w2.U;
                }
            }
            if (n < -111) break block38;
            this.a(true);
        }
    }

    final void a(w w2, w w3, int n, int n2) {
        if (n2 != 0) {
            return;
        }
        if (null != w2) {
            w3.Mb = w2.Mb - -w2.F;
            w3.Ib = w2.N + (w2.Ib - -n);
        } else {
            w3.Ib = 0;
            w3.Mb = 0;
        }
    }

    final int a(byte by, int n) {
        int n2;
        boolean bl = client.A;
        int n3 = 0;
        if (this.Y != null && this.J != null && (n2 = this.J.b(this.Y, n)) > n3) {
            n3 = n2;
        }
        if (by != 84) {
            this.w_hb = -71;
        }
        if (this.I != null && n3 < (n2 = this.I.K)) {
            n3 = n2;
        }
        if (null != this.M) {
            w w2 = (w)this.M.c((byte)-125);
            while (w2 != null) {
                int n4 = w2.w_mb + w2.w_vb;
                if (~n3 > ~n4) {
                    n3 = n4;
                }
                w w3 = (w)this.M.d(true);
            }
        }
        return n3;
    }

    protected w() {
    }

    w(long l, w w2, int n, int n2, int n3, int n4, String string) {
        this.w_mb = n3;
        this.bh_i = l;
        this.N = n4;
        this.w_vb = n;
        this.Ib = n2;
        this.a(-119, w2);
        if (null != string) {
            this.Y = string;
        }
    }

    static {
        Fb = 100;
    }
}
