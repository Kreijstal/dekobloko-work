/*
 * Decompiled with CFR 0.152.
 */
final class ch {
    static boolean ch_c = false;
    static int[] ch_a;
    static String ch_d;
    static int[] ch_b;

    public static void a(int n) {
        if (n <= 76) {
            return;
        }
        ch_b = null;
        ch_d = null;
        ch_a = null;
    }

    static final void a(boolean bl, int n) {
        gg.a(0, 20763, 640 + hk.hk_j >> -522707743, hk.hk_j + -640 >> -824402751, hk.hk_i);
        if (~lg.W < -1) {
            if (null != ve.ve_dc) {
                ve.ve_dc.e(g.R.w_vb, 0);
            }
            g.R.a(1141039778, bl && !ve.Qb);
            wm.wm_h.a(n + 1141039778, bl && !ve.Qb);
        }
        if (bf.bf_r > n || tg.tg_e > 0) {
            if (null != ve.ve_dc) {
                ve.ve_dc.e(ee.ee_i.w_vb, 0);
            }
            ee.ee_i.a(n ^ 0x4402E2A2, bl && !dn.dn_k);
            oh.oh_d.a(n ^ 0x4402E2A2, bl && !dn.dn_k);
        }
        mk.a((byte)-5);
    }

    static {
        ch_d = "Password: ";
    }
}
