/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.ms.directX.DSBufferDesc
 *  com.ms.directX.DSCursors
 *  com.ms.directX.DirectSound
 *  com.ms.directX.WaveFormatEx
 */
import com.ms.directX.DSBufferDesc;
import com.ms.directX.DSCursors;
import com.ms.directX.DirectSound;
import com.ms.directX.WaveFormatEx;

final class hi
implements ej {
    private DSBufferDesc[] hi_a;
    private DSCursors[] hi_b = new DSCursors[2];

    public hi() throws Exception {
        int n;
        this.hi_a = new DSBufferDesc[2];
        new DirectSound();
        new WaveFormatEx();
        for (n = 0; 2 > n; ++n) {
            this.hi_a[n] = new DSBufferDesc();
        }
        for (n = 0; n < 2; ++n) {
            this.hi_b[n] = new DSCursors();
        }
    }
}
