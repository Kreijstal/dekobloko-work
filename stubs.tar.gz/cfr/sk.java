/*
 * Decompiled with CFR 0.152.
 */
final class sk {
    static w sk_c;
    static String sk_i;
    private int sk_p;
    boolean sk_o;
    private int sk_j;
    static int sk_k;
    static ei[][] sk_a;
    private boolean sk_n = false;
    private int sk_d;
    static int sk_e;
    static ck sk_g;
    static String sk_m;
    int sk_h = 0;
    private int sk_q;
    int sk_l;
    static ji sk_f;
    static String sk_b;

    final void a(int n, byte by) {
        block1: {
            if (-1 == ~this.sk_q) {
                this.sk_h = n;
                this.sk_o = true;
                this.sk_n = false;
            }
            if (by < -53) break block1;
            sk_b = null;
        }
    }

    final boolean a(boolean bl) {
        if (!bl) {
            sk.e(-70);
        }
        return ~this.sk_q != -1;
    }

    final boolean c(int n) {
        if (n <= 111) {
            sk_g = null;
        }
        return ~this.sk_d == -103;
    }

    final void a(boolean bl, int n, int n2) {
        this.sk_q = 0;
        this.sk_n = bl;
        if (this.sk_n) {
            this.sk_h = n2;
        }
        int n3 = -68 / ((54 - n) / 44);
    }

    final boolean a(byte by) {
        if (by != -51) {
            return false;
        }
        return ~this.sk_d == -104;
    }

    final boolean b(boolean bl) {
        if (!bl) {
            return true;
        }
        return this.sk_d == 96;
    }

    final void a(byte by, int n) {
        block7: {
            if (by != 58) {
                this.sk_h = 111;
            }
            this.sk_d = 0;
            this.sk_p = 0;
            this.sk_o = false;
            if (0 == this.sk_q) {
                this.sk_d = wh.wh_c;
            }
            if (0 == this.sk_q && ~wh.wh_c == -97) {
                if (~this.sk_h >= -1) {
                    this.sk_h = this.sk_l;
                }
                this.sk_n = false;
                --this.sk_h;
                this.sk_o = true;
            }
            if (-1 == ~this.sk_q && wh.wh_c == 97) {
                ++this.sk_h;
                this.sk_n = false;
                this.sk_o = true;
                if (this.sk_l <= this.sk_h) {
                    this.sk_h = 0;
                }
            }
            if (this.sk_q != 0 || 98 != wh.wh_c && ~wh.wh_c != -100) break block7;
            if (-1 < ~this.sk_h) {
                this.sk_h = n;
            }
            this.sk_n = false;
            this.sk_o = true;
        }
    }

    final boolean b(int n) {
        int n2 = 90 % ((31 - n) / 42);
        return this.sk_d == 97;
    }

    final void a(int n, int n2, int n3, boolean bl) {
        this.sk_n = bl;
        this.sk_q = n2;
        this.sk_h = this.sk_n ? n3 : n;
    }

    final void a(int n) {
        block5: {
            this.sk_o = false;
            this.sk_p = 0;
            if (n > -24) {
                return;
            }
            this.sk_d = 0;
            if (0 == this.sk_q && wh.wh_c == 98) {
                if (this.sk_h <= 0) {
                    this.sk_h = this.sk_l;
                }
                --this.sk_h;
                this.sk_n = false;
                this.sk_o = true;
            }
            if (~this.sk_q == -1) {
                this.sk_d = wh.wh_c;
            }
            if (0 != this.sk_q || -100 != ~wh.wh_c) break block5;
            ++this.sk_h;
            this.sk_n = false;
            if (this.sk_h >= this.sk_l) {
                this.sk_h = 0;
            }
            this.sk_o = true;
        }
    }

    static final boolean a(boolean bl, CharSequence charSequence, boolean bl2, int n) {
        boolean bl3;
        block13: {
            boolean bl4 = client.A;
            if (n < 2 || n > 36) {
                throw new IllegalArgumentException("" + n);
            }
            boolean bl5 = false;
            bl3 = false;
            int n2 = 0;
            int n3 = charSequence.length();
            for (int i = 0; i < n3; ++i) {
                int n4;
                int n5 = charSequence.charAt(i);
                if (0 == i) {
                    if (n5 == 45) {
                        bl5 = true;
                        continue;
                    }
                    if (n5 == 43 && bl2) continue;
                }
                if (48 <= n5 && 57 >= n5) {
                    n5 -= 48;
                } else if (65 <= n5 && n5 <= 90) {
                    n5 -= 55;
                } else if (n5 >= 97 && n5 <= 122) {
                    n5 -= 87;
                } else {
                    return false;
                }
                if (n5 >= n) {
                    return false;
                }
                if (bl5) {
                    n5 = -n5;
                }
                if ((n4 = n5 + n2 * n) / n != n2) {
                    return false;
                }
                bl3 = true;
                n2 = n4;
            }
            if (bl) break block13;
            sk_b = null;
        }
        return bl3;
    }

    static final int a(int n, int n2) {
        if (n2 >= -52) {
            sk_k = -122;
        }
        if (-4097 < ~(n &= 0x1FFF)) {
            return n < 2048 ? pd.pd_i[n] : pd.pd_i[4096 - n];
        }
        return -6145 >= ~n ? -pd.pd_i[-n + 8192] : -pd.pd_i[-4096 + n];
    }

    final void d(int n) {
        block0: {
            this.sk_d = 0;
            this.sk_p = n;
            this.sk_o = false;
            if (~this.sk_q != -1) break block0;
            this.sk_d = wh.wh_c;
        }
    }

    public static void e(int n) {
        sk_c = null;
        sk_i = null;
        sk_m = null;
        sk_f = null;
        sk_g = null;
        if (n != -28610) {
            sk.e(69);
        }
        sk_a = null;
        sk_b = null;
    }

    final void a(int n, int n2, int n3) {
        block8: {
            block9: {
                if (this.sk_l <= n) {
                    throw new IllegalArgumentException();
                }
                if (~n3 <= ~this.sk_l) {
                    throw new IllegalArgumentException();
                }
                this.sk_d = 0;
                this.sk_p = 0;
                this.sk_o = false;
                if (-1 != ~ig.Yb) {
                    this.sk_n = true;
                    this.sk_q = ig.Yb;
                    this.sk_p = ig.Yb;
                    this.sk_h = n3;
                    this.sk_j = ib.ib_kb;
                }
                if (this.sk_q != 0 && be.be_n != 0) {
                    if (this.sk_j <= 0) {
                        this.sk_j = qd.Ob;
                    }
                    --this.sk_j;
                }
                if (n2 != -20563) {
                    return;
                }
                if (-1 == ~ig.Yb && -1 == ~be.be_n) {
                    this.sk_q = 0;
                }
                if (-1 != ~this.sk_q || !this.sk_n && !pm.pm_b) break block8;
                if (n >= 0) break block9;
                if (!this.sk_n) break block8;
                this.sk_h = -1;
                break block8;
            }
            if (~this.sk_h != ~n) {
                this.sk_o = true;
            }
            this.sk_n = true;
            this.sk_h = n;
        }
    }

    final boolean b(byte by) {
        if (by != 114) {
            return false;
        }
        return 0 != this.sk_p || 84 == this.sk_d || -84 == ~this.sk_d;
    }

    public sk() {
    }

    sk(int n) {
        this.sk_l = n;
    }

    static {
        sk_i = "START!";
        sk_a = new ei[2][8];
        sk_m = "Private";
        sk_b = "Draw?";
    }
}
