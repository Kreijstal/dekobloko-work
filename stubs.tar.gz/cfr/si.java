/*
 * Decompiled with CFR 0.152.
 */
import java.lang.reflect.Method;
import java.util.Iterator;

final class si
implements Iterable {
    static vj si_e;
    int si_a;
    static ck[] si_d;
    static String si_j;
    private bh si_l;
    bh[] si_h;
    static String[] si_f;
    static String si_i;
    static ck si_n;
    static String si_c;
    static String si_k;
    static w[] si_b;
    static String si_g;
    static String si_m;

    final bh a(long l, byte by) {
        boolean bl = client.A;
        bh bh2 = this.si_h[(int)(l & (long)(this.si_a - 1))];
        this.si_l = bh2.bh_b;
        while (bh2 != this.si_l) {
            if ((l ^ 0xFFFFFFFFFFFFFFFFL) == (this.si_l.bh_i ^ 0xFFFFFFFFFFFFFFFFL)) {
                bh bh3 = this.si_l;
                this.si_l = this.si_l.bh_b;
                return bh3;
            }
            this.si_l = this.si_l.bh_b;
        }
        this.si_l = null;
        if (by == -37) {
            return null;
        }
        this.si_a = 79;
        return null;
    }

    final void a(long l, boolean bl, bh bh2) {
        if (null != bh2.bh_a) {
            bh2.b((byte)107);
        }
        bh bh3 = this.si_h[(int)(l & (long)(this.si_a + -1))];
        bh2.bh_a = bh3.bh_a;
        if (bl) {
            si_d = null;
        }
        bh2.bh_b = bh3;
        bh2.bh_a.bh_b = bh2;
        bh2.bh_b.bh_a = bh2;
        bh2.bh_i = l;
    }

    static final int a(boolean bl, String string, boolean bl2) {
        if (bl) {
            si.a(115, true, -31, -28, 79, (byte)85, -127);
        }
        if (!bl2) {
            return rk.R.a(string);
        }
        return bg.bg_g.a(string);
    }

    static final void d(int n) {
        if (cl.cl_r != null) {
            cl.cl_r.n(22);
        }
        sn.sn_k = new cn();
        if (n != -31842) {
            String string = null;
            si.a(true, string, true);
        }
        de.W.c(sn.sn_k, (byte)87);
    }

    static final void a(int n) {
        block1: {
            if (null != qc.qc_s) {
                qc.qc_s.a(0);
                qc.qc_s = null;
            }
            if (n > 57) break block1;
            String string = null;
            si.a(true, string, true);
        }
    }

    static final ck[] a(int n, int n2, ji ji2, byte by) {
        block1: {
            if (!gb.a(n2, ji2, n, 106)) {
                return null;
            }
            if (by == -46) break block1;
            ck[] ckArray = null;
            si.a(55, false, ckArray, true);
        }
        return ca.m(0);
    }

    static final ck[] a(int n, boolean bl2, ck[] ckArray, boolean bl3) {
        ck[] ckArray2;
        boolean bl4 = client.A;
        if (n != 25972) {
            return null;
        }
        ck[] ckArray3 = ckArray2 = new ck[ckArray.length];
        int n2 = 0;
        while (~ckArray.length < ~n2) {
            ckArray2[n2] = me.a(ckArray[n2], bl3, (byte)-87, bl2);
            ++n2;
        }
        return ckArray3;
    }

    static final boolean c(int n) {
        if (n != -12851) {
            si_i = null;
        }
        return null != qc.qc_s && ph.xb == wf.wf_u;
    }

    public final Iterator iterator() {
        return new cm(this);
    }

    static final void b(int n) {
        block5: {
            try {
                Method method = Runtime.class.getMethod("maxMemory", new Class[0]);
                if (n != 1) {
                    si_g = null;
                }
                if (method == null) break block5;
                try {
                    Runtime runtime = Runtime.getRuntime();
                    Object[] objectArray = null;
                    Long l = (Long)method.invoke(runtime, objectArray);
                    ab.ab_e = 1 + (int)(l / 0x100000L);
                }
                catch (Throwable throwable) {
                }
            }
            catch (Exception exception) {}
        }
    }

    static final void a(int n, boolean bl2, int n2, int n3, int n4, byte by, int n5) {
        if (by != -41) {
            return;
        }
        String string = -3 == ~pk.pk_r ? wk.wk_n : ob.ob_l;
        pn.a(n3, n2, bl2, n4, string, by + 168, n, n5);
    }

    public static void e(int n) {
        block0: {
            si_b = null;
            si_k = null;
            si_f = null;
            si_m = null;
            si_d = null;
            si_e = null;
            si_i = null;
            si_j = null;
            si_n = null;
            si_g = null;
            si_c = null;
            if (n == 0) break block0;
            si_n = null;
        }
    }

    si(int n) {
        this.si_a = n;
        this.si_h = new bh[n];
        int n2 = 0;
        while (~n < ~n2) {
            bh bh2;
            this.si_h[n2] = bh2 = new bh();
            bh2.bh_a = bh2;
            bh2.bh_b = bh2;
            ++n2;
        }
    }

    static {
        si_j = "Mute this player for 48 hours";
        si_e = new vj();
        si_k = "Unrated game";
        si_f = new String[]{"Bucket size", "Speed", "Colours", "Special items", "Shape feedback"};
        si_i = "You cannot add yourself!";
        si_c = "Unfortunately your configuration doesn't support fullscreen mode. You could try restarting your browser and using the signed applet.";
        si_g = "You are not currently logged in to the<nbsp>game.";
        si_m = "Connecting to<br>friend server...";
    }
}
