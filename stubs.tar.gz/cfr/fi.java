/*
 * Decompiled with CFR 0.152.
 */
interface fi {
    public void a(int var1);

    public void a(String var1, int var2);
}
