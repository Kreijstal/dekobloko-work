/*
 * Decompiled with CFR 0.152.
 */
final class ni
extends mm {
    private byte[][] M = new byte[256][];
    int[][] X;

    ni(byte[] byArray, int[] nArray, int[] nArray2, int[] nArray3, int[] nArray4, int[] nArray5, byte[][] byArray2) {
        super(byArray, nArray, nArray2, nArray3, nArray4);
        this.M = byArray2;
        this.X = new int[4][];
        this.X[0] = nArray5;
    }

    private static final void a(int n, int[] nArray, byte[] byArray, int[] nArray2, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        int n9 = 256 - n8;
        for (int i = -n5; i < 0; ++i) {
            for (int j = -n4; j < 0; ++j) {
                if ((n = byArray[n2++]) != 0) {
                    int n10 = nArray[n3];
                    int n11 = nArray2[n & 0xFF];
                    nArray[n3++] = ((n11 & 0xFF00FF) * n8 + (n10 & 0xFF00FF) * n9 & 0xFF00FF00) + ((n11 & 0xFF00) * n8 + (n10 & 0xFF00) * n9 & 0xFF0000) >> 8;
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    @Override
    final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7, boolean bl) {
        int n8;
        int n9 = n2 + n3 * hk.hk_j;
        int n10 = hk.hk_j - n4;
        int n11 = 0;
        int n12 = 0;
        if (n3 < hk.hk_h) {
            n8 = hk.hk_h - n3;
            n5 -= n8;
            n3 = hk.hk_h;
            n12 += n8 * n4;
            n9 += n8 * hk.hk_j;
        }
        if (n3 + n5 > hk.hk_b) {
            n5 -= n3 + n5 - hk.hk_b;
        }
        if (n2 < hk.hk_c) {
            n8 = hk.hk_c - n2;
            n4 -= n8;
            n2 = hk.hk_c;
            n12 += n8;
            n9 += n8;
            n11 += n8;
            n10 += n8;
        }
        if (n2 + n4 > hk.hk_g) {
            n8 = n2 + n4 - hk.hk_g;
            n4 -= n8;
            n11 += n8;
            n10 += n8;
        }
        if (n4 > 0) {
            if (n5 <= 0) {
                return;
            }
            if (bl) {
                lm.a(hk.hk_l, this.M[n], n6, n12, n9, n4, n5, n10, n11, n7);
            } else {
                ni.a(0, hk.hk_l, this.M[n], this.X[n6], n12, n9, n4, n5, n10, n11, n7);
            }
            return;
        }
    }

    private static final void a(int n, int[] nArray, byte[] byArray, int[] nArray2, int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = -(n4 >> 2);
        n4 = -(n4 & 3);
        for (int i = -n5; i < 0; ++i) {
            int n9;
            for (n9 = n8; n9 < 0; ++n9) {
                if ((n = byArray[n2++]) != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                } else {
                    ++n3;
                }
                n = byArray[n2++];
                if (n != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                } else {
                    ++n3;
                }
                n = byArray[n2++];
                if (n != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                } else {
                    ++n3;
                }
                n = byArray[n2++];
                if (n != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                    continue;
                }
                ++n3;
            }
            for (n9 = n4; n9 < 0; ++n9) {
                if ((n = byArray[n2++]) != 0) {
                    nArray[n3++] = nArray2[n & 0xFF];
                    continue;
                }
                ++n3;
            }
            n3 += n6;
            n2 += n7;
        }
    }

    @Override
    final void a(int n, int n2, int n3, int n4, int n5, int n6, boolean bl) {
        int n7;
        int n8 = n2 + n3 * hk.hk_j;
        int n9 = hk.hk_j - n4;
        int n10 = 0;
        int n11 = 0;
        if (n3 < hk.hk_h) {
            n7 = hk.hk_h - n3;
            n5 -= n7;
            n3 = hk.hk_h;
            n11 += n7 * n4;
            n8 += n7 * hk.hk_j;
        }
        if (n3 + n5 > hk.hk_b) {
            n5 -= n3 + n5 - hk.hk_b;
        }
        if (n2 < hk.hk_c) {
            n7 = hk.hk_c - n2;
            n4 -= n7;
            n2 = hk.hk_c;
            n11 += n7;
            n8 += n7;
            n10 += n7;
            n9 += n7;
        }
        if (n2 + n4 > hk.hk_g) {
            n7 = n2 + n4 - hk.hk_g;
            n4 -= n7;
            n10 += n7;
            n9 += n7;
        }
        if (n4 > 0) {
            if (n5 <= 0) {
                return;
            }
            if (bl) {
                lm.a(hk.hk_l, this.M[n], n6, n11, n8, n4, n5, n9, n10);
            } else {
                ni.a(0, hk.hk_l, this.M[n], this.X[n6], n11, n8, n4, n5, n9, n10);
            }
            return;
        }
    }
}
