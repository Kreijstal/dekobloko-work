/*
 * Decompiled with CFR 0.152.
 */
final class vk {
    static qm vk_d = new qm(9, 0, 4, 1);
    static int vk_f;
    static String vk_e;
    static byte[][] vk_c;
    static ig vk_a;
    static String[] vk_b;

    static final void a(boolean bl, int n) {
        block0: {
            dd.a(bl, false, (byte)66);
            if (n == 841566312) break block0;
            vk_f = 7;
        }
    }

    static final void a(int n, byte by, ck[] ckArray, int n2, int n3, int n4) {
        boolean bl = client.A;
        if (null == ckArray) {
            return;
        }
        if (-1 > ~n2) {
            int n5;
            if (-1 <= ~n) {
                return;
            }
            int n6 = null != ckArray[3] ? ckArray[3].K : 0;
            int n7 = ckArray[5] == null ? 0 : ckArray[5].K;
            int n8 = ckArray[1] != null ? ckArray[1].C : 0;
            int n9 = ckArray[7] != null ? ckArray[7].C : 0;
            int n10 = n2 + n4;
            int n11 = n3 + n;
            int n12 = n4 + n6;
            if (by != 50) {
                return;
            }
            int n13 = n10 - n7;
            int n14 = n3 + n8;
            int n15 = -n9 + n11;
            int n16 = n12;
            int n17 = n13;
            if (n16 > n17) {
                n16 = n17 = n4 + n6 * n2 / (n7 + n6);
            }
            int n18 = n14;
            int n19 = n15;
            if (~n18 < ~n19) {
                n18 = n19 = n8 * n / (n8 - -n9) + n3;
            }
            hk.b(hl.hl_e);
            if (null != ckArray[0]) {
                hk.f(n4, n3, n16, n18);
                ckArray[0].c(n4, n3);
                hk.a(hl.hl_e);
            }
            if (null != ckArray[2]) {
                hk.f(n17, n3, n10, n18);
                ckArray[2].c(n13, n3);
                hk.a(hl.hl_e);
            }
            if (null != ckArray[6]) {
                hk.f(n4, n19, n16, n11);
                ckArray[6].c(n4, n15);
                hk.a(hl.hl_e);
            }
            if (ckArray[8] != null) {
                hk.f(n17, n19, n10, n11);
                ckArray[8].c(n13, n15);
                hk.a(hl.hl_e);
            }
            if (null != ckArray[1] && -1 != ~ckArray[1].K) {
                hk.f(n16, n3, n17, n18);
                for (n5 = n12; n5 < n13; n5 += ckArray[1].K) {
                    ckArray[1].c(n5, n3);
                }
                hk.a(hl.hl_e);
            }
            if (null != ckArray[7] && ckArray[7].K != 0) {
                hk.f(n16, n19, n17, n11);
                for (n5 = n12; n5 < n13; n5 += ckArray[7].K) {
                    ckArray[7].c(n5, n15);
                }
                hk.a(hl.hl_e);
            }
            if (ckArray[3] != null && ~ckArray[3].C != -1) {
                hk.f(n4, n18, n16, n19);
                for (n5 = n14; n15 > n5; n5 += ckArray[3].C) {
                    ckArray[3].c(n4, n5);
                }
                hk.a(hl.hl_e);
            }
            if (null != ckArray[5] && ckArray[5].C != 0) {
                hk.f(n17, n18, n10, n19);
                n5 = n14;
                while (~n5 > ~n15) {
                    ckArray[5].c(n13, n5);
                    n5 += ckArray[5].C;
                }
                hk.a(hl.hl_e);
            }
            if (ckArray[4] != null && 0 != ckArray[4].K && ~ckArray[4].C != -1) {
                hk.f(n16, n18, n17, n19);
                for (n5 = n14; n5 < n15; n5 += ckArray[4].C) {
                    int n20 = n12;
                    while (~n20 > ~n13) {
                        ckArray[4].c(n20, n5);
                        n20 += ckArray[4].K;
                    }
                }
                hk.a(hl.hl_e);
            }
            return;
        }
    }

    static final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        boolean bl = client.A;
        if (n7 != -22981) {
            return;
        }
        int n8 = ~n5 > -81 ? 18 * (n5 / 20) : 54;
        int n9 = 0;
        if (60 <= n5) {
            if (-81 >= ~n5) {
                if (-94 < ~n5) {
                    n9 = vl.a(23841, 80, 40 + 18 * ve.ve_ic[-79 + n5]);
                } else {
                    hk.a(-48 + n2, -2 + n6 + 54, 96, 40, 4, 65280, 100);
                }
            } else {
                n8 += vl.a(23841, 80, 40 + 18 * n);
            }
        } else {
            n8 += vl.a(n7 ^ 0xFFFFFB1A, 80, 40 + 18 * n4);
        }
        fb.fb_c[n3][0].c(-45 + n2, n6 - -72, 18, 18);
        fb.fb_c[n3][0].c(n2 + -27, 72 + n6, 18, 18);
        fb.fb_c[n3][0].c(-27 + n2, n6 - -54, 18, 18);
        fb.fb_c[n3][0].c(36 + n2 - 45, n6 - -n8 + n9, 18, -n9 + 18);
        fb.fb_c[n3][3].c(54 + (n2 + -45), n9 + n6 - -n8, 18, 18 - n9);
        fb.fb_c[n3][3].c(36 + (n2 + -45), n6 - -72, 18, 18);
        fb.fb_c[n3][3].c(n2 - -9, n6 - -72, 18, 18);
        fb.fb_c[n3][3].c(72 + (-45 + n2), 72 + n6, 18, 18);
    }

    static final void a(int n) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        boolean bl = client.A;
        gb.Pb = new int[]{0, n, -8144, 65536, 0, 0, 0, -65536, 0, 0, 0, 65536};
        int n10 = jb.jb_g.length;
        int[] nArray = new int[n10];
        for (n9 = 0; n10 > n9; ++n9) {
            vg vg2 = jb.jb_g[n9];
            vg2.a(n + -14200);
            kc.b(8192, n9);
            n8 = vg2.H + vg2.vg_f >> -585987071;
            n7 = vg2.vg_b - -vg2.vg_n >> -1997616223;
            n6 = vg2.vg_i + vg2.vg_a >> -1541714015;
            n5 = gb.Pb[9] >> 849399746;
            n4 = gb.Pb[10] >> -765538462;
            int n11 = gb.Pb[11] >> -1876878686;
            int n12 = n4 * o.o_e[4] + (o.o_e[3] * n5 - -(n11 * o.o_e[5])) >> -385907858;
            n3 = n5 * o.o_e[6] + n4 * o.o_e[7] - -(o.o_e[8] * n11) >> -169876850;
            n2 = n11 * o.o_e[11] + n4 * o.o_e[10] + n5 * o.o_e[9] >> 268344750;
            nArray[n9] = n7 * n3 + n8 * n12 - -(n6 * n2) >> -8557136;
        }
        n9 = gb.Pb[9] >> -1155241432;
        int n13 = gb.Pb[10] >> -465257400;
        n8 = gb.Pb[11] >> 2107408328;
        n7 = gd.gd_e << -1099401052;
        n6 = 0;
        n5 = sk.a(n7, -58) >> 1652838728;
        n4 = ue.a(n7, 112) >> 841566312;
        if (-1 != bh.bh_g && 0 != ~pm.pm_f) {
            n6 = -320 + bh.bh_g;
            n5 = 240 - pm.pm_f;
            n4 = -128;
        }
        double d = 256.0 / Math.sqrt(n5 * n5 + n6 * n6 - -(n4 * n4));
        n5 = (int)((double)n5 * d);
        n6 = (int)((double)n6 * d);
        n4 = (int)((double)n4 * d);
        n3 = -n9 + n6;
        n2 = n5 - n13;
        int n14 = -n8 + n4;
        d = 256.0 / Math.sqrt(n14 * n14 + n3 * n3 - -(n2 * n2));
        n3 = (int)((double)n3 * d);
        n2 = (int)((double)n2 * d);
        n14 = (int)((double)n14 * d);
        for (int i = 0; jb.jb_g.length > i; ++i) {
            int n15 = 0;
            int n16 = 1;
            while (~n16 > ~jb.jb_g.length) {
                if (nArray[n15] < nArray[n16]) {
                    n15 = n16;
                }
                ++n16;
            }
            nArray[n15] = Integer.MIN_VALUE;
            vg vg3 = jb.jb_g[n15];
            kc.b(8192, n15);
            for (int j = 0; 3 > j; ++j) {
                int n17 = j;
                o.o_e[n17] = o.o_e[n17] + df.U[i][j];
            }
            on.a(true, gb.Pb, false, o.o_e, true, false, vg3);
            ug.a(vg3, n5, n3, n6, false, n14, n4, n2);
        }
    }

    static final String a(String string, int n, boolean bl) {
        if (!bl) {
            vk_c = null;
        }
        if (-4 == ~n) {
            return rk.U;
        }
        if (6 == n) {
            return vk_e;
        }
        if (7 == n) {
            return qn.qn_pb;
        }
        if (~n == -9) {
            return pm.pm_a;
        }
        if (n == 9) {
            return el.I;
        }
        if (n == 10) {
            return kb.kb_b;
        }
        if (~n == -12) {
            return dc.dc_i;
        }
        if (-15 != ~n) {
            return null;
        }
        return cm.a((byte)119, pd.pd_c, new String[]{string});
    }

    static final void a(boolean bl2, byte by) {
        block2: {
            if (~id.P <= -4 || ~te.te_p <= -3 && bj.bj_d[12]) {
                pn.a(false, true, true);
            } else {
                int n = !ph.n(-30146) ? 1 : 0;
                String string = rg.rg_f;
                wj.a(n, -118, false, 1, bl2, string);
            }
            if (by <= -29) break block2;
            vk.a(-124);
        }
    }

    public static void a(byte by) {
        vk_a = null;
        vk_c = null;
        vk_e = null;
        if (by != -93) {
            vk.a(true, -94);
        }
        vk_b = null;
        vk_d = null;
    }

    static {
        vk_e = "This game is full.";
        vk_c = new byte[250][];
        vk_b = new String[]{"Move left:", "Move right:", "Rotate left:", "Rotate right:", "or", "Drop shape:", "Leaderboard:"};
    }
}
