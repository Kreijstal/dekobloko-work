/*
 * Decompiled with CFR 0.152.
 */
final class jc {
    static w jc_h;
    static int jc_g;
    static ck jc_f;
    static w jc_d;
    static String jc_b;
    static String jc_a;
    static String jc_e;
    static w jc_c;

    static final void a(String[] stringArray, int n, String string, int n2) {
        block0: {
            boolean bl = client.A;
            sh.sh_d = kl.z;
            ea.x = ~n != -256 ? (100 <= n && n <= 105 ? wi.a(stringArray, -3) : un.a(n, string, 127)) : bn.a(false, jk.jk_e < 13);
            if (n2 == 0) break block0;
            String string2 = null;
            jc.a(null, -25, string2, -72);
        }
    }

    public static void a(boolean bl) {
        jc_h = null;
        jc_e = null;
        jc_d = null;
        if (!bl) {
            ac ac2 = null;
            jc.a(ac2, -72);
        }
        jc_f = null;
        jc_b = null;
        jc_a = null;
        jc_c = null;
    }

    static final void b(byte by) {
        block0: {
            if (by == 84) break block0;
            jc_d = null;
        }
    }

    static final void a(ac ac2, int n) {
        ac2.E = new int[]{n};
        ac2.y = new char[]{(char)63};
    }

    jc() {
    }

    public final String toString() {
        throw new IllegalStateException();
    }

    static final void a(byte by) {
        hm.hm_b = null;
        bf.bf_v = null;
        ve.ve_vc = null;
        tf.tf_gb = null;
        jg.jg_i = true;
        if (by < 97) {
            return;
        }
        if (kf.Q != null) {
            jb.jb_f = jf.jf_e;
            wj.Mb = kf.Q;
            jf.jf_e = null;
            kf.Q = null;
            wj.Mb.w_fb = -1;
            wj.Mb.Bb = -1;
        }
        k.k_a = null;
    }

    static {
        jc_g = 0;
        jc_a = "Logging in...";
        jc_e = "You have <%0> unread messages!";
        jc_b = "Simultaneous Bonus: ";
    }
}
