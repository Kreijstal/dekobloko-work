/*
 * Decompiled with CFR 0.152.
 */
final class rn {
    static String rn_a;
    static ck rn_c;
    static int[] rn_b;
    static ck[][] rn_e;
    static int rn_d;
    private static final String z;

    public static void a(int n) {
        rn_b = null;
        rn_c = null;
        rn_e = null;
        if (n >= -116) {
            return;
        }
        rn_a = null;
    }

    static {
        z = "rn.A(";
        rn_b = new int[8192];
        rn_a = "You must be a member to play with the current options.";
    }
}
