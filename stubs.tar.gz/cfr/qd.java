/*
 * Decompiled with CFR 0.152.
 */
final class qd
extends w {
    w Tb;
    static boolean Qb;
    static int Ob;
    static String[][] Pb;
    static int Rb;
    static boolean Nb;
    private w Sb;

    private final void a(int n, int n2, int n3) {
        block7: {
            if (n2 != 9328) {
                Pb = null;
            }
            int n4 = -n;
            if (null != this.Sb) {
                n4 = this.Sb.a(true);
            }
            int n5 = -n;
            if (null != this.Tb) {
                n5 = this.Tb.a((byte)84, -n4 + -n3 + this.w_mb - (n + n3));
            }
            int n6 = n3 + (n5 + n) + (n3 - -n4);
            if (~n6 < ~this.w_mb) {
                n5 += this.w_mb + -n6;
                n6 = this.w_mb;
            }
            if (-2 == ~this.X) {
                n3 += (-n6 + this.w_mb) / 2;
            }
            if (this.X == 2) {
                n3 += -n6 + this.w_mb;
            }
            if (this.Sb != null) {
                this.Sb.a(n4, 0, 0, this.N, n3);
                this.Sb.W = this.W;
            }
            if (null == this.Tb) break block7;
            this.Tb.a(n5, 0, 0, this.N, n3 - (-n4 - n));
            this.Tb.X = this.Sb == null ? this.X : 0;
            this.Tb.W = this.W;
        }
    }

    final int b(int n, int n2, int n3) {
        int n4 = -n2;
        if (n3 != 1940) {
            String string = null;
            qd.a(string, -28);
        }
        int n5 = -n2;
        if (this.Sb != null) {
            n4 = this.Sb.a(true);
        }
        if (this.Tb != null) {
            n5 = this.Tb.a(true);
        }
        return n + n4 + n - -n2 - -n5;
    }

    final void a(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        block0: {
            this.a(n5, 0, n4, n, n3);
            this.a(n6, 9328, n2);
            if (n7 == 500) break block0;
            qd.e(84);
        }
    }

    public static void f(int n) {
        block0: {
            Pb = null;
            if (n >= 67) break block0;
            qd.e(-21);
        }
    }

    static final void a(String string, int n) {
        int n2 = bh.bh_g;
        int n3 = pm.pm_f;
        int n4 = ua.H.J.a(string, 500);
        int n5 = ua.H.J.b(string, 500) + 6;
        int n6 = kf.O * n4 - -2;
        int n7 = vh.a(12, -18265, n5, n2);
        int n8 = o.a(20, n + 2, n6, n3);
        hk.f(n7, n8, n5, n6, 0);
        hk.a(1 + n7, n8 - -1, n5 - 2, n6 + n, 0xFFFF80);
        ua.H.J.a(string, 3 + n7, -ua.H.J.R + (wg.wg_e + (n8 - -1)), 500, 1000, 0, -1, 0, 0, kf.O);
    }

    static final boolean e(int n) {
        int n2 = 63 % ((79 - n) / 37);
        return null != vh.vh_h;
    }

    qd(long l, w w2, w w3, w w4, ck ck2, String string) {
        super(l, w2);
        if (ck2 != null) {
            this.Sb = new w(0L, w3);
            this.Sb.I = ck2;
            this.a(this.Sb, -16834);
        }
        if (null != string) {
            this.Tb = new w(0L, w4, string);
            this.a(this.Tb, -16834);
        }
        this.d(-65);
    }

    static {
        Ob = 4;
        Rb = 0;
        Pb = new String[][]{{"Standard", "Large"}, {"Slow", "Medium", "Fast", "Maximum", "Panic!"}, {"3", "4", "5", "6", "7"}, {"None", "Level 1 - wildcards only", "Level 2 - wildcards, earthquakes and drills", "Level 3 - Level 2 with bombs and power drills added", "Level 4 - all special items enabled"}, {"Level 1 - when loose pieces are eliminated, they are cooked<br>into a solid shape and sent to the next player", "Level 2 - like Level 1, but in addition to loose tiles, whole solid shapes<br>are sent to the next player when eliminated", "Level 3 - like Level 2, but even special items will bombard<br>the next player with everything they destroy!"}};
    }
}
