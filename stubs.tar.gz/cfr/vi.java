/*
 * Decompiled with CFR 0.152.
 */
abstract class vi
extends be {
    int y;
    static wl A = new wl(256);
    static ck[] z;

    public static void f(byte by) {
        block0: {
            A = null;
            z = null;
            if (by == 46) break block0;
            String string = null;
            vi.a(null, null, null, (byte)-124, string);
        }
    }

    abstract Object c(int var1);

    abstract boolean g(byte var1);

    vi(int n) {
        this.y = n;
    }

    static final nj a(ji ji2, ji ji3, String string, byte by, String string2) {
        int n = ji3.b(-1, string);
        int n2 = -37 % ((by - 39) / 44);
        int n3 = ji3.a(n, 13030, string2);
        return e.a(ji2, n, n3, (byte)-75, ji3);
    }

    static final int d(int n) {
        if (n != 1) {
            z = null;
        }
        return 1;
    }

    static final boolean a(int[] nArray, int n) {
        bf bf2;
        boolean bl = client.A;
        if (wf.wf_u != ph.xb) {
            return false;
        }
        long l = ik.a(n + 4);
        if (~ub.ub_a != -1 && dl.N < 0 && (bf2 = (bf)ci.ci_h.c((byte)-98)) != null && bf2.bf_p < l) {
            bf2.b((byte)112);
            sm.sm_e = bf2.bf_n.length;
            de.V.wl_n = 0;
            int n2 = 0;
            while (~n2 > ~sm.sm_e) {
                de.V.wl_r[n2] = bf2.bf_n[n2];
                ++n2;
            }
            lg.U = bb.bb_d;
            bb.bb_d = kf.L;
            kf.L = bh.bh_k;
            bh.bh_k = bf2.bf_s;
            return true;
        }
        if (n != 0) {
            vi.d(-63);
        }
        while (true) {
            if (0 > dl.N) {
                de.V.wl_n = 0;
                if (!pe.b(n + 25973, 1)) {
                    return false;
                }
                dl.N = de.V.i((byte)81);
                de.V.wl_n = 0;
                sm.sm_e = nArray[dl.N];
            }
            if (!fh.a((byte)116)) {
                return false;
            }
            if (ub.ub_a == 0) break;
            int n3 = ub.ub_a;
            if (0.0 != pg.pg_b && -1 < ~(n3 = (int)((double)n3 + gg.A.nextGaussian() * pg.pg_b))) {
                n3 = 0;
            }
            bf bf3 = new bf(l + (long)n3, dl.N, new byte[sm.sm_e]);
            for (int i = 0; sm.sm_e > i; ++i) {
                bf3.bf_n[i] = de.V.wl_r[i];
            }
            ci.ci_h.a(bf3, n ^ 0xAD9);
            dl.N = -1;
        }
        lg.U = bb.bb_d;
        bb.bb_d = kf.L;
        kf.L = bh.bh_k;
        bh.bh_k = dl.N;
        dl.N = -1;
        return true;
    }
}
