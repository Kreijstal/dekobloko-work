/*
 * Decompiled with CFR 0.152.
 */
interface gl {
    public void a(boolean var1, int var2, int var3, byte var4, ce var5);
}
