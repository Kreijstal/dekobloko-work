/*
 * Decompiled with CFR 0.152.
 */
import java.util.Random;

final class tf
extends kf
implements rl,
vn,
fi {
    df tf_db;
    static w tf_gb;
    private og tf_fb = new og("", null, 12);
    private og T;
    private og tf_eb;
    static Random tf_cb;
    private og tf_hb;
    private ek X;
    private dl W;
    private ek V;
    static String Z;
    static String tf_ab;
    private og S;
    private og Y = new og("", null, 100);
    private qi U;
    static boolean tf_bb;

    public tf() {
        super(0, 0, 496, 0, null);
        this.tf_eb = new og("", null, 100);
        this.tf_hb = new og("", null, 20);
        this.S = new og("", null, 20);
        this.T = new og("", null, 3);
        boolean bl = true;
        this.W = new dl("", null, bl);
        this.X = new ek(se.Q, null);
        this.V = new ek(ec.ec_q, null);
        this.tf_fb.B = ea.C;
        this.Y.B = ad.ad_t;
        this.tf_eb.B = aa.aa_a;
        this.tf_hb.B = wd.wd_b;
        this.S.B = ua.C;
        this.T.B = fb.fb_a;
        this.W.B = al.al_j;
        this.tf_fb.a(new jm(this.tf_fb), -5362);
        this.Y.a(new ii(this.Y), -5362);
        this.tf_eb.a(new tl(this.tf_eb, this.Y), -5362);
        this.tf_hb.a(new te(this.tf_hb, this.tf_fb, this.Y), -5362);
        this.S.a(new re(this.S, this.tf_hb), -5362);
        this.T.a(new kd(this.T), -5362);
        this.X.I = false;
        this.X.ce_p = new fk();
        this.V.ce_p = new on();
        this.tf_fb.ce_p = new di(0x989898);
        this.Y.ce_p = this.tf_eb.ce_p = new di(0x989898);
        this.T.ce_p = new di(0x989898);
        this.W.ce_p = new tg();
        this.tf_hb.ce_p = this.S.ce_p = new gm(0x989898);
        String string = cm.a((byte)102, me.G, new String[]{this.g((byte)63), this.h((byte)29)});
        int n = 20;
        n += this.a(9828, this.Y, n, eg.eg_c, 170);
        n += 5 + this.a(this.tf_eb, oc.oc_d, 20, (byte)-44, 170, n, "");
        n += this.a(9828, this.tf_hb, n, ch.ch_d, 170);
        n += this.a(125, this.S, n, sl.sl_e, ga.ga_c, 170) + 5;
        n += 5 + this.a(114, this.tf_fb, n, rg.rg_e, ij.ij_b, 170);
        n += this.a(qe.qe_e, (byte)-107, (ce)this.T, 170, n);
        de de2 = new de(46, n, -90 + this.ce_t, 25, this.W, true, -120 + this.ce_t, 5, bj.bj_f, 0xB0B0B0, h.h_a);
        this.b(de2, (byte)-55);
        n += de2.y;
        a a2 = new a(hh.hh_e, 0, 0, 0, 0, 0xFFFFFF, -1, 0, 0, hh.hh_e.R, -1, Integer.MAX_VALUE, true);
        this.U = new qi(string, a2);
        this.U.B = "";
        this.U.a(rb.rb_i, 0, 1);
        this.U.a(rb.rb_i, 1, 1);
        this.U.ce_v = this;
        this.U.c(-114, 46, n, -90 + this.ce_t);
        this.b(this.U, (byte)-55);
        int n2 = 4;
        int n3 = 200;
        this.X.b(40, n3, -n3 + 496 >> 1635535617, n += 15 + this.U.y, -16555);
        this.V.b(40, 60, 3 + n2, n + 15, -16555);
        this.V.ce_v = this;
        this.X.ce_v = this;
        this.b(this.X, (byte)-55);
        this.b(this.V, (byte)-55);
        this.tf_db = new df(this);
        this.tf_db.b(150, -60 + -this.tf_fb.ce_t + (this.ce_t + -this.tf_fb.ce_u), this.tf_fb.ce_u + this.tf_fb.ce_t + 60, this.tf_fb.D - -20, -16555);
        this.b(this.tf_db, (byte)-55);
        this.b(55 + n - -n2, 496, 0, 0, -16555);
    }

    private final boolean f(byte by) {
        int n;
        block3: {
            if (!this.i(94)) {
                return false;
            }
            n = -1;
            try {
                n = Integer.parseInt(this.T.E);
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            if (by == -35) break block3;
            tf.b(-18, false, -28, 107);
        }
        return nk.a(this.tf_hb.E, (byte)123, this, this.W.H, n, this.tf_fb.E, this.Y.E);
    }

    static final boolean a(byte by, int[] nArray) {
        boolean bl = client.A;
        if (by < 2) {
            return false;
        }
        int n = 0;
        while (~n > -9) {
            if (-1 != ~nArray[n]) {
                return true;
            }
            ++n;
        }
        return false;
    }

    static final void a(byte by, boolean bl) {
        ll.a(-1, bl);
        hm.a(-1, bl);
        int n = 36 / ((-24 - by) / 53);
    }

    @Override
    public final void a(byte by, int n, ek ek2, int n2, int n3) {
        block2: {
            block1: {
                if (by != 67) {
                    return;
                }
                if (this.V != ek2) break block1;
                t.k((byte)-73);
                break block2;
            }
            if (ek2 != this.X) break block2;
            this.f((byte)-35);
        }
    }

    @Override
    final void a(ce ce2, int n, int n2, int n3) {
        block0: {
            super.a(ce2, 75, n2, n3);
            this.X.I = this.i(-113);
            if (n > 38) break block0;
            ce ce3 = null;
            this.a(-32, 53, ce3, '[');
        }
    }

    static final void i(byte by) {
        block1: {
            if (null != w.H && w.H.pf_l != null) {
                w.H.pf_l.w_ab = false;
            }
            ki.ki_w = null;
            w.H = null;
            if (by < -55) break block1;
            tf.a((byte)-5, false);
        }
    }

    @Override
    public final void a(int n) {
        if (n != 25) {
            return;
        }
        ((jm)this.tf_fb.a(-96)).a(true);
    }

    private final int a(int n, ce ce2, int n2, String string, String string2, int n3) {
        block0: {
            if (n > 99) break block0;
            tf_cb = null;
        }
        return this.a(ce2, string2, 35, (byte)-44, n3, n2, string);
    }

    private final int a(ce ce2, String string, int n, byte by, int n2, int n3, String string2) {
        pa pa2;
        de de2;
        block0: {
            de2 = new de(20, n3, 120 + n2, 25, ce2, false, 120, 3, hh.hh_e, 0xFFFFFF, string);
            this.b(de2, (byte)-55);
            pa2 = new pa(((jl)((Object)ce2)).a(-122), string2, 126, n3 + de2.y, n2 + 50, n);
            pa2.ce_v = this;
            this.b(pa2, (byte)-55);
            if (by == -44) break block0;
            tf_bb = false;
        }
        return de2.y - -pa2.y;
    }

    public static void b(boolean bl2) {
        if (!bl2) {
            tf.a((byte)125, true);
        }
        tf_ab = null;
        Z = null;
        tf_gb = null;
        tf_cb = null;
    }

    private final boolean a(jl jl2, int n) {
        nb nb2 = jl2.a(-101);
        if (nb2 == null) {
            return true;
        }
        int n2 = -62 % ((n - 73) / 51);
        tb tb2 = nb2.a(20350);
        if (vm.vm_u == tb2) {
            return false;
        }
        if (le.le_o == tb2) {
            return false;
        }
        return ki.ki_t != tb2;
    }

    private final String h(byte by) {
        block0: {
            if (by == 29) break block0;
            tf.b(118, false, -20, 75);
        }
        return "</col></u>";
    }

    private final String g(byte by) {
        int n = 85 / ((by - -4) / 60);
        return "<u=2164A2><col=2164A2>";
    }

    private final boolean i(int n) {
        if (!(this.a(this.tf_fb, 127) && this.a(this.Y, -111) && this.a(this.tf_eb, 124) && this.a(this.tf_hb, 126) && this.a(this.S, -94) && this.a(this.T, 124))) {
            return false;
        }
        int n2 = 37 % ((16 - n) / 54);
        return true;
    }

    @Override
    final boolean a(int n, int n2, ce ce2, char c) {
        int n3 = -45 % ((-22 - n) / 49);
        if (super.a(-84, n2, ce2, c)) {
            return true;
        }
        if (-99 == ~n2) {
            return this.a(ce2, (byte)-115);
        }
        if (99 != n2) {
            return false;
        }
        return this.a(32, ce2);
    }

    static final ji a(int n, int n2, boolean bl2, boolean bl3, int n3) {
        block0: {
            if (n2 >= 73) break block0;
            Z = null;
        }
        return kc.a(bl3, n, n3, false, false, bl2);
    }

    @Override
    public final void a(qi qi2, int n, int n2, int n3) {
        block5: {
            boolean bl2 = client.A;
            if (0 != n3) {
                if (1 != n3) {
                    if (2 == n3) {
                        jg.a(true, "conduct.ws");
                    }
                } else {
                    jg.a(true, "privacy.ws");
                }
            } else {
                jg.a(true, "terms.ws");
            }
            if (n2 < -87) break block5;
            this.tf_fb = null;
        }
    }

    @Override
    public final void a(String string, int n) {
        og og2 = this.tf_fb;
        if (n != -28464) {
            ce ce2 = null;
            this.a(null, (byte)117, ce2, -76, -79);
        }
        String string2 = string;
        og2.a(string2, (byte)114, false);
    }

    static final void b(int n, boolean bl2, int n2, int n3) {
        block10: {
            String string;
            hl hl2;
            boolean bl3 = client.A;
            if (bl.T < dl.M) {
                ++bl.T;
            }
            if (le.le_m.eh_i != ac.B) {
                qc.Y += le.le_m.eh_i - ac.B;
                ac.B = le.le_m.eh_i;
            }
            if (bl.T <= 0) {
                return;
            }
            on.b((byte)-100);
            ea.D.a(false, bl2);
            if (bc.E != null) {
                if (!wc.wc_n) {
                    bc.E = null;
                } else {
                    bc.E.a(ea.D.w_pb, bl2, ea.D.E, 29166);
                }
            }
            for (int j = n2; j < 5; ++j) {
                w w2 = dh.dh_c[j];
                if (null == w2) continue;
                if (w2.w_ob != 0) {
                    cg.a(1, w2, j);
                }
                int n4 = rf.a(0, j);
                si.si_b[j].I = ef.O[n4];
                le.D[j].Y = sg.sg_a[n4];
            }
            if (~qb.qb_p.w_ob != -1) {
                pd.pd_f = new mg(qb.qb_p.E, qb.qb_p.w_pb, qb.qb_p.w_mb, qb.qb_p.N, n, ui.x, tg.tg_h, ib.ib_nb, ua.H, al.al_h, df.df_ab, null, 0L);
            }
            if ((hl2 = wj.a((byte)55, kf.O, n3, nk.nk_b)) != null) {
                cb.a(hl2, false);
            }
            if (null == (string = sf.c(-36))) break block10;
            sl.sl_g = string;
        }
    }

    private final int a(String string, byte by, ce ce2, int n, int n2) {
        de de2 = new de(20, n2, 120 - -n, 25, ce2, false, 120, 3, hh.hh_e, 0xFFFFFF, string);
        this.b(de2, (byte)-55);
        g g2 = new g(((jl)((Object)ce2)).a(-126));
        this.b(g2, (byte)-55);
        if (by != -107) {
            this.tf_db = null;
        }
        g2.b(15, 15, de2.ce_t + (de2.ce_u + 3), de2.D - -(-15 + de2.y >> 778367041), -16555);
        return de2.y;
    }

    private final int a(int n, ce ce2, int n2, String string, int n3) {
        de de2;
        block0: {
            de2 = new de(20, n2, n3 + 120, 25, ce2, false, 120, 3, hh.hh_e, 0xFFFFFF, string);
            this.b(de2, (byte)-55);
            if (n == 9828) break block0;
            String string2 = null;
            this.a(null, null, -93, (byte)120, -33, 113, string2);
        }
        return de2.y;
    }

    static {
        tf_ab = "Status";
        Z = "Click";
        tf_cb = new Random();
    }
}
