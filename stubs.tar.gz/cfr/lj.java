/*
 * Decompiled with CFR 0.152.
 */
import java.awt.Image;

final class lj {
    static w lj_c;
    static String lj_b;
    static Image lj_a;

    public static void a(int n) {
        int n2 = 67 % ((n - -1) / 55);
        lj_b = null;
        lj_a = null;
        lj_c = null;
    }

    static final void a(int n, int n2, int n3, boolean bl) {
        block0: {
            sl.a(n2, -67, n3, n);
            ob.b(n3, -299374302, n, n2);
            fh.a(n2, n, bl, n3);
            if (kf.G == null) break block0;
            pb.a(true);
        }
    }

    static {
        lj_b = "Invite <%0> to this game";
    }
}
