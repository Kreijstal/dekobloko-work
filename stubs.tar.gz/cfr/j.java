/*
 * Decompiled with CFR 0.152.
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

final class j {
    static int j_c;
    static int[] j_d;
    static String j_a;
    static int j_b;

    static final void a(int n) {
        block0: {
            jb.a(tg.tg_h, ua.H, gf.gf_g, -47, ui.x);
            if (n == 8225) break block0;
            j_a = null;
        }
    }

    static final void a(int n, int n2, fd fd2, int n3, int n4, long l2, int n5, boolean bl, int n6, int n7, boolean bl2, boolean bl3, int n8, String string) {
        de.V = new uf(n3);
        we.we_b = new uf(n4);
        mc.mc_e = string;
        lf.lf_f = fd2;
        if (!bl3) {
            return;
        }
        kb.kb_g = n6;
        l.l_c = n5;
        qk.qk_a = n;
        ce.ce_w = bl2;
        rm.rm_c = l2;
        ef.P = n7;
        hc.hc_a = n8;
        ci.ci_c = bl;
        re.re_v = n2;
        if (null != lf.lf_f.fd_v) {
            try {
                dj.dj_cb = new nh(lf.lf_f.fd_v, 64, 0);
            }
            catch (IOException iOException) {
                throw new RuntimeException(iOException.toString());
            }
        }
    }

    static final void a(byte by, boolean bl, int n, int n2, int n3, int n4, int n5) {
        boolean bl2 = client.A;
        if (n3 <= n5) {
            return;
        }
        if (1 + n5 >= n) {
            return;
        }
        if (~n >= ~(5 + n5) || ~n2 == ~n4) {
            for (int i = -1 + n; i > n5; --i) {
                int n6 = n5;
                while (~i < ~n6) {
                    int n7 = ch.ch_a[1 + n6];
                    int n8 = ch.ch_a[n6];
                    if (ee.a((byte)100, bl, n7, n8)) {
                        ch.ch_a[n6] = n7;
                        ch.ch_a[1 + n6] = n8;
                    }
                    ++n6;
                }
            }
        } else {
            int n9 = (n2 >> 861831393) + ((n4 >> -973240543) + (n4 & n2 & 1));
            int n10 = n5;
            int n11 = n2;
            int n12 = n4;
            for (int i = n5; n > i; ++i) {
                int n13;
                int n14 = ch.ch_a[i];
                int n15 = n13 = bl ? ad.ad_i[n14] : cc.cc_h[n14];
                if (n9 < n13) {
                    ch.ch_a[i] = ch.ch_a[n10];
                    ch.ch_a[n10++] = n14;
                    if (n11 <= n13) continue;
                    n11 = n13;
                    continue;
                }
                if (n13 <= n12) continue;
                n12 = n13;
            }
            j.a((byte)-33, bl, n10, n2, n3, n11, n5);
            j.a(by, bl, n, n12, n3, n4, n10);
            return;
        }
    }

    static final String a(Throwable throwable, byte by) throws IOException {
        String string;
        String string2;
        boolean bl = client.A;
        if (!(throwable instanceof jb)) {
            string2 = "";
        } else {
            jb jb2 = (jb)throwable;
            string2 = jb2.jb_i + " | ";
            throwable = jb2.jb_e;
        }
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        throwable.printStackTrace(printWriter);
        printWriter.close();
        String string3 = stringWriter.toString();
        if (by != 37) {
            j_c = 30;
        }
        BufferedReader bufferedReader = new BufferedReader(new StringReader(string3));
        String string4 = bufferedReader.readLine();
        while ((string = bufferedReader.readLine()) != null) {
            int n;
            int n2 = string.indexOf(40);
            int n3 = string.indexOf(41, n2 + 1);
            String string5 = n2 != -1 ? string.substring(0, n2) : string;
            string5 = string5.trim();
            string5 = string5.substring(string5.lastIndexOf(32) + 1);
            string5 = string5.substring(1 + string5.lastIndexOf(9));
            string2 = string2 + string5;
            if (~n2 != 0 && ~n3 != 0 && ~(n = string.indexOf(".java:", n2)) <= -1) {
                string2 = string2 + string.substring(n - -5, n3);
            }
            string2 = string2 + ' ';
        }
        string2 = string2 + "| " + string4;
        return string2;
    }

    static final boolean a(int n, char c) {
        if (n != -8241) {
            j_d = null;
        }
        return c >= '0' && '9' >= c || c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z';
    }

    public static void a(boolean bl) {
        if (!bl) {
            j_d = null;
        }
        j_a = null;
        j_d = null;
    }

    static final byte a(char c, byte by) {
        boolean bl = client.A;
        if (by != 28) {
            return 85;
        }
        int n = !(c > '\u0000' && c < '\u0080' || c >= '\u00a0' && '\u00ff' >= c) ? (c != '\u20ac' ? (c == '\u201a' ? -126 : ('\u0192' != c ? (c != '\u201e' ? (c == '\u2026' ? -123 : (c == '\u2020' ? -122 : ('\u2021' != c ? (c == '\u02c6' ? -120 : (c != '\u2030' ? (c != '\u0160' ? (c == '\u2039' ? -117 : (c != '\u0152' ? ('\u017d' == c ? -114 : (c == '\u2018' ? -111 : (c != '\u2019' ? (c != '\u201c' ? (c == '\u201d' ? -108 : ('\u2022' != c ? ('\u2013' == c ? -106 : ('\u2014' != c ? (c == '\u02dc' ? -104 : (c != '\u2122' ? (c != '\u0161' ? ('\u203a' == c ? -101 : (c == '\u0153' ? -100 : (c == '\u017e' ? -98 : (c != '\u0178' ? 63 : -97)))) : -102) : -103)) : -105)) : -107)) : -109) : -110))) : -116)) : -118) : -119)) : -121))) : -124) : -125)) : -128) : (int)c;
        return (byte)n;
    }

    static final String a(String string, String string2, String string3, int n) {
        int n2;
        boolean bl = client.A;
        int n3 = string2.length();
        int n4 = string.length();
        int n5 = string3.length();
        if (n == n4) {
            throw new IllegalArgumentException("Key cannot have zero length");
        }
        int n6 = n3;
        int n7 = -n4 + n5;
        if (0 != n7) {
            int n8 = 0;
            while ((n8 = string2.indexOf(string, n8)) >= 0) {
                n6 += n7;
                n8 += n4;
            }
        }
        StringBuilder stringBuilder = new StringBuilder(n6);
        int n9 = 0;
        while (0 <= (n2 = string2.indexOf(string, n9))) {
            stringBuilder.append(string2.substring(n9, n2));
            stringBuilder.append(string3);
            n9 = n2 - -n4;
        }
        stringBuilder.append(string2.substring(n9));
        return stringBuilder.toString();
    }

    static {
        j_a = "Not yet achieved";
        j_d = b.h(26);
    }
}
