/*
 * Decompiled with CFR 0.152.
 */
interface rl {
    public void a(qi var1, int var2, int var3, int var4);
}
