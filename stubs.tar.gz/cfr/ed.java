/*
 * Decompiled with CFR 0.152.
 */
import java.util.Calendar;
import java.util.TimeZone;

final class ed {
    static String[] ed_b;
    static String ed_e;
    static Calendar ed_a;
    static String ed_d;
    static int ed_f;
    static int ed_g;
    static String ed_c;

    static final void a(int n, int n2, String string, int n3, byte by, mm mm2) {
        int n4 = 2;
        if (se.S == mm2) {
            n4 = 1;
        }
        mm2.b(string, n2 + -n4, n3 + -n4, 0, -1);
        mm2.b(string, -n4 + n2, n3, 0, -1);
        mm2.b(string, n2 + -n4, n3 + n4, 0, -1);
        mm2.b(string, n2, n3 - n4, 0, -1);
        mm2.b(string, n2, n4 + n3, 0, -1);
        mm2.b(string, n2 - -n4, n3 + -n4, 0, -1);
        mm2.b(string, n4 + n2, n3, 0, -1);
        mm2.b(string, n2 + n4, n3 + n4, 0, -1);
        if (mm2 == w.w_kb) {
            mm2.b(string, 1 + n2, n3 + -n4, 0, -1);
            mm2.b(string, n2 - 1, -n4 + n3, 0, -1);
            mm2.b(string, n2 + n4, n3 + -1, 0, -1);
            mm2.b(string, -n4 + n2, -1 + n3, 0, -1);
            mm2.b(string, n4 + n2, 1 + n3, 0, -1);
            mm2.b(string, n2 - n4, 1 + n3, 0, -1);
            mm2.b(string, n2 - -1, n4 + n3, 0, -1);
            mm2.b(string, n2 - 1, n4 + n3, 0, -1);
        }
        if (by != 75) {
            ed_c = null;
        }
        mm2.b(string, n2, n3, n, -1);
    }

    public static void b(int n) {
        ed_d = null;
        ed_b = null;
        int n2 = -49 / ((-30 - n) / 54);
        ed_e = null;
        ed_a = null;
        ed_c = null;
    }

    static final void a(byte by, boolean bl) {
        block0: {
            int n = -33 / ((by - 79) / 41);
            ea.D.a(1141039778, bl);
            mf mf2 = bc.E;
            if (null == mf2) break block0;
            mf2.a(ea.D.w_pb, ea.D.E, (byte)-72);
        }
    }

    static final void a(ji ji2, int n2, mi mi2, int n3) {
        sh.sh_i = n2 * n.a((byte)-74) / 1000;
        if (n3 != 20350) {
            return;
        }
        wi.a((byte)-51, ji2);
        pb.a(ji2, -2);
        em.a((byte)-113, ji2);
        bg.a(-120);
        bb.a(true);
        gd.gd_e = 0 - sh.sh_i;
    }

    static final void a(int n2) {
        block1: {
            if (!v.v_d) {
                throw new IllegalStateException();
            }
            qi.M = true;
            vk.a(true, 841566312);
            hc.hc_d = 0;
            if (n2 > 101) break block1;
            String string = null;
            ed.a(string, (byte)-16);
        }
    }

    static final wb a(String string, byte by) {
        boolean bl = client.A;
        if (mc.mc_a == null) {
            return null;
        }
        if (string == null) {
            return null;
        }
        if (~string.length() == -1) {
            return null;
        }
        String string2 = kf.a(string, (byte)2);
        int n2 = 38 % ((-44 - by) / 47);
        if (string2 == null) {
            return null;
        }
        wb wb2 = (wb)mc.mc_a.a(24710, string2.hashCode());
        while (wb2 != null) {
            String string3 = kf.a(wb2.Ob, (byte)2);
            if (string3.equals(string2)) {
                return wb2;
            }
            wb2 = (wb)mc.mc_a.d(-17713);
        }
        return null;
    }

    static {
        ed_e = "Name is available";
        ed_a = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        ed_d = null;
    }
}
