/*
 * Decompiled with CFR 0.152.
 */
final class dh {
    int dh_a;
    static int dh_f;
    static int dh_d;
    static int dh_e;
    static String[] dh_b;
    static w[] dh_c;

    static final void a(mm mm2, int n, int n2, cc cc2, cc cc3, cc cc4, int n3, int n4, mm mm3, int n5, int n6, int n7, int n8, boolean bl, int n9, int n10, int n11, int n12, int n13, int n14) {
        wf.wf_q = mm2;
        if (bl) {
            dh.a(null, 99, -109, null, null, null, 54, -67, null, 70, -37, -96, -83, true, 8, 108, -4, 38, -94, -69);
        }
        aj.aj_d = mm3;
        fl.b(n9, n12, n14, 0, n6);
        vm.a(cc3, n7, n, -11);
        mk.a(n5, n10, (byte)-118, cc4, n2, cc2);
        tb.a(n4, -25073, n13);
        qm.a(n11, -115, n3, n8);
    }

    public static void a(byte by) {
        block0: {
            dh_c = null;
            dh_b = null;
            if (by == -68) break block0;
            dh.a(null, -53, 78, null, null, null, -74, -100, null, 108, -57, 96, -30, true, 2, 34, -16, -53, -123, 32);
        }
    }

    dh() {
    }

    static final jb a(Throwable throwable, String string) {
        jb jb2;
        if (throwable instanceof jb) {
            jb2 = (jb)throwable;
            jb2.jb_i = jb2.jb_i + ' ' + string;
        } else {
            jb2 = new jb(throwable, string);
        }
        return jb2;
    }

    static {
        dh_e = -1;
    }
}
