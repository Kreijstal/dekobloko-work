/*
 * Decompiled with CFR 0.152.
 */
final class uj {
    static String uj_g;
    static String[] uj_f;
    static int uj_a;
    static String uj_e;
    static String uj_b;
    static String uj_c;
    static ck[][] uj_d;

    static final void a(int n, int n2, int n3, int n4, int n5, int n6) {
        boolean bl = client.A;
        int n7 = n2 + (2 + (485 + n5) + 16);
        int n8 = -37 / ((-64 - n6) / 62);
        re.x.a(-6 + n7, 0, 3, -6 + ea.D.N, 3);
        int n9 = -5 + re.x.N;
        sk.sk_c.a(2 + (485 + n5) - -n2, 0, -n + n9, n, 5);
        wj.Mb.a(sk.sk_c.w_mb - (n5 + jb.jb_f.w_mb), 0, 0, n, n5);
        jb.jb_f.a(jb.jb_f.w_mb, 0, 0, n, n5 + wj.Mb.w_mb);
        dn.dn_l.a(6, 5, n2, 5, (n9 -= n - -2) - 5, 487 + n5 - -n2, 2);
        if (null != bc.E) {
            bc.E.b(dn.dn_l.N, dn.dn_l.w_mb, dn.dn_l.w_vb, dn.dn_l.Ib, -16555);
        }
        int n10 = -n7 + (-n5 + ea.D.w_mb);
        int n11 = n10 / 2;
        int n12 = n3 + (n11 + n5);
        int n13 = 0;
        int n14 = 0;
        while (~n14 > -7) {
            if (~n14 <= -6 || null != dh.dh_c[n14]) {
                int n15 = 3 - -((-6 + (ea.D.N - -2)) * n13 / (dh.dh_f - -1));
                n9 = 1 + ((-4 + ea.D.N) * ++n13 / (1 + dh.dh_f) - n15);
                if (n14 < 5) {
                    dh.dh_c[n14].a(n10, 0, n15, n9, n7);
                    ui.E[n14].a(-n5 + n11, 0, 0, n9, n5);
                    si.si_b[n14].a(n3, 0, n4, -n4 + (n9 - n4), n11);
                    le.D[n14].a(-n12 + (-n5 + n10), 0, n4, -n4 + (n9 - n4), n12);
                } else {
                    qb.qb_p.a(n10, 0, n15, n9, n7);
                }
            }
            ++n14;
        }
    }

    public static void a(byte by) {
        uj_b = null;
        uj_f = null;
        uj_c = null;
        if (by <= 99) {
            return;
        }
        uj_e = null;
        uj_d = null;
        uj_g = null;
    }

    static final synchronized byte[] a(int n, int n2) {
        if (n2 == 100 && rb.rb_h > 0) {
            byte[] byArray = of.of_f[--rb.rb_h];
            of.of_f[rb.rb_h] = null;
            return byArray;
        }
        if (~n2 == -5001 && la.la_a > 0) {
            byte[] byArray = vk.vk_c[--la.la_a];
            vk.vk_c[la.la_a] = null;
            return byArray;
        }
        if (n != 5) {
            return null;
        }
        if (n2 == 30000 && ~d.d_c < -1) {
            byte[] byArray = gk.yb[--d.d_c];
            gk.yb[d.d_c] = null;
            return byArray;
        }
        if (null != jg.jg_b) {
            for (int j = 0; ln.ln_d.length > j; ++j) {
                if (ln.ln_d[j] != n2 || ~wa.wa_d[j] >= -1) continue;
                int n3 = j;
                int n4 = wa.wa_d[n3] - 1;
                wa.wa_d[n3] = n4;
                byte[] byArray = jg.jg_b[j][n4];
                jg.jg_b[j][wa.wa_d[j]] = null;
                return byArray;
            }
        }
        return new byte[n2];
    }

    static {
        uj_f = new String[]{"Welcome to the Master Challenge!<br><br>The Master Challenge is not for the faint of heart. Games are short, and, unlike Stamina Mode, the Master Challenge gets very harsh very quickly. Get as many points as you can, while you can.", "The Master Challenge will test your skill in every different Deko Bloko strategy. You will need to use different strategies as the game progresses. Have you noticed the strategy box on the right? Keep checking it for each new theme."};
        uj_e = "Seriously offensive language";
        uj_b = "<%0> SHAPES";
        uj_c = "to return to the normal view.";
        uj_d = new ck[8][];
        uj_g = "Rated games are available to members only. To become a member and gain access to Rated games, extra game options and more, please visit the 'Account' section of the website.";
    }
}
