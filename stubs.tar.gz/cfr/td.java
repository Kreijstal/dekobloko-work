/*
 * Decompiled with CFR 0.152.
 */
final class td {
    private static vl td_a = new vl();

    private static final void c(vl vl2) {
        int n;
        byte by = vl2.I;
        int n2 = vl2.vl_p;
        int n3 = vl2.vl_b;
        int n4 = vl2.vl_o;
        int[] nArray = wb.Zb;
        int n5 = vl2.z;
        byte[] byArray = vl2.vl_w;
        int n6 = vl2.E;
        int n7 = n = vl2.vl_e;
        int n8 = vl2.vl_m + 1;
        block0: while (true) {
            byte by2;
            if (n2 > 0) {
                while (true) {
                    if (n == 0) {
                        int n9 = vl2.vl_f;
                        vl2.vl_f += n7 - n;
                        if (vl2.vl_f < n9) {
                            // empty if block
                        }
                        vl2.I = by;
                        vl2.vl_p = n2;
                        vl2.vl_b = n3;
                        vl2.vl_o = n4;
                        wb.Zb = nArray;
                        vl2.z = n5;
                        vl2.vl_w = byArray;
                        vl2.E = n6;
                        vl2.vl_e = n;
                        return;
                    }
                    if (n2 == 1) break;
                    byArray[n6] = by;
                    --n2;
                    ++n6;
                    --n;
                }
                if (n == 0) {
                    n2 = 1;
                    break;
                }
                byArray[n6] = by;
                ++n6;
                --n;
            }
            while (true) {
                if (n3 == n8) {
                    n2 = 0;
                    break block0;
                }
                by = (byte)n4;
                n5 = nArray[n5];
                by2 = (byte)n5;
                n5 >>= 8;
                ++n3;
                if (by2 != n4) {
                    n4 = by2;
                    if (n == 0) {
                        n2 = 1;
                        break block0;
                    }
                    byArray[n6] = by;
                    ++n6;
                    --n;
                    continue;
                }
                if (n3 != n8) break;
                if (n == 0) {
                    n2 = 1;
                    break block0;
                }
                byArray[n6] = by;
                ++n6;
                --n;
            }
            n2 = 2;
            n5 = nArray[n5];
            by2 = (byte)n5;
            n5 >>= 8;
            if (++n3 == n8) continue;
            if (by2 != n4) {
                n4 = by2;
                continue;
            }
            n2 = 3;
            n5 = nArray[n5];
            by2 = (byte)n5;
            n5 >>= 8;
            if (++n3 == n8) continue;
            if (by2 != n4) {
                n4 = by2;
                continue;
            }
            n5 = nArray[n5];
            by2 = (byte)n5;
            n5 >>= 8;
            ++n3;
            n2 = (by2 & 0xFF) + 4;
            n5 = nArray[n5];
            n4 = (byte)n5;
            n5 >>= 8;
            ++n3;
        }
        int n10 = vl2.vl_f;
        vl2.vl_f += n7 - n;
        if (vl2.vl_f < n10) {
            // empty if block
        }
        vl2.I = by;
        vl2.vl_p = n2;
        vl2.vl_b = n3;
        vl2.vl_o = n4;
        wb.Zb = nArray;
        vl2.z = n5;
        vl2.vl_w = byArray;
        vl2.E = n6;
        vl2.vl_e = n;
    }

    private static final void d(vl vl2) {
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        int n10 = 0;
        int n11 = 0;
        int n12 = 0;
        int n13 = 0;
        int n14 = 0;
        int n15 = 0;
        int n16 = 0;
        byte by = 0;
        byte by2 = 0;
        int n17 = 0;
        int[] nArray = null;
        int[] nArray2 = null;
        int[] nArray3 = null;
        vl2.vl_l = 1;
        if (wb.Zb == null) {
            wb.Zb = new int[vl2.vl_l * 100000];
        }
        boolean bl = true;
        while (bl) {
            int n18;
            int n19;
            int n20;
            byte by3 = td.a(vl2);
            if (by3 == 23) {
                return;
            }
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.a(vl2);
            by3 = td.e(vl2);
            if (by3 != 0) {
                // empty if block
            }
            vl2.H = 0;
            by3 = td.a(vl2);
            vl2.H = vl2.H << 8 | by3 & 0xFF;
            by3 = td.a(vl2);
            vl2.H = vl2.H << 8 | by3 & 0xFF;
            by3 = td.a(vl2);
            vl2.H = vl2.H << 8 | by3 & 0xFF;
            for (n = 0; n < 16; ++n) {
                by3 = td.e(vl2);
                vl2.y[n] = by3 == 1;
            }
            for (n = 0; n < 256; ++n) {
                vl2.vl_q[n] = false;
            }
            for (n = 0; n < 16; ++n) {
                if (!vl2.y[n]) continue;
                for (n2 = 0; n2 < 16; ++n2) {
                    by3 = td.e(vl2);
                    if (by3 != 1) continue;
                    vl2.vl_q[n * 16 + n2] = true;
                }
            }
            td.b(vl2);
            n4 = vl2.vl_n + 2;
            n5 = td.a(3, vl2);
            n6 = td.a(15, vl2);
            for (n = 0; n < n6; ++n) {
                n2 = 0;
                while ((by3 = td.e(vl2)) != 0) {
                    ++n2;
                }
                vl2.vl_a[n] = (byte)n2;
            }
            byte[] byArray = new byte[6];
            for (n20 = 0; n20 < n5; n20 = (int)((byte)(n20 + 1))) {
                byArray[n20] = (byte)n20;
            }
            for (n = 0; n < n6; ++n) {
                n19 = byArray[n20];
                for (n20 = vl2.vl_a[n]; n20 > 0; n20 = (int)((byte)(n20 - 1))) {
                    byArray[n20] = byArray[n20 - 1];
                }
                byArray[0] = (byte)n19;
                vl2.vl_g[n] = (byte)n19;
            }
            for (n3 = 0; n3 < n5; ++n3) {
                n14 = td.a(5, vl2);
                for (n = 0; n < n4; ++n) {
                    while ((by3 = td.e(vl2)) != 0) {
                        by3 = td.e(vl2);
                        if (by3 == 0) {
                            // empty if block
                        }
                        --n14;
                    }
                    vl2.x[n3][n] = (byte)n14;
                }
            }
            for (n3 = 0; n3 < n5; ++n3) {
                int n21 = 32;
                byte by4 = 0;
                for (n = 0; n < n4; ++n) {
                    if (vl2.x[n3][n] > by4) {
                        by4 = vl2.x[n3][n];
                    }
                    if (vl2.x[n3][n] >= n21) continue;
                    n21 = vl2.x[n3][n];
                }
                td.a(vl2.D[n3], vl2.vl_u[n3], vl2.vl_c[n3], vl2.x[n3], n21, by4, n4);
                vl2.vl_v[n3] = n21;
            }
            n7 = vl2.vl_n + 1;
            n8 = -1;
            n9 = 0;
            for (n = 0; n <= 255; ++n) {
                vl2.B[n] = 0;
            }
            n20 = 4095;
            for (n18 = 15; n18 >= 0; --n18) {
                for (n19 = 15; n19 >= 0; --n19) {
                    vl2.vl_h[n20] = (byte)(n18 * 16 + n19);
                    --n20;
                }
                vl2.vl_t[n18] = n20 + 1;
            }
            n11 = 0;
            if (n9 == 0) {
                n9 = 50;
                by2 = vl2.vl_g[++n8];
                n17 = vl2.vl_v[by2];
                nArray = vl2.D[by2];
                nArray3 = vl2.vl_c[by2];
                nArray2 = vl2.vl_u[by2];
            }
            --n9;
            n15 = n17;
            n16 = td.a(n15, vl2);
            while (n16 > nArray[n15]) {
                ++n15;
                by = td.e(vl2);
                n16 = n16 << 1 | by;
            }
            n10 = nArray3[n16 - nArray2[n15]];
            while (n10 != n7) {
                int n22;
                if (n10 == 0 || n10 == 1) {
                    n12 = -1;
                    n13 = 1;
                    do {
                        if (n10 == 0) {
                            n12 += 1 * n13;
                        } else if (n10 == 1) {
                            n12 += 2 * n13;
                        }
                        n13 *= 2;
                        if (n9 == 0) {
                            n9 = 50;
                            by2 = vl2.vl_g[++n8];
                            n17 = vl2.vl_v[by2];
                            nArray = vl2.D[by2];
                            nArray3 = vl2.vl_c[by2];
                            nArray2 = vl2.vl_u[by2];
                        }
                        --n9;
                        n15 = n17;
                        n16 = td.a(n15, vl2);
                        while (n16 > nArray[n15]) {
                            ++n15;
                            by = td.e(vl2);
                            n16 = n16 << 1 | by;
                        }
                    } while ((n10 = nArray3[n16 - nArray2[n15]]) == 0 || n10 == 1);
                    by3 = vl2.vl_d[vl2.vl_h[vl2.vl_t[0]] & 0xFF];
                    int n23 = by3 & 0xFF;
                    vl2.B[n23] = vl2.B[n23] + ++n12;
                    while (n12 > 0) {
                        wb.Zb[n11] = by3 & 0xFF;
                        ++n11;
                        --n12;
                    }
                    continue;
                }
                int n24 = n10 - 1;
                if (n24 < 16) {
                    n22 = vl2.vl_t[0];
                    by3 = vl2.vl_h[n22 + n24];
                    while (n24 > 3) {
                        int n25 = n22 + n24;
                        vl2.vl_h[n25] = vl2.vl_h[n25 - 1];
                        vl2.vl_h[n25 - 1] = vl2.vl_h[n25 - 2];
                        vl2.vl_h[n25 - 2] = vl2.vl_h[n25 - 3];
                        vl2.vl_h[n25 - 3] = vl2.vl_h[n25 - 4];
                        n24 -= 4;
                    }
                    while (n24 > 0) {
                        vl2.vl_h[n22 + n24] = vl2.vl_h[n22 + n24 - 1];
                        --n24;
                    }
                    vl2.vl_h[n22] = by3;
                } else {
                    int n26;
                    int n27 = n24 / 16;
                    int n28 = n24 % 16;
                    n22 = n26 = vl2.vl_t[n27] + n28;
                    by3 = vl2.vl_h[n26];
                    while (n26 > vl2.vl_t[n27]) {
                        vl2.vl_h[n26] = vl2.vl_h[n26 - 1];
                        --n26;
                    }
                    int n29 = n27;
                    vl2.vl_t[n29] = vl2.vl_t[n29] + 1;
                    while (n27 > 0) {
                        int n30 = n27;
                        vl2.vl_t[n30] = vl2.vl_t[n30] - 1;
                        vl2.vl_h[vl2.vl_t[n27]] = vl2.vl_h[vl2.vl_t[n27 - 1] + 16 - 1];
                        --n27;
                    }
                    vl2.vl_t[0] = vl2.vl_t[0] - 1;
                    vl2.vl_h[vl2.vl_t[0]] = by3;
                    if (vl2.vl_t[0] == 0) {
                        n20 = 4095;
                        for (n18 = 15; n18 >= 0; --n18) {
                            for (n19 = 15; n19 >= 0; --n19) {
                                vl2.vl_h[n20] = vl2.vl_h[vl2.vl_t[n18] + n19];
                                --n20;
                            }
                            vl2.vl_t[n18] = n20 + 1;
                        }
                    }
                }
                int n31 = vl2.vl_d[by3 & 0xFF] & 0xFF;
                vl2.B[n31] = vl2.B[n31] + 1;
                wb.Zb[n11] = vl2.vl_d[by3 & 0xFF] & 0xFF;
                ++n11;
                if (n9 == 0) {
                    n9 = 50;
                    by2 = vl2.vl_g[++n8];
                    n17 = vl2.vl_v[by2];
                    nArray = vl2.D[by2];
                    nArray3 = vl2.vl_c[by2];
                    nArray2 = vl2.vl_u[by2];
                }
                --n9;
                n15 = n17;
                n16 = td.a(n15, vl2);
                while (n16 > nArray[n15]) {
                    ++n15;
                    by = td.e(vl2);
                    n16 = n16 << 1 | by;
                }
                n10 = nArray3[n16 - nArray2[n15]];
            }
            vl2.vl_p = 0;
            vl2.I = 0;
            vl2.vl_s[0] = 0;
            for (n = 1; n <= 256; ++n) {
                vl2.vl_s[n] = vl2.B[n - 1];
            }
            for (n = 1; n <= 256; ++n) {
                int n32 = n;
                vl2.vl_s[n32] = vl2.vl_s[n32] + vl2.vl_s[n - 1];
            }
            for (n = 0; n < n11; ++n) {
                by3 = (byte)(wb.Zb[n] & 0xFF);
                int n33 = vl2.vl_s[by3 & 0xFF];
                wb.Zb[n33] = wb.Zb[n33] | n << 8;
                int n34 = by3 & 0xFF;
                vl2.vl_s[n34] = vl2.vl_s[n34] + 1;
            }
            vl2.z = wb.Zb[vl2.H] >> 8;
            vl2.vl_b = 0;
            vl2.z = wb.Zb[vl2.z];
            vl2.vl_o = (byte)(vl2.z & 0xFF);
            vl2.z >>= 8;
            ++vl2.vl_b;
            vl2.vl_m = n11;
            td.c(vl2);
            if (vl2.vl_b == vl2.vl_m + 1 && vl2.vl_p == 0) {
                bl = true;
                continue;
            }
            bl = false;
        }
    }

    private static final void a(int[] nArray, int[] nArray2, int[] nArray3, byte[] byArray, int n, int n2, int n3) {
        int n4;
        int n5 = 0;
        for (n4 = n; n4 <= n2; ++n4) {
            for (int i = 0; i < n3; ++i) {
                if (byArray[i] != n4) continue;
                nArray3[n5] = i;
                ++n5;
            }
        }
        for (n4 = 0; n4 < 23; ++n4) {
            nArray2[n4] = 0;
        }
        for (n4 = 0; n4 < n3; ++n4) {
            int n6 = byArray[n4] + 1;
            nArray2[n6] = nArray2[n6] + 1;
        }
        for (n4 = 1; n4 < 23; ++n4) {
            int n7 = n4;
            nArray2[n7] = nArray2[n7] + nArray2[n4 - 1];
        }
        for (n4 = 0; n4 < 23; ++n4) {
            nArray[n4] = 0;
        }
        int n8 = 0;
        for (n4 = n; n4 <= n2; ++n4) {
            nArray[n4] = (n8 += nArray2[n4 + 1] - nArray2[n4]) - 1;
            n8 <<= 1;
        }
        for (n4 = n + 1; n4 <= n2; ++n4) {
            nArray2[n4] = (nArray[n4 - 1] + 1 << 1) - nArray2[n4];
        }
    }

    private static final void b(vl vl2) {
        vl2.vl_n = 0;
        for (int i = 0; i < 256; ++i) {
            if (!vl2.vl_q[i]) continue;
            vl2.vl_d[vl2.vl_n] = (byte)i;
            ++vl2.vl_n;
        }
    }

    public static void a() {
        td_a = null;
    }

    private static final byte e(vl vl2) {
        return (byte)td.a(1, vl2);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static final int a(byte[] byArray, int n, byte[] byArray2, int n2, int n3) {
        vl vl2 = td_a;
        synchronized (vl2) {
            td.td_a.vl_j = byArray2;
            td.td_a.vl_r = n3;
            td.td_a.vl_w = byArray;
            td.td_a.E = 0;
            td.td_a.vl_e = n;
            td.td_a.F = 0;
            td.td_a.C = 0;
            td.td_a.vl_i = 0;
            td.td_a.vl_f = 0;
            td.d(td_a);
            td.td_a.vl_j = null;
            td.td_a.vl_w = null;
            return n -= td.td_a.vl_e;
        }
    }

    private static final byte a(vl vl2) {
        return (byte)td.a(8, vl2);
    }

    private static final int a(int n, vl vl2) {
        while (true) {
            if (vl2.F >= n) {
                int n2 = vl2.C >> vl2.F - n & (1 << n) - 1;
                vl2.F -= n;
                return n2;
            }
            vl2.C = vl2.C << 8 | vl2.vl_j[vl2.vl_r] & 0xFF;
            vl2.F += 8;
            ++vl2.vl_r;
            ++vl2.vl_i;
            if (vl2.vl_i != 0) continue;
        }
    }
}
