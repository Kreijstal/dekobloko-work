/*
 * Decompiled with CFR 0.152.
 */
import java.applet.Applet;

final class th {
    static Applet th_b;
    static String th_a;

    static final void a(ui ui2, int n) {
        wj.Ob.a(ui2, n, 0, -1);
        rc.rc_d = ui2;
    }

    public static void a(int n) {
        th_a = null;
        if (n <= 120) {
            th_b = null;
        }
        th_b = null;
    }

    static final void a(int n, int n2, boolean bl2, int n3, boolean bl3, boolean bl4, boolean bl5, int n4, int n5, int n6, int n7, byte by, int n8, boolean bl6) {
        sl.sl_g = null;
        ce.e(116);
        bl6 = lk.a(n5, -121, n2, n7, bl6, n6, n3);
        ph.a(bl4, n8, n4, bl5, bl6, bl2, bl3, -1, n, n7);
        a.a(n8, bl4, true);
        if (by <= 42) {
            th_a = null;
        }
        tf.b(n5, bl6, 0, n8);
    }

    static final void a(int n, boolean bl2) {
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n2 = uf2.wl_n;
        uf2.a(true, 2);
        uf2.a(false, kk.kk_l.length, kk.kk_l, 0);
        uf2.a(true, qa.x);
        uf2.a(bl2, jb.jb_c);
        uf2.a(false, v.v_a.length, v.v_a, 0);
        uf2.b(uf2.wl_n - n2, bl2);
    }

    static {
        th_a = "Settling Score: ";
    }
}
