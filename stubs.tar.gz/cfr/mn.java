/*
 * Decompiled with CFR 0.152.
 */
final class mn {
    static boolean mn_c;
    static String mn_a;
    static w mn_e;
    static int[] mn_b;
    static String[] mn_d;

    static final void a(int n, boolean bl, boolean bl2, boolean bl3, int n2) {
        block53: {
            boolean bl4 = client.A;
            if (n != 0) {
                mn.a(-82);
            }
            qf.a(tg.tg_e, n + 101);
            if (cd.cd_m != null) {
                w w2;
                int n3;
                ma.G.Hb = true;
                w w3 = fh.fh_d;
                fh.fh_d.N = 0;
                w3.w_mb = 0;
                w w4 = nn.nn_a;
                nn.nn_a.N = 0;
                w4.w_mb = 0;
                w w5 = tg.tg_i;
                tg.tg_i.N = 0;
                w5.w_mb = 0;
                if (ig.b(true)) {
                    int n4;
                    int n5;
                    int n6;
                    int n7;
                    int n8;
                    int n9;
                    fl.fl_b.Y = jf.jf_f.toUpperCase();
                    n3 = (2 + oh.oh_d.w_mb) / 2;
                    fh.fh_d.a(-2 + n3, 0, oh.oh_d.N - 40, 40, 0);
                    if (~cd.cd_m.ve_mc < ~cd.cd_m.ve_rc) {
                        fh.fh_d.Y = ea.ea_u.toUpperCase();
                        fh.fh_d.Hb = true;
                    } else {
                        fh.fh_d.Y = cb.cb_k.toUpperCase();
                        fh.fh_d.Hb = false;
                    }
                    fh.fh_d.w_lb = d.d_g.w_lb;
                    if (~cj.cj_a < -1) {
                        String string = ~cj.cj_a != -2 ? cm.a((byte)122, fl.fl_a, new String[]{Integer.toString(cj.cj_a)}) : ec.ec_c;
                        fh.fh_d.Y = fh.fh_d.Y + "<br>" + string;
                        if (-1 == ~(oe.G & 0x10) && !dn.dn_k) {
                            fh.fh_d.w_lb = d.d_g.S;
                        }
                    }
                    nn.nn_a.a(-n3 + oh.oh_d.w_mb, 0, -40 + oh.oh_d.N, 40, n3);
                    nn.nn_a.Y = mc.mc_c.toUpperCase();
                    nn.nn_a.Hb = bl && km.C == 0L;
                    w2 = nn.nn_a;
                    int n10 = 2;
                    if (null != bc.D) {
                        if (null == km.D) {
                            rd.rd_c = new boolean[j.j_b];
                            km.D = new byte[j.j_b];
                        }
                        for (n9 = 0; j.j_b > n9; ++n9) {
                            rd.rd_c[n9] = false;
                        }
                        for (n10 = 0; 2 > n10; ++n10) {
                            n9 = 0;
                            block2: for (n8 = 0; n8 < bc.D.length; ++n8) {
                                int[] nArray;
                                int[] nArray2 = nArray = bc.D[n8];
                                for (n7 = 0; nArray.length > n7; n7 += 2) {
                                    n6 = nArray[n7];
                                    n5 = nArray[1 + n7];
                                    if (n6 == -1) {
                                        int n11 = n4 = ~n10 != -1 ? cd.cd_m.ve_rc : cd.cd_m.ve_mc;
                                        if (n5 == n4) continue;
                                        continue block2;
                                    }
                                    if (n5 != (0xFF & cd.cd_m.ve_kc[n6])) continue block2;
                                }
                                n9 = 1;
                                n7 = -1;
                                n6 = 0;
                                while (~n6 > ~nArray.length) {
                                    n5 = nArray[n6];
                                    if (~n7 > ~n5) {
                                        n7 = n5;
                                    }
                                    n6 += 2;
                                }
                                rd.rd_c[n7] = true;
                            }
                            if (n9 != 0) break;
                        }
                        if (te.te_p >= 2 && bj.bj_d[12]) {
                            n10 = 2;
                        }
                    }
                    if (~n10 > -3) {
                        nn.nn_a.Hb = false;
                        if (nn.nn_a.Kb) {
                            String string;
                            String string2;
                            String string3 = null;
                            n8 = 0;
                            for (int k = 0; j.j_b > k; ++k) {
                                if (!rd.rd_c[k]) continue;
                                String string4 = "<col=A00000>" + pa.pa_db[k] + "</col>";
                                if (null == string3) {
                                    string3 = string4;
                                    continue;
                                }
                                n8 = 1;
                                string3 = string3 + ", " + string4;
                            }
                            if (n10 == 0) {
                                string2 = hh.hh_d;
                                string = n8 == 0 ? cm.a((byte)82, ci.ci_e, new String[]{string3}) : mf.S + string3;
                            } else {
                                string2 = bg.bg_e;
                                string = n8 != 0 ? jf.jf_a + string3 : cm.a((byte)119, fn.fn_f, new String[]{string3});
                            }
                            sl.sl_g = "<col=A00000>" + string2 + "<br>" + string;
                        }
                    } else if (null != cb.cb_e || mg.Ob != null || ik.ik_h != null || af.af_b != null) {
                        n9 = 0;
                        n8 = 0;
                        int n12 = 0;
                        n7 = 0;
                        n6 = 0;
                        n5 = 0;
                        while (n5 < j.j_b) {
                            int n13;
                            n4 = cd.cd_m.ve_kc[n5] & 0xFF;
                            if (cb.cb_e != null && cb.cb_e[n5] != null && cb.cb_e[n5][n4]) {
                                n9 = 1;
                            }
                            if (null != mg.Ob && null != mg.Ob[n5]) {
                                n13 = mg.Ob[n5][n4];
                                if (~n13 < ~n12) {
                                    n12 = n13;
                                }
                                if (n13 != 0 && !uc.uc_a) {
                                    n9 = 1;
                                }
                            }
                            if (ik.ik_h != null) {
                                if (ik.ik_h[n5] == null) {
                                    if (null != af.af_b && af.af_b[n5] != null) {
                                        n6 |= af.af_b[n5][n4];
                                    }
                                    ++n5;
                                    continue;
                                }
                                n13 = ik.ik_h[n5][n4];
                                if (n13 != 0 && !uc.uc_a) {
                                    n9 = 1;
                                }
                                if (n13 > n7) {
                                    n7 = n13;
                                }
                            }
                            if (null != af.af_b && af.af_b[n5] != null) {
                                n6 |= af.af_b[n5][n4];
                            }
                            ++n5;
                        }
                        n5 = 0;
                        vj vj2 = tb.tb_b.Ob.M;
                        tj tj2 = (tj)vj2.c((byte)83);
                        while (null != tj2) {
                            if (!tj2.g((byte)68)) {
                                if (n9 != 0 && !tj2.tj_ec) {
                                    n5 = 1;
                                    break;
                                }
                                if (tj2.Ub < n12) {
                                    n5 = 1;
                                    break;
                                }
                                if (~tj2.Xb > ~n7) {
                                    n5 = 1;
                                    break;
                                }
                                if ((n6 & ~tj2.Sb) > 0) {
                                    n5 = 1;
                                    break;
                                }
                                if (n8 != 0) {
                                    n5 = 1;
                                    break;
                                }
                            }
                            tj2 = (tj)vj2.d(true);
                        }
                        if (te.te_p >= 2 && bj.bj_d[12]) {
                            n5 = 0;
                        }
                        if (n5 != 0) {
                            nn.nn_a.Hb = false;
                            if (nn.nn_a.Kb) {
                                sl.sl_g = 0 != je.je_f.ak_h.Pb ? cm.a((byte)94, ii.ii_s, new String[]{eg.eg_b}) : ui.L;
                            }
                        }
                    }
                } else {
                    String string = cd.cd_m.Vb;
                    fl.fl_b.Y = cm.a((byte)101, hf.hf_a, new String[]{string}).toUpperCase();
                    tg.tg_i.a(oh.oh_d.w_mb, n ^ 0, oh.oh_d.N - 40, 40, 0);
                    tg.tg_i.Y = cm.a((byte)116, h.h_e, new String[]{string});
                    w2 = tg.tg_i;
                }
                if (km.C != 0L) {
                    n3 = (int)(km.C + -ik.a(4));
                    if ((n3 = (999 + n3) / 1000) < 1) {
                        n3 = 1;
                    }
                    w2.Y = cm.a((byte)119, cf.cf_b, new String[]{Integer.toString(n3)});
                }
                he.he_jb.Y = cm.a((byte)101, sb.sb_n, new String[]{Integer.toString(cd.cd_m.ve_rc), Integer.toString(cd.cd_m.ve_mc)});
            }
            ee.ee_i.a(false, bl2 && !bl3 && !dn.dn_k);
            oh.oh_d.a(false, bl2 && !bl3 && !dn.dn_k);
            mn_e.a(false, bl2 && !bl3 && dn.dn_k);
            je.je_f.ak_h.b(false);
            if (cd.cd_m == null) break block53;
            if (~ma.G.w_ob != -1) {
                md.a(n ^ 9, n2, cd.cd_m.e(-76));
            }
            if (-1 != ~nn.nn_a.w_ob) {
                gm.I = true;
            }
            if (-1 != ~fh.fh_d.w_ob) {
                dn.dn_k = true;
            }
            if (qc.qc_q.w_ob != 0) {
                dn.dn_k = false;
            }
            mc.a(cd.cd_m, false, n2, (byte)-126);
        }
    }

    static final void a(boolean bl, long l, int n) {
        uf uf2 = we.we_b;
        uf2.f(n, -4);
        ++uf2.wl_n;
        int n2 = uf2.wl_n;
        uf2.a(true, 7);
        uf2.a(l, (byte)0);
        uf2.b(-n2 + uf2.wl_n, bl);
    }

    public static void a(int n) {
        mn_e = null;
        if (n >= -113) {
            return;
        }
        mn_b = null;
        mn_d = null;
        mn_a = null;
    }

    static {
        mn_a = "Return to game";
        mn_d = new String[]{"Waiting for text", "Warte auf Text", "En attente du texte", "Aguardando textos", "Op tekst wachten", "Esperando a texto"};
        mn_b = new int[]{40, 30, 24, 19, 15, 12, 9, 6, 4, 2, 0};
    }
}
