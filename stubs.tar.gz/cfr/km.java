/*
 * Decompiled with CFR 0.152.
 */
class km
extends be {
    static String B = "ESC - cancel this line";
    static ni A;
    static long C;
    static en z;
    static String y;
    static byte[] D;

    static final boolean b(int n, int n2) {
        if (n2 != -8222) {
            return false;
        }
        return ~n <= -3;
    }

    km() {
    }

    public static void c(int n) {
        if (n != 710) {
            return;
        }
        D = null;
        y = null;
        B = null;
        A = null;
        z = null;
    }

    static final byte[] a(int n, CharSequence charSequence) {
        boolean bl = client.A;
        if (n != 6216) {
            D = null;
        }
        int n2 = charSequence.length();
        byte[] byArray = new byte[n2];
        int n3 = 0;
        while (~n3 > ~n2) {
            char c = charSequence.charAt(n3);
            byArray[n3] = '\u0000' < c && c < '\u0080' || c >= '\u00a0' && c <= '\u00ff' ? (byte)c : (c != '\u20ac' ? (c == '\u201a' ? (byte)-126 : (c != '\u0192' ? (c == '\u201e' ? (byte)-124 : (c != '\u2026' ? (c != '\u2020' ? ('\u2021' != c ? (c != '\u02c6' ? (c != '\u2030' ? (c == '\u0160' ? (byte)-118 : (c != '\u2039' ? (c == '\u0152' ? (byte)-116 : (c == '\u017d' ? (byte)-114 : (c == '\u2018' ? (byte)-111 : (c == '\u2019' ? (byte)-110 : (c == '\u201c' ? (byte)-109 : (c == '\u201d' ? (byte)-108 : (c != '\u2022' ? (c != '\u2013' ? ('\u2014' != c ? (c == '\u02dc' ? (byte)-104 : (c != '\u2122' ? ('\u0161' == c ? (byte)-102 : (c != '\u203a' ? ('\u0153' != c ? (c != '\u017e' ? (c == '\u0178' ? (byte)-97 : (byte)63) : (byte)-98) : (byte)-100) : (byte)-101)) : (byte)-103)) : (byte)-105) : (byte)-106) : (byte)-107))))))) : (byte)-117)) : (byte)-119) : (byte)-120) : (byte)-121) : (byte)-122) : (byte)-123)) : (byte)-125)) : (byte)-128);
            ++n3;
        }
        return byArray;
    }

    static {
        y = "Advertising websites";
    }
}
